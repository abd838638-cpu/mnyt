/*
 * Material You NewTab — Hisham Agent v2
 * Personal in-extension AI assistant (BYOK) with:
 *  - normal chat / deep-think / deep-search modes
 *  - OpenAI-compatible + Gemini providers (user-supplied API key)
 *  - streaming answers, copy/regenerate, instant local commands
 *  - extension control tools (theme, widgets, todos, shortcuts, search)
 * The key never leaves the browser except to the provider the user chose.
 */
(function () {
"use strict";

/* ============================== i18n ============================== */
function hLang() {
    try {
        const l = document.documentElement.lang || localStorage.getItem("selectedLanguage") || "en";
        return (l && l.indexOf("ar") === 0) || l === "ar_SA" ? "ar" : "en";
    } catch (_) { return "en"; }
}
const STR = {
en: {
    tileLabel: "Hisham Agent", tileSub: "AI Assistant",
    headTitle: "Hisham Agent", headSub: "Your assistant inside the extension",
    online: "Ready", offline: "Add API key to start",
    modeChat: "Chat", modeChatSub: "fast answers",
    modeThink: "Deep Think", modeThinkSub: "step-by-step",
    modeSearch: "Deep Search", modeSearchSub: "web research",
    needKey: "Add your API key to start chatting.",
    setupBtn: "Setup API key",
    welcomeTitle: "Hi, I'm Hisham Agent ✦",
    welcomeText: "I can answer questions, research the web deeply, and control this extension (theme, widgets, todos, shortcuts…). Add your own API key, then just ask.",
    chips: ["Change theme to violet", "Add todo: read 10 pages", "Hide the weather card", "Deep search: future of AI browsers"],
    inputPh: "Ask Hisham Agent anything…",
    sendTitle: "Send", stopTitle: "Stop",
    footNote: "Key is stored only in this browser • Deep Search uses DuckDuckGo + Wikipedia",
    setupTitle: "Connect your AI key",
    setupSub: "Bring your own API key. It stays in your browser (localStorage) and is only sent to the provider you pick.",
    provider: "Provider", endpoint: "API endpoint (Base URL)",
    apiKey: "API key", model: "Model name",
    save: "Save", test: "Test", close: "Close",
    keyPh: "sk-… / AIza…", modelPh: "e.g. gpt-4o-mini",
    fetchModels: "⟳ Fetch", fetchingModels: "Fetching models…",
    modelsFound: "{n} models found — pick one ↓",
    modelsFail: "Couldn't list models — type the name manually.",
    customModel: "✏️ Custom name…",
    getKey: "Get a key:",
    priv: "Privacy: the key is saved only in this browser. Requests go directly from your browser to the provider. Deep-search fetches public web summaries (DuckDuckGo / Wikipedia) to ground the answer.",
    saved: "Saved ✓", testing: "Testing…",
    testOk: "Connection works ✓", testFail: "Failed: ",
    needKeyFirst: "Please add your API key first (⚙ Setup).",
    stopped: "⏹ Stopped.",
    errNet: "Network error: ",
    errCors: "Can't reach the API endpoint (network/CORS blocked). Check the Base URL in ⚙ Setup, or pick a provider that allows browser calls.",
    errKey: "Invalid API key or model. Open ⚙ Setup and check the key / model name.",
    acted: "✓ Done: ",
    thinkTitle: "🧠 Deep thinking — tap to expand",
    stepsTitle: "🔍 Deep search progress",
    s1: "Generating search queries…", s2: "Searching the web…", s3: "Reading sources…", s4: "Writing the final answer…",
    sources: "Sources",
    settings: "API settings",
    newChat: "New chat",
    shortcutAdded: "Shortcut added",
    todoAdded: "Todo added",
    themeDone: "Theme updated",
    searchDone: "Searching for",
    toggleDone: "Updated",
    unknownTool: "Unsupported action",
    noAnswer: "(empty reply)",
    citations: "Based on web sources below.",
    localAnswer: "Local command executed.",
    openMenu: "Menu opened — change anything there too.",
    copy: "Copy", copied: "Copied ✓", regen: "↻ Regenerate",
    copyFail: "Copy failed",
    confirmClearTodos: "Delete ALL todos? This cannot be undone.",
    todosTitle: "📝 Your todos",
    noTodos: "No todos yet.",
    todoDone: "Completed",
    todoDeleted: "Deleted",
    todoNotFound: "No matching task found for",
    clearedTodos: "Cleared {n} tasks",
    clearNone: "There are no todos to clear.",
    modelPillTitle: "API settings — provider & model",
    yesText: "Yes", noText: "No",
},
ar: {
    tileLabel: "Hisham Agent", tileSub: "مساعد ذكي",
    headTitle: "Hisham Agent", headSub: "مساعدك داخل الإضافة",
    online: "جاهز", offline: "أضف مفتاح API للبدء",
    modeChat: "محادثة", modeChatSub: "إجابات سريعة",
    modeThink: "تفكير عميق", modeThinkSub: "خطوة بخطوة",
    modeSearch: "بحث عميق", modeSearchSub: "بحث ويب معمّق",
    needKey: "أضف مفتاح API الخاص بك لبدء المحادثة.",
    setupBtn: "إعداد المفتاح",
    welcomeTitle: "أهلاً، أنا Hisham Agent ✦",
    welcomeText: "أقدر أجاوب على أسئلتك، وأبحث في الويب بعمق، وأتحكم في الإضافة (الثيم، الودجات، المهام، الاختصارات…). أضف مفتاح API الخاص بك ثم اسألني أي شيء.",
    chips: ["غيّر الثيم إلى بنفسجي", "أضف مهمة: قراءة ١٠ صفحات", "أخفِ بطاقة الطقس", "بحث عميق: مستقبل متصفحات الذكاء الاصطناعي"],
    inputPh: "اسأل Hisham Agent أي شيء…",
    sendTitle: "إرسال", stopTitle: "إيقاف",
    footNote: "المفتاح يُحفظ في متصفحك فقط • البحث العميق يستخدم DuckDuckGo وويكيبيديا",
    setupTitle: "اربط مفتاح الذكاء الاصطناعي",
    setupSub: "استخدم مفتاح API الخاص بك. يُحفظ في متصفحك (localStorage) فقط ويُرسل للمزود الذي تختاره.",
    provider: "المزوّد", endpoint: "رابط الـ API (Base URL)",
    apiKey: "مفتاح API", model: "اسم الموديل",
    save: "حفظ", test: "اختبار", close: "إغلاق",
    keyPh: "sk-… / AIza…", modelPh: "مثال: gpt-4o-mini",
    fetchModels: "⟳ جلب", fetchingModels: "جارٍ جلب الموديلات…",
    modelsFound: "تم العثور على {n} موديل — اختر واحداً ↓",
    modelsFail: "تعذّر جلب القائمة — اكتب الاسم يدوياً.",
    customModel: "✏️ اسم مخصص…",
    getKey: "احصل على مفتاح:",
    priv: "الخصوصية: المفتاح يُحفظ في متصفحك فقط. الطلبات تذهب مباشرة من متصفحك إلى المزود. البحث العميق يجلب ملخصات ويب عامة (DuckDuckGo / ويكيبيديا) لدعم الإجابة.",
    saved: "تم الحفظ ✓", testing: "جارٍ الاختبار…",
    testOk: "الاتصال يعمل ✓", testFail: "فشل: ",
    needKeyFirst: "أضف مفتاح API أولاً (⚙ الإعدادات).",
    stopped: "⏹ تم الإيقاف.",
    errNet: "خطأ شبكة: ",
    errCors: "تعذّر الوصول إلى رابط الـ API (الحماية CORS أو الشبكة). تحقق من الرابط في ⚙ الإعدادات أو اختر مزوداً يدعم النداء من المتصفح.",
    errKey: "المفتاح أو اسم الموديل غير صحيح. افتح ⚙ الإعدادات وتحقق.",
    acted: "✓ تم: ",
    thinkTitle: "🧠 التفكير العميق — اضغط للعرض",
    stepsTitle: "🔍 تقدم البحث العميق",
    s1: "توليد استعلامات البحث…", s2: "البحث في الويب…", s3: "قراءة المصادر…", s4: "كتابة الإجابة النهائية…",
    sources: "المصادر",
    settings: "إعدادات API",
    newChat: "محادثة جديدة",
    shortcutAdded: "تمت إضافة الاختصار",
    todoAdded: "تمت إضافة المهمة",
    themeDone: "تم تحديث الثيم",
    searchDone: "جارٍ البحث عن",
    toggleDone: "تم التحديث",
    unknownTool: "إجراء غير مدعوم",
    noAnswer: "(رد فارغ)",
    citations: "بناءً على مصادر الويب أدناه.",
    localAnswer: "تم تنفيذ الأمر محلياً.",
    openMenu: "تم فتح القائمة — يمكنك التغيير من هناك أيضاً.",
    copy: "نسخ", copied: "تم النسخ ✓", regen: "↻ إعادة التوليد",
    copyFail: "فشل النسخ",
    confirmClearTodos: "حذف كل المهام؟ لا يمكن التراجع.",
    todosTitle: "📝 مهامك",
    noTodos: "لا توجد مهام بعد.",
    todoDone: "تم إنجاز",
    todoDeleted: "تم حذف",
    todoNotFound: "لا توجد مهمة مطابقة لـ",
    clearedTodos: "تم مسح {n} مهمة",
    clearNone: "لا توجد مهام لمسحها.",
    modelPillTitle: "إعدادات API — المزود والموديل",
    yesText: "نعم", noText: "لا",
}
};
function t(k) { const l = hLang(); return (STR[l] && STR[l][k] !== undefined) ? STR[l][k] : STR.en[k]; }

/* ============================== config ============================== */
const CFG_KEY = "mynt_hisham_cfg";
const HIST_KEY = "mynt_hisham_history";
const MODE_KEY = "mynt_hisham_mode";
const PRESETS = {
    openai:    { endpoint: "https://api.openai.com/v1", models: ["gpt-5-mini", "gpt-4o-mini", "gpt-4o", "gpt-4.1-mini"], defModel: "gpt-4o-mini",
                 links: [["OpenAI", "https://platform.openai.com/api-keys"]] },
    openrouter:{ endpoint: "https://openrouter.ai/api/v1", models: ["openai/gpt-4o-mini", "anthropic/claude-3.5-sonnet", "google/gemini-2.5-flash", "deepseek/deepseek-chat"], defModel: "openai/gpt-4o-mini",
                 links: [["OpenRouter", "https://openrouter.ai/keys"]] },
    deepseek:  { endpoint: "https://api.deepseek.com/v1", models: ["deepseek-chat", "deepseek-reasoner"], defModel: "deepseek-chat",
                 links: [["DeepSeek", "https://platform.deepseek.com/api_keys"]] },
    gemini:    { endpoint: "https://generativelanguage.googleapis.com/v1beta", models: ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-pro", "gemini-1.5-flash"], defModel: "gemini-2.5-flash",
                 links: [["Google AI Studio", "https://aistudio.google.com/app/apikey"]] },
    custom:    { endpoint: "", models: [], defModel: "",
                 links: [] },
};
function getCfg() {
    try {
        const raw = localStorage.getItem(CFG_KEY);
        if (raw) { const c = JSON.parse(raw); if (c && typeof c === "object") return c; }
    } catch (_) {}
    return { provider: "openai", endpoint: PRESETS.openai.endpoint, apiKey: "", model: PRESETS.openai.defModel };
}
function setCfg(c) { try { localStorage.setItem(CFG_KEY, JSON.stringify(c)); } catch (_) {} }
function hasKey() { const c = getCfg(); return !!(c.apiKey && c.apiKey.trim().length > 4 && c.model); }

/* List models the user's key can actually use.
   - OpenAI-compatible (OpenAI / DeepSeek / OpenRouter / custom): GET {base}/models
   - Gemini: GET v1beta/models?key=… (filtered to generateContent-capable) */
async function fetchModels(cfg, signal) {
    const provider = (cfg && cfg.provider) || "openai";
    if (provider === "gemini") {
        if (!cfg.apiKey || !cfg.apiKey.trim()) throw new Error("NOKEY");
        const url = "https://generativelanguage.googleapis.com/v1beta/models?key=" + encodeURIComponent(cfg.apiKey.trim()) + "&pageSize=100";
        const r = await fetch(url, { signal: signal });
        if (!r.ok) {
            const detail = await readApiError(r);
            if (r.status === 400 || r.status === 401 || r.status === 403 || r.status === 404) throw keyError(detail, r.status);
            throw new Error("HTTP " + r.status + (detail ? " " + detail : ""));
        }
        const j = await r.json();
        const arr = (j.models || []).filter(function (m) {
            return (m.supportedGenerationMethods || []).indexOf("generateContent") >= 0;
        });
        return arr.map(function (m) { return String(m.name || "").replace(/^models\//, ""); }).filter(Boolean).sort();
    }
    const base = (cfg.endpoint || (PRESETS[provider] && PRESETS[provider].endpoint) || PRESETS.openai.endpoint).replace(/\/+$/, "");
    if (!base) throw new Error("NOENDPOINT");
    const headers = {};
    if (cfg.apiKey && cfg.apiKey.trim()) headers["Authorization"] = "Bearer " + cfg.apiKey.trim();
    else if (provider !== "openrouter") throw new Error("NOKEY");
    const r = await fetch(base + "/models", { signal: signal, headers: headers });
    if (!r.ok) {
        const detail = await readApiError(r);
        if (r.status === 401 || r.status === 403) throw keyError(detail, r.status);
        throw new Error("HTTP " + r.status + (detail ? " " + detail : ""));
    }
    const j = await r.json();
    const arr = j.data || j.models || [];
    const ids = arr.map(function (m) { return m && (m.id || m.name); }).filter(Boolean);
    return ids.map(String).sort().slice(0, 300);
}

/* ============================== state ============================== */
let mode = "chat"; // chat | think | search
try {
    const sm = localStorage.getItem(MODE_KEY);
    if (sm === "chat" || sm === "think" || sm === "search") mode = sm;
} catch (_) {}
let history = [];  // {role, text, think?, sources?, acted?, time}
let busy = false;
let aborter = null;
try {
    const h = JSON.parse(localStorage.getItem(HIST_KEY) || "[]");
    if (Array.isArray(h)) history = h.filter(function (m) { return m && (m.role === "user" || m.role === "assistant") && typeof m.text === "string"; }).slice(-60);
} catch (_) {}
function saveHist() { try { localStorage.setItem(HIST_KEY, JSON.stringify(history.slice(-60))); } catch (_) {} }

/* ============================== helpers ============================== */
function $(id) { return document.getElementById(id); }
function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function now() { try { return new Date().toLocaleTimeString(hLang() === "ar" ? "ar" : "en", { hour: "2-digit", minute: "2-digit" }); } catch (_) { return ""; } }
function isArabic(s) { return /[\u0600-\u06FF]/.test(s || ""); }
function norm(s) { return String(s || "").toLowerCase().replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").trim(); }
function validWebUrl(u) {
    try {
        const p = new URL(u);
        if (p.protocol !== "http:" && p.protocol !== "https:") return false;
        const h = p.hostname || "";
        if (h === "localhost") return true;
        if (/^\d+\.\d+\.\d+\.\d+$/.test(h)) return true; // LAN IPs allowed
        if (!/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$/i.test(h)) return false;
        if (h.indexOf(".") < 0) return false;
        const tld = h.split(".").pop();
        if (!/^[a-z]{2,}$/i.test(tld)) return false;
        return true;
    } catch (_) { return false; }
}

/* mini markdown: code blocks, inline code, bold, lists, links */
function md(src) {
    let s = esc(src);
    const blocks = [];
    s = s.replace(/```(\w*)\n?([\s\S]*?)```/g, function (_, lang, code) {
        blocks.push('<pre><code>' + code.replace(/^\n+|\n+$/g, "") + '</code></pre>');
        return "%%BLOCK" + (blocks.length - 1) + "%%";
    });
    s = s.replace(/`([^`\n]+)`/g, "<code>$1</code>");
    s = s.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
    s = s.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
    s = s.split(/\n/).map(function (line) {
        if (/^%%BLOCK\d+%%$/.test(line.trim())) return line.trim();
        if (/^\s*[-*•]\s+/.test(line)) return "<ul><li>" + line.replace(/^\s*[-*•]\s+/, "") + "</li></ul>";
        if (/^\s*\d+[.)]\s+/.test(line)) return "<ul><li>" + line.replace(/^\s*\d+[.)]\s+/, "") + "</li></ul>";
        if (/^#{1,4}\s+/.test(line)) return "<p><b>" + line.replace(/^#{1,4}\s+/, "") + "</b></p>";
        if (line.trim() === "") return "";
        return "<p>" + line + "</p>";
    }).join("");
    s = s.replace(/<\/ul><ul>/g, "");
    s = s.replace(/%%BLOCK(\d+)%%/g, function (_, i) { return blocks[+i] || ""; });
    return s;
}
/* preview-safe markdown for streaming (auto-close dangling fence) */
function mdPreview(src) {
    let fences = 0;
    try { fences = (src.match(/```/g) || []).length; } catch (_) {}
    return md(fences % 2 === 1 ? src + "\n```" : src);
}
function friendlyErr(e) {
    if (e && e.name === "AbortError") return t("stopped");
    if (e && e.message === "KEY") {
        let m = t("errKey");
        if (e.status) m += " (HTTP " + e.status + ")";
        if (e.detail) m += "\n\n📋 " + e.detail;
        const hh = hintForApiError(e.detail);
        if (hh) m += "\n" + hh;
        return m;
    }
    const m = String((e && e.message) || e || "");
    if (/Failed to fetch|NetworkError|Load failed|CORS/i.test(m)) return t("errCors");
    return t("errNet") + m.slice(0, 220);
}
/* read the provider's real error message (OpenAI + Gemini share {error:{message}}) */
async function readApiError(res) {
    try {
        const tx = await res.text();
        try {
            const j = JSON.parse(tx);
            const em = (j.error && (j.error.message || j.error.status)) || j.message || "";
            if (em) return String(em).slice(0, 300);
            return tx.slice(0, 200);
        } catch (_) { return tx.slice(0, 200); }
    } catch (_) { return ""; }
}
function keyError(detail, status) {
    const e = new Error("KEY");
    e.detail = String(detail || "").slice(0, 300);
    e.status = status || 0;
    try { console.warn("[HishamAgent] API error", status, e.detail); } catch (_) {}
    return e;
}
/* map common provider errors to an actionable hint (Arabic/English) */
function hintForApiError(detail) {
    const d = String(detail || "");
    const L = hLang();
    const map = [
        [/API key not valid|invalid.+api.?key|API_KEY_INVALID|Incorrect API key/i,
            { en: "💡 Tip: copy the FULL key from AI Studio (no extra spaces).",
              ar: "💡 تلميح: انسخ المفتاح كاملاً من AI Studio بدون مسافات زائدة." }],
        [/is not found|model.+not.+found|INVALID_ARGUMENT|not a valid model/i,
            { en: "💡 Tip: press ⟳ Fetch in ⚙ Setup and pick a model from the list.",
              ar: "💡 تلميح: اضغط زر ⟳ جلب في ⚙ الإعدادات واختر موديلاً من القائمة." }],
        [/has not been used|is disabled|SERVICE_DISABLED|enable.+api/i,
            { en: "💡 Tip: enable the Generative Language API for your Google project.",
              ar: "💡 تلميح: فعّل Generative Language API في مشروع جوجل الخاص بك." }],
        [/quota|exceeded|rate.?limit|RESOURCE_EXHAUSTED|limit:?\s*0/i,
            { en: "💡 Tip: quota / rate limit reached — wait a little or check your plan.",
              ar: "💡 تلميح: وصلت لحد الاستخدام — انتظر قليلاً أو راجع خطتك." }],
        [/billing|BILLING/i,
            { en: "💡 Tip: this looks like a billing issue on the provider side.",
              ar: "💡 تلميح: يبدو أن هناك مشكلة فوترة لدى المزود." }],
        [/permission|PERMISSION_DENIED|restrictions|API key.+http|referer/i,
            { en: "💡 Tip: the key is restricted (API / website / IP restrictions) — allow this use or make a new unrestricted key.",
              ar: "💡 تلميح: المفتاح مقيّد (قيود API أو مواقع أو IP) — اسمح بهذا الاستخدام أو أنشئ مفتاحاً جديداً بدون قيود." }],
    ];
    for (let i = 0; i < map.length; i++) {
        if (map[i][0].test(d)) return L === "ar" ? map[i][1].ar : map[i][1].en;
    }
    return "";
}

/* ============================== todos store (matches todo-list.js) ============================== */
function readTodoStore() {
    let o = {};
    try { o = JSON.parse(localStorage.getItem("todoList") || "{}") || {}; } catch (_) { o = {}; }
    if (!o || typeof o !== "object" || Array.isArray(o)) o = {};
    const out = [];
    Object.keys(o).forEach(function (id) {
        const x = o[id];
        if (x && typeof x.title === "string" && x.title.trim()) {
            out.push({ id: id, title: x.title.trim(), done: x.status === "completed", pinned: !!x.pinned });
        }
    });
    return out;
}
function formatTodos() {
    const all = readTodoStore();
    if (!all.length) return t("todosTitle") + "\n" + t("noTodos");
    return t("todosTitle") + "\n" + all.map(function (x, i) {
        return (x.done ? "✓ " : "• ") + x.title;
    }).join("\n");
}
function findTodoRow(text) {
    // returns {id, li} for first row whose title contains `text`
    const needle = norm(text);
    if (!needle) return null;
    const lis = document.querySelectorAll("#todoullist li[data-id]");
    for (let i = 0; i < lis.length; i++) {
        const span = lis[i].querySelector('span[role="checkbox"]');
        const title = span ? span.textContent : lis[i].textContent;
        if (norm(title).indexOf(needle) >= 0) return { id: lis[i].dataset.id, li: lis[i], span: span };
    }
    // fallback to storage ids
    const all = readTodoStore();
    for (let i = 0; i < all.length; i++) {
        if (norm(all[i].title).indexOf(needle) >= 0) return { id: all[i].id, li: null, span: null };
    }
    return null;
}

/* ============================== extension tools ============================== */
function setCheckbox(id, want, invert) {
    const el = document.getElementById(id);
    if (!el) return false;
    // want = visible? for inverted (hide-*) checkboxes checked means hidden
    const desired = invert ? !want : !!want;
    if (!!el.checked !== desired) { el.click(); }
    return true;
}
const COLOR_NAMES = {
    blue: "#4285f4", teal: "#00bfa5", indigo: "#3f51b5", sky: "#0ea5e9",
    amber: "#f59e0b", orange: "#ff7043", red: "#ef4444", coral: "#ff6f61",
    pink: "#ec407a", magenta: "#d946ef", purple: "#8b5cf6", violet: "#8b5cf6",
    olive: "#808000", yellow: "#facc15", green: "#22c55e", forest: "#166534",
    cyan: "#06b6d4", mint: "#6ee7b7", gold: "#d4af37", rose: "#f43f5e",
    lavender: "#b57edc", lime: "#a3e635", sage: "#9caf88", slate: "#64748b",
    brown: "#795548", silver: "#c0c0c0",
    // arabic aliases
    "أزرق": "#4285f4", "ازرق": "#4285f4", "سماوي": "#0ea5e9",
    "بنفسجي": "#8b5cf6", "موف": "#8b5cf6", "وردي": "#ec407a",
    "أحمر": "#ef4444", "احمر": "#ef4444", "أخضر": "#22c55e", "اخضر": "#22c55e",
    "أصفر": "#facc15", "اصفر": "#facc15", "برتقالي": "#ff7043",
    "أسود": "#1f2937", "اسود": "#1f2937", "أبيض": "#f8fafc", "ابيض": "#f8fafc",
    "ذهبي": "#d4af37", "فضي": "#c0c0c0", "بني": "#795548", "رمادي": "#64748b",
    "فيروزي": "#00bfa5", "نعناعي": "#6ee7b7", "كحلي": "#3f51b5", "نيلي": "#3f51b5",
};
function resolveColor(c) {
    if (!c) return null;
    c = String(c).trim();
    if (/^#[0-9a-fA-F]{3,8}$/.test(c)) return c;
    const low = c.toLowerCase();
    if (COLOR_NAMES[low]) return COLOR_NAMES[low];
    if (COLOR_NAMES[c]) return COLOR_NAMES[c];
    return null;
}
const Agent = {
    snapshot: function () {
        const g = function (id) { const e = document.getElementById(id); return e ? !!e.checked : null; };
        const todos = readTodoStore();
        return {
            lang: hLang(),
            clockHidden: g("hideClock"), digital: g("digitalCheckbox"),
            greeting: g("greetingcheckbox"), customText: g("userTextCheckbox"),
            weatherHidden: g("hideWeatherCheckbox"), weatherCardHidden: g("hideWeatherCard"),
            quotes: g("motivationalQuotesCheckbox"), suggestions: g("searchsuggestionscheckbox"),
            shortcuts: g("shortcutsCheckbox"), bookmarks: g("bookmarksCheckbox"),
            aiTools: g("aiToolsCheckbox"), googleApps: g("googleAppsCheckbox"),
            todoPanel: g("todoListCheckbox"),
            todos: todos.slice(0, 12).map(function (x) { return (x.done ? "[done] " : "[pending] ") + x.title; }),
            todoCount: todos.length,
            todoPending: todos.filter(function (x) { return !x.done; }).length,
            themeMode: (function () { try { return localStorage.getItem("themeMode") || localStorage.getItem("darkMode") || "unknown"; } catch (e) { return "unknown"; } })(),
        };
    },
    setTheme: function (color) {
        const hex = resolveColor(color);
        if (!hex && color) {
            // try preset plate by value
            try {
                const plate = document.querySelector('.colorPlate[value="' + String(color).toLowerCase() + '"]');
                if (plate) { plate.click(); return t("themeDone") + " (" + color + ")"; }
            } catch (_) {}
            return "Unknown color: " + color;
        }
        const val = (hex || "#8b5cf6").toLowerCase();
        try {
            const plate = document.querySelector('.colorPlate[value="' + val + '"]');
            if (plate) { plate.click(); return t("themeDone") + " (" + val + ")"; }
        } catch (_) {}
        try {
            if (typeof applyCustomTheme === "function") { applyCustomTheme(val); return t("themeDone") + " (" + val + ")"; }
            if (typeof applySelectedTheme === "function") { applySelectedTheme(val); return t("themeDone") + " (" + val + ")"; }
        } catch (e) { return "Theme error: " + e.message; }
        try {
            document.documentElement.style.setProperty("--accent", val);
            localStorage.setItem("selectedTheme", val);
            return t("themeDone") + " (" + val + ")";
        } catch (e) { return "Theme error: " + e.message; }
    },
    setThemeMode: function (m) {
        m = String(m || "").toLowerCase();
        let target = m.indexOf("dark") >= 0 || m.indexOf("داكن") >= 0 || m.indexOf("ليلي") >= 0 ? "dark"
            : m.indexOf("light") >= 0 || m.indexOf("فاتح") >= 0 || m.indexOf("نهاري") >= 0 ? "light" : "system";
        try {
            if (typeof window.setThemeMode === "function") { window.setThemeMode(target); return t("toggleDone") + ": " + target; }
        } catch (_) {}
        try {
            localStorage.setItem("themeMode", target);
            location.reload();
            return t("toggleDone") + ": " + target;
        } catch (e) { return "Mode error: " + e.message; }
    },
    toggleWidget: function (w, visible) {
        w = String(w || "").toLowerCase();
        const map = {
            clock: ["hideClock", true], digital: ["digitalCheckbox", false],
            greeting: ["greetingcheckbox", false], customtext: ["userTextCheckbox", false], text: ["userTextCheckbox", false],
            weather: ["hideWeatherCheckbox", true], weathercard: ["hideWeatherCard", true], card: ["hideWeatherCard", true],
            quotes: ["motivationalQuotesCheckbox", false], suggestions: ["searchsuggestionscheckbox", false],
            shortcuts: ["shortcutsCheckbox", false], bookmarks: ["bookmarksCheckbox", false],
            aitools: ["aiToolsCheckbox", false], googleapps: ["googleAppsCheckbox", false], apps: ["googleAppsCheckbox", false],
            todo: ["todoListCheckbox", false], todos: ["todoListCheckbox", false],
            mic: ["micIconCheckbox", false], searchengines: ["shortcut_switchcheckbox", false],
            // arabic
            "الساعة": ["hideClock", true], "الطقس": ["hideWeatherCheckbox", true],
            "بطاقة الطقس": ["hideWeatherCard", true], "البطاقة": ["hideWeatherCard", true],
            "الاقتباسات": ["motivationalQuotesCheckbox", false], "الاختصارات": ["shortcutsCheckbox", false],
            "الإشارات": ["bookmarksCheckbox", false], "المهام": ["todoListCheckbox", false],
            "قائمة المهام": ["todoListCheckbox", false],
        };
        const key = w.replace(/[\s_-]+/g, "");
        const hit = map[key] || map[w];
        if (!hit) return t("unknownTool") + ": " + w;
        if (!setCheckbox(hit[0], !!visible, hit[1])) return t("unknownTool") + ": " + w;
        return t("toggleDone") + " (" + w + ")";
    },
    addTodo: function (text) {
        text = String(text || "").trim().slice(0, 280);
        if (!text) return "Empty todo";
        try {
            const input = $("todoInput"), btn = $("todoAdd");
            if (input && btn) {
                input.value = text;
                // FIX: #todoAdd starts disabled — must fire `input` so the
                // extension enables the button before .click() does anything.
                input.dispatchEvent(new Event("input", { bubbles: true }));
                btn.click();
                if (input.value === "") return t("todoAdded") + ": " + text;
            }
        } catch (_) {}
        // fallback: same object shape todo-list.js uses ({id:{title,status,pinned}})
        try {
            let o = {};
            try { o = JSON.parse(localStorage.getItem("todoList") || "{}") || {}; } catch (e) { o = {}; }
            if (!o || typeof o !== "object" || Array.isArray(o)) o = {};
            o["hisham-" + Date.now()] = { title: text, status: "pending", pinned: false };
            localStorage.setItem("todoList", JSON.stringify(o));
        } catch (_) {}
        return t("todoAdded") + ": " + text;
    },
    completeTodo: function (text) {
        text = String(text || "").trim();
        if (!text) return "Empty todo";
        const row = findTodoRow(text);
        if (!row) return t("todoNotFound") + " \"" + text + "\"";
        try {
            if (row.span) {
                const done = row.li && row.li.classList.contains("checked");
                if (!done) row.span.click();
                return t("todoDone") + ": " + text;
            }
            // storage-only fallback
            const o = JSON.parse(localStorage.getItem("todoList") || "{}") || {};
            if (o[row.id]) { o[row.id].status = "completed"; localStorage.setItem("todoList", JSON.stringify(o)); }
            return t("todoDone") + ": " + text;
        } catch (e) { return "Error: " + e.message; }
    },
    deleteTodo: function (text) {
        text = String(text || "").trim();
        if (!text) return "Empty todo";
        const row = findTodoRow(text);
        if (!row) return t("todoNotFound") + " \"" + text + "\"";
        try {
            if (row.li) {
                const btn = row.li.querySelector(".todoremovebtn");
                if (btn) { btn.click(); return t("todoDeleted") + ": " + text; }
            }
            const o = JSON.parse(localStorage.getItem("todoList") || "{}") || {};
            if (o[row.id]) { delete o[row.id]; localStorage.setItem("todoList", JSON.stringify(o)); }
            return t("todoDeleted") + ": " + text;
        } catch (e) { return "Error: " + e.message; }
    },
    clearTodos: async function () {
        const all = readTodoStore();
        if (!all.length) return t("clearNone");
        try {
            if (typeof window.confirmPrompt === "function") {
                const ok = await window.confirmPrompt(t("confirmClearTodos"), t("yesText"), t("noText"));
                if (!ok) return t("stopped");
            }
        } catch (_) {}
        let n = 0;
        try {
            const list = $("todoullist");
            if (list) {
                let guard = 0, btn;
                while ((btn = list.querySelector(".todoremovebtn")) && guard++ < 300) {
                    try { btn.click(); n++; } catch (_) { break; }
                }
            }
        } catch (_) {}
        return t("clearedTodos").replace("{n}", String(n || all.length));
    },
    webSearch: function (q) {
        q = String(q || "").trim();
        if (!q) return "Empty query";
        const go = function () { try { closeDrawer(); } catch (_) {} };
        // BEST: the extension's own search (respects user's engine + chrome.search)
        try {
            if (typeof performSearch === "function") { go(); performSearch(q); return t("searchDone") + ": " + q; }
        } catch (_) {}
        try {
            const input = $("searchQ");
            const btn = (typeof enterBTN !== "undefined" && enterBTN) ? enterBTN : document.getElementById("enterBtn");
            if (input && btn) {
                input.value = q;
                input.dispatchEvent(new Event("input", { bubbles: true }));
                go(); btn.click();
                return t("searchDone") + ": " + q;
            }
        } catch (_) {}
        go();
        window.open("https://www.google.com/search?q=" + encodeURIComponent(q), "_blank");
        return t("searchDone") + ": " + q;
    },
    addShortcut: function (name, url) {
        name = String(name || "").trim() || url;
        url = String(url || "").trim();
        if (!url) return "Missing URL";
        let u = url;
        if (!/^https?:\/\//i.test(u)) u = "https://" + u;
        if (!validWebUrl(u)) return "Invalid URL: " + url;
        try {
            const n = parseInt(localStorage.getItem("shortcutAmount") || "0", 10) || 0;
            localStorage.setItem("shortcutName" + n, name);
            localStorage.setItem("shortcutURL" + n, u);
            localStorage.setItem("shortcutAmount", String(n + 1));
            return t("shortcutAdded") + ": " + name + " (" + u + ") — " + (hLang() === "ar" ? "أعد تحميل الصفحة لرؤيته" : "reload the page to see it");
        } catch (e) { return "Shortcut error: " + e.message; }
    },
    openMenu: function () {
        try { const b = $("menuButton"); if (b) b.click(); } catch (_) {}
        return t("openMenu");
    }
};
window.MYNTHishamAgent = Agent;

/* local command fallback (works even if the model ignores the action format) */
function localCommands(text) {
    const out = [];
    let m;
    // clear all todos
    if (/(امسح|احذف|امسحلي|clear|delete|remove)\s+(كل|جميع|all)\s+(المهام|مهامي|todos|tasks)/i.test(text)) out.push({ tool: "clearTodos" });
    // complete todo
    m = text.match(/(?:أكمل مهمة|اكمل مهمة|أنجز مهمة|انجز مهمة|عل[ ّ]م.*منجزة|complete\s+todo|mark\s+.*done|finish\s+task)\s*[:：]?\s*(.+)/i);
    if (m && m[1] && m[1].trim().length > 1) out.push({ tool: "completeTodo", text: m[1].split(/[.\n]/)[0].trim() });
    // delete one todo (not "all")
    m = text.match(/(?:احذف مهمة|احذف المهمة|امسح مهمة|delete\s+todo|remove\s+task)\s*[:：]?\s*(.+)/i);
    if (m && m[1] && m[1].trim().length > 1 && !/^(كل|جميع|all)/i.test(m[1].trim())) out.push({ tool: "deleteTodo", text: m[1].split(/[.\n]/)[0].trim() });
    // add todo: "أضف مهمة: X" / "add todo: X" / "ضيف مهمة X"
    m = text.match(/(?:أضف مهمة|ضيف مهمة|اضف مهمة|أضيفي مهمة|add\s+(?:a\s+)?todo|add\s+task)\s*[:：]?\s*(.+)/i);
    if (m && m[1]) { const todo = m[1].split(/[.\n]/)[0].trim(); if (todo.length > 1) out.push({ tool: "addTodo", text: todo }); }
    // theme: "غير الثيم إلى X" / "change theme to X" / "اللون X"
    m = text.match(/(?:غير|غيّر|بدل|ضع|حط|change|set)\s+(?:الثيم|السمة|اللون|theme|color)\s+(?:إلى|الى|لـ|ل|to)?\s*([#\w\u0600-\u06FF]+)/);
    if (m && m[1]) { const c = resolveColor(m[1]); if (c) out.push({ tool: "setTheme", color: c }); }
    else {
        m = text.match(/(?:theme|color)\s+([a-zA-Z#]+)/i);
        if (m && resolveColor(m[1])) out.push({ tool: "setTheme", color: resolveColor(m[1]) });
    }
    // dark/light
    if (/(الوضع الداكن|الوضع الليلي|dark mode|dark theme)/i.test(text) && /(فعّل|شغّل|ضع|enable|switch to|turn on)/i.test(text)) out.push({ tool: "setThemeMode", mode: "dark" });
    else if (/(الوضع الفاتح|الوضع النهاري|light mode|light theme)/i.test(text) && /(فعّل|شغّل|ضع|enable|switch to|turn on)/i.test(text)) out.push({ tool: "setThemeMode", mode: "light" });
    // hide/show widgets
    const vis = /(أظهر|اظهر|أعرض|show|enable|turn on)/i.test(text) ? true : /(أخف|اخف|إخف|hide|disable|turn off)/i.test(text) ? false : null;
    if (vis !== null) {
        const pairs = [["الطقس", "weather"], ["البطاقة", "weathercard"], ["بطاقة الطقس", "weathercard"],
            ["الساعة", "clock"], ["الاقتباسات", "quotes"], ["الاختصارات", "shortcuts"],
            ["المهام", "todo"], ["الإشارات", "bookmarks"], ["weather", "weather"], ["clock", "clock"],
            ["quotes", "quotes"], ["shortcuts", "shortcuts"], ["todo", "todo"], ["bookmarks", "bookmarks"]];
        pairs.forEach(function (p) {
            if (p[1] === "weather" && /بطاق|card/i.test(text)) return; // "بطاقة الطقس" means card only
            if (text.indexOf(p[0]) >= 0 || text.toLowerCase().indexOf(p[0]) >= 0) out.push({ tool: "toggleWidget", widget: p[1], visible: vis });
        });
    }
    // search: "ابحث عن X"
    m = text.match(/(?:ابحث عن|دور على|search for|google)\s+(.+)/i);
    if (m && m[1] && m[1].trim().length > 1 && !/^(theme|todo|task)/i.test(m[1])) {
        // only treat as web-search action when user explicitly wants a web search, not a question
        if (/^(ابحث عن|search)/i.test(text.trim())) out.push({ tool: "webSearch", query: m[1].trim().slice(0, 120) });
    }
    return out;
}
/* pure local intents answered instantly without an LLM round-trip */
function isPureIntent(text, kind) {
    const s = text.trim();
    if (kind === "nav") return /^(ابحث عن|دور على|search for|google)\s+.+/i.test(s);
    if (kind === "todos") return /^(اعرض|أعرض|اظهر|أظهر|وريني|عرض|list|show|display|get|what are)[\s\S]{0,30}(مهام|مهامي|todos|tasks)|^(مهامي|my todos|todos|tasks)\s*\??$/i.test(s);
    if (kind === "menu") return /^(افتح|open)\s+(القائمة|الاعدادات|الإعدادات|menu|settings)/i.test(s);
    return false;
}

/* ============================== LLM calls ============================== */
function sysPrompt(extra) {
    const snap = Agent.snapshot();
    const lang = hLang();
    let dt = "";
    try {
        const d = new Date();
        dt = d.toLocaleDateString(lang === "ar" ? "ar" : "en", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) + " " + d.toLocaleTimeString(lang === "ar" ? "ar" : "en", { hour: "2-digit", minute: "2-digit" });
    } catch (_) {}
    const base = lang === "ar"
        ? "أنت Hisham Agent، مساعد ذكي يعيش داخل إضافة New Tab. اليوم: " + dt + ". أجب بالعربية (فصحى بسيطة) إلا إذا سأل المستخدم بلغة أخرى. كن مفيداً ومباشراً: فقرات قصيرة وقوائم عند الحاجة، بدون مقدمات طويلة.\n"
        : "You are Hisham Agent, a smart assistant living inside a New Tab extension. Today: " + dt + ". Reply in the user's language, be helpful and direct: short paragraphs and lists when needed, no long intros.\n";
    const tools = "You can control the extension. When the user asks to change something, append at the VERY END a fenced block:\n```agent-actions\n[{\"tool\":\"setTheme\",\"color\":\"violet\"}, ...]\n```\nAvailable tools (JSON):\n" +
        '- {"tool":"setTheme","color":"<name|hex>"} colors: blue teal indigo sky amber orange red coral pink magenta purple violet green cyan mint gold rose lavender lime yellow forest sage slate brown silver or #hex\n' +
        '- {"tool":"setThemeMode","mode":"dark|light|system"}\n' +
        '- {"tool":"toggleWidget","widget":"clock|weather|weathercard|quotes|shortcuts|bookmarks|todo|suggestions|digital|greeting","visible":true|false}\n' +
        '- {"tool":"addTodo","text":"..."}\n' +
        '- {"tool":"completeTodo","text":"<part of the task title>"}\n' +
        '- {"tool":"deleteTodo","text":"<part of the task title>"}\n' +
        '- {"tool":"clearTodos"} (only when the user explicitly asks to delete ALL)\n' +
        '- {"tool":"webSearch","query":"..."}\n' +
        '- {"tool":"addShortcut","name":"...","url":"..."}\n' +
        '- {"tool":"openMenu"}\n' +
        "Current extension state: " + JSON.stringify(snap) + "\n" +
        "Rules: only include actions the user actually requested. Keep the visible reply clean (no JSON visible). If you executed a change, confirm it briefly in the reply.";
    return base + tools + (extra || "");
}
function toGeminiContents(msgs) {
    return msgs.map(function (m) {
        return { role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.text }] };
    });
}
function extractToken(d, provider, model) {
    if (provider === "gemini") {
        try { return ((d.candidates || [])[0].content.parts || []).map(function (p) { return p.text || ""; }).join(""); }
        catch (_) { return ""; }
    }
    try {
        const delta = ((d.choices || [])[0] || {}).delta || {};
        if (String(model || "").indexOf("reasoner") >= 0 && delta.reasoning_content && !delta.content) {
            return { think: delta.reasoning_content };
        }
        return delta.content || "";
    } catch (_) { return ""; }
}
/* non-streaming call (queries, tests, fallbacks) */
async function callLLM(opt) {
    const cfg = getCfg();
    const provider = cfg.provider || "openai";
    const signal = aborter ? aborter.signal : null;
    if (provider === "gemini") {
        const url = "https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(cfg.model) + ":generateContent?key=" + encodeURIComponent(cfg.apiKey.trim());
        const res = await fetch(url, {
            method: "POST", signal: signal,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                system_instruction: { parts: [{ text: opt.system }] },
                contents: toGeminiContents(opt.messages),
                generationConfig: { temperature: opt.temperature != null ? opt.temperature : 0.7, maxOutputTokens: opt.maxTokens || 1500 }
            })
        });
        if (!res.ok) {
            const detail = await readApiError(res);
            if (res.status === 400 || res.status === 401 || res.status === 403 || res.status === 404) throw keyError(detail, res.status);
            const e = new Error("HTTP " + res.status + (detail ? " " + detail : ""));
            e.status = res.status; e.detail = detail;
            throw e;
        }
        const j = await res.json();
        const parts = j && j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts;
        return (parts || []).map(function (p) { return p.text || ""; }).join("");
    } else {
        const base = (cfg.endpoint || (PRESETS[provider] && PRESETS[provider].endpoint) || PRESETS.openai.endpoint).replace(/\/+$/, "");
        const url = base + "/chat/completions";
        const headers = { "Content-Type": "application/json", "Authorization": "Bearer " + cfg.apiKey.trim() };
        if (provider === "openrouter") { headers["HTTP-Referer"] = location.href; headers["X-Title"] = "MYNT Hisham Agent"; }
        const body = {
            model: cfg.model,
            messages: [{ role: "system", content: opt.system }].concat(opt.messages.map(function (m) { return { role: m.role, content: m.text }; })),
            temperature: opt.temperature != null ? opt.temperature : 0.7,
            max_tokens: opt.maxTokens || 1500
        };
        const res = await fetch(url, { method: "POST", signal: signal, headers: headers, body: JSON.stringify(body) });
        if (!res.ok) {
            const detail = await readApiError(res);
            if (res.status === 401 || res.status === 403 || res.status === 404) throw keyError(detail, res.status);
            const e = new Error("HTTP " + res.status + (detail ? " " + detail : ""));
            e.status = res.status; e.detail = detail;
            throw e;
        }
        const j = await res.json();
        return (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || "";
    }
}
/* streaming call for final answers — onUpdate(accText, accThink); falls back to callLLM */
async function streamLLM(opt, onUpdate) {
    const cfg = getCfg();
    const provider = cfg.provider || "openai";
    const signal = aborter ? aborter.signal : null;
    let url, headers, body;
    if (provider === "gemini") {
        url = "https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(cfg.model) + ":streamGenerateContent?alt=sse&key=" + encodeURIComponent(cfg.apiKey.trim());
        headers = { "Content-Type": "application/json" };
        body = {
            system_instruction: { parts: [{ text: opt.system }] },
            contents: toGeminiContents(opt.messages),
            generationConfig: { temperature: opt.temperature != null ? opt.temperature : 0.7, maxOutputTokens: opt.maxTokens || 1500 }
        };
    } else {
        const base = (cfg.endpoint || (PRESETS[provider] && PRESETS[provider].endpoint) || PRESETS.openai.endpoint).replace(/\/+$/, "");
        url = base + "/chat/completions";
        headers = { "Content-Type": "application/json", "Authorization": "Bearer " + cfg.apiKey.trim() };
        if (provider === "openrouter") { headers["HTTP-Referer"] = location.href; headers["X-Title"] = "MYNT Hisham Agent"; }
        body = {
            model: cfg.model, stream: true,
            messages: [{ role: "system", content: opt.system }].concat(opt.messages.map(function (m) { return { role: m.role, content: m.text }; })),
            temperature: opt.temperature != null ? opt.temperature : 0.7,
            max_tokens: opt.maxTokens || 1500
        };
    }
    let res;
    try {
        res = await fetch(url, { method: "POST", signal: signal, headers: headers, body: JSON.stringify(body) });
    } catch (e) { throw e; }
    if (!res.ok) {
        const detail = await readApiError(res);
        if (res.status === 400 || res.status === 401 || res.status === 403 || res.status === 404) throw keyError(detail, res.status);
        const e = new Error("HTTP " + res.status + (detail ? " " + detail : ""));
        e.status = res.status; e.detail = detail;
        throw e;
    }
    if (!res.body || typeof res.body.getReader !== "function") {
        // provider doesn't support SSE — graceful fallback to one-shot call
        const full = await callLLM(opt);
        onUpdate(full, "");
        return { text: full, think: "" };
    }
    const reader = res.body.getReader();
    const dec = (typeof TextDecoder !== "undefined") ? new TextDecoder() : null;
    let buf = "", acc = "", accThink = "";
    const handleBlock = function (block) {
        const lines = block.split("\n");
        for (let i = 0; i < lines.length; i++) {
            let line = lines[i].trim();
            if (line.indexOf("data:") === 0) line = line.slice(5).trim();
            else if (line === "" || line[0] === ":") continue;
            else continue;
            if (line === "[DONE]") return "done";
            try {
                const d = JSON.parse(line);
                const tok = extractToken(d, provider, cfg.model);
                if (tok && typeof tok === "object" && tok.think) { accThink += tok.think; }
                else if (tok) { acc += tok; }
                onUpdate(acc, accThink);
            } catch (_) {}
        }
        return null;
    };
    for (;;) {
        const chunk = await reader.read();
        if (chunk.done) break;
        const piece = dec ? dec.decode(chunk.value, { stream: true }) : "";
        buf += piece;
        const blocks = buf.split("\n\n");
        buf = blocks.pop();
        for (let b = 0; b < blocks.length; b++) {
            if (handleBlock(blocks[b]) === "done") { try { reader.cancel(); } catch (_) {} return { text: acc, think: accThink }; }
        }
    }
    if (buf.trim()) handleBlock(buf);
    return { text: acc, think: accThink };
}
function splitThink(text) {
    let think = "";
    let m = text.match(/<think>([\s\S]*?)<\/think>/i);
    if (m) { think = m[1].trim(); text = text.replace(m[0], "").trim(); }
    else {
        m = text.match(/```think([\s\S]*?)```/i);
        if (m) { think = m[1].trim(); text = text.replace(m[0], "").trim(); }
    }
    return { think: think, text: text };
}
function tryParseActionArray(s) {
    try {
        const a = JSON.parse(String(s).trim());
        if (Array.isArray(a) && a.length && a.every(function (x) { return x && typeof x.tool === "string"; })) return a;
    } catch (_) {}
    return null;
}
function splitActions(text) {
    let actions = [];
    let m = text.match(/```agent-actions\s*([\s\S]*?)```/i);
    if (m) {
        actions = tryParseActionArray(m[1]) || [];
        text = text.replace(m[0], "").trim();
    }
    if (!actions.length) {
        // fallback: ```json fence holding a tool array
        const re = /```json\s*([\s\S]*?)```/gi;
        let jm;
        while ((jm = re.exec(text)) !== null) {
            const a = tryParseActionArray(jm[1]);
            if (a) { actions = a; text = text.replace(jm[0], "").trim(); break; }
        }
    }
    return { actions: actions, text: text };
}
async function runActions(actions) {
    const done = [];
    const list = actions || [];
    for (let i = 0; i < list.length; i++) {
        const a = list[i] || {};
        try {
            let r = "";
            if (a.tool === "setTheme") r = Agent.setTheme(a.color);
            else if (a.tool === "setThemeMode") r = Agent.setThemeMode(a.mode);
            else if (a.tool === "toggleWidget") r = Agent.toggleWidget(a.widget, a.visible);
            else if (a.tool === "addTodo") r = Agent.addTodo(a.text);
            else if (a.tool === "completeTodo") r = Agent.completeTodo(a.text);
            else if (a.tool === "deleteTodo") r = Agent.deleteTodo(a.text);
            else if (a.tool === "clearTodos") r = await Agent.clearTodos();
            else if (a.tool === "webSearch") r = Agent.webSearch(a.query);
            else if (a.tool === "addShortcut") r = Agent.addShortcut(a.name, a.url);
            else if (a.tool === "openMenu") r = Agent.openMenu();
            else r = t("unknownTool") + ": " + (a.tool || "?");
            done.push(r);
        } catch (e) { done.push("Error: " + e.message); }
    }
    return done;
}

/* ============================== deep search ============================== */
async function ddgSearch(q) {
    try {
        const u = "https://api.duckduckgo.com/?q=" + encodeURIComponent(q) + "&format=json&no_html=1&skip_disambig=1";
        const r = await fetch(u, { signal: aborter ? aborter.signal : undefined });
        if (!r.ok) return [];
        const j = await r.json();
        const out = [];
        if (j.AbstractText) out.push({ title: j.Heading || q, snippet: j.AbstractText, url: j.AbstractURL || "" });
        (j.RelatedTopics || []).slice(0, 6).forEach(function (x) {
            if (x.Text) out.push({ title: (x.Text || "").slice(0, 90), snippet: x.Text, url: x.FirstURL || "" });
            else if (x.Topics) x.Topics.slice(0, 3).forEach(function (y) { if (y.Text) out.push({ title: y.Text.slice(0, 90), snippet: y.Text, url: y.FirstURL || "" }); });
        });
        (j.Results || []).slice(0, 4).forEach(function (x) { if (x.Text) out.push({ title: x.Text.slice(0, 90), snippet: x.Text, url: x.FirstURL || "" }); });
        return out;
    } catch (_) { return []; }
}
async function wikiSearch(q, lang) {
    try {
        const host = lang === "ar" ? "ar.wikipedia.org" : "en.wikipedia.org";
        const u = "https://" + host + "/w/api.php?action=opensearch&search=" + encodeURIComponent(q) + "&limit=5&namespace=0&format=json&origin=*";
        const r = await fetch(u, { signal: aborter ? aborter.signal : undefined });
        if (!r.ok) return [];
        const j = await r.json();
        const titles = j[1] || [], descs = j[2] || [], urls = j[3] || [];
        return titles.map(function (ti, i) { return { title: ti, snippet: descs[i] || ti, url: urls[i] || "", wiki: true, wikiLang: lang }; });
    } catch (_) { return []; }
}
/* fetch real article intros so answers are grounded in content, not just titles */
async function wikiExtract(title, lang) {
    try {
        const u = "https://" + lang + ".wikipedia.org/w/api.php?action=query&prop=extracts&exintro&explaintext&exsentences=5&titles=" + encodeURIComponent(title) + "&format=json&origin=*";
        const r = await fetch(u, { signal: aborter ? aborter.signal : undefined });
        if (!r.ok) return "";
        const j = await r.json();
        const pages = (j.query && j.query.pages) || {};
        const k = Object.keys(pages)[0];
        const ex = (k && pages[k] && pages[k].extract) || "";
        return String(ex).slice(0, 800);
    } catch (_) { return ""; }
}
function dedupSources(arr) {
    const seen = {}, out = [];
    arr.forEach(function (s) {
        const k = (s.url || s.title).toLowerCase();
        if (!k || seen[k]) return;
        seen[k] = 1;
        out.push(s);
        if (out.length >= 14) return;
    });
    return out.slice(0, 14);
}

/* ============================== UI ============================== */
let els = {};
const MODE_META = {
    chat:   { icon: "💬", en: ["modeChat", "modeChatSub"] },
    think:  { icon: "🧠", en: ["modeThink", "modeThinkSub"] },
    search: { icon: "🔍", en: ["modeSearch", "modeSearchSub"] },
};
function buildDrawer() {
    if ($("hishamOverlay")) return;
    const overlay = document.createElement("div");
    overlay.id = "hishamOverlay"; overlay.className = "hisham-overlay";
    const drawer = document.createElement("aside");
    drawer.id = "hishamDrawer"; drawer.className = "hisham-drawer hidden-drawer";
    drawer.setAttribute("role", "dialog"); drawer.setAttribute("aria-label", "Hisham Agent");
    const modeBtn = function (m) {
        return '<button class="hisham-mode' + (mode === m ? " active" : "") + '" data-mode="' + m + '" role="tab">' + MODE_META[m].icon + " " + esc(t(MODE_META[m].en[0])) + "<small>" + esc(t(MODE_META[m].en[1])) + "</small></button>";
    };
    drawer.innerHTML =
        '<div class="hisham-head">' +
            '<div class="hisham-avatar"><svg viewBox="0 0 24 24" fill="none"><path fill="#fff" d="M12 2l2.4 5.2 5.6.6-4.1 3.9 1.1 5.5L12 14.4 7 17.2l1.1-5.5L4 7.8l5.6-.6L12 2z"/><circle cx="12" cy="12" r="10.2" stroke="#fff" stroke-width="1.4" opacity=".7"/></svg></div>' +
            '<div class="hisham-titles"><strong id="hishamHeadTitle">' + esc(t("headTitle")) + '</strong>' +
            '<small id="hishamHeadSub">' + esc(t("headSub")) + '</small>' +
            '<span class="hisham-status"><span class="hisham-dot" id="hishamDot"></span><span id="hishamStatus">' + esc(hasKey() ? t("online") : t("offline")) + '</span></span></div>' +
            '<button class="hisham-icon-btn" id="hishamNewBtn" title="' + esc(t("newChat")) + '">＋</button>' +
            '<button class="hisham-icon-btn" id="hishamSetupBtn" title="' + esc(t("settings")) + '">⚙</button>' +
            '<button class="hisham-icon-btn" id="hishamCloseBtn" title="' + esc(t("close")) + '">✕</button>' +
        '</div>' +
        '<div class="hisham-modes" role="tablist">' + modeBtn("chat") + modeBtn("think") + modeBtn("search") + '</div>' +
        '<div class="hisham-model-row"><button class="hisham-model-pill" id="hishamModelPill" title="' + esc(t("modelPillTitle")) + '"></button></div>' +
        '<div class="hisham-setup-banner" id="hishamSetupBanner" style="display:none">🔑 <span id="hishamNeedKey">' + esc(t("needKey")) + '</span><button id="hishamSetupBtn2">' + esc(t("setupBtn")) + '</button></div>' +
        '<div class="hisham-body" id="hishamBody" aria-live="polite"></div>' +
        '<div class="hisham-foot">' +
            '<div class="hisham-quick" id="hishamQuick"></div>' +
            '<div class="hisham-input-row">' +
                '<textarea class="hisham-input" id="hishamInput" rows="1" placeholder="' + esc(t("inputPh")) + '"></textarea>' +
                '<button class="hisham-stop" id="hishamStop" style="display:none" title="' + esc(t("stopTitle")) + '">■</button>' +
                '<button class="hisham-send" id="hishamSend" title="' + esc(t("sendTitle")) + '"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/></svg></button>' +
            '</div>' +
            '<div class="hisham-foot-note">' + esc(t("footNote")) + '</div>' +
        '</div>' +
        '<div class="hisham-toast" id="hishamToast"></div>';
    document.body.appendChild(overlay);
    document.body.appendChild(drawer);
    buildPanel();
    els = {
        overlay: overlay, drawer: drawer, body: $("hishamBody"), input: $("hishamInput"),
        send: $("hishamSend"), stop: $("hishamStop"), dot: $("hishamDot"), status: $("hishamStatus"),
        banner: $("hishamSetupBanner"), quick: $("hishamQuick"), toast: $("hishamToast"),
        pill: $("hishamModelPill"),
    };
    overlay.addEventListener("click", closeDrawer);
    $("hishamCloseBtn").addEventListener("click", closeDrawer);
    $("hishamSetupBtn").addEventListener("click", openPanel);
    $("hishamSetupBtn2").addEventListener("click", openPanel);
    $("hishamModelPill").addEventListener("click", openPanel);
    $("hishamNewBtn").addEventListener("click", function () {
        history = []; saveHist(); renderAll(); toast(t("newChat") + " ✓");
    });
    drawer.querySelectorAll(".hisham-mode").forEach(function (b) {
        b.addEventListener("click", function () { setMode(b.dataset.mode); });
    });
    els.send.addEventListener("click", send);
    els.input.addEventListener("keydown", function (e) {
        if ((e.key === "Enter" && !e.shiftKey) || (e.key === "Enter" && (e.ctrlKey || e.metaKey))) { e.preventDefault(); send(); }
    });
    els.input.addEventListener("input", function () {
        els.input.style.height = "auto";
        els.input.style.height = Math.min(120, els.input.scrollHeight) + "px";
    });
    els.stop.addEventListener("click", function () {
        try { if (aborter) aborter.abort(); } catch (_) {}
    });
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && !drawer.classList.contains("hidden-drawer")) closeDrawer();
    });
    renderAll();
    refreshStatus();
}
function buildPanel() {
    if ($("hishamPanel")) return;
    const cfg = getCfg();
    const p = document.createElement("div");
    p.id = "hishamPanel"; p.className = "hisham-panel hidden-panel";
    p.setAttribute("role", "dialog"); p.setAttribute("aria-label", "Hisham Agent setup");
    const provBtns = Object.keys(PRESETS).map(function (k) {
        return '<button class="hisham-prov' + (cfg.provider === k ? " active" : "") + '" data-prov="' + k + '">' + k[0].toUpperCase() + k.slice(1) + '</button>';
    }).join("");
    const links = Object.keys(PRESETS).map(function (k) {
        return (PRESETS[k].links || []).map(function (l) { return '<a href="' + l[1] + '" target="_blank" rel="noopener">' + l[0] + '</a>'; }).join(" · ");
    }).join(" · ");
    p.innerHTML =
        '<div class="hisham-panel-head"><button class="hisham-panel-close" id="hishamPanelClose">✕</button>' +
        '<h3>✦ ' + esc(t("setupTitle")) + '</h3><p>' + esc(t("setupSub")) + '</p></div>' +
        '<div class="hisham-panel-body">' +
            '<div class="hisham-field"><label>' + esc(t("provider")) + '</label><div class="hisham-prov-grid" id="hishamProvs">' + provBtns + '</div></div>' +
            '<div class="hisham-field"><label>' + esc(t("endpoint")) + '</label><input id="hishamEndpoint" dir="ltr" value="' + esc(cfg.endpoint || "") + '" placeholder="https://api.openai.com/v1"></div>' +
            '<div class="hisham-field"><label>' + esc(t("apiKey")) + '</label><input id="hishamKey" dir="ltr" type="password" autocomplete="off" value="' + esc(cfg.apiKey || "") + '" placeholder="' + esc(t("keyPh")) + '"></div>' +
            '<div class="hisham-field"><label>' + esc(t("model")) + '</label><div class="hisham-model-row2"><select id="hishamModelSel" dir="ltr"></select><button type="button" class="hisham-mini-fetch" id="hishamFetchBtn" title="' + esc(t("fetchModels")) + '">' + esc(t("fetchModels")) + '</button></div><input id="hishamModelCustom" class="hisham-model-custom" dir="ltr" autocomplete="off" placeholder="' + esc(t("modelPh")) + '" style="display:none"><div class="hint hisham-model-status" id="hishamModelHint"></div><div class="hint">' + esc(t("getKey")) + ' ' + links + '</div></div>' +
            '<div class="hisham-test-result" id="hishamTestRes"></div>' +
            '<div class="hisham-row-btns"><button class="hisham-btn ghost" id="hishamTestBtn">' + esc(t("test")) + '</button><button class="hisham-btn primary" id="hishamSaveBtn">' + esc(t("save")) + '</button></div>' +
            '<div class="hisham-priv">🔒 ' + esc(t("priv")) + '</div>' +
        '</div>';
    document.body.appendChild(p);
    /* ---- visible model dropdown (fetched list + custom name) ---- */
    const CUSTOM_VAL = "__custom__";
    const modelSel = function () { return $("hishamModelSel"); };
    const modelCustom = function () { return $("hishamModelCustom"); };
    const getModelValue = function () {
        const s = modelSel(), c = modelCustom();
        if (s && s.value === CUSTOM_VAL) return (c && c.value.trim()) || "";
        return (s && s.value && s.value.trim()) || "";
    };
    const syncCustomInput = function () {
        const s = modelSel(), c = modelCustom();
        if (!s || !c) return;
        c.style.display = (s.value === CUSTOM_VAL) ? "block" : "none";
    };
    const fillModelSelect = function (list, current) {
        const s = modelSel(), c = modelCustom();
        if (!s) return;
        const opts = (list || []).map(String);
        const cur = (current != null ? current : getModelValue()).trim();
        s.innerHTML = opts.map(function (m) { return '<option value="' + esc(m) + '">' + esc(m) + '</option>'; }).join("") +
            '<option value="' + CUSTOM_VAL + '">' + esc(t("customModel")) + '</option>';
        if (cur && opts.indexOf(cur) >= 0) { s.value = cur; if (c) c.value = ""; }
        else if (cur) { s.value = CUSTOM_VAL; if (c) c.value = cur; }
        else { s.value = opts[0] || CUSTOM_VAL; }
        syncCustomInput();
    };
    fillModelSelect((PRESETS[cfg.provider] && PRESETS[cfg.provider].models) || [], cfg.model || "");
    if (modelSel()) modelSel().addEventListener("change", syncCustomInput);
    /* ---- automatic model list: fetched from the user's own API ---- */
    let modelFetchToken = 0;
    const setModelHint = function (msg, isErr) {
        const hh = $("hishamModelHint");
        if (hh) { hh.textContent = msg || ""; hh.classList.toggle("hisham-hint-err", !!isErr); }
    };
    const refreshModels = async function (auto) {
        const active = p.querySelector(".hisham-prov.active");
        const prov = (active && active.dataset && active.dataset.prov) || cfg.provider || "openai";
        const saved = getCfg();
        const ep = $("hishamEndpoint"), ky = $("hishamKey");
        const cc = {
            provider: prov,
            endpoint: (ep && ep.value.trim()) || saved.endpoint || ((PRESETS[prov] && PRESETS[prov].endpoint) || ""),
            apiKey: (ky && ky.value.trim()) || saved.apiKey || "",
            model: getModelValue() || saved.model || ""
        };
        if (!cc.apiKey && prov !== "openrouter") {
            if (!auto) setModelHint(t("needKeyFirst"), true);
            return;
        }
        const my = ++modelFetchToken;
        const fb = $("hishamFetchBtn");
        if (fb) fb.disabled = true;
        if (!auto) setModelHint(t("fetchingModels"), false);
        try {
            const list = await fetchModels(cc, null);
            if (my !== modelFetchToken) return;
            if (!list.length) throw new Error("EMPTY");
            fillModelSelect(list, cc.model);
            // auto-pick a sensible default when nothing chosen yet
            if (!getModelValue()) {
                const def = PRESETS[prov] && PRESETS[prov].defModel;
                fillModelSelect(list, (def && list.indexOf(def) >= 0) ? def : list[0]);
            }
            setModelHint(t("modelsFound").replace("{n}", String(list.length)), false);
        } catch (e) {
            if (my !== modelFetchToken) return;
            if (e && e.message === "KEY") setModelHint(t("errKey") + (e.detail ? " — " + String(e.detail).slice(0, 120) : ""), true);
            else setModelHint(t("modelsFail"), true);
        } finally {
            if (my === modelFetchToken && fb) fb.disabled = false;
        }
    };
    p.querySelectorAll(".hisham-prov").forEach(function (b) {
        b.addEventListener("click", function () {
            p.querySelectorAll(".hisham-prov").forEach(function (x) { x.classList.toggle("active", x === b); });
            const pr = b.dataset.prov;
            const ep = $("hishamEndpoint");
            if (PRESETS[pr] && PRESETS[pr].endpoint && (!ep.value || Object.keys(PRESETS).some(function (k) { return PRESETS[k].endpoint === ep.value; }))) ep.value = PRESETS[pr].endpoint;
            fillModelSelect((PRESETS[pr] && PRESETS[pr].models) || [], getModelValue() || (PRESETS[pr] && PRESETS[pr].defModel) || "");
            refreshModels(true); // auto-list models for the new provider
        });
    });
    $("hishamFetchBtn").addEventListener("click", function () { refreshModels(false); });
    let keyTimer = null;
    const scheduleModelRefresh = function () {
        clearTimeout(keyTimer);
        keyTimer = setTimeout(function () {
            const ky = $("hishamKey");
            if (ky && ky.value.trim().length > 4) refreshModels(true);
        }, 900);
    };
    $("hishamKey").addEventListener("input", scheduleModelRefresh);
    $("hishamEndpoint").addEventListener("change", function () {
        const ky = $("hishamKey");
        if (ky && ky.value.trim().length > 4) refreshModels(true);
    });
    // auto-fetch on open when a key is already saved
    if (cfg.apiKey && cfg.apiKey.trim().length > 4) refreshModels(true);
    $("hishamPanelClose").addEventListener("click", closePanel);
    $("hishamSaveBtn").addEventListener("click", function () {
        const active = p.querySelector(".hisham-prov.active");
        const prov = (active && active.dataset && active.dataset.prov) || cfg.provider || "openai";
        const nc = { provider: prov, endpoint: $("hishamEndpoint").value.trim(), apiKey: $("hishamKey").value.trim(), model: getModelValue() };
        if (!nc.endpoint) nc.endpoint = (PRESETS[prov] && PRESETS[prov].endpoint) || "";
        setCfg(nc);
        refreshStatus(); renderAll();
        const r = $("hishamTestRes"); r.className = "hisham-test-result ok"; r.textContent = t("saved");
        setTimeout(closePanel, 650);
    });
    $("hishamTestBtn").addEventListener("click", async function () {
        const r = $("hishamTestRes");
        r.className = "hisham-test-result ok"; r.textContent = t("testing");
        const active = p.querySelector(".hisham-prov.active");
        const prov = (active && active.dataset && active.dataset.prov) || "openai";
        const bak = getCfg();
        const tmp = { provider: prov, endpoint: $("hishamEndpoint").value.trim() || ((PRESETS[prov] && PRESETS[prov].endpoint) || ""), apiKey: $("hishamKey").value.trim(), model: getModelValue() };
        setCfg(tmp);
        aborter = new AbortController();
        const to = setTimeout(function () { try { aborter.abort(); } catch (_) {} }, 25000);
        try {
            const ans = await callLLM({ system: "Reply with exactly: OK", messages: [{ role: "user", text: hLang() === "ar" ? "قل OK فقط" : "Say OK only" }], maxTokens: 20 });
            clearTimeout(to);
            r.className = "hisham-test-result ok"; r.textContent = t("testOk") + (ans ? " (" + ans.trim().slice(0, 60) + ")" : "");
        } catch (e) {
            clearTimeout(to);
            setCfg(bak);
            r.className = "hisham-test-result err";
            r.textContent = t("testFail") + friendlyErr(e);
        }
    });
}
/* rebuild setup panel on every open → always fresh language + saved values */
function openPanel() {
    buildDrawer();
    const old = $("hishamPanel");
    if (old) old.remove();
    buildPanel();
    const p = $("hishamPanel");
    if (p) p.classList.remove("hidden-panel");
}
function closePanel() { const p = $("hishamPanel"); if (p) p.classList.add("hidden-panel"); }
function openDrawer() {
    buildDrawer();
    els.overlay.classList.add("show");
    els.drawer.classList.remove("hidden-drawer");
    refreshStatus(); renderAll();
    setTimeout(function () { try { els.input.focus(); } catch (_) {} }, 250);
}
function closeDrawer() {
    if (!els.drawer) return;
    els.overlay.classList.remove("show");
    els.drawer.classList.add("hidden-drawer");
    closePanel();
}
function toast(msg) {
    if (!els.toast) return;
    els.toast.textContent = msg;
    els.toast.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { els.toast.classList.remove("show"); }, 2200);
}
function pillText() {
    const c = getCfg();
    const prov = c.provider || "openai";
    const name = prov[0].toUpperCase() + prov.slice(1);
    return "⚡ " + name + (c.model ? " • " + c.model : "");
}
function refreshStatus() {
    if (!els.status) return;
    const ok = hasKey();
    els.status.textContent = ok ? t("online") : t("offline");
    if (els.dot) els.dot.classList.toggle("off", !ok);
    if (els.banner) els.banner.style.display = ok ? "none" : "flex";
    if (els.pill) els.pill.textContent = pillText();
}
/* re-apply language to the whole drawer (tile + header + modes + panel next open) */
function retranslateUI() {
    try {
        const lbl = $("hishamAgent");
        if (lbl) {
            let name = null;
            try {
                if (typeof translations !== "undefined" && typeof currentLanguage !== "undefined" && translations[currentLanguage]) {
                    name = translations[currentLanguage].hishamAgent;
                }
            } catch (_) {}
            lbl.textContent = name || t("tileLabel");
        }
    } catch (_) {}
    if (!$("hishamDrawer")) return;
    try {
        $("hishamHeadTitle").textContent = t("headTitle");
        $("hishamHeadSub").textContent = t("headSub");
        const d = $("hishamDrawer");
        d.querySelectorAll(".hisham-mode").forEach(function (b) {
            const m = b.dataset.mode;
            if (MODE_META[m]) b.innerHTML = MODE_META[m].icon + " " + esc(t(MODE_META[m].en[0])) + "<small>" + esc(t(MODE_META[m].en[1])) + "</small>";
        });
        $("hishamNeedKey").textContent = t("needKey");
        $("hishamSetupBtn2").textContent = t("setupBtn");
        $("hishamInput").placeholder = t("inputPh");
        $("hishamSend").title = t("sendTitle");
        $("hishamStop").title = t("stopTitle");
        $("hishamCloseBtn").title = t("close");
        $("hishamSetupBtn").title = t("settings");
        $("hishamNewBtn").title = t("newChat");
        $("hishamModelPill").title = t("modelPillTitle");
        const note = d.querySelector(".hisham-foot-note");
        if (note) note.textContent = t("footNote");
        closePanel();
        renderAll(); refreshStatus();
    } catch (_) {}
}

/* message rendering */
function bubble(role, html, time) {
    const dir = isArabic(html.replace(/<[^>]+>/g, "")) ? ' dir="auto"' : "";
    if (role === "user") return '<div class="hisham-msg user"><div class="hisham-bubble"' + dir + '>' + html + '<time>' + esc(time || now()) + '</time></div></div>';
    return '<div class="hisham-msg bot"><div class="hisham-mini-avatar">✦</div><div class="hisham-bubble"' + dir + '>' + html + '<time>' + esc(time || now()) + '</time></div></div>';
}
function renderAll() {
    if (!els.body) return;
    const L = hLang();
    let h = "";
    let lastAsst = -1;
    history.forEach(function (m, i) { if (m.role === "assistant") lastAsst = i; });
    if (!history.length) {
        h += '<div class="hisham-welcome"><div class="hisham-welcome-orb">✦</div><h3>' + esc(t("welcomeTitle")) + '</h3><p>' + esc(t("welcomeText")) + '</p><div class="hisham-chips">' +
            t("chips").map(function (c) { return '<button class="hisham-chip" data-chip="' + esc(c) + '">' + esc(c) + '</button>'; }).join("") +
            '</div></div>';
    } else {
        history.forEach(function (m, idx) {
            if (m.role === "user") { h += bubble("user", esc(m.text), m.time); return; }
            let inner = md(m.text || t("noAnswer"));
            if (m.think) inner = '<details class="hisham-think"><summary>' + esc(t("thinkTitle")) + '</summary><div class="think-body">' + esc(m.think) + '</div></details>' + inner;
            if (m.sources && m.sources.length) {
                inner += '<div class="hisham-srcs"><div style="font-size:.72rem;font-weight:800;opacity:.7">🔗 ' + esc(t("sources")) + '</div>' +
                    m.sources.map(function (s) { return '<a class="hisham-src" href="' + esc(s.url || "#") + '" target="_blank" rel="noopener"><b>' + esc(s.title || s.url) + '</b><span>' + esc(s.url || "") + '</span></a>'; }).join("") + '</div>';
            }
            if (m.acted && m.acted.length) inner += '<div><span class="hisham-acted">' + esc(t("acted") + m.acted.join(" • ").slice(0, 220)) + '</span></div>';
            inner += '<div class="hisham-msg-actions"><button class="hisham-mini-btn" data-copy="' + idx + '">⧉ ' + esc(t("copy")) + '</button>' +
                (idx === lastAsst ? '<button class="hisham-mini-btn" data-regen="' + idx + '">' + esc(t("regen")) + '</button>' : '') + '</div>';
            h += bubble("bot", inner, m.time);
        });
    }
    els.body.innerHTML = h;
    els.body.querySelectorAll("[data-chip]").forEach(function (b) {
        b.addEventListener("click", function () { els.input.value = b.dataset.chip; send(); });
    });
    els.body.querySelectorAll("[data-copy]").forEach(function (b) {
        b.addEventListener("click", function () { copyMsg(parseInt(b.dataset.copy, 10)); });
    });
    els.body.querySelectorAll("[data-regen]").forEach(function (b) {
        b.addEventListener("click", function () { regenerate(parseInt(b.dataset.regen, 10)); });
    });
    els.body.scrollTop = els.body.scrollHeight;
    // quick replies
    const quicks = L === "ar" ? ["🌓 داكن", "💜 بنفسجي", "📝 مهامي", "🔍 بحث عميق"] : ["🌓 Dark", "💜 Violet", "📝 My todos", "🔍 Deep search"];
    els.quick.innerHTML = quicks.map(function (q) { return '<button class="hisham-chip">' + esc(q) + '</button>'; }).join("");
    els.quick.querySelectorAll("button").forEach(function (b) {
        b.addEventListener("click", function () {
            const v = b.textContent;
            if (v.indexOf("داكن") >= 0 || v.indexOf("Dark") >= 0) { els.input.value = L === "ar" ? "فعّل الوضع الداكن" : "Switch to dark mode"; }
            else if (v.indexOf("بنفسجي") >= 0 || v.indexOf("Violet") >= 0) { els.input.value = L === "ar" ? "غيّر الثيم إلى بنفسجي" : "Change theme to violet"; }
            else if (v.indexOf("مهام") >= 0 || v.indexOf("todos") >= 0) { els.input.value = L === "ar" ? "اعرض مهامي الحالية" : "List my current todos"; }
            else { setMode("search"); els.input.focus(); toast(t("modeSearch")); return; }
            send();
        });
    });
}
function copyMsg(idx) {
    const m = history[idx];
    if (!m) return;
    const done = function () { toast(t("copied")); };
    const fail = function () { toast(t("copyFail")); };
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(m.text || "").then(done, fail);
        } else {
            const ta = document.createElement("textarea");
            ta.value = m.text || "";
            document.body.appendChild(ta); ta.select();
            try { document.execCommand("copy") ? done() : fail(); } catch (_) { fail(); }
            ta.remove();
        }
    } catch (_) { fail(); }
}
function setMode(m) {
    if (m !== "chat" && m !== "think" && m !== "search") return;
    mode = m;
    try { localStorage.setItem(MODE_KEY, m); } catch (_) {}
    const d = $("hishamDrawer");
    if (d) d.querySelectorAll(".hisham-mode").forEach(function (x) { x.classList.toggle("active", x.dataset.mode === m); });
}
function pushTyping(stepsHtml) {
    const id = "hishamTyping" + Date.now();
    const div = document.createElement("div");
    div.id = id;
    div.innerHTML = '<div class="hisham-msg bot"><div class="hisham-mini-avatar">✦</div><div class="hisham-bubble hisham-typing"><i></i><i></i><i></i></div></div>' + (stepsHtml || "");
    els.body.appendChild(div);
    els.body.scrollTop = els.body.scrollHeight;
    return id;
}
function dropTyping(id) { const e = document.getElementById(id); if (e) e.remove(); }
/* live streaming placeholder */
function pushStream() {
    const id = "hishamStream" + Date.now();
    const div = document.createElement("div");
    div.id = id;
    div.innerHTML = '<div class="hisham-msg bot"><div class="hisham-mini-avatar">✦</div><div class="hisham-bubble streaming"><span class="hisham-caret"></span></div></div>';
    els.body.appendChild(div);
    els.body.scrollTop = els.body.scrollHeight;
    return id;
}
function updateStream(id, text, think) {
    const e = document.getElementById(id);
    if (!e) return;
    const b = e.querySelector(".hisham-bubble");
    if (!b) return;
    let h = "";
    if (think) h += '<details class="hisham-think" open><summary>' + esc(t("thinkTitle")) + '</summary><div class="think-body">' + esc(thickSlice(think)) + '</div></details>';
    h += (text ? mdPreview(text) : "") + '<span class="hisham-caret"></span>';
    b.innerHTML = h;
    els.body.scrollTop = els.body.scrollHeight;
}
function thickSlice(s) { return String(s || "").slice(-4000); }
function dropStream(id) { const e = document.getElementById(id); if (e) e.remove(); }

/* ============================== send flows ============================== */
function pushErr(e) {
    history.push({ role: "assistant", text: friendlyErr(e), time: now() });
    saveHist(); renderAll();
}
async function execFlow(utext) {
    // instant local intents — no LLM round-trip, no waiting
    if (isPureIntent(utext, "todos")) {
        history.push({ role: "assistant", text: formatTodos(), time: now() });
        saveHist(); renderAll();
        return;
    }
    if (isPureIntent(utext, "menu")) {
        const r = Agent.openMenu();
        history.push({ role: "assistant", text: r, acted: [r], time: now() });
        saveHist(); renderAll();
        return;
    }
    const pre = localCommands(utext);
    const nav = pre.find(function (a) { return a.tool === "webSearch"; });
    if (nav && isPureIntent(utext, "nav")) {
        const r = Agent.webSearch(nav.query); // navigates away — answer must be local
        history.push({ role: "assistant", text: r, acted: [r], time: now() });
        saveHist(); renderAll();
        return;
    }
    busy = true; els.send.disabled = true; els.stop.style.display = "grid";
    aborter = new AbortController();
    const failSafe = setTimeout(function () { try { aborter.abort(); } catch (_) {} }, 120000);
    try {
        if (mode === "search") await deepSearchFlow(utext);
        else await chatFlow(utext, mode === "think");
    } catch (e) { pushErr(e); }
    finally {
        clearTimeout(failSafe);
        busy = false; els.send.disabled = false; els.stop.style.display = "none";
    }
}
async function send() {
    if (busy) return;
    const text = (els.input.value || "").trim();
    if (!text) return;
    if (!hasKey()) { openPanel(); toast(t("needKeyFirst")); return; }
    els.input.value = ""; els.input.style.height = "auto";
    history.push({ role: "user", text: text, time: now() }); saveHist(); renderAll();
    await execFlow(text);
}
async function regenerate(idx) {
    if (busy || !hasKey()) return;
    let uidx = -1;
    for (let i = idx - 1; i >= 0; i--) { if (history[i].role === "user") { uidx = i; break; } }
    if (uidx < 0) return;
    const utext = history[uidx].text;
    history.splice(idx, 1); saveHist(); renderAll();
    await execFlow(utext);
}
function ctxMessages() {
    // token-safe: walk backwards with a ~12k char budget (plus hard cap of 16)
    const items = history.filter(function (m) { return m.text && !/^(⏹|Network|Invalid|خطأ|تم الإيقاف|تعذّر|Can't reach)/.test(m.text); });
    const out = [];
    let budget = 12000;
    for (let i = items.length - 1; i >= 0 && out.length < 16; i--) {
        const m = items[i];
        const len = (m.text || "").length;
        if (out.length && len > budget) break;
        out.unshift({ role: m.role, text: (m.text || "").slice(-6000) });
        budget -= len;
    }
    return out;
}
/* streamed final answer with live bubble; returns {text, think} */
async function streamAnswer(sys, messages, opt, streamBox) {
    let acc = "", accThink = "";
    let pending = false, dead = false;
    const flush = function () {
        pending = false;
        if (dead) return;
        updateStream(streamBox, acc, accThink);
    };
    const res = await streamLLM(
        { system: sys, messages: messages, temperature: opt.temperature, maxTokens: opt.maxTokens },
        function (a, at) {
            acc = a; accThink = at || "";
            if (!pending) { pending = true; setTimeout(flush, 90); }
        }
    );
    dead = true;
    acc = res.text; accThink = res.think || accThink;
    updateStream(streamBox, acc, accThink);
    // auto-retry once on empty reply
    if (!acc.trim()) {
        const retry = await callLLM({ system: sys, messages: messages, temperature: opt.temperature, maxTokens: opt.maxTokens });
        acc = retry || "";
        const th = splitThink(acc);
        accThink = th.think || accThink;
        acc = th.text;
        updateStream(streamBox, acc, accThink);
    }
    return { text: acc, think: accThink };
}
async function chatFlow(text, deepThink) {
    const sys = sysPrompt(deepThink
        ? (hLang() === "ar" ? "\nوضع التفكير العميق مفعّل: فكّر بعمق خطوة بخطوة داخل <think>...</think> (استكشف زوايا متعددة، تحقق من افتراضاتك) ثم اكتب الإجابة النهائية الواضحة بعدها." : "\nDeep-think mode is ON: reason carefully step-by-step inside <think>...</think> (explore angles, check assumptions), then write the final clear answer after it.")
        : "");
    const tid = pushTyping();
    const sid = pushStream();
    dropTyping(tid);
    try {
        const out = await streamAnswer(sys, ctxMessages(), { temperature: deepThink ? 0.5 : 0.7, maxTokens: deepThink ? 2200 : 1500 }, sid);
        dropStream(sid);
        const th = splitThink(out.text || "");
        if (out.think && !th.think) th.think = out.think;
        const ac = splitActions(th.text);
        let acted = [];
        // 1) model-emitted actions
        if (ac.actions.length) acted = acted.concat(await runActions(ac.actions));
        // 2) local fallback commands (dedupe by tool)
        const local = localCommands(text).filter(function (a) { return !ac.actions.some(function (b) { return b.tool === a.tool; }); });
        if (local.length) acted = acted.concat(await runActions(local));
        history.push({ role: "assistant", text: ac.text.trim() || (acted.length ? t("localAnswer") : t("noAnswer")), think: th.think || "", acted: acted, time: now() });
        saveHist(); renderAll();
    } catch (e) { dropStream(sid); throw e; }
}
async function deepSearchFlow(question) {
    const renderSteps = function (active) {
        const labels = [t("s1"), t("s2"), t("s3"), t("s4")];
        return '<div class="hisham-steps"><b>🔍 ' + esc(t("stepsTitle")) + '</b><br>' + labels.map(function (l, i) {
            const cls = i < active ? "step done" : i === active ? "step active" : "step";
            const icon = i < active ? "✅ " : i === active ? "⏳ " : "▫️ ";
            return '<span class="' + cls + '">' + icon + esc(l) + '</span><br>';
        }).join("") + '</div>';
    };
    const tid = pushTyping(renderSteps(0));
    let sid = null;
    const setStep = function (n) {
        const box = document.getElementById(tid);
        if (box) { const s = box.querySelector(".hisham-steps"); if (s) { const tmp = document.createElement("div"); tmp.innerHTML = renderSteps(n); s.replaceWith(tmp.firstChild); } }
        els.body.scrollTop = els.body.scrollHeight;
    };
    try {
        // 1) queries
        let queries = [];
        try {
            const qraw = await callLLM({
                system: hLang() === "ar" ? "ولّد فقط 3-5 استعلامات بحث قصيرة ومتنوعة (كل سطر استعلام، بالعربية والإنجليزية) حول سؤال المستخدم. بدون شرح." : "Generate only 3-5 short varied web search queries (one per line) about the user's question. No explanation.",
                messages: [{ role: "user", text: question }], temperature: 0.4, maxTokens: 200
            });
            queries = qraw.split("\n").map(function (s) { return s.replace(/^[\d\-•*.)\s]+/, "").trim(); }).filter(function (s) { return s.length > 2; }).slice(0, 5);
        } catch (_) {}
        if (!queries.length) queries = [question];
        setStep(1);
        // 2) web
        const lang = hLang();
        const all = [];
        for (const q of queries) {
            const results = await Promise.all([ddgSearch(q), wikiSearch(q, lang), lang === "ar" ? wikiSearch(q, "en") : Promise.resolve([])]);
            all.push.apply(all, results[0].concat(results[1], results[2]));
            setStep(1);
        }
        let sources = dedupSources(all);
        setStep(2);
        if (!sources.length) {
            // graceful fallback: normal answer
            dropTyping(tid);
            return chatFlow(question + (lang === "ar" ? "\n(تعذّر الوصول لمصادر ويب، أجب من معرفتك)" : "\n(Web sources unavailable, answer from knowledge)"), false);
        }
        // 3) read real article intros for top wiki pages (grounding > snippets)
        try {
            const wikiTops = sources.filter(function (s) { return s.wiki && s.url; }).slice(0, 4);
            const extracts = await Promise.all(wikiTops.map(function (s) { return wikiExtract(s.title, s.wikiLang || lang); }));
            extracts.forEach(function (ex, i) { if (ex) wikiTops[i].content = ex; });
        } catch (_) {}
        setStep(3);
        const srcText = sources.map(function (s, i) {
            let body = (s.snippet || "").slice(0, 380);
            if (s.content) body += "\n" + s.content.slice(0, 800);
            return "[" + (i + 1) + "] " + s.title + " — " + body + "\nURL: " + s.url;
        }).join("\n\n");
        const sys = sysPrompt((lang === "ar"
            ? "\nوضع البحث العميق: أجب إجابة شاملة منظمة (ملخص، تفاصيل، نقاط، خلاصة) اعتماداً على المصادر التالية، واذكر أرقام المصادر [1] [2] داخل النص. ثم أكمل أي إجراء مطلوب للإضافة عبر ```agent-actions```."
            : "\nDeep-search mode: write a comprehensive structured answer (summary, details, bullets, conclusion) grounded in these sources, citing [1] [2] inline. Then append any requested extension actions via ```agent-actions```.") +
            "\n\nWEB SOURCES:\n" + srcText);
        dropTyping(tid);
        sid = pushStream();
        const out = await streamAnswer(sys, [{ role: "user", text: question }], { temperature: 0.5, maxTokens: 2400 }, sid);
        dropStream(sid);
        const th = splitThink(out.text || "");
        if (out.think && !th.think) th.think = out.think;
        const ac = splitActions(th.text);
        const acted = ac.actions.length ? await runActions(ac.actions) : [];
        const local = localCommands(question).filter(function (a) { return !ac.actions.some(function (b) { return b.tool === a.tool; }); });
        const acted2 = local.length ? await runActions(local) : [];
        history.push({ role: "assistant", text: (ac.text.trim() || t("noAnswer")) + "\n\n_" + t("citations") + "_", think: th.think || "", sources: sources.slice(0, 8), acted: acted.concat(acted2), time: now() });
        saveHist(); renderAll();
    } catch (e) { dropTyping(tid); if (sid) dropStream(sid); throw e; }
}

/* ============================== tile hookup ============================== */
function hookTile() {
    const tile = $("hishamAgentTile");
    if (tile && !tile.dataset.hooked) {
        tile.dataset.hooked = "1";
        tile.addEventListener("click", function (e) { e.preventDefault(); e.stopPropagation(); openDrawer(); });
        tile.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openDrawer(); } });
    }
    try {
        window.addEventListener("material-you-language-change", retranslateUI);
    } catch (_) {}
}

/* ============================== boot ============================== */
function boot() {
    hookTile();
    try { if (els.status) refreshStatus(); } catch (_) {}
    // public API for console / other scripts
    window.openHishamAgent = openDrawer;
    window.closeHishamAgent = closeDrawer;
    window.askHishamAgent = function (text) {
        openDrawer();
        if (text) { try { els.input.value = String(text); } catch (_) {} send(); }
    };
    window.HishamAgentConfig = { get: getCfg, set: function (c) { setCfg(c); refreshStatus(); } };
    window.HishamAgentModels = { list: fetchModels };
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
else boot();

})();

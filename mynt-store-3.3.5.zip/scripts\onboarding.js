(function () {
    var ONBOARDING_DONE_KEY = "onboardingDone";
    var USER_NAME_KEY = "userName";

    if (localStorage.getItem(ONBOARDING_DONE_KEY) === "true") return;

    var overlay = document.getElementById("onboardingOverlay");
    var slides = document.querySelectorAll(".onboarding-slide");
    var dots = document.querySelectorAll(".onb-dot");
    var progressBar = document.getElementById("onboardingProgressBar");
    if (!overlay || !slides.length) return;
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-labelledby", "onbTitle");
    slides.forEach(function (slide) { slide.inert = !slide.classList.contains("active"); });

    var currentSlide = 0;
    var totalSlides = slides.length;

    // ── State ──
    var userName = "";

    function getLang() {
        return localStorage.getItem("selectedLanguage") || "en";
    }

    // ── Translations ──
    var fallbackTexts = {
        onbTitle: "Welcome to<br>Material You NewTab",
        onbSubtitle: "Let's set up your experience",
        onbNamePlaceholder: "Enter your name",
        onbContinueBtn: "Continue",
        onbFeatTitle: "Everything you need",
        onbFeatSub: "A beautiful new tab page, crafted for you",
        onbFeat1Title: "Custom Themes",
        onbFeat1Desc: "Stunning colors, gradients & wallpapers",
        onbFeat2Title: "Quick Shortcuts",
        onbFeat2Desc: "Bookmarks & speed dial at your fingertips",
        onbFeat3Title: "Live Weather",
        onbFeat3Desc: "Real-time forecasts & beautiful clock",
        onbFeat4Title: "To-Do & More",
        onbFeat4Desc: "Stay organized with built-in tools",
        onbBackBtn: "Back",
        onbNextBtn: "Next",
        onbReadyTitle: "You're all set!",
        onbReadySub: "Everything is ready. Let's start exploring.",
        onbReadySubNamed: "Everything is ready, {name}. Let's start exploring.",
        onbStartBtn: "Start Exploring",
        onbSkipBtn: "Skip"
    };

    function getText(key) {
        var lang = getLang();
        if (typeof translations !== "undefined") {
            var val = (translations[lang] && translations[lang][key]) ||
                      (translations["en"] && translations["en"][key]);
            if (val) return val;
        }
        return fallbackTexts[key] || key;
    }

    function applyTexts() {
        var els = {
            onbTitle: document.getElementById("onbTitle"),
            onbSubtitle: document.getElementById("onbSubtitle"),
            onbNameInput: document.getElementById("onbNameInput"),
            onbContinueBtn: document.getElementById("onbContinueBtn"),
            onbFeatTitle: document.getElementById("onbFeatTitle"),
            onbFeatSub: document.getElementById("onbFeatSub"),
            onbFeat1Title: document.getElementById("onbFeat1Title"),
            onbFeat1Desc: document.getElementById("onbFeat1Desc"),
            onbFeat2Title: document.getElementById("onbFeat2Title"),
            onbFeat2Desc: document.getElementById("onbFeat2Desc"),
            onbFeat3Title: document.getElementById("onbFeat3Title"),
            onbFeat3Desc: document.getElementById("onbFeat3Desc"),
            onbFeat4Title: document.getElementById("onbFeat4Title"),
            onbFeat4Desc: document.getElementById("onbFeat4Desc"),
            onbBackBtn: document.getElementById("onbBackBtn"),
            onbNextBtn: document.getElementById("onbNextBtn"),
            onbReadyTitle: document.getElementById("onbReadyTitle"),
            onbReadySub: document.getElementById("onbReadySub"),
            onbStartBtn: document.getElementById("onbStartBtn"),
            onbSkipBtn: document.getElementById("onbSkipBtn")
        };

        for (var key in els) {
            if (els[key]) {
                if (key === "onbTitle") {
                    els[key].innerHTML = getText(key);
                } else {
                    els[key].textContent = getText(key);
                }
            }
        }

        // name input placeholder
        var input = document.getElementById("onbNameInput");
        if (input) input.placeholder = getText("onbNamePlaceholder");
    }

    // ── Slide Navigation ──
    function goToSlide(index, direction) {
        if (index < 0 || index >= totalSlides) return;
        if (index === currentSlide) return;

        // Save name when leaving slide 0
        if (currentSlide === 0) {
            var nameInput = document.getElementById("onbNameInput");
            if (nameInput) userName = nameInput.value.trim();
        }

        var currentEl = slides[currentSlide];
        var nextEl = slides[index];

        // Remove active from current, add exit animation
        currentEl.classList.remove("active");
        currentEl.inert = true;
        if (direction === "next") {
            currentEl.classList.add("exit-left");
        } else {
            currentEl.classList.add("exit-right");
        }

        // Prepare next slide
        nextEl.classList.remove("exit-left", "exit-right");
        nextEl.classList.add("active");
        nextEl.inert = false;
        overlay.setAttribute("aria-labelledby", nextEl.querySelector("h1,h2").id);
        nextEl.querySelector("input,button")?.focus({ preventScroll: true });

        // Update dots
        for (var d = 0; d < dots.length; d++) {
            dots[d].classList.toggle("active", d === index);
        }

        // Update progress bar
        var progress = ((index + 1) / totalSlides) * 100;
        progressBar.style.width = progress + "%";

        currentSlide = index;

        // Restore name when returning to slide 0
        if (index === 0) {
            var nameInput = document.getElementById("onbNameInput");
            if (nameInput) {
                nameInput.value = userName;
                setTimeout(function () { nameInput.focus(); }, 400);
            }
        }

        // Personalize last slide
        if (index === totalSlides - 1 && userName) {
            var readySub = document.getElementById("onbReadySub");
            if (readySub) {
                readySub.textContent = getText("onbReadySubNamed").replace("{name}", userName);
            }
        }
    }

    function nextSlide() {
        goToSlide(currentSlide + 1, "next");
    }

    function prevSlide() {
        goToSlide(currentSlide - 1, "prev");
    }

    // ── Complete Onboarding ──
    function completeOnboarding() {
        if (userName) {
            localStorage.setItem(USER_NAME_KEY, userName);
        }
        localStorage.setItem(ONBOARDING_DONE_KEY, "true");

        overlay.style.opacity = "0";
        overlay.style.transition = "opacity 0.4s ease";
        setTimeout(function () {
            overlay.style.display = "none";
        }, 400);

        window.dispatchEvent(new CustomEvent("material-you-onboarding-done", {
            detail: { name: userName }
        }));
    }

    // ── Event Listeners ──
    document.getElementById("onbNext1").addEventListener("click", nextSlide);
    document.getElementById("onbNext2").addEventListener("click", nextSlide);
    document.getElementById("onbPrev2").addEventListener("click", prevSlide);
    document.getElementById("onbFinish").addEventListener("click", completeOnboarding);

    // Skip: exit the tour immediately (keeps a typed name if any)
    document.getElementById("onbSkipBtn").addEventListener("click", function () {
        if (currentSlide === 0) {
            var skipNameInput = document.getElementById("onbNameInput");
            if (skipNameInput) userName = skipNameInput.value.trim();
        }
        completeOnboarding();
    });

    document.getElementById("onbNameInput").addEventListener("keydown", function (e) {
        if (e.key === "Enter") nextSlide();
    });

    // Dot clicks
    for (var i = 0; i < dots.length; i++) {
        dots[i].addEventListener("click", function () {
            var idx = parseInt(this.getAttribute("data-index"));
            if (idx > currentSlide) goToSlide(idx, "next");
            else if (idx < currentSlide) goToSlide(idx, "prev");
        });
    }

    // Keyboard navigation (only when no input is focused)
    document.addEventListener("keydown", function (e) {
        if (overlay.style.display === "none") return;
        if (document.activeElement && document.activeElement.tagName === "INPUT") return;
        if (e.key === "ArrowRight") {
            if (currentSlide < totalSlides - 1) nextSlide();
        } else if (e.key === "ArrowLeft") {
            if (currentSlide > 0) prevSlide();
        } else if (e.key === "Escape") {
            completeOnboarding();
        }
    });

    // ── Show overlay ──
    overlay.style.display = "flex";
    applyTexts();

    // Set initial progress
    progressBar.style.width = ((1 / totalSlides) * 100) + "%";

    // Focus name input after animation
    setTimeout(function () {
        var nameInput = document.getElementById("onbNameInput");
        if (nameInput) nameInput.focus();
    }, 500);

    // Listen for language changes
    window.addEventListener("material-you-language-change", applyTexts);
})();

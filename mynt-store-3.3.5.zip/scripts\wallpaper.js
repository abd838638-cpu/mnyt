/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 */

// -------------------------- Wallpaper -----------------------------
const dbName = "ImageDB";
const storeName = "backgroundImages";
const timestampKey = "lastUpdateTime";
const imageTypeKey = "imageType";

// Folder wallpaper keys
const FOLDER_COUNT_KEY  = "folderWallpaperCount";
const FOLDER_FILE_PREFIX = "folderFile_";

// Pin / freeze wallpaper key
const PINNED_INDEX_KEY = "pinnedWallpaperIndex"; // localStorage: index of pinned file (-1 = none)

// Track the currently displayed folder file index for pinning
let _currentFolderIndex = -1;

function syncPinWallpaperButtonState() {
    const pinBtn = document.getElementById("pinWallpaperTrigger");
    if (!pinBtn) return;

    const count = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");
    const pinned = localStorage.getItem(PINNED_INDEX_KEY);
    const isPinned = count > 0 && pinned !== null && pinned !== "-1";
    const pinIcon = pinBtn.querySelector(".pinIcon");
    const checkIcon = pinBtn.querySelector(".pinCheckIcon");

    pinBtn.classList.toggle("pinActive", isPinned);
    if (pinIcon) pinIcon.style.display = isPinned ? "none" : "";
    if (checkIcon) checkIcon.style.display = isPinned ? "" : "none";
}

// Open IndexedDB database
function openDatabase() {
    return new Promise((resolve, reject) => {
        if (!window.indexedDB) { reject("IndexedDB not supported"); return; }
        const request = indexedDB.open(dbName, 1);
        request.onupgradeneeded = function (event) {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(storeName)) {
                db.createObjectStore(storeName);
            }
        };
        request.onsuccess = (event) => resolve(event.target.result);
        request.onerror = (event) => {
            const msg = (event.target.error && event.target.error.message)
                ? event.target.error.message
                : String(event.target.errorCode || "unknown");
            reject("Database error: " + msg);
        };
        request.onblocked = () => reject("Database blocked");
    });
}

// Save image Blob, timestamp, and type to IndexedDB
async function saveImageToIndexedDB(imageBlob, isRandom) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, "readwrite");
        const store = transaction.objectStore(storeName);
        store.put(imageBlob, "backgroundImage");
        store.put(new Date().toISOString(), timestampKey);
        store.put(isRandom ? "random" : "upload", imageTypeKey);
        transaction.oncomplete = () => resolve();
        transaction.onerror = (event) => reject("Transaction error: " + event.target.errorCode);
    });
}

// Load image Blob, timestamp, and type from IndexedDB
async function loadImageAndDetails() {
    const db = await openDatabase();
    return Promise.all([
        getFromStore(db, "backgroundImage"),
        getFromStore(db, timestampKey),
        getFromStore(db, imageTypeKey)
    ]);
}

function getFromStore(db, key) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, "readonly");
        const store = transaction.objectStore(storeName);
        const request = store.get(key);
        request.onsuccess = () => resolve(request.result);
        request.onerror = (event) => reject("Request error: " + event.target.errorCode);
    });
}

// Clear image data from IndexedDB
async function clearImageFromIndexedDB() {
    const db = await openDatabase();
    return new Promise(async (resolve, reject) => {
        const tx = db.transaction(storeName, "readwrite");
        const store = tx.objectStore(storeName);

        // Clear single wallpaper
        store.delete("backgroundImage");
        store.delete(timestampKey);
        store.delete(imageTypeKey);

        // Clear folder wallpapers
        const count = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");
        for (let i = 0; i < count; i++) {
            store.delete(FOLDER_FILE_PREFIX + i);
        }
        localStorage.removeItem(FOLDER_COUNT_KEY);

        tx.oncomplete = () => resolve();
        tx.onerror = (event) => reject("Delete error: " + event.target.errorCode);
    });
}

// ── Handle single file upload ──────────────────────────────────────────────
document.getElementById("imageUpload").addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (!file) return;

    const fileUrl = URL.createObjectURL(file);
    const isVideo = file.type.startsWith("video/");
    const videoBg = document.getElementById("videoBg");

    // Clear any existing folder wallpapers when a single upload is chosen
    clearFolderWallpapers();

    if (isVideo) {
        clearBodyBgImage();
        // Reset ALL inline styles left from previous delete/hide operations
        videoBg.style.cssText = "";
        // Make visible BEFORE setting src — prevents a blank flash in Chrome
        videoBg.style.display = "block";
        // Restore saved brightness (not hardcoded 1) so video appears at the
        // user's chosen brightness level immediately on load/reload.
        videoBg.style.opacity = String(Math.min(1, Math.max(0.1,
            parseFloat(localStorage.getItem("videoBgOpacity") || "1"))));
        videoBg.src = fileUrl;
        // Do NOT call load() here — setting src is enough; load() resets the
        // media element and can cause the video to appear blank in some Chrome versions.
        videoBg.play().catch(() => {}); // .catch so autoplay policy doesn't throw
        toggleBackgroundType(true);
        updateVideoSettingsPanel(true);
        localStorage.setItem("hasSingleWallpaper", "true");
        saveImageToIndexedDB(file, false).catch(console.error);
    } else {
        const image = new Image();
        image.onload = function () {
            videoBg.pause();
            videoBg.removeAttribute("src");
            videoBg.load();
            videoBg.style.display = "none";
            setBodyBgImage(fileUrl);
            toggleBackgroundType(true);
            updateVideoSettingsPanel(false);
            localStorage.setItem("hasSingleWallpaper", "true");
            saveImageToIndexedDB(file, false).catch(console.error);
            // Note: blob URL is kept alive; setBodyBgImage revokes the previous one
            // automatically when the next wallpaper is set (or clearBodyBgImage on delete).
        };
        image.src = fileUrl;
    }
    // Reset input so same file can be re-selected
    this.value = "";
});

// ── Helper: set / clear body background image immediately ──────────────────
// Track the active blob URL so we revoke the PREVIOUS one only after a new
// URL takes its place — prevents the "second wallpaper disappears" bug where
// revoking a blob URL while it is still the active background-image causes
// the browser to immediately drop the image.
let _activeBgBlobUrl = null;

function setBodyBgImage(url) {
    // Revoke the previous blob URL now that a new one is taking over.
    if (_activeBgBlobUrl && _activeBgBlobUrl !== url) {
        URL.revokeObjectURL(_activeBgBlobUrl);
    }
    _activeBgBlobUrl = (url && url.startsWith("blob:")) ? url : null;

    // Use inline backgroundImage directly so clear is always instant (CSS var changes
    // don't always trigger a browser repaint in extension contexts)
    document.body.style.backgroundImage = url ? `url(${url})` : "";
    // Keep CSS variable in sync for any external code that reads it
    if (url) {
        document.body.style.setProperty("--bg-image", `url(${url})`);
    } else {
        document.body.style.removeProperty("--bg-image");
    }
    // Keep data-bg in sync so other features (clear button, shuffle, pin) always
    // know a wallpaper is active — even when set from gallery/lucky where
    // toggleBackgroundType() is never called.
    document.body.setAttribute("data-bg", url ? "wallpaper" : "color");
}

function clearBodyBgImage() {
    // Revoke the active blob URL if any before clearing
    if (_activeBgBlobUrl) {
        URL.revokeObjectURL(_activeBgBlobUrl);
        _activeBgBlobUrl = null;
    }
    // Remove the CSS custom property first so the stylesheet rule resolves to none
    document.body.style.removeProperty("--bg-image");
    // Set backgroundImage to empty string — this removes the inline property entirely,
    // letting the CSS rule body { background-image: var(--bg-image, none) } take effect.
    // Since --bg-image is now removed, the rule resolves immediately to none with no flicker.
    document.body.style.backgroundImage = "";
}

// Function to update the background type attribute
function toggleBackgroundType(hasWallpaper) {
    document.body.setAttribute("data-bg", hasWallpaper ? "wallpaper" : "color");
    if (!hasWallpaper) clearBodyBgImage();
}

// ===================== Global Brightness Control (images & videos) =====================
(function initBrightnessControl() {
    const brightnessKey = "videoBgOpacity";
    const DEFAULT_BRIGHTNESS = 1;
    const brightnessBar = document.getElementById("videoBrightnessBar");
    const brightnessSlider = document.getElementById("videoOpacitySlider");
    const brightnessLevel = document.getElementById("videoBrightnessLevel");

    // Apply brightness value to both the CSS pseudo-element overlay (images)
    // and the video element's opacity (videos).
    function applyBrightness(val) {
        const clamped = Math.min(1, Math.max(0.1, val));
        // Set on <html> so it matches preload.js (which also sets on documentElement).
        // CSS custom properties inherit: html → body → body::before (the dark overlay).
        document.documentElement.style.setProperty("--bg-brightness", clamped);
        // Also apply directly to video element opacity
        const videoBg = document.getElementById("videoBg");
        if (videoBg) {
            const isHidden = localStorage.getItem("videoBgHidden") === "true";
            if (!isHidden) videoBg.style.opacity = clamped;
        }
    }

    function setBrightnessPosition(val) {
        const clamped = Math.min(1, Math.max(0.1, val));
        const pct = clamped * 100;
        if (brightnessSlider) brightnessSlider.style.width = pct + "%";
        if (brightnessLevel) brightnessLevel.textContent = Math.round(pct) + "%";
        localStorage.setItem(brightnessKey, clamped);
        applyBrightness(clamped);
    }

    // Expose so other code (e.g. on wallpaper load) can sync the slider
    window.applyBrightness = applyBrightness;
    window.setBrightnessPosition = setBrightnessPosition;

    function handleBrightnessDrag(e) {
        if (!brightnessBar) return;
        const clientX = e.type.startsWith("touch") ? e.touches[0].clientX : e.clientX;
        const rect = brightnessBar.getBoundingClientRect();
        let pos = clientX - rect.left;
        pos = Math.max(0, Math.min(rect.width, pos));
        setBrightnessPosition(pos / rect.width);
    }

    function startBrightnessDrag() {
        const onMove = e => handleBrightnessDrag(e);
        const onEnd = () => {
            ["mousemove", "touchmove"].forEach(evt => document.removeEventListener(evt, onMove));
            ["mouseup", "touchend"].forEach(evt => document.removeEventListener(evt, onEnd));
        };
        ["mousemove", "touchmove"].forEach(evt => document.addEventListener(evt, onMove));
        ["mouseup", "touchend"].forEach(evt => document.addEventListener(evt, onEnd));
    }

    if (brightnessBar) {
        ["mousedown", "touchstart"].forEach(evt => {
            brightnessBar.addEventListener(evt, e => {
                e.preventDefault();
                handleBrightnessDrag(e);
                startBrightnessDrag();
            }, { passive: false });
        });
    }

    // Init on load
    const saved = parseFloat(localStorage.getItem(brightnessKey) || String(DEFAULT_BRIGHTNESS));
    setBrightnessPosition(saved);
})();
// ===================== End Global Brightness Control =====================

// ===================== Video Settings Panel =====================
function updateVideoSettingsPanel(isVideoActive) {
    document.body.setAttribute("data-video-bg", isVideoActive ? "active" : "inactive");
    // Keep the perf fast-path in sync with panel state (covers upload/clear
    // paths even before the MutationObserver fires).
    try {
        document.body.classList.toggle("perf-video", !!isVideoActive);
    } catch (e) {}
}

function initVideoSettingsPanel() {
    const panel = document.getElementById("videoSettingsPanel");
    if (!panel) return;

    const videoBg = document.getElementById("videoBg");
    const muteBtn = document.getElementById("videoMuteBtn");
    const playPauseBtn = document.getElementById("videoPlayPauseBtn");
    const hideBtn = document.getElementById("videoHideBtn");
    const muteIcon = document.getElementById("videoMuteIcon");
    const playPauseIcon = document.getElementById("videoPlayPauseIcon");
    const hideBtnIcon = document.getElementById("videoHideIcon");

    const savedMuted = localStorage.getItem("videoBgMuted") !== "false";
    const savedHidden = localStorage.getItem("videoBgHidden") === "true";

    function updateMuteIcon() {
        if (!muteIcon) return;
        if (videoBg.muted) {
            muteIcon.innerHTML = `<path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>`;
        } else {
            muteIcon.innerHTML = `<path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>`;
        }
    }

    function updatePlayPauseIcon() {
        if (!playPauseIcon) return;
        if (videoBg.paused) {
            playPauseIcon.innerHTML = `<path d="M8 5v14l11-7z"/>`;
        } else {
            playPauseIcon.innerHTML = `<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>`;
        }
    }

    function updateHideIcon(isHidden) {
        if (!hideBtnIcon) return;
        if (!isHidden) {
            hideBtnIcon.innerHTML = `<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>`;
        } else {
            hideBtnIcon.innerHTML = `<path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/>`;
        }
    }

    updateMuteIcon();
    updatePlayPauseIcon();
    updateHideIcon(savedHidden);

    if (muteBtn) {
        muteBtn.addEventListener("click", () => {
            videoBg.muted = !videoBg.muted;
            localStorage.setItem("videoBgMuted", videoBg.muted);
            updateMuteIcon();
        });
    }

    if (playPauseBtn) {
        playPauseBtn.addEventListener("click", () => {
            if (videoBg.paused) { videoBg.play(); } else { videoBg.pause(); }
            setTimeout(updatePlayPauseIcon, 50);
        });
    }

    if (hideBtn) {
        let isHidden = savedHidden;
        if (isHidden) videoBg.style.opacity = "0";
        hideBtn.addEventListener("click", () => {
            isHidden = !isHidden;
            const brightnessVal = parseFloat(localStorage.getItem("videoBgOpacity") || "1");
            videoBg.style.opacity = isHidden ? "0" : brightnessVal;
            localStorage.setItem("videoBgHidden", isHidden);
            updateHideIcon(isHidden);
        });
    }

    const savedOpacity = parseFloat(localStorage.getItem("videoBgOpacity") || "1");
    videoBg.muted = savedMuted;
    videoBg.style.opacity = savedHidden ? "0" : savedOpacity;
}

document.addEventListener("DOMContentLoaded", () => {
    initVideoSettingsPanel();
});
// ===================== End Video Settings Panel =====================


// ===================== Folder Wallpaper =====================

// Save multiple files to IndexedDB as a folder
async function saveFolderToIndexedDB(files, onProgress) {
    const db = await openDatabase();
    const count = files.length;

    return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, "readwrite");
        const store = tx.objectStore(storeName);

        // Clear any existing single wallpaper to avoid confusion
        store.delete("backgroundImage");
        store.delete(timestampKey);
        store.delete(imageTypeKey);

        // Save files one by one with progress tracking
        let saved = 0;
        function saveNext(i) {
            if (i >= count) return;
            const req = store.put(files[i], FOLDER_FILE_PREFIX + i);
            req.onsuccess = () => {
                saved++;
                if (onProgress) onProgress(saved, count);
                // Not chaining — IndexedDB handles it async
            };
        }
        files.forEach((file, i) => {
            const req = store.put(file, FOLDER_FILE_PREFIX + i);
            req.onsuccess = () => {
                saved++;
                if (onProgress) onProgress(saved, count);
            };
        });

        tx.oncomplete = () => {
            localStorage.setItem(FOLDER_COUNT_KEY, count);
            resolve();
        };
        tx.onerror = (e) => reject(e);
    });
}

// Load a random file from the folder in IndexedDB
async function loadRandomFolderFile() {
    const count = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");
    if (count === 0) return null;

    const randomIndex = Math.floor(Math.random() * count);
    const db = await openDatabase();
    return getFromStore(db, FOLDER_FILE_PREFIX + randomIndex);
}

// Clear only folder wallpapers from IndexedDB
async function clearFolderWallpapers() {
    const count = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");
    if (count === 0) {
        localStorage.removeItem(PINNED_INDEX_KEY);
        syncPinWallpaperButtonState();
        updateFolderBadge();
        return;
    }

    const db = await openDatabase();
    const tx = db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    for (let i = 0; i < count; i++) {
        store.delete(FOLDER_FILE_PREFIX + i);
    }
    localStorage.removeItem(FOLDER_COUNT_KEY);
    localStorage.removeItem(PINNED_INDEX_KEY);
    syncPinWallpaperButtonState();
    updateFolderBadge();
}

// Apply a random file from the saved folder (or a specific index if provided)
async function applyRandomFolderFile(specificIndex) {
    const count = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");
    if (count === 0) return false;

    let index;
    if (specificIndex !== undefined && specificIndex >= 0 && specificIndex < count) {
        index = specificIndex;
    } else {
        index = Math.floor(Math.random() * count);
        // Store the current random index so pin can reference it
        _currentFolderIndex = index;
    }

    const db = await openDatabase();
    const blob = await getFromStore(db, FOLDER_FILE_PREFIX + index);
    if (!blob) return false;

    const isVideo = blob.type.startsWith("video/");
    const fileUrl = URL.createObjectURL(blob);
    const videoBg = document.getElementById("videoBg");

    if (isVideo) {
        clearBodyBgImage();
        videoBg.style.cssText = "";
        videoBg.style.display = "block";
        videoBg.style.opacity = String(Math.min(1, Math.max(0.1,
            parseFloat(localStorage.getItem("videoBgOpacity") || "1"))));
        videoBg.src = fileUrl;
        videoBg.play().catch(() => {});
        updateVideoSettingsPanel(true);
    } else {
        videoBg.style.display = "none";
        videoBg.src = "";
        setBodyBgImage(fileUrl);
        updateVideoSettingsPanel(false);
        // setBodyBgImage will revoke this URL when the next wallpaper replaces it.
    }

    toggleBackgroundType(true);
    return true;
}

// Update the badge count on the folder button
function updateFolderBadge(liveCount, progress) {
    const badge = document.getElementById("folderWallpaperBadge");
    if (!badge) return;

    // If liveCount provided → we're mid-upload, animate
    if (liveCount !== undefined) {
        badge.textContent = liveCount;
        badge.style.display = "flex";
        badge.style.color = "#ffffff";

        // Interpolate background from near-black (#1a1a1a) → theme color (darkColor-blue)
        // Use CSS variable for target; get computed value for blending
        const ratio = Math.max(0, Math.min(1, progress || 0));
        const themeColor = getComputedStyle(document.documentElement)
            .getPropertyValue("--darkColor-blue").trim() || "#6200ea";

        // Parse theme color to RGB for interpolation
        const hex = themeColor.replace("#", "");
        const tr = parseInt(hex.substring(0,2), 16);
        const tg = parseInt(hex.substring(2,4), 16);
        const tb = parseInt(hex.substring(4,6), 16);

        // Start color: very dark (near-black tinted with theme hue)
        const sr = Math.round(tr * 0.12);
        const sg = Math.round(tg * 0.12);
        const sb = Math.round(tb * 0.12);

        const r = Math.round(sr + (tr - sr) * ratio);
        const g = Math.round(sg + (tg - sg) * ratio);
        const b = Math.round(sb + (tb - sb) * ratio);

        badge.style.backgroundColor = `rgb(${r},${g},${b})`;
        badge.style.transition = "background-color 0.1s ease";
        return;
    }

    // Normal call → restore CSS var driven color
    badge.style.backgroundColor = "";
    badge.style.transition = "";
    badge.style.color = "";
    const count = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");
    if (count > 0) {
        badge.textContent = count;
        badge.style.display = "flex";
        badge.style.color = "#ffffff";
    } else {
        badge.style.display = "none";
    }
}

// Handle folder file input selection
document.addEventListener("DOMContentLoaded", () => {
    updateFolderBadge();

    const folderInput = document.getElementById("folderWallpaperInput");
    const folderBtn   = document.getElementById("folderWallpaperTrigger");

    if (folderBtn) {
        folderBtn.addEventListener("click", () => folderInput && folderInput.click());
    }

    // Shuffle / random wallpaper button
    const shuffleBtn = document.getElementById("shuffleWallpaperTrigger");
    if (shuffleBtn) {
        shuffleBtn.addEventListener("click", async () => {
            const count = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");
            if (count === 0) {
                const isWallpaperActive = document.body.getAttribute("data-bg") === "wallpaper";
                if (isWallpaperActive) {
                    await alertPrompt(translations[currentLanguage]?.NoFolderSelected || translations["en"].NoFolderSelected);
                } else {
                    await alertPrompt(translations[currentLanguage]?.Nobackgroundset || translations["en"].Nobackgroundset);
                }
                return;
            }
            // Clear pin when shuffling to a new random wallpaper
            localStorage.removeItem(PINNED_INDEX_KEY);
            updatePinBtnState();
            await applyRandomFolderFile();
        });
    }

    // ── Pin / Freeze wallpaper button ──
    const pinBtn = document.getElementById("pinWallpaperTrigger");
    function updatePinBtnState() {
        syncPinWallpaperButtonState();
    }

    function showPinToast(isPinning) {
        if (typeof bmShowToast === "function") {
            bmShowToast(isPinning ? "wallpaper_pinned" : "wallpaper_unpinned", isPinning ? "pin" : "unpin");
        }
    }

    if (pinBtn) {
        updatePinBtnState(); // init state on load
        pinBtn.addEventListener("click", async () => {
            const count = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");
            if (count === 0) {
                const isWallpaperActive = document.body.getAttribute("data-bg") === "wallpaper";
                if (isWallpaperActive) {
                    await alertPrompt(translations[currentLanguage]?.NoFolderSelected || translations["en"].NoFolderSelected);
                } else {
                    await alertPrompt(translations[currentLanguage]?.Nobackgroundset || translations["en"].Nobackgroundset);
                }
                return;
            }
            const pinned = localStorage.getItem(PINNED_INDEX_KEY);
            const isPinned = pinned !== null && pinned !== "-1";
            if (isPinned) {
                // Unpin
                localStorage.removeItem(PINNED_INDEX_KEY);
                updatePinBtnState();
                showPinToast(false);
            } else {
                // Pin current wallpaper
                const idxToPin = _currentFolderIndex >= 0 ? _currentFolderIndex : 0;
                localStorage.setItem(PINNED_INDEX_KEY, idxToPin);
                updatePinBtnState();
                showPinToast(true);
            }
        });
    }

    if (folderInput) {
        folderInput.addEventListener("change", async function () {
            const files = Array.from(this.files).filter(f =>
                f.type.startsWith("image/") || f.type.startsWith("video/")
            );
            if (!files.length) return;

            // Show progress bar
            const wrapper = document.getElementById("folderProgressWrapper");
            const segContainer = document.getElementById("folderProgressSegments");
            const percentEl = document.getElementById("folderProgressPercent");
            const total = files.length;

            const speedEl = document.getElementById("folderProgressSpeed");
            let uploadStartTime = null;
            let totalBytes = files.reduce((acc, f) => acc + f.size, 0);

            if (wrapper && segContainer && percentEl) {
                // Build segments
                segContainer.innerHTML = "";
                const MAX_SEGS = Math.min(total, 60);
                for (let s = 0; s < MAX_SEGS; s++) {
                    const seg = document.createElement("div");
                    seg.className = "folderProgressSeg";
                    segContainer.appendChild(seg);
                }
                percentEl.textContent = "0%";
                if (speedEl) speedEl.textContent = "";
                wrapper.style.display = "flex";
                wrapper.style.opacity = "1";
                uploadStartTime = Date.now();
                // Show badge immediately at 0 with dark color
                updateFolderBadge(0, 0);
            }

            function formatSpeed(bytesPerSec) {
                if (bytesPerSec >= 1024 * 1024) return (bytesPerSec / (1024 * 1024)).toFixed(1) + " MB/s";
                if (bytesPerSec >= 1024) return (bytesPerSec / 1024).toFixed(0) + " KB/s";
                return bytesPerSec.toFixed(0) + " B/s";
            }

            function updateProgress(done, total) {
                if (!wrapper || !segContainer || !percentEl) return;
                const ratio = done / total;
                // Cap at 99% — 100% only fires after wallpaper is visually applied
                const displayPct = Math.min(99, Math.round(ratio * 100));
                const displayRatio = displayPct / 100;
                percentEl.textContent = displayPct + "%";
                // Speed calculation
                if (speedEl && uploadStartTime) {
                    const elapsed = (Date.now() - uploadStartTime) / 1000;
                    const bytesProcessed = ratio * totalBytes;
                    if (elapsed > 0.1) {
                        speedEl.textContent = formatSpeed(bytesProcessed / elapsed);
                    }
                }
                // Fill segments — also capped at 99%
                const segs = segContainer.querySelectorAll(".folderProgressSeg");
                const filled = Math.round(displayRatio * segs.length);
                segs.forEach((seg, i) => {
                    seg.classList.toggle("folderProgressSegFilled", i < filled);
                });
                // Live badge: count increases + color transitions from dark→theme
                updateFolderBadge(done, displayRatio);
            }

            function completeProgress(total) {
                if (!wrapper || !segContainer || !percentEl) return;
                // Slowly animate from current % up to 99.9% then jump to 100%
                // when the image is actually painted — gives a satisfying finish
                const segs = segContainer.querySelectorAll(".folderProgressSeg");
                let startPct = Math.min(98, parseInt(percentEl.textContent) || 98);
                const TARGET = 99.9;
                const DURATION = 900; // ms to go from current → 99.9%
                const startTime = performance.now();

                function animateTo100(ts) {
                    const elapsed = ts - startTime;
                    const t = Math.min(1, elapsed / DURATION);
                    // Ease-out: slows down as it approaches 99.9%
                    const eased = 1 - Math.pow(1 - t, 3);
                    const current = startPct + (TARGET - startPct) * eased;
                    percentEl.textContent = current.toFixed(1) + "%";
                    // Fill segments proportionally
                    const filled = Math.round((current / 100) * segs.length);
                    segs.forEach((seg, i) => seg.classList.toggle("folderProgressSegFilled", i < filled));

                    if (t < 1) {
                        requestAnimationFrame(animateTo100);
                    } else {
                        // Reached 99.9% — now snap to 100%
                        setTimeout(() => {
                            percentEl.textContent = "100%";
                            if (speedEl) speedEl.textContent = "";
                            segs.forEach(seg => seg.classList.add("folderProgressSegFilled"));
                            updateFolderBadge(total, 1);
                        }, 120);
                    }
                }
                requestAnimationFrame(animateTo100);
            }

            // Clear old folder
            await clearFolderWallpapers();

            // Pick a random file NOW (in memory) so we can apply it the instant saving finishes
            const prePickedIndex = Math.floor(Math.random() * files.length);
            _currentFolderIndex = prePickedIndex;

            // Save new folder with progress
            await saveFolderToIndexedDB(files, updateProgress);
            updateFolderBadge();

            // Apply the pre-picked file directly from memory — zero extra DB read
            const prePickedBlob = files[prePickedIndex];
            const isVideo = prePickedBlob.type.startsWith("video/");
            const fileUrl = URL.createObjectURL(prePickedBlob);
            const videoBg = document.getElementById("videoBg");
            if (isVideo) {
                clearBodyBgImage();
                videoBg.style.cssText = "";
                videoBg.style.display = "block";
                videoBg.style.opacity = String(Math.min(1, Math.max(0.1,
            parseFloat(localStorage.getItem("videoBgOpacity") || "1"))));
                videoBg.src = fileUrl;
                videoBg.play().catch(() => {});
                updateVideoSettingsPanel(true);
                // Video: reach 100% once it starts playing
                videoBg.addEventListener("playing", function onPlaying() {
                    videoBg.removeEventListener("playing", onPlaying);
                    completeProgress(files.length);
                }, { once: true });
            } else {
                const img = new Image();
                img.onload = function () {
                    videoBg.style.display = "none";
                    videoBg.src = "";
                    setBodyBgImage(fileUrl);
                    updateVideoSettingsPanel(false);
                    // Image: reach 100% once it's decoded and painted
                    completeProgress(files.length);
                };
                img.src = fileUrl;
            }
            toggleBackgroundType(true);

            // Hide progress bar with fade
            if (wrapper) {
                wrapper.style.opacity = "0";
                setTimeout(() => { wrapper.style.display = "none"; wrapper.style.opacity = "1"; }, 600);
            }

            this.value = ""; // Reset so same folder can be re-selected
        });
    }
});
// ===================== End Folder Wallpaper =====================


// ===================== Perf-video fast-path + background pause =====================
// Root-cause companion to the CSS fix: whenever a video wallpaper is visible we
// add body.perf-video (single-layer video blur, no fullscreen backdrop-filter).
// We also pause decoding when the tab is hidden — a background new-tab keeps
// decoding video otherwise, wasting battery and causing a jank burst on return.
(function initVideoPerfMode() {
    function syncPerfVideoClass() {
        try {
            const videoBg = document.getElementById("videoBg");
            if (!videoBg) return;
            const visible = videoBg.style.display !== "none" &&
                videoBg.getAttribute("src");
            document.body.classList.toggle("perf-video", !!visible);
        } catch (e) {}
    }
    function pauseForHidden() {
        try {
            const videoBg = document.getElementById("videoBg");
            if (!videoBg || !videoBg.getAttribute("src")) return;
            if (document.hidden) {
                if (!videoBg.paused) {
                    videoBg._resumeAfterHidden = true;
                    videoBg.pause();
                }
            } else if (videoBg._resumeAfterHidden) {
                videoBg._resumeAfterHidden = false;
                const hidden = localStorage.getItem("videoBgHidden") === "true";
                if (!hidden) videoBg.play().catch(() => {});
            }
        } catch (e) {}
    }
    document.addEventListener("visibilitychange", pauseForHidden);
    window.addEventListener("pageshow", pauseForHidden);
    // UX-robustness: unsupported codec / corrupt file must never leave a
    // black fullscreen video. Fall back to the color background gracefully.
    const bootVideoErrorFallback = () => {
        const videoBg = document.getElementById("videoBg");
        if (!videoBg || videoBg._luxErrorBound) return;
        videoBg._luxErrorBound = true;
        videoBg.addEventListener("error", () => {
            try {
                videoBg.removeAttribute("src");
                videoBg.load();
                videoBg.style.display = "none";
                document.body.classList.remove("perf-video");
                updateVideoSettingsPanel(false);
                document.body.setAttribute("data-bg", "color");
            } catch (e) {}
        });
    };
    // Observe src/display flips from any wallpaper path (single, folder, clear).
    window.addEventListener("load", syncPerfVideoClass);
    window.addEventListener("load", bootVideoErrorFallback);
    if (typeof MutationObserver !== "undefined") {
        const boot = () => {
            const videoBg = document.getElementById("videoBg");
            if (!videoBg) return;
            new MutationObserver(syncPerfVideoClass).observe(videoBg, {
                attributes: true, attributeFilter: ["src", "style"]
            });
            syncPerfVideoClass();
            bootVideoErrorFallback();
        };
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", boot, { once: true });
        } else { boot(); }
    }
    window.syncPerfVideoClass = syncPerfVideoClass;
})();
// ===================== End Perf-video fast-path =====================

// Check and update image on page load
function checkAndUpdateImage() {
    const folderCount = parseInt(localStorage.getItem(FOLDER_COUNT_KEY) || "0");

    // If folder wallpapers exist, use them
    if (folderCount > 0) {
        // Check if a wallpaper is pinned — if so, always load that one
        const pinnedIndex = parseInt(localStorage.getItem(PINNED_INDEX_KEY) ?? "-1");
        const useIndex = (pinnedIndex >= 0 && pinnedIndex < folderCount) ? pinnedIndex : undefined;
        if (useIndex !== undefined) {
            _currentFolderIndex = useIndex;
        }
        applyRandomFolderFile(useIndex).then(success => {
            if (!success) toggleBackgroundType(false);
        }).catch(function () {});
        return;
    }

    // Otherwise, fall back to single uploaded wallpaper
    loadImageAndDetails()
        .then(([blob, savedTimestamp, imageType]) => {
            const videoBg = document.getElementById("videoBg");

            if (!blob || !savedTimestamp) {
                toggleBackgroundType(false);
                videoBg.style.display = "none";
                videoBg.src = "";
                return;
            }

            const isVideo = blob.type.startsWith("video/");
            const fileUrl = URL.createObjectURL(blob);

            if (isVideo) {
                clearBodyBgImage();
                videoBg.style.cssText = "";
                videoBg.style.display = "block";
                videoBg.style.opacity = String(Math.min(1, Math.max(0.1,
            parseFloat(localStorage.getItem("videoBgOpacity") || "1"))));
                videoBg.src = fileUrl;
                videoBg.play().catch(() => {});
                updateVideoSettingsPanel(true);
            } else {
                videoBg.style.display = "none";
                videoBg.src = "";
                setBodyBgImage(fileUrl);
                updateVideoSettingsPanel(false);
                // setBodyBgImage will revoke this URL when the next wallpaper replaces it.
            }
            toggleBackgroundType(true);
        })
        .catch((error) => {
            console.error("Error loading image:", error);
            toggleBackgroundType(false);
        });
}

// Event listeners
document.getElementById("uploadTrigger").addEventListener("click", () =>
    document.getElementById("imageUpload").click()
);

document.getElementById("clearImage").addEventListener("click", async function () {
    // Determine if a wallpaper is actually present. We trust several signals so the
    // button keeps working even when data-bg is out of sync (e.g. a wallpaper applied
    // from the gallery/lucky, or an older build that forgot to set data-bg):
    //   1. data-bg attribute
    //   2. the actual inline/CSS background-image on <body>
    //   3. the video wallpaper element having a source
    const inlineBg = document.body.style.backgroundImage || "";
    const computedBg = (function () {
        try { return getComputedStyle(document.body).backgroundImage || ""; } catch (e) { return ""; }
    })();
    const hasBgImage = (inlineBg && inlineBg !== "none") ||
        (computedBg && computedBg !== "none");
    const videoEl = document.getElementById("videoBg");
    const hasVideoBg = !!(videoEl && videoEl.getAttribute("src") &&
        videoEl.style.display !== "none");
    const isWallpaperActive = document.body.getAttribute("data-bg") === "wallpaper" ||
        hasBgImage || hasVideoBg;

    if (!isWallpaperActive) {
        try {
            await alertPrompt(translations[currentLanguage]?.Nobackgroundset || translations["en"].Nobackgroundset);
        } catch (e) {
            console.error("alertPrompt error:", e);
        }
        return;
    }

    try {
        const confirmationMessage = (translations[currentLanguage]?.clearbackgroundimage || translations["en"].clearbackgroundimage);
        if (await confirmPrompt(confirmationMessage)) {
            // ── Step 1: Update UI IMMEDIATELY before any async work ──
            const videoBg = document.getElementById("videoBg");
            videoBg.pause();
            videoBg.removeAttribute("src");
            videoBg.style.cssText = "display: none !important; visibility: hidden !important; opacity: 0 !important;";
            clearBodyBgImage();
            document.body.setAttribute("data-bg", "color");
            // Hide video settings panel immediately (triggers CSS hide animation)
            updateVideoSettingsPanel(false);

            // ── Step 2: Clean up storage (UI already cleared above) ──
            await clearImageFromIndexedDB();
            localStorage.removeItem("hasSingleWallpaper");
            localStorage.removeItem("videoBgHidden");
            localStorage.removeItem("videoBgOpacity");
            localStorage.removeItem(PINNED_INDEX_KEY);
            syncPinWallpaperButtonState();
            videoBg.load();
            videoBg.style.cssText = "display: none;";
            updateFolderBadge();
        }
    } catch (error) {
        console.error("clearImage error:", error);
    }
});

// Start image check on page load
checkAndUpdateImage();
// ------------------------ End of BG Image --------------------------

// ===================== Blur Control =====================
(function () {
    const blurKey = "bgBlurAmount";
    const MAX_BLUR = 30;
    const DEFAULT_BLUR = 0;

    const blurBar = document.querySelector("#blurBarControl .opacityBar");
    const blurSliderEl = document.getElementById("blurSlider");
    const blurLevelEl = document.getElementById("blurLevel");

    const MIN_DISPLAY_PCT = 14;

    function setBlurPosition(px) {
        const clamped = Math.min(MAX_BLUR, Math.max(0, px));
        const rawPct = (clamped / MAX_BLUR) * 100;
        const displayPct = MIN_DISPLAY_PCT + (rawPct / 100) * (100 - MIN_DISPLAY_PCT);
        if (blurSliderEl) blurSliderEl.style.width = `${displayPct}%`;
        if (blurLevelEl) blurLevelEl.textContent = `${localizeNumbers(Math.round(rawPct).toString(), currentLanguage)}%`;
        document.body.style.setProperty("--bg-blur", `${clamped}px`);
        localStorage.setItem(blurKey, clamped);
    }

    function handleBlurDrag(e) {
        if (!blurBar) return;
        const clientX = e.type.startsWith("touch") ? e.touches[0].clientX : e.clientX;
        const rect = blurBar.getBoundingClientRect();
        const padding = 0;
        const usableWidth = rect.width - padding * 2;
        let pos = clientX - (rect.left + padding);
        pos = Math.max(0, Math.min(usableWidth, pos));
        const blurPx = (pos / usableWidth) * MAX_BLUR;
        setBlurPosition(blurPx);
    }

    function startBlurDrag() {
        const onMove = e => handleBlurDrag(e);
        const onEnd = () => {
            ["mousemove", "touchmove"].forEach(evt => document.removeEventListener(evt, onMove));
            ["mouseup", "touchend"].forEach(evt => document.removeEventListener(evt, onEnd));
        };
        ["mousemove", "touchmove"].forEach(evt => document.addEventListener(evt, onMove));
        ["mouseup", "touchend"].forEach(evt => document.addEventListener(evt, onEnd));
    }

    if (blurBar) {
        ["mousedown", "touchstart"].forEach(evt => {
            blurBar.addEventListener(evt, e => {
                e.preventDefault();
                handleBlurDrag(e);
                startBlurDrag();
            }, { passive: false });
        });
    }

    const savedBlur = parseFloat(localStorage.getItem(blurKey) || String(DEFAULT_BLUR));
    setBlurPosition(savedBlur);
})();
// ===================== End Blur Control =====================

/**
 * animation-speed.js
 * ─────────────────────────────────────────────────────────────────
 * 1. Universal animation speed multiplier (--ui-anim-mult)
 *    Slider in Appearance section controls all CSS transitions.
 *
 * 2. Universal close animation helper (window.closeWithAnim)
 *    Any panel/popup calls closeWithAnim(el, hideFn, [direction])
 *    instead of directly setting display:none.
 *
 * 3. Draggable panels: makes todo & google-apps panels draggable.
 *
 * 4. JS-side panelScaleIn respects the multiplier.
 * ─────────────────────────────────────────────────────────────────
 */
(function () {
    "use strict";

    const STORAGE_KEY = "uiAnimSpeed";
    const DEFAULT_SPEED = 50; // 1–100

    /* ─── Map slider value (1-100) → CSS multiplier ──────────────
       speed 100 → mult 0.25  (very fast — quarter duration)
       speed 50  → mult 1.0   (normal)
       speed 1   → mult 3.0   (very slow — triple duration)
    ─────────────────────────────────────────────────────────────── */
    function speedToMult(speed) {
        const s = Math.max(1, Math.min(100, speed));
        if (s >= 50) {
            // 50→1.0, 100→0.25  (exponential)
            return 1.0 * Math.pow(0.25, (s - 50) / 50);
        } else {
            // 50→1.0, 1→3.0  (exponential)
            return 1.0 * Math.pow(3.0, (50 - s) / 49);
        }
    }

    function applyAnimMult(speed) {
        const mult = speedToMult(speed);
        const panelOpenMs = Math.round(220 * mult);
        const panelCloseMs = Math.round(panelOpenMs * 0.9);
        // Set on <html> (documentElement), NOT on body:
        // 1. The CSS transitions for @property color vars live on `html`, so html must
        //    see the updated --ui-anim-mult (html cannot inherit from its child body).
        // 2. body and all descendants inherit --ui-anim-mult from html automatically.
        // 3. preload.js also sets it on documentElement, keeping both consistent.
        document.documentElement.style.setProperty("--ui-anim-mult", mult.toFixed(3));
        document.documentElement.style.setProperty("--panel-open-dur", `${panelOpenMs}ms`);
        document.documentElement.style.setProperty("--panel-close-dur", `${panelCloseMs}ms`);
        return mult;
    }

    /* ─── JS panel open animation respecting the multiplier ────── */
    function panelScaleInDur() {
        if (matchMedia("(prefers-reduced-motion: reduce)").matches) return 0;
        const mult = speedToMult(
            parseInt(localStorage.getItem(STORAGE_KEY) || DEFAULT_SPEED)
        );
        return Math.round(220 * mult);
    }

    function panelCloseDur() {
        return Math.round(panelScaleInDur() * 0.9);
    }

    window.getPanelAnimDur = panelScaleInDur;
    window.getPanelCloseDur = panelCloseDur;
    window.panelOpenAnim = function(el, displayVal) {
        const dur = panelScaleInDur();
        if (el && el._panelOpenRaf) {
            cancelAnimationFrame(el._panelOpenRaf);
            el._panelOpenRaf = null;
        }
        el.style.display = displayVal || "block";
        el.style.animation = "none";
        el._panelOpenRaf = requestAnimationFrame(() => {
            el._panelOpenRaf = null;
            if (el._panelDragActive) return;
            el.style.animation = `panelScaleInV2 ${dur}ms cubic-bezier(0.34,1.56,0.64,1) forwards`;
        });
    };

    /* ─── Universal close animation ─────────────────────────────
       Usage: window.closeWithAnim(element, () => { el.style.display = "none"; })
    ─────────────────────────────────────────────────────────────── */
    window.closeWithAnim = function(el, hideFn, direction) {
        if (!el) { if (hideFn) hideFn(); return; }
        const cls = direction === "down" ? "panel-closing-down" : "panel-closing";
        // Cancel any pending close timer to prevent double-hide
        if (el._closeTimer) { clearTimeout(el._closeTimer); el._closeTimer = null; }
        el.classList.add(cls);
        const dur = panelCloseDur() + 28;
        el._closeTimer = setTimeout(() => {
            el.classList.remove(cls);
            if (hideFn) hideFn();
        }, dur);
    };

    /* ─── Make a panel draggable ────────────────────────────────── */
    function makeDraggable(panel, handle) {
        if (!panel || !handle) return;
        let sx, sy, sl, st, drag = false;
        handle.style.cursor = "grab";
        handle.addEventListener("mousedown", e => {
            if (e.button !== 0) return;
            if (e.target.closest("button, input, select, textarea, a, [role='button']")) return;
            e.preventDefault();
            drag = true;
            panel._panelDragActive = true;
            if (panel._panelOpenRaf) {
                cancelAnimationFrame(panel._panelOpenRaf);
                panel._panelOpenRaf = null;
            }
            sx = e.clientX; sy = e.clientY;
            const r = panel.getBoundingClientRect();
            panel.classList.remove("panel-closing", "panel-closing-down");
            panel.style.animation = "none";
            panel.style.transform = "none";
            panel.style.left = r.left + "px";
            panel.style.top  = r.top  + "px";
            panel.style.right = "auto";
            panel.style.bottom = "auto";
            sl = r.left; st = r.top;
            handle.style.cursor = "grabbing";
        });
        document.addEventListener("mousemove", e => {
            if (!drag) return;
            const vw = window.innerWidth, vh = window.innerHeight;
            const pw = panel.offsetWidth, ph = panel.offsetHeight;
            panel.style.left  = Math.max(0, Math.min(vw - pw - 4, sl + e.clientX - sx)) + "px";
            panel.style.top   = Math.max(0, Math.min(vh - ph - 4, st + e.clientY - sy)) + "px";
            panel.style.right = "auto";
            panel.style.bottom = "auto";
        });
        document.addEventListener("mouseup", () => {
            if (drag) {
                drag = false;
                panel._panelDragActive = false;
                handle.style.cursor = "grab";
            }
        });
    }

    /* ─── DOMContentLoaded ───────────────────────────────────────── */
    function resetFloatingPanelPosition(panel) {
        if (!panel) return;
        if (panel._panelOpenRaf) {
            cancelAnimationFrame(panel._panelOpenRaf);
            panel._panelOpenRaf = null;
        }
        panel._panelDragActive = false;
        panel.classList.remove("panel-closing", "panel-closing-down");
        panel.style.removeProperty("left");
        panel.style.removeProperty("top");
        panel.style.removeProperty("right");
        panel.style.removeProperty("bottom");
        panel.style.removeProperty("transform");
        panel.style.removeProperty("animation");
    }

    window.resetFloatingPanelPosition = resetFloatingPanelPosition;

    document.addEventListener("DOMContentLoaded", function () {

        /* ── Apply saved speed immediately ──────────────────────── */
        const saved = parseInt(localStorage.getItem(STORAGE_KEY) || DEFAULT_SPEED);
        applyAnimMult(saved);

        /* ── Appearance slider ───────────────────────────────────── */
        const slider = document.getElementById("animSpeedSlider");
        const valEl  = document.getElementById("animSpeedVal");

        function updateSliderFill(s, val) {
            // Set a CSS custom property on the element — CSS handles the gradient
            s.style.setProperty("--slider-fill", val + "%");
        }

        function sliderValueToX(s, val) {
            const rect = s.getBoundingClientRect();
            const min = parseInt(s.min) || 0;
            const max = parseInt(s.max) || 100;
            const ratio = (val - min) / Math.max(1, (max - min));
            const thumbSize = 15;
            const travel = Math.max(0, rect.width - thumbSize);
            return rect.left + (thumbSize / 2) + (travel * ratio);
        }

        function updateDefaultMarkerPosition(s, defaultVal) {
            const row = s ? s.closest(".anim-speed-row") : null;
            if (!s || !row || s.offsetWidth <= 0) return;
            const min = parseInt(s.min) || 0;
            const max = parseInt(s.max) || 100;
            const ratio = (defaultVal - min) / Math.max(1, (max - min));
            const thumbSize = 15;
            const travel = Math.max(0, s.offsetWidth - thumbSize);
            const markerX = s.offsetLeft + (thumbSize / 2) + (travel * ratio);
            const markerY = s.offsetTop + (s.offsetHeight / 2);
            row.style.setProperty("--anim-default-marker-x", markerX + "px");
            row.style.setProperty("--anim-default-marker-y", markerY + "px");
        }

        function getDefaultMarkerRow(s) {
            return s ? s.closest(".anim-speed-row") : null;
        }

        function isDefaultSnapEnabled(s) {
            return !!s && s.dataset.defaultSnapEnabled !== "0";
        }

        function ensureDefaultMarkerToggle(s, defaultVal) {
            const row = getDefaultMarkerRow(s);
            if (!s || !row) return null;

            let markerBtn = row.querySelector(".default-marker-toggle");
            if (!markerBtn) {
                markerBtn = document.createElement("button");
                markerBtn.type = "button";
                markerBtn.className = "default-marker-toggle";
                markerBtn.setAttribute("aria-label", "Toggle default snap");
                row.appendChild(markerBtn);

                markerBtn.addEventListener("click", (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    s.dataset.defaultSnapEnabled = isDefaultSnapEnabled(s) ? "0" : "1";
                    syncDefaultMarkerGlow(s, defaultVal);
                });
            }

            return markerBtn;
        }

        function syncDefaultMarkerGlow(s, defaultVal) {
            if (!s) return;
            const row = getDefaultMarkerRow(s);
            const markerBtn = ensureDefaultMarkerToggle(s, defaultVal);
            const snapEnabled = isDefaultSnapEnabled(s);
            const currentVal = parseInt(s.value);
            const isAtDefault = currentVal === defaultVal;
            const shouldGlow = snapEnabled && isAtDefault;

            if (row) {
                row.dataset.defaultSnapEnabled = snapEnabled ? "1" : "0";
                row.dataset.defaultSnapActive = shouldGlow ? "1" : "0";
            }

            if (markerBtn) {
                markerBtn.setAttribute("aria-pressed", snapEnabled ? "true" : "false");
                markerBtn.title = snapEnabled
                    ? "Default snap on. Click to turn it off."
                    : "Default snap off. Click to turn it on.";
            }

            if (shouldGlow) {
                s.dataset.snapped = "1";
            } else {
                delete s.dataset.snapped;
            }
        }

        function applySnapBehavior(s, defaultVal, onSnap) {
            const SNAP_ZONE_PX = 14;
            const SNAP_RELEASE_ZONE_PX = 36;
            let snapLocked = false;

            s.addEventListener("input", () => {
                if (!isDefaultSnapEnabled(s)) {
                    snapLocked = false;
                    syncDefaultMarkerGlow(s, defaultVal);
                    return;
                }

                const val = parseInt(s.value);
                const snapX = sliderValueToX(s, defaultVal);
                const currX = sliderValueToX(s, val);
                const dist = Math.abs(currX - snapX);

                if (snapLocked) {
                    if (dist < SNAP_RELEASE_ZONE_PX) {
                        s.value = defaultVal;
                        onSnap(defaultVal);
                        syncDefaultMarkerGlow(s, defaultVal);
                        return;
                    }

                    snapLocked = false;
                    syncDefaultMarkerGlow(s, defaultVal);
                    return;
                }

                if (dist < SNAP_ZONE_PX) {
                    snapLocked = true;
                    s.value = defaultVal;
                    onSnap(defaultVal);
                    syncDefaultMarkerGlow(s, defaultVal);
                    return;
                }

                syncDefaultMarkerGlow(s, defaultVal);
            });
        }

        if (slider) {
            const markerRow = slider.closest(".anim-speed-row");
            const markerLabel = document.getElementById("animSpeedLabelText");
            const refreshDefaultMarker = () => updateDefaultMarkerPosition(slider, DEFAULT_SPEED);

            slider.value = saved;
            if (valEl) valEl.textContent = saved + "%";
            updateSliderFill(slider, saved);
            refreshDefaultMarker();
            syncDefaultMarkerGlow(slider, DEFAULT_SPEED);
            requestAnimationFrame(refreshDefaultMarker);
            setTimeout(refreshDefaultMarker, 80);
            setTimeout(refreshDefaultMarker, 260);
            window.addEventListener("resize", refreshDefaultMarker);
            window.addEventListener("load", refreshDefaultMarker);

            if (document.fonts?.ready) {
                document.fonts.ready
                    .then(() => requestAnimationFrame(refreshDefaultMarker))
                    .catch(() => {});
            }

            if (typeof ResizeObserver !== "undefined") {
                const markerResizeObserver = new ResizeObserver(() => {
                    requestAnimationFrame(refreshDefaultMarker);
                });
                markerResizeObserver.observe(slider);
                if (markerRow) markerResizeObserver.observe(markerRow);
            }

            if (typeof MutationObserver !== "undefined") {
                const markerMutationObserver = new MutationObserver(() => {
                    requestAnimationFrame(refreshDefaultMarker);
                });
                markerMutationObserver.observe(document.documentElement, {
                    attributes: true,
                    attributeFilter: ["lang", "dir", "class"]
                });
                if (markerLabel) {
                    markerMutationObserver.observe(markerLabel, {
                        childList: true,
                        subtree: true,
                        characterData: true
                    });
                }
            }

            applySnapBehavior(slider, DEFAULT_SPEED, (snappedVal) => {
                applyAnimMult(snappedVal);
                if (valEl) valEl.textContent = snappedVal + "%";
                updateSliderFill(slider, snappedVal);
                localStorage.setItem(STORAGE_KEY, snappedVal);
            });

            slider.addEventListener("input", () => {
                const v = parseInt(slider.value);
                applyAnimMult(v);
                if (valEl) valEl.textContent = v + "%";
                updateSliderFill(slider, v);
                syncDefaultMarkerGlow(slider, DEFAULT_SPEED);
                localStorage.setItem(STORAGE_KEY, v);
            });
        }

        /* ── Independent opacity for todo/google-apps panels ───────────── */
        const DEFAULT_PANEL_OPACITY = 95;
        const PANEL_OPACITY_STEPS = [95, 75, 50, 25, 15];
        const PANEL_OPACITY_CONFIG = Object.freeze({
            todoContainer: "todoPanelSurfaceAlpha",
            iconContainer: "googleAppsPanelSurfaceAlpha",
            shortcutIconPopover: "shortcutIconPanelSurfaceAlpha"
        });

        function clampPanelOpacity(val) {
            const parsed = parseInt(val, 10);
            if (!Number.isFinite(parsed)) return DEFAULT_PANEL_OPACITY;
            return Math.max(
                PANEL_OPACITY_STEPS[PANEL_OPACITY_STEPS.length - 1],
                Math.min(PANEL_OPACITY_STEPS[0], parsed)
            );
        }

        function getNearestPanelOpacityStep(val) {
            const clamped = clampPanelOpacity(val);
            return PANEL_OPACITY_STEPS.reduce((closest, current) => (
                Math.abs(current - clamped) < Math.abs(closest - clamped) ? current : closest
            ), PANEL_OPACITY_STEPS[0]);
        }

        function getPanelOpacityButton(panel) {
            return panel ? panel.querySelector(".panel-opacity-btn") : null;
        }

        function getPanelOpacityStorageKey(panel) {
            if (!panel || !panel.id) return null;
            return PANEL_OPACITY_CONFIG[panel.id] || null;
        }

        function applyFloatingPanelOpacity(panel, alpha) {
            if (!panel) return;
            const clamped = getNearestPanelOpacityStep(alpha);
            const borderAlpha = Math.min(100, clamped + 8);
            panel.style.setProperty("--floating-panel-surface-alpha", `${clamped}%`);
            panel.style.setProperty("--floating-panel-border-alpha", `${borderAlpha}%`);

            const btn = getPanelOpacityButton(panel);
            if (btn) {
                btn.dataset.opacityLevel = String(clamped);
                btn.title = `Panel opacity ${clamped}%`;
                btn.setAttribute("aria-label", `Panel opacity ${clamped}%`);
            }
        }

        function cycleFloatingPanelOpacity(panel) {
            const storageKey = getPanelOpacityStorageKey(panel);
            if (!storageKey) return;
            const current = getNearestPanelOpacityStep(
                localStorage.getItem(storageKey) || DEFAULT_PANEL_OPACITY
            );
            const currentIndex = PANEL_OPACITY_STEPS.indexOf(current);
            const next = PANEL_OPACITY_STEPS[(currentIndex + 1) % PANEL_OPACITY_STEPS.length];
            localStorage.setItem(storageKey, String(next));
            applyFloatingPanelOpacity(panel, next);
        }

        const panelOpacityButtons = document.querySelectorAll(".panel-opacity-btn");
        panelOpacityButtons.forEach((btn) => {
            btn.addEventListener("mousedown", (e) => {
                e.stopPropagation();
            });
            btn.addEventListener("click", (e) => {
                e.preventDefault();
                e.stopPropagation();
                const panel = document.getElementById(btn.dataset.panelTarget) ||
                    btn.closest("#todoContainer, #iconContainer, #shortcutIconPopover");
                cycleFloatingPanelOpacity(panel);
            });
        });

        Object.entries(PANEL_OPACITY_CONFIG).forEach(([panelId, storageKey]) => {
            const panel = document.getElementById(panelId);
            if (!panel) return;
            const savedOpacity = getNearestPanelOpacityStep(
                localStorage.getItem(storageKey) || DEFAULT_PANEL_OPACITY
            );
            localStorage.setItem(storageKey, String(savedOpacity));
            applyFloatingPanelOpacity(
                panel,
                savedOpacity
            );
        });

        /* ── Make todo panel draggable ───────────────────────────── */
        const todoContainer = document.getElementById("todoContainer");
        const todoDragBar   = document.getElementById("todoDragBar");
        if (todoContainer && todoDragBar) makeDraggable(todoContainer, todoDragBar);

        /* ── Make google-apps panel draggable ────────────────────── */
        const iconContainer    = document.getElementById("iconContainer");
        const googleAppsDragBar = document.getElementById("googleAppsDragBar");
        if (iconContainer && googleAppsDragBar) makeDraggable(iconContainer, googleAppsDragBar);

        /* ── Make editBookmarkModal draggable ────────────────────── */


        /* shadow-control close button is handled entirely in shadow-control.js */

        /* ── Patch edit bookmark modal close ─────────────────────── */
        const editBookmarkModal = document.getElementById("editBookmarkModal");

        function closeBookmarkModal() {
            if (!editBookmarkModal || editBookmarkModal.style.display === "none") return;
            if (typeof window.closeEditBookmarkModal === "function") {
                window.closeEditBookmarkModal();
                return;
            }
            const dur = typeof window.getPanelAnimDur === "function"
                ? Math.max(160, Math.round(window.getPanelAnimDur()))
                : 220;
            clearTimeout(editBookmarkModal._closeTimer);
            editBookmarkModal.style.setProperty("--edit-bookmark-modal-dur", `${dur}ms`);
            editBookmarkModal.classList.remove("edit-bookmark-modal-opening");
            void editBookmarkModal.offsetWidth;
            editBookmarkModal.classList.add("edit-bookmark-modal-closing");
            editBookmarkModal._closeTimer = setTimeout(() => {
                editBookmarkModal.classList.remove("edit-bookmark-modal-closing");
                editBookmarkModal.style.display = "none";
            }, Math.round(dur * 0.95) + 40);
        }
        window._closeBookmarkModal = closeBookmarkModal;

        // Hook cancel button
        const cancelBtn = document.getElementById("cancelBookmarkEdit");
        if (cancelBtn) {
            cancelBtn.addEventListener("click", function(e) {
                e.stopImmediatePropagation();
                closeBookmarkModal();
            }, true);
        }
        // Hook backdrop click
        if (editBookmarkModal) {
            editBookmarkModal.addEventListener("click", function(e) {
                if (e.target === editBookmarkModal) closeBookmarkModal();
            });
        }

        /* ── Patch AI tools modal close ─────────────────────────── */
        const aiModal   = document.getElementById("aiToolsSettingsModal");
        const aiOverlay = document.getElementById("aiToolsSettingsOverlay");
        function closeAiModal() {
            if (!aiModal || aiModal.style.display === "none") return;
            // Always delegate to the proper animated close from ai-tools.js
            if (typeof window.closeAIToolsSettings === "function") {
                window.closeAIToolsSettings();
            } else {
                // Fallback: use the CSS animation on the modal itself
                const mult = parseFloat(
                    getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")
                ) || 1;
                const closeDur = Math.round(260 * 0.9 * mult);
                aiModal.classList.remove("ai-modal-opening");
                aiModal.classList.add("ai-modal-closing");
                if (aiOverlay) {
                    aiOverlay.style.transition = `opacity ${closeDur}ms ease`;
                    aiOverlay.style.opacity = "0";
                }
                setTimeout(() => {
                    aiModal.classList.remove("ai-modal-closing");
                    aiModal.style.display = "none";
                    if (aiOverlay) {
                        aiOverlay.style.display = "none";
                        aiOverlay.style.opacity = "";
                        aiOverlay.style.transition = "";
                    }
                }, closeDur + 30);
            }
        }
        window._closeAiModal = closeAiModal;

        if (aiOverlay) {
            aiOverlay.addEventListener("click", function(e) {
                e.stopImmediatePropagation();
                closeAiModal();
            }, true);
        }

    }); // DOMContentLoaded

})();


(function () {
    "use strict";

    const STORAGE_KEY       = "shadowControl";
    const DEFAULT_INTENSITY = 50;
    const DEFAULT_VARIANT   = "dark"; 
    const DEFAULT_SPEED     = 50;     
    const UI_TRANSLATION_CACHE_PREFIX = "ui_mt_";
    const ALL_GROUPS = [
        "search","widgets",
        "modals","contextmenu","buttons","shortcuts",
        "bookmarks","menu"
    ];
    const PRESETS = {
        all:       [...ALL_GROUPS],
        none:      [],
        important: ["search","modals","contextmenu","menu"],
        cards:     ["shortcuts","widgets","buttons","bookmarks"],
        large:     ["modals","contextmenu","menu"],
        minimal:   ["search"],
    };
    const GROUP_MAP = {
        search:"Search",
        widgets:"Widgets", modals:"Modals", contextmenu:"ContextMenu",
        buttons:"Buttons", shortcuts:"Shortcuts",
        bookmarks:"Bookmarks", menu:"Menu"
    };

    const COLOR_VARIANTS = {
        dark:    "var(--darkColor-blue)",
        darker:  "var(--darkerColor-blue)",
        bg:      "var(--bg-color-blue)",
    };
    const COLOR_VARIANT_ORDER = ["dark", "darker", "bg"];
    const CUSTOM_VARIANT_PREFIX = "custom:";
    const MAX_CUSTOM_SHADOW_COLORS = 3;
    const MIN_SWATCH_BG_CONTRAST = 1.55;

    const ANIM_PRESETS = {
        none:       { label: "Off", key: "shadowAnimOff" },
        pulse:      { label: "Pulse", key: "shadowAnimPulse" },
        breathe:    { label: "Breathe", key: "shadowAnimBreathe" },
        orbit:      { label: "Orbit", key: "shadowAnimOrbit" },
        colorshift: { label: "Color Shift", key: "shadowAnimColorShift" },
        wave:       { label: "Wave", key: "shadowAnimWave" },
        flicker:    { label: "Flicker", key: "shadowAnimFlicker" },
        thunder:    { label: "Thunder", key: "shadowAnimThunder" },
    };

    
    function _t(key, fb) {
        try {
            const lang = typeof currentLanguage !== "undefined" ? currentLanguage : "en";
            return (translations[lang]?.[key] || translations["en"]?.[key]) || fb;
        } catch(e) { return fb; }
    }

    function getUiTranslationCacheKey(lang, text) {
        return `${UI_TRANSLATION_CACHE_PREFIX}${lang}_${text}`;
    }

    async function translateUiText(text, targetLang) {
        const lang = (targetLang || "en");
        if (!text || lang === "en") return text;

        const cacheKey = getUiTranslationCacheKey(lang, text);
        const cached = localStorage.getItem(cacheKey);
        if (cached) return cached;

        try {
            const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${encodeURIComponent(lang)}&dt=t&q=${encodeURIComponent(text)}`;
            const response = await fetch(url);
            if (!response.ok) throw new Error(`Translation failed with status ${response.status}`);
            const data = await response.json();
            const translatedText = Array.isArray(data?.[0])
                ? data[0].map(chunk => chunk?.[0] || "").join("").trim()
                : "";

            if (translatedText) {
                localStorage.setItem(cacheKey, translatedText);
                return translatedText;
            }
        } catch (error) {
            console.error("Error translating shadow control label:", error);
        }

        return text;
    }

    function applyAnimButtonTranslations() {
        const lang = typeof currentLanguage !== "undefined" ? currentLanguage : "en";

        document.querySelectorAll(".shadow-anim-btn[data-anim]").forEach(btn => {
            const preset = ANIM_PRESETS[btn.dataset.anim];
            if (!preset) return;

            const translatedLabel = _t(preset.key, preset.label);
            btn.textContent = translatedLabel;
            btn.title = translatedLabel;

            if (lang === "en" || translatedLabel !== preset.label) {
                return;
            }

            const cacheKey = getUiTranslationCacheKey(lang, preset.label);
            const cachedLabel = localStorage.getItem(cacheKey);
            if (cachedLabel) {
                btn.textContent = cachedLabel;
                btn.title = cachedLabel;
                return;
            }

            translateUiText(preset.label, lang).then(dynamicLabel => {
                if (!dynamicLabel || dynamicLabel === preset.label) return;
                btn.textContent = dynamicLabel;
                btn.title = dynamicLabel;
            }).catch(function () {});
        });
    }

    
    function loadState() {
        try {
            const s = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
            if (s) {
                s.groups        = Array.isArray(s.groups)
                    ? s.groups.filter(g => ALL_GROUPS.includes(g))
                    : [...ALL_GROUPS];
                s.intensity     = (s.intensity  != null) ? s.intensity  : DEFAULT_INTENSITY;
                s.hoverOnly     = s.hoverOnly    ?? false;
                s.colorVariant  = s.colorVariant || DEFAULT_VARIANT;
                s.customColors  = Array.isArray(s.customColors)
                    ? s.customColors.filter(c => /^#([0-9a-f]{6})$/i.test(String(c || "").trim())).slice(0, MAX_CUSTOM_SHADOW_COLORS)
                    : [];
                if (!COLOR_VARIANTS[s.colorVariant] && !String(s.colorVariant).startsWith(CUSTOM_VARIANT_PREFIX)) {
                    s.colorVariant = DEFAULT_VARIANT;
                }
                if (String(s.colorVariant).startsWith(CUSTOM_VARIANT_PREFIX)) {
                    const idx = parseInt(String(s.colorVariant).slice(CUSTOM_VARIANT_PREFIX.length), 10);
                    if (!Number.isInteger(idx) || idx < 0 || idx >= s.customColors.length) {
                        s.colorVariant = DEFAULT_VARIANT;
                    }
                }
                s.animation     = s.animation    || "none";
                if (s.animation === "rainbow") s.animation = "colorshift";
                s.speed         = (s.speed       != null) ? s.speed     : DEFAULT_SPEED;
                s.shadowsEnabled = s.shadowsEnabled ?? true;
                return s;
            }
        } catch(e) {}
        return {
            groups: [...ALL_GROUPS],
            intensity: DEFAULT_INTENSITY,
            hoverOnly: false,
            colorVariant: DEFAULT_VARIANT,
            customColors: [],
            animation: "none",
            speed: DEFAULT_SPEED,
            shadowsEnabled: true
        };
    }
    function saveState(s) { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); }

    function resolveCssColorToRgb(colorExpr) {
        if (!colorExpr) return null;
        const probe = document.createElement("span");
        probe.style.cssText = "position:absolute;visibility:hidden;pointer-events:none;color:transparent;";
        probe.style.color = colorExpr;
        document.body.appendChild(probe);
        const resolved = getComputedStyle(probe).color;
        document.body.removeChild(probe);
        const m = resolved.match(/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
        if (!m) return null;
        return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)];
    }

    function relativeLuminance(rgb) {
        if (!rgb) return 0;
        const srgb = rgb.map(v => {
            const c = v / 255;
            return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
        });
        return 0.2126 * srgb[0] + 0.7152 * srgb[1] + 0.0722 * srgb[2];
    }

    function contrastRatio(rgbA, rgbB) {
        const l1 = relativeLuminance(rgbA);
        const l2 = relativeLuminance(rgbB);
        const hi = Math.max(l1, l2);
        const lo = Math.min(l1, l2);
        return (hi + 0.05) / (lo + 0.05);
    }

    function rgbDistance(rgbA, rgbB) {
        if (!rgbA || !rgbB) return 0;
        const dr = rgbA[0] - rgbB[0];
        const dg = rgbA[1] - rgbB[1];
        const db = rgbA[2] - rgbB[2];
        return Math.sqrt((dr * dr) + (dg * dg) + (db * db));
    }

    function buildReadableSwatchColor(baseColorExpr, panelBgExpr) {
        const baseRgb = resolveCssColorToRgb(baseColorExpr);
        const bgRgb = resolveCssColorToRgb(panelBgExpr);
        if (!baseRgb || !bgRgb) return baseColorExpr;

        if (contrastRatio(baseRgb, bgRgb) >= MIN_SWATCH_BG_CONTRAST) return baseColorExpr;

        const bgLum = relativeLuminance(bgRgb);
        const mixTarget = bgLum < 0.48 ? "#ffffff" : "#000000";
        const steps = [18, 28, 40, 52, 64, 76, 88];
        for (const pct of steps) {
            const candidate = `color-mix(in srgb, ${baseColorExpr} ${pct}%, ${mixTarget} ${100 - pct}%)`;
            const candidateRgb = resolveCssColorToRgb(candidate);
            if (candidateRgb && contrastRatio(candidateRgb, bgRgb) >= MIN_SWATCH_BG_CONTRAST) {
                return candidate;
            }
        }

        return mixTarget;
    }

    function getAdaptiveVariantExpressions() {
        const panelBg = getComputedStyle(document.documentElement).getPropertyValue("--bg-color-blue").trim() || "var(--bg-color-blue)";
        return {
            dark: buildReadableSwatchColor("var(--darkColor-blue)", panelBg),
            darker: buildReadableSwatchColor("var(--darkerColor-blue)", panelBg),
            bg: buildReadableSwatchColor("var(--bg-color-blue)", panelBg),
        };
    }

    function getVariantColorExpression(variant, customColorsOverride) {
        if (String(variant || "").startsWith(CUSTOM_VARIANT_PREFIX)) {
            const idx = parseInt(String(variant).slice(CUSTOM_VARIANT_PREFIX.length), 10);
            const customColors = customColorsOverride || (Array.isArray(_state?.customColors) ? _state.customColors : []);
            return customColors[idx] || null;
        }
        const adaptivePalette = getAdaptiveVariantExpressions();
        return adaptivePalette[variant] || COLOR_VARIANTS[variant] || COLOR_VARIANTS[DEFAULT_VARIANT];
    }

    function resolveColor(variant, customColors) {
        const colorExpr = getVariantColorExpression(variant, customColors);
        if (!colorExpr) return null;

        const root = document.documentElement;

        // PRIORITY 1: read the inline style on <html> — this is set by theme.js to the
        // FINAL target color immediately (before any @property animation). This means
        // we always get the destination color, not a mid-animation interpolated value,
        // which was causing the shadow to "stick" while themes transitioned.
        const inlineVarMatch = colorExpr.match(/^var\((--[^)]+)\)$/);
        if (inlineVarMatch) {
            const inlineVal = root.style.getPropertyValue(inlineVarMatch[1]).trim();
            if (inlineVal && !inlineVal.startsWith("var(")) {
                const mInline = inlineVal.match(/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
                if (mInline) return rgbToHex(parseInt(mInline[1]), parseInt(mInline[2]), parseInt(mInline[3]));
                if (inlineVal.startsWith("#")) return inlineVal;
            }
        }

        // FALLBACK: DOM-based getComputedStyle (for predefined themes where vars
        // are set via CSS rules, not inline styles)
        const tmp = document.createElement("div");
        tmp.style.cssText = "position:absolute;visibility:hidden;pointer-events:none";
        tmp.style.setProperty("color", colorExpr);
        document.body.appendChild(tmp);
        const resolved = getComputedStyle(tmp).color;
        document.body.removeChild(tmp);

        const m = resolved.match(/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
        if (m) return rgbToHex(parseInt(m[1]), parseInt(m[2]), parseInt(m[3]));
        return "#2979E8";
    }

    function getShadowColor(variant, customColors) {
        return resolveColor(variant || DEFAULT_VARIANT, customColors);
    }

    
    function buildBoxShadow(size, color, intensity, offX, offY) {
        if (intensity <= 0) return "none";
        const f = intensity / 100;
        const blur  = { sm:12, md:24, lg:44, xl:64 }[size];
        const blur2 = { sm:5,  md:10, lg:18, xl:26 }[size];
        const tintPct = color ? Math.round(8 + f * 38) : 0;
        const alpha1  = (0.08 + f * 0.22).toFixed(3);
        const alpha2  = (0.04 + f * 0.12).toFixed(3);
        const b1 = Math.round(blur  * f);
        const b2 = Math.round(blur2 * f);
        const ox = Math.round(offX || 0);
        const oy = Math.round(offY || 0);
        // Use var(--shadow-tint-color) instead of the literal hex so the browser
        // animates the color via the @property CSS transition — smooth theme switching.
        const tintSrc = color ? "var(--shadow-tint-color)" : null;
        const l1 = tintSrc
            ? `${ox}px ${oy}px ${b1}px color-mix(in srgb, ${tintSrc} ${tintPct}%, rgba(0,0,0,${alpha1}))`
            : `${ox}px ${oy}px ${b1}px rgba(0,0,0,${alpha1})`;
        const l2 = `0 0 ${b2}px rgba(0,0,0,${alpha2})`;
        return `${l1}, ${l2}`;
    }

    function buildCenteredBoxShadow(color, intensity, scale, offX, offY) {
        if (intensity <= 0) return "none";
        const f = intensity / 100;
        const sc = scale || 1;
        const blur1 = Math.round((4 + f * 22) * sc);
        const blur2 = Math.round((8 + f * 40) * sc);
        const spread1 = Math.round((-2 - f * 1) * sc);
        const spread2 = Math.round((-5 - f * 2) * sc);
        const tintPct1 = color ? Math.round(8 + f * 38) : 0;
        const tintPct2 = color ? Math.round(14 + f * 44) : 0;
        const alpha1 = (0.06 + f * 0.18).toFixed(3);
        const alpha2 = (0.08 + f * 0.20).toFixed(3);
        const ox = Math.round(offX || 0);
        const oy = Math.round(offY || 0);
        const tintSrc = color ? "var(--shadow-tint-color)" : null;
        const l1 = tintSrc
            ? `${ox}px ${oy}px ${blur1}px ${spread1}px color-mix(in srgb, ${tintSrc} ${tintPct1}%, rgba(0,0,0,${alpha1}))`
            : `${ox}px ${oy}px ${blur1}px ${spread1}px rgba(0,0,0,${alpha1})`;
        const l2 = tintSrc
            ? `${ox}px ${oy}px ${blur2}px ${spread2}px color-mix(in srgb, ${tintSrc} ${tintPct2}%, rgba(0,0,0,${alpha2}))`
            : `${ox}px ${oy}px ${blur2}px ${spread2}px rgba(0,0,0,${alpha2})`;
        return `${l1}, ${l2}`;
    }

    
    
    const DROP_SHADOW_ZERO = "drop-shadow(0px 0px 0px rgba(0,0,0,0))";

    function buildDropShadowZero(color, offX, offY) {
        const ox = Math.round(offX || 0);
        const oy = (offY != null) ? Math.round(offY) : 0;
        return color
            ? `drop-shadow(${ox}px ${oy}px 0px color-mix(in srgb, var(--shadow-tint-color) 1%, rgba(0,0,0,0)))`
            : `drop-shadow(${ox}px ${oy}px 0px rgba(0,0,0,0))`;
    }

    function buildDropShadow(color, intensity, scale, offX, offY) {
        if (intensity <= 0) return buildDropShadowZero(color, offX, offY);
        const f    = intensity / 100;
        const sc   = scale || 1;
        const blur = Math.round(26 * sc * f);
        const tintPct = color ? Math.round(8 + f * 38) : 0;
        const alpha   = (0.08 + f * 0.22).toFixed(3);
        const ox = Math.round(offX || 0);
        const oy = (offY != null) ? Math.round(offY) : 0;
        // Use var(--shadow-tint-color) for animatable color via @property transition
        const tintSrc = color ? "var(--shadow-tint-color)" : null;
        return tintSrc
            ? `drop-shadow(${ox}px ${oy}px ${blur}px color-mix(in srgb, ${tintSrc} ${tintPct}%, rgba(0,0,0,${alpha})))`
            : `drop-shadow(${ox}px ${oy}px ${blur}px rgba(0,0,0,${alpha}))`;
    }

    
    const BOX_SHADOW_CLOCK_ZERO   = "0 0 0 0 transparent";
    const BOX_SHADOW_WEATHER_ZERO = "0 0 0 0 transparent";

    function buildClockBoxShadow(color, intensity, isWeather) {
        if (intensity <= 0) return isWeather ? BOX_SHADOW_WEATHER_ZERO : BOX_SHADOW_CLOCK_ZERO;
        const f = intensity / 100;
        const blur1 = Math.round((isWeather ? 36 : 32) * f);
        const blur2 = Math.round((isWeather ? 12 : 10) * f);
        const oy1 = 0;
        const oy2 = 0;
        const tintPct = color ? Math.round(10 + f * (isWeather ? 30 : 25)) : 0;
        const alpha1 = (0.08 + f * (isWeather ? 0.22 : 0.20)).toFixed(3);
        const alpha2 = (0.04 + f * 0.12).toFixed(3);
        // Use var(--shadow-tint-color) for animatable color via @property transition
        const tintSrc = color ? "var(--shadow-tint-color)" : null;
        const l1 = tintSrc
            ? `0 ${oy1}px ${blur1}px color-mix(in srgb, ${tintSrc} ${tintPct}%, rgba(0,0,0,${alpha1}))`
            : `0 ${oy1}px ${blur1}px rgba(0,0,0,${alpha1})`;
        const l2 = `0 ${oy2}px ${blur2}px rgba(0,0,0,${alpha2})`;
        return `${l1}, ${l2}`;
    }

    
    function isCSSInvertedDarkMode() {
        const pref = localStorage.getItem("preferredTheme") || "light";
        const sysDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        const isDark = pref === "dark" || (pref === "system" && sysDark);
        if (!isDark) return false;
        const isDualActive   = document.body.getAttribute("data-dual-theme")   === "active";
        const isCustomActive = document.body.getAttribute("data-custom-theme") === "active";
        return !isDualActive && !isCustomActive;
    }

    
    function applyShadows(state, animOverride) {
        const enabled = state.shadowsEnabled !== false;
        const isAnimationActive = !!(state.animation && state.animation !== "none");
        const effectiveHoverOnly = !!state.hoverOnly && !isAnimationActive;
        document.body.classList.toggle("shadow-master-off", !enabled);
        if (!enabled) {
            ALL_GROUPS.forEach(g => document.body.classList.remove("no-shadow-" + g));
            document.body.classList.remove("shadow-hover-only");
            ["sm","md","lg","xl"].forEach(s => {
                document.body.style.setProperty("--theme-shadow-" + s, "none");
            });
            document.body.style.setProperty("--theme-shadow-ai-pill", "none");
            document.body.style.setProperty("--theme-shadow-ai-pill-hover", "none");
            document.body.style.setProperty("--theme-drop-shadow", DROP_SHADOW_ZERO);
            document.body.style.setProperty("--theme-drop-shadow-lg", DROP_SHADOW_ZERO);
            document.body.style.setProperty("--theme-drop-shadow-clock", DROP_SHADOW_ZERO);
            document.body.style.setProperty("--theme-drop-shadow-weather", DROP_SHADOW_ZERO);
            document.body.style.setProperty("--theme-dot-shadow-sm", "none");
            document.body.style.setProperty("--theme-dot-shadow-md", "none");
            ["blur-sm","blur-md","blur-sm2","blur-md2","spread","offset-x"].forEach(k =>
                document.body.style.setProperty("--dot-" + k, "0px"));
            document.body.style.setProperty("--dot-alpha2", "0");
            return;
        }

        const intensity = Math.max(0, Math.min(100, state.intensity ?? DEFAULT_INTENSITY));
        const variant   = state.colorVariant || DEFAULT_VARIANT;
        const color     = getShadowColor(variant, state.customColors);
        const inverted  = isCSSInvertedDarkMode();

        // Keep theme changes instant; picker dragging updates frequently enough to feel smooth.
        if (color) {
            document.documentElement.style.setProperty("--shadow-tint-color", color);
        }

        const isBlackTheme = document.documentElement.classList.contains("black-theme") ||
                             document.body.classList.contains("black-theme");

        ALL_GROUPS.forEach(g =>
            document.body.classList.toggle("no-shadow-" + g, !state.groups.includes(g))
        );

        const _wasHoverOnly = applyShadows._prevHoverOnly;
        applyShadows._prevHoverOnly = effectiveHoverOnly;

        // ── Animated transition for clock/weather when toggling hover mode ──────
        //
        // The CSS rule for body.shadow-hover-only forces `transition:none` on the
        // clock/weather filter elements, which means toggling the class instantly
        // snaps their filter to 0 or to full — no animation.
        //
        // We intercept both directions and drive the animation in JS:
        //
        //  Always On → Hover Only (_enteringHoverMode):
        //    1. Capture current computed filter (full shadow value).
        //    2. Set it as inline style so the element keeps its shadow after the
        //       class is added (inline style beats CSS class rule).
        //    3. Add the class (CSS says filter:0 + transition:none, but inline wins).
        //    4. rAF: set inline transition + animate filter → DROP_SHADOW_ZERO.
        //    5. After fade-out: remove inline filter & transition — JS hover takes over.
        //
        //  Hover Only → Always On (_leavingHoverMode):
        //    1. Remove the class (CSS filter:0 + transition:none gone).
        //    2. Elements are at computed filter:0 from CSS class.
        //    3. Snap: freeze transition, clear inline filter → CSS var wins instantly.
        //    4. rAF: restore CSS transition for future changes.

        const _enteringHoverMode = (!_wasHoverOnly && effectiveHoverOnly);
        const _leavingHoverMode  = (!!_wasHoverOnly && !effectiveHoverOnly);

        const _clockWeatherEls = Array.from(document.querySelectorAll(
            "#analogClock, #digitalClock, .rightDiv .topDiv .rAndakar .weather-bg-filter"
        ));

        if (_enteringHoverMode) {
            // Capture current computed filter BEFORE the class changes anything
            var _capturedFilters = _clockWeatherEls.map(function(el) {
                return getComputedStyle(el).getPropertyValue("filter") || DROP_SHADOW_ZERO;
            });
            // Freeze current filter as inline so adding the class doesn't snap to 0
            _clockWeatherEls.forEach(function(el, i) {
                el.style.setProperty("filter", _capturedFilters[i]);
                el.style.setProperty("transition", "none");
            });
        }

        // ── Hover Only → Always On: establish box-shadow transition BEFORE toggling class ──
        //
        // The box-shadow elements have `box-shadow: none !important; transition: box-shadow ...`
        // only while `shadow-hover-only` is present. The moment that class is removed, both the
        // box-shadow:none AND the transition disappear simultaneously — so the browser sees no
        // transition and snaps the shadow in instantly.
        //
        // Fix: add `shadow-exiting-hover` (CSS provides transition only, no box-shadow:none)
        // and force a style flush (offsetWidth) so the browser records the current computed state.
        // Then when we remove `shadow-hover-only`, the CSS-computed box-shadow changes from none
        // to the real value while the transition rule (from shadow-exiting-hover) is already live —
        // the browser sees a change on a transitioned property and animates it smoothly.
        if (_leavingHoverMode) {
            document.body.classList.add("shadow-exiting-hover");
            void document.body.offsetWidth; // force style flush to record box-shadow:none state
        }

        document.body.classList.toggle("shadow-hover-only", effectiveHoverOnly);

        if (_enteringHoverMode) {
            // rAF: release transition freeze, then animate filter → 0 over _hoverFadeOutMs
            requestAnimationFrame(function() {
                var dur = (_hoverFadeOutMs / 1000).toFixed(2) + "s";
                _clockWeatherEls.forEach(function(el) {
                    el.style.setProperty("transition", "filter " + dur + " ease");
                    el.style.setProperty("filter", DROP_SHADOW_ZERO);
                });
                // After animation ends: remove inline styles — JS hover takes over
                setTimeout(function() {
                    _clockWeatherEls.forEach(function(el) {
                        el.style.removeProperty("filter");
                        el.style.removeProperty("transition");
                    });
                }, _hoverFadeOutMs + 50);
            });

        } else if (_leavingHoverMode) {
            // Hover Only → Always On: animate from 0 → full shadow over _hoverFadeInMs.
            //
            // WHITE FLASH FIX: animating from DROP_SHADOW_ZERO = rgba(0,0,0,0) to a
            // color-mix target causes the browser to interpolate through intermediate
            // hues (often appearing white). Fix: build a "zero" start value using the
            // SAME color as the target but with intensity=0 — so the interpolation only
            // changes blur/alpha, never hue.
            var _clockTarget   = document.body.style.getPropertyValue("--theme-drop-shadow-clock")   || DROP_SHADOW_ZERO;
            var _weatherTarget = document.body.style.getPropertyValue("--theme-drop-shadow-weather") || DROP_SHADOW_ZERO;

            // Build a color-matched zero: same shadow string but intensity=0 → blur=0, alpha≈0
            // buildDropShadow(color, 0, scale) returns DROP_SHADOW_ZERO, so we inline the
            // zero-intensity formula: drop-shadow(0 0 0px color-mix(…, COLOR 10%, rgba(0,0,0,0.10)))
            // Simpler: extract the color token from the target string and build a transparent version.
            function _makeZeroFrom(targetStr) {
                // The regex `color-mix\([^)]+\)` fails on nested parens like
                // color-mix(in srgb, var(--shadow-tint-color) 10%, rgba(0,0,0,0.35))
                // because [^)]+ stops at the first ) inside rgba().
                // Falling back to DROP_SHADOW_ZERO = rgba(0,0,0,0) means the browser
                // interpolates from a hue-less transparent → colored shadow, passing
                // through white mid-animation.
                //
                // Fix: if the target uses color-mix, anchor the zero to the SAME
                // var(--shadow-tint-color) reference so interpolation only changes
                // blur/alpha — never hue — and the white flash never occurs.
                if (targetStr.indexOf("color-mix") !== -1) {
                    // Tinted shadow: zero = same color reference, blur=0, alpha=0
                    return "drop-shadow(0px 0px 0px color-mix(in srgb, var(--shadow-tint-color) 10%, rgba(0,0,0,0)))";
                }
                // Non-tinted (neutral/plain rgba) shadow: transparent black is safe
                return DROP_SHADOW_ZERO;
            }

            var _clockZero   = _makeZeroFrom(_clockTarget);
            var _weatherZero = _makeZeroFrom(_weatherTarget);

            // Step 1: pin each element at the color-matched zero (no hue shift later)
            _clockWeatherEls.forEach(function(el) {
                var isWeather = el.classList.contains("weather-bg-filter");
                el.style.setProperty("transition", "none");
                el.style.setProperty("filter", isWeather ? _weatherZero : _clockZero);
            });

            // Commit zero-state first, then start transition immediately so clock/weather
            // re-appear in sync with other elements when returning to Always On.
            void document.body.offsetWidth;
            var dur = (_hoverFadeInMs / 1000).toFixed(2) + "s";
            _clockWeatherEls.forEach(function(el) {
                var isWeather = el.classList.contains("weather-bg-filter");
                var target = isWeather ? _weatherTarget : _clockTarget;
                el.style.setProperty("transition", "filter " + dur + " ease");
                el.style.setProperty("filter", target);
            });
            // After animation ends — hand control back to CSS var
            // and remove the exit-transition helper class
            setTimeout(function() {
                _clockWeatherEls.forEach(function(el) {
                    el.style.removeProperty("filter");
                    el.style.removeProperty("transition");
                });
                document.body.classList.remove("shadow-exiting-hover");
            }, _hoverFadeInMs + 50);

        } else if (!effectiveHoverOnly) {
            // Already in Always On — clear any stale inline filter (normal tick)
            _clockWeatherEls.forEach(function(el) {
                el.style.removeProperty("filter");
            });
        }

        if (intensity <= 0) {
            ["sm","md","lg","xl"].forEach(s => {
                document.body.style.setProperty("--theme-shadow-" + s, "none");
            });
            document.body.style.setProperty("--theme-shadow-ai-pill", "none");
            document.body.style.setProperty("--theme-shadow-ai-pill-hover", "none");
            document.body.style.setProperty("--theme-drop-shadow",    buildDropShadow(color, 0, 0.8, 0, 0));
            document.body.style.setProperty("--theme-drop-shadow-lg", buildDropShadow(color, 0, 1.4, 0, 0));
            document.body.style.setProperty("--theme-drop-shadow-clock",   buildDropShadow(color, 0, 1.0, 0, 0));
            document.body.style.setProperty("--theme-drop-shadow-weather", buildDropShadow(color, 0, 1.1, 0, 0));
            document.body.style.setProperty("--theme-dot-shadow-sm", "none");
            document.body.style.setProperty("--theme-dot-shadow-md", "none");
            ["blur-sm","blur-md","blur-sm2","blur-md2","spread","offset-x"].forEach(k =>
                document.body.style.setProperty("--dot-" + k, "0px"));
            document.body.style.setProperty("--dot-alpha2", "0");
            return;
        }






        let shadowColor;
        if (isBlackTheme) {
            shadowColor = color;
        } else if (inverted) {
            shadowColor = color;
        } else {
            shadowColor = color;
        }
        const anim = animOverride || {};

        const animatedColor = anim.color || shadowColor;

        // COLORSHIFT FIX: buildBoxShadow uses var(--shadow-tint-color) as its
        // color source (via color-mix). We must update --shadow-tint-color to
        // the animatedColor (the shifted hue) so box shadows reflect the cycle.
        // This overrides the base-color write above whenever anim.color is set.
        if (animatedColor) {
            document.documentElement.style.setProperty("--shadow-tint-color", animatedColor);
        }

        ["sm","md","lg","xl"].forEach(size =>
            document.body.style.setProperty(
                "--theme-shadow-" + size,
                buildBoxShadow(size, animatedColor, anim.intensity != null ? anim.intensity : intensity, anim.offX, anim.offY)
            )
        );
        document.body.style.setProperty(
            "--theme-shadow-ai-pill",
            buildCenteredBoxShadow(
                animatedColor,
                anim.intensity != null ? anim.intensity : intensity,
                1,
                anim.offX,
                anim.offY
            )
        );
        document.body.style.setProperty(
            "--theme-shadow-ai-pill-hover",
            buildCenteredBoxShadow(
                animatedColor,
                Math.min(100, (anim.intensity != null ? anim.intensity : intensity) + 12),
                1.2,
                anim.offX,
                anim.offY
            )
        );

        // Dot shadows — set only SHAPE variables on body.
        // COLOR is always resolved per-element from --dot-shadow-color (defined in CSS/JS per dot).
        // This guarantees every dot glows with its own color regardless of the global accent.
        const dotIntensity = anim.intensity != null ? anim.intensity : intensity;
        const dotF = Math.max(0, dotIntensity / 100);
        const dotOx = Math.round(anim.offX || 0);
        const dotOy = Math.round(anim.offY || 0);
        const dotAlpha2 = (0.08 + dotF * 0.12).toFixed(3);
        const dotSpread = Math.round(1 * dotF);
        const dotBlurSm  = dotIntensity <= 0 ? 0 : Math.round(10 * dotF);
        const dotBlurMd  = dotIntensity <= 0 ? 0 : Math.round(16 * dotF);
        const dotBlurSm2 = dotIntensity <= 0 ? 0 : Math.round(4  * dotF);
        const dotBlurMd2 = dotIntensity <= 0 ? 0 : Math.round(6  * dotF);
        document.body.style.setProperty("--dot-blur-sm",  dotBlurSm  + "px");
        document.body.style.setProperty("--dot-blur-md",  dotBlurMd  + "px");
        document.body.style.setProperty("--dot-blur-sm2", dotBlurSm2 + "px");
        document.body.style.setProperty("--dot-blur-md2", dotBlurMd2 + "px");
        document.body.style.setProperty("--dot-spread",   dotSpread  + "px");
        document.body.style.setProperty("--dot-offset-x", dotOx      + "px");
        document.body.style.setProperty("--dot-offset-y", dotOy      + "px");
        document.body.style.setProperty("--dot-alpha2",   dotAlpha2);
        // Disable --theme-dot-shadow-sm/md for dots (CSS drives color directly per element)
        document.body.style.setProperty("--theme-dot-shadow-sm", "unset");
        document.body.style.setProperty("--theme-dot-shadow-md", "unset");

        const dsColor = animatedColor;
        const dsOffY = anim.orbitExplicit ? anim.offY : null;
        const dsIntensity = anim.intensity != null ? anim.intensity : intensity;

        document.body.style.setProperty("--theme-drop-shadow",    buildDropShadow(dsColor, dsIntensity, 0.8,  anim.offX, dsOffY));
        document.body.style.setProperty("--theme-drop-shadow-lg", buildDropShadow(dsColor, dsIntensity, 1.4,  anim.offX, dsOffY));
        document.body.style.setProperty("--theme-drop-shadow-clock",   buildDropShadow(dsColor, Math.min(100, dsIntensity * 1.0), 1.0, anim.offX, dsOffY));
        document.body.style.setProperty("--theme-drop-shadow-weather", buildDropShadow(dsColor, Math.min(100, dsIntensity * 1.1), 1.1, anim.offX, dsOffY));
    }

    
    function applySpeed(speed) {
        const s = Math.max(1, Math.min(100, speed ?? DEFAULT_SPEED));
        const dur = (0.05 + ((100 - s) / 100) * 1.15).toFixed(2);
        // --sc-dur: shadow-control-only transition duration.
        // Does NOT affect --shadow-transition-dur (used by sidebar/menu box-shadow via --dur-4)
        // so the Shadow Speed slider ONLY controls shadow show/hide speed, nothing else.
        document.body.style.setProperty("--sc-dur", dur + "s");
        // JS hover fade timing uses same duration as CSS shadow transitions
        _hoverFadeInMs  = Math.round(parseFloat(dur) * 1000);
        _hoverFadeOutMs = Math.round(parseFloat(dur) * 1000 * 1.3);
    }

    // Hover fade timing (ms) — driven by Shadow Speed slider via applySpeed
    let _hoverFadeInMs  = 200;
    let _hoverFadeOutMs = 280;


    function getAnimPeriodMult(speed) {
        const s = Math.max(1, Math.min(100, speed ?? DEFAULT_SPEED));

        return 0.2 * Math.pow(15, (100 - s) / 99);
    }


    let _animFrame = null;
    let _animStart = null;
    let _animLastPaint = 0;
    let _animLastRafTs = 0;
    let _videoShadowFrameBudget = 80;
    let _videoSmoothFrameCount = 0;
    let _videoStateLastCheck = 0;
    let _videoStateCached = false;

    function stopAnimation() {
        if (_animFrame) { cancelAnimationFrame(_animFrame); _animFrame = null; }
        _animStart = null;
        _animLastPaint = 0;
        _animLastRafTs = 0;
        _videoShadowFrameBudget = 120;
        _videoSmoothFrameCount = 0;
        document.documentElement.classList.remove("shadow-live-color");
        document.body.classList.remove(
            "shadow-anim-running",
            "shadow-anim-pulse","shadow-anim-breathe","shadow-anim-orbit",
            "shadow-anim-colorshift","shadow-anim-wave",
            "shadow-anim-flicker","shadow-anim-thunder"
        );
    }

    function adaptVideoShadowFrameBudget(rafDelta) {
        if (rafDelta > 42) {
            _videoShadowFrameBudget = Math.min(260, _videoShadowFrameBudget + 18);
            _videoSmoothFrameCount = 0;
            return;
        }

        if (rafDelta < 24) {
            _videoSmoothFrameCount++;
            if (_videoSmoothFrameCount >= 36) {
                _videoShadowFrameBudget = Math.max(80, _videoShadowFrameBudget - 8);
                _videoSmoothFrameCount = 0;
            }
            return;
        }

        _videoSmoothFrameCount = 0;
    }

    function isVideoBackgroundActive() {
        const video = document.getElementById("videoBg");
        if (!video) return false;
        const styles = getComputedStyle(video);
        const hasSource = !!(video.currentSrc || video.src);
        const visible = styles.display !== "none" &&
            styles.visibility !== "hidden" &&
            parseFloat(styles.opacity || "1") > 0.01;
        return hasSource && visible;
    }

    function isVideoBackgroundActiveCached(ts) {
        if (!_videoStateLastCheck || ts - _videoStateLastCheck > 450) {
            _videoStateCached = isVideoBackgroundActive();
            _videoStateLastCheck = ts;
            // PERF-ROOT-FIX: mirror video state to body.perf-video so CSS can
            // swap the fullscreen backdrop-blur for a single-layer video blur.
            // Cheap (runs at most ~2x/sec) and drives the CSS fast-path.
            try {
                document.body.classList.toggle("perf-video", !!_videoStateCached);
            } catch (e) {}
        }
        return _videoStateCached;
    }

    function getPerfVideoFrameBudget() {
        // Base 120ms (~8fps shadow updates — visually identical for soft
        // shadows, 33% less style-recalc than the old 80ms). If the user also
        // has background blur dialed up, video+blur+shadows triple-stack, so
        // stretch to 200ms (~5fps). Shadows are low-frequency visuals; nobody
        // can tell 8fps from 60fps on a 24px blur — but the compositor can.
        try {
            const blur = parseFloat(
                getComputedStyle(document.body).getPropertyValue("--bg-blur")
            ) || 0;
            if (blur > 0.5) return 200;
        } catch (e) {}
        return 120;
    }

    function hexToRgb(hex) {
        hex = hex.replace("#","");
        if (hex.length === 3) hex = hex.split("").map(c => c+c).join("");
        const n = parseInt(hex, 16);
        return [(n>>16)&255, (n>>8)&255, n&255];
    }

    function rgbToHex(r,g,b) {
        return "#" + [r,g,b].map(v => Math.round(Math.max(0,Math.min(255,v))).toString(16).padStart(2,"0")).join("");
    }

    function hslToHex(h, s, l) {
        const hue = (((h % 360) + 360) % 360) / 360;
        const sat = Math.max(0, Math.min(100, s)) / 100;
        const lig = Math.max(0, Math.min(100, l)) / 100;

        function hue2rgb(p, q, t) {
            if (t < 0) t += 1;
            if (t > 1) t -= 1;
            if (t < 1 / 6) return p + (q - p) * 6 * t;
            if (t < 1 / 2) return q;
            if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
            return p;
        }

        let r, g, b;
        if (sat === 0) {
            r = g = b = lig;
        } else {
            const q = lig < 0.5 ? lig * (1 + sat) : lig + sat - lig * sat;
            const p = 2 * lig - q;
            r = hue2rgb(p, q, hue + 1 / 3);
            g = hue2rgb(p, q, hue);
            b = hue2rgb(p, q, hue - 1 / 3);
        }

        return rgbToHex(r * 255, g * 255, b * 255);
    }

    function getSpectrumColor(hue, saturation = 96, lightness = 62) {
        return hslToHex(hue, saturation, lightness);
    }

    function normalizeToHex(color) {
        if (!color) return null;
        if (color.startsWith("#")) return color;

        const m = color.match(/rgb\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
        if (m) return rgbToHex(parseInt(m[1]), parseInt(m[2]), parseInt(m[3]));
        return null; 
    }

    function shiftHue(color, hueShift) {
        const hex = normalizeToHex(color);
        if (!hex) return color;
        let [r,g,b] = hexToRgb(hex);

        r/=255; g/=255; b/=255;
        const max=Math.max(r,g,b), min=Math.min(r,g,b);
        let h,s,l=(max+min)/2;
        if(max===min){h=s=0;}else{
            const d=max-min;
            s=l>0.5?d/(2-max-min):d/(max+min);
            switch(max){
                case r:h=((g-b)/d+(g<b?6:0))/6;break;
                case g:h=((b-r)/d+2)/6;break;
                case b:h=((r-g)/d+4)/6;break;
            }
        }
        h=(h+(hueShift/360))%1; if(h<0)h+=1;

        function hue2rgb(p,q,t){if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return p+(q-p)*6*t;if(t<1/2)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p;}
        let nr,ng,nb;
        if(s===0){nr=ng=nb=l;}else{
            const q=l<0.5?l*(1+s):l+s-l*s;
            const p=2*l-q;
            nr=hue2rgb(p,q,h+1/3);ng=hue2rgb(p,q,h);nb=hue2rgb(p,q,h-1/3);
        }
        return rgbToHex(nr*255,ng*255,nb*255);
    }

    let _shadowUiSnapRafId = null;
    function applyShadowsNoTransition(state) {
        if (!state) return;
        const root = document.documentElement;
        root.classList.add("shadow-theme-no-transition");
        startAnimation(state);
        if (_shadowUiSnapRafId) {
            cancelAnimationFrame(_shadowUiSnapRafId);
        }
        _shadowUiSnapRafId = requestAnimationFrame(() => {
            _shadowUiSnapRafId = null;
            root.classList.remove("shadow-theme-no-transition");
        });
    }

    function startAnimation(state) {
        stopAnimation();
        applySpeed(state.speed);
        const anim = state.animation || "none";

        if (state.shadowsEnabled === false) {
            applyShadows(state);
            return;
        }

        if (anim === "none" || state.groups.length === 0) {
            applyShadows(state);
            return;
        }

        // PERF + A11Y: with prefers-reduced-motion, never run the rAF shadow
        // loop — render one static frame. Also the single biggest hang fix:
        // previously pulse/breathe/etc rewrote ~12 CSS vars at 60fps forever.
        try {
            if (window.matchMedia &&
                window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
                applyShadows(state);
                return;
            }
        } catch (e) {}

        document.body.classList.add("shadow-anim-running");
        document.body.classList.add("shadow-anim-" + anim);
        document.documentElement.classList.toggle(
            "shadow-live-color",
            anim === "colorshift"
        );
        const baseIntensity = Math.max(0, Math.min(100, state.intensity));
        const variant = state.colorVariant || DEFAULT_VARIANT;
        const baseColor = getShadowColor(variant, state.customColors);

        const pm = getAnimPeriodMult(state.speed);
        _animLastPaint = 0;
        _animLastRafTs = 0;
        _videoShadowFrameBudget = getPerfVideoFrameBudget();
        _videoSmoothFrameCount = 0;

        function tick(ts) {
            if (!_animStart) _animStart = ts;
            // PERF: hidden tab → skip shadow writes entirely (rAF is paused
            // anyway, but visibility flips can queue a burst on return).
            if (document.hidden) {
                _animFrame = requestAnimationFrame(tick);
                return;
            }
            const videoActive = isVideoBackgroundActiveCached(ts);
            if (videoActive) {
                if (_animLastRafTs) adaptVideoShadowFrameBudget(ts - _animLastRafTs);
                _animLastRafTs = ts;

                if (_animLastPaint && ts - _animLastPaint < _videoShadowFrameBudget) {
                    _animFrame = requestAnimationFrame(tick);
                    return;
                }
                _animLastPaint = ts;
            } else {
                _animLastRafTs = ts;
                _videoSmoothFrameCount = 0;
                // NOTE: budget recomputed only on video-state flips (cached
                // check above runs ~2x/sec); never per-frame getComputedStyle.
                if (document.body.classList.contains("perf-video")) {
                    try { document.body.classList.remove("perf-video"); } catch (e) {}
                    _videoShadowFrameBudget = getPerfVideoFrameBudget();
                }
            }
            const t = (ts - _animStart) / 1000; 
            let override = {};

            if (anim === "pulse") {
                // Sharp fast beat — quick spike then quick decay (heartbeat feel)
                const beat = Math.pow(Math.max(0, Math.sin(Math.PI * t / (0.55 * pm))), 3);
                override.intensity = Math.min(100, baseIntensity * (0.45 + 0.80 * beat));
            }
            else if (anim === "breathe") {
                // Very slow, deep inhale/exhale — nearly off at bottom
                const cycle = 0.5 + 0.5 * Math.sin(2 * Math.PI * t / (5 * pm) - Math.PI / 2);
                override.intensity = Math.min(100, baseIntensity * (0.05 + 0.95 * cycle));
            }
            else if (anim === "orbit") {
                // Shadow sweeps around the element in a circular orbit
                const radius = 6 + baseIntensity * 0.08;
                const period = 2.5 * pm;
                override.offX = radius * Math.cos(2 * Math.PI * t / period);
                override.offY = radius * Math.sin(2 * Math.PI * t / period);
                override.intensity = baseIntensity;
                override.orbitExplicit = true;
            }
            else if (anim === "colorshift") {
                // Smooth cycle through the full spectrum, independent of the current theme color.
                const hue = (t * (95 / pm)) % 360;
                override.color     = getSpectrumColor(hue, 96, 62);
                override.intensity = baseIntensity;
            }
            else if (anim === "wave") {
                // Intensity swells from full → near-zero → full in sine wave — no color change
                const mult = 0.5 + 0.5 * Math.sin(2 * Math.PI * t / (2 * pm));
                override.intensity = Math.min(100, baseIntensity * Math.max(0.02, mult));
            }
            else if (anim === "flicker") {
                // Candle flame — skewed upward (more time bright than dim)
                const n  = 0.72 + 0.18 * Math.sin(t * 6.1  / pm)
                                + 0.14 * Math.sin(t * 14.3 / pm + 0.9)
                                + 0.08 * Math.sin(t * 31.7 / pm + 2.1)
                                + 0.06 * Math.sin(t * 53.0 / pm + 4.4);
                override.intensity = Math.min(100, baseIntensity * Math.max(0.08, n));
            }
            else if (anim === "thunder") {
                // 90% of the time the shadow is nearly invisible — then a violent spike
                const phase   = (t / (4.5 * pm)) % 1;
                const inStrike = phase > 0.88;
                let bolt;
                if (inStrike) {
                    const sp = (phase - 0.88) / 0.12;
                    bolt = Math.pow(Math.sin(Math.PI * sp), 0.4);
                } else {
                    bolt = 0;
                }
                override.intensity = Math.min(100, baseIntensity * (0.08 + bolt * 1.6));
            }
            applyShadows(state, override);
            _animFrame = requestAnimationFrame(tick);
        }
        _animFrame = requestAnimationFrame(tick);
    }

    
    let _state = null;
    let _themeUpdateTimer = null;

    let _shadowRafId = null;
    let _shadowThemeSnapRafId = null;
    let _shadowBootTimer = null;
    let _shadowBooting = false;

    function getShadowBootSuppressMs() {
        const uiMult = parseFloat(
            document.documentElement.style.getPropertyValue("--ui-anim-mult") || "1"
        );
        const mult = (isNaN(uiMult) || uiMult <= 0) ? 1 : uiMult;
        return Math.max(260, Math.round(240 * mult) + 120);
    }

    function beginShadowBootSuppression() {
        _shadowBooting = true;
        document.documentElement.classList.add("shadow-init-no-transition");
        clearTimeout(_shadowBootTimer);
        _shadowBootTimer = setTimeout(() => {
            _shadowBooting = false;
            document.documentElement.classList.remove("shadow-init-no-transition");
            if (_state && _state.animation === "none") {
                applyShadows(_state);
            }
        }, getShadowBootSuppressMs());
    }

    function applyCurrentThemeShadow(options = {}) {
        if (!_state) return;
        if (options.livePreview) {
            applyShadows(_state);
        } else if (_state.animation === "none") {
            applyShadows(_state);
        } else {
            startAnimation(_state);
        }
        updateSwatches(_state.colorVariant || DEFAULT_VARIANT);
    }

    function snapCurrentThemeShadow(options = {}) {
        const root = document.documentElement;
        root.classList.add("shadow-theme-no-transition");
        applyCurrentThemeShadow(options);
        if (_shadowThemeSnapRafId) {
            cancelAnimationFrame(_shadowThemeSnapRafId);
        }
        _shadowThemeSnapRafId = requestAnimationFrame(() => {
            _shadowThemeSnapRafId = null;
            root.classList.remove("shadow-theme-no-transition");
        });
    }

    window.updateThemeShadowNow = function () {
        if (_shadowRafId) return;
        _shadowRafId = requestAnimationFrame(() => {
            _shadowRafId = null;
            applyCurrentThemeShadow({ livePreview: !!window._colorPickerDragging });
        });
    };

    function watchThemeColor() {
        // Event-driven only — no polling.
        // theme-colors-changed is dispatched by theme.js/dual-color.js on every change.
        document.addEventListener("theme-colors-changed", () => {
            if (!_state) return;

            // During color-picker drag: debounce to ONE update per animation frame.
            if (window._colorPickerDragging) {
                window.updateThemeShadowNow();
                return;
            }

            // If the user is actively editing the shadow color, do not overwrite the preview with the saved state
            if (window.customColorPickerModal && window.customColorPickerModal.isOpen() && window.customColorPickerModal.isStandalone() && window.customColorPickerModal.getTitle() === "Shadow Color") {
                return;
            }

            // Not dragging: snap shadows to the new theme with no theme-switch animation.
            snapCurrentThemeShadow();

            if (_shadowBooting) {
                clearTimeout(_themeUpdateTimer);
                return;
            }

            clearTimeout(_themeUpdateTimer);
        });
    }

    
    function renderCustomShadowSwatches(activeVariant) {
        const host = document.getElementById("shadowCustomSwatches");
        const addBtn = document.getElementById("shadowAddColorBtn");
        if (!host) return;
        host.innerHTML = "";
        const customColors = Array.isArray(_state?.customColors) ? _state.customColors : [];
        customColors.forEach((hex, index) => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = "shadow-swatch shadow-swatch-custom";
            btn.dataset.variant = `${CUSTOM_VARIANT_PREFIX}${index}`;
            btn.title = `Custom Shadow ${index + 1}`;
            btn.style.background = hex;
            btn.classList.toggle("active", btn.dataset.variant === activeVariant);
            btn.addEventListener("click", () => {
                if (!_state) return;
                if (_state.colorVariant === btn.dataset.variant) {
                    openShadowCustomColorPicker(index);
                    return;
                }
                _state.colorVariant = btn.dataset.variant;
                updateSwatches(_state.colorVariant);
                applyShadowsNoTransition(_state);
                saveState(_state);
                if (window.customColorPickerModal && window.customColorPickerModal.isOpen() && window.customColorPickerModal.isStandalone() && window.customColorPickerModal.getTitle() === "Shadow Color") {
                    openShadowCustomColorPicker(index);
                }
            });
            btn.addEventListener("dblclick", () => openShadowCustomColorPicker(index));
            btn.addEventListener("contextmenu", (event) => {
                event.preventDefault();
                if (!_state) return;
                _state.customColors.splice(index, 1);
                if (_state.colorVariant === btn.dataset.variant) {
                    _state.colorVariant = DEFAULT_VARIANT;
                } else if (String(_state.colorVariant || "").startsWith(CUSTOM_VARIANT_PREFIX)) {
                    const activeIndex = parseInt(String(_state.colorVariant).slice(CUSTOM_VARIANT_PREFIX.length), 10);
                    if (activeIndex > index) {
                        _state.colorVariant = `${CUSTOM_VARIANT_PREFIX}${activeIndex - 1}`;
                    }
                }
                updateSwatches(_state.colorVariant || DEFAULT_VARIANT);
                applyShadowsNoTransition(_state);
                saveState(_state);
            });
            host.appendChild(btn);
        });
        if (addBtn) {
            addBtn.disabled = customColors.length >= MAX_CUSTOM_SHADOW_COLORS;
            addBtn.title = addBtn.disabled ? "Maximum 3 custom colors" : "Add shadow color";
        }
    }

    function updateSwatches(activeVariant) {
        const adaptivePalette = getAdaptiveVariantExpressions();
        document.querySelectorAll(".shadow-swatch[data-variant]").forEach(btn => {
            const v = btn.dataset.variant;
            btn.classList.toggle("active", v === activeVariant);
            const swatchColor = adaptivePalette[v] || COLOR_VARIANTS[v];
            if (swatchColor) btn.style.background = swatchColor;
        });
        renderCustomShadowSwatches(activeVariant);
    }

    function openShadowCustomColorPicker(editIndex = -1) {
        if (!window.customColorPickerModal || typeof window.customColorPickerModal.openSingle !== "function" || !_state) {
            return;
        }
        const customColors = Array.isArray(_state.customColors) ? _state.customColors : [];
        if (editIndex < 0 && customColors.length >= MAX_CUSTOM_SHADOW_COLORS) {
            return;
        }
        const initialColor = editIndex >= 0
            ? customColors[editIndex]
            : (getShadowColor(_state.colorVariant || DEFAULT_VARIANT) || "#FFFFFF");
        window.customColorPickerModal.openSingle({
            title: "Shadow Color",
            color: initialColor,
            onPreview: (hex) => {
                if (!_state) return;
                const tempColors = Array.isArray(_state.customColors) ? [..._state.customColors] : [];
                if (editIndex >= 0 && editIndex < tempColors.length) {
                    tempColors[editIndex] = hex;
                } else {
                    tempColors[editIndex >= 0 ? editIndex : tempColors.length] = hex;
                }
                const tempState = {
                    ..._state,
                    customColors: tempColors,
                    colorVariant: editIndex >= 0 ? `${CUSTOM_VARIANT_PREFIX}${editIndex}` : `${CUSTOM_VARIANT_PREFIX}${tempColors.length - 1}`
                };
                applyShadowsNoTransition(tempState);
            },
            onCancel: () => {
                if (!_state) return;
                applyShadowsNoTransition(_state);
            },
            onApply: (hex) => {
                if (!_state) return;
                const nextColors = Array.isArray(_state.customColors) ? [..._state.customColors] : [];
                if (editIndex >= 0 && editIndex < nextColors.length) {
                    nextColors[editIndex] = hex;
                    _state.colorVariant = `${CUSTOM_VARIANT_PREFIX}${editIndex}`;
                } else if (nextColors.length < MAX_CUSTOM_SHADOW_COLORS) {
                    nextColors.push(hex);
                    _state.colorVariant = `${CUSTOM_VARIANT_PREFIX}${nextColors.length - 1}`;
                }
                _state.customColors = nextColors.slice(0, MAX_CUSTOM_SHADOW_COLORS);
                updateSwatches(_state.colorVariant);
                applyShadowsNoTransition(_state);
                saveState(_state);
            }
        });
    }

    
    function updateAnimBtns(activeAnim) {
        document.querySelectorAll(".shadow-anim-btn[data-anim]").forEach(btn => {
            btn.classList.toggle("active", btn.dataset.anim === activeAnim);
        });

        const hoverRow = document.querySelector(".shadow-mode-row");
        if (hoverRow) {
            hoverRow.style.display = (activeAnim === "none") ? "" : "none";
        }
    }

    
    function makeDraggable(panel, handle) {
        if (!panel || !handle) return;
        let sx, sy, sl, st, drag = false;
        handle.style.cursor = "grab";
        handle.addEventListener("mousedown", e => {
            if (e.button !== 0) return;
            if (e.target.closest("button, input, select, textarea, a, [role='button']")) return;
            e.preventDefault();
            drag = true;
            panel._panelDragActive = true;
            sx = e.clientX; sy = e.clientY;
            const r = panel.getBoundingClientRect();
            sl = r.left; st = r.top;
            handle.style.cursor = "grabbing";
        });
        document.addEventListener("mousemove", e => {
            if (!drag) return;
            const vw = window.innerWidth, vh = window.innerHeight;
            const pw = panel.offsetWidth,  ph = panel.offsetHeight;
            panel.style.left  = Math.max(0, Math.min(vw-pw-4, sl + e.clientX - sx)) + "px";
            panel.style.top   = Math.max(0, Math.min(vh-ph-4, st + e.clientY - sy)) + "px";
            panel.style.right = "auto";
            panel.style.bottom = "auto";
        });
        document.addEventListener("mouseup", () => {
            if (drag) {
                drag = false;
                panel._panelDragActive = false;
                handle.style.cursor = "grab";
            }
        });
    }

    
    function applyTranslations() {
        document.querySelectorAll("[data-i18n]").forEach(el => {
            el.textContent = _t(el.dataset.i18n, el.textContent);
        });
        const set = (id, key, fb) => { const e = document.getElementById(id); if(e) e.textContent = _t(key, fb); };
        set("shadowControlBtnLabel","shadowControl","Shadow Control");
        set("shadowPanelTitle",     "shadowControl","Shadow Control");
        set("shadowIntensityLabel", "shadowIntensity","Intensity");
        set("shadowSpeedLabel",     "shadowSpeed","Speed");
        set("shadowColorLabel",     "shadowColor","Color");
        set("shadowAnimLabel",      "shadowAnimation","Animation");
        set("sqAll","sqAll","All"); set("sqNone","sqNone","None");
        set("sqImportant","sqImportant","Important"); set("sqCards","sqCards","Cards");
        set("sqLarge","sqLarge","Large"); set("sqMinimal","sqMinimal","Minimal");
        set("shSearchLabel","shSearch","Search Bar");
        set("shMenuLabel","shMenu","Menu Panel");
        set("shBookmarksLabel","shBookmarks","Bookmarks");
        set("shWidgetsLabel","shWidgets","Widgets");
        set("shModalsLabel","shModals","Modals");
        set("shContextMenuLabel","shContextMenu","Context Menus");
        set("shButtonsLabel","shButtons","Buttons");
        set("shShortcutsLabel","shShortcuts","Shortcuts");
        set("shadowListToggleLabel", "shadowElements", "Elements");
        set("shadowMasterLabel", "shadowMaster", "Shadows");
        applyAnimButtonTranslations();
    }

    function updateCheckboxes(state) {
        ALL_GROUPS.forEach(g => {
            const el = document.getElementById("sh" + GROUP_MAP[g]);
            if (el) el.checked = state.groups.includes(g);
        });
    }

    function updateHoverBtn(hoverOnly) {
        const btn = document.getElementById("shadowHoverModeBtn");
        if (!btn) return;
        const icon  = btn.querySelector(".shadow-hover-icon");
        const label = btn.querySelector(".shadow-hover-label");
        btn.classList.toggle("hover-mode-active", hoverOnly);
        // Show the DESTINATION state on the button (what clicking will switch to),
        // not the current state. When hoverOnly=true → clicking goes to Always On.
        // When hoverOnly=false → clicking goes to Hover Only.
        if (icon)  icon.textContent  = hoverOnly ? "\u25C9" : "\u2726";
        if (label) label.textContent = hoverOnly ? _t("shadowAlways","Always On") : _t("shadowHoverOnly","Hover Only");

    }

    const SNAP_DEFAULT           = DEFAULT_INTENSITY;
    const SNAP_ZONE_PX           = 14;
    const SNAP_RELEASE_ZONE_PX   = 36;

    function updateSliderFill(slider) {
        slider.style.background = `linear-gradient(to right,
            var(--darkColor-blue) 0%, var(--darkColor-blue) ${slider.value}%,
            color-mix(in srgb, var(--darkColor-blue) 22%, transparent) ${slider.value}%,
            color-mix(in srgb, var(--darkColor-blue) 22%, transparent) 100%)`;
    }

    function getSliderThumbSize(slider) {
        const cs = getComputedStyle(slider);
        const raw = cs.getPropertyValue("--shadow-slider-thumb-size").trim();
        const parsed = parseFloat(raw);
        return Number.isFinite(parsed) && parsed > 0 ? parsed : 16;
    }

    function sliderValueToX(slider, val) {
        const r = slider.getBoundingClientRect();
        const min = parseInt(slider.min) || 0;
        const max = parseInt(slider.max) || 100;
        const ratio = (val - min) / Math.max(1, (max - min));
        const thumb = getSliderThumbSize(slider);
        const travel = Math.max(0, r.width - thumb);
        return r.left + (thumb / 2) + (travel * ratio);
    }

    function updateDefaultMarkerPosition(slider, defaultVal) {
        const row = slider ? slider.closest(".shadow-intensity-row") : null;
        if (!slider || !row || slider.offsetWidth <= 0) return;
        const min = parseInt(slider.min) || 0;
        const max = parseInt(slider.max) || 100;
        const exactMidVal = min + ((max - min) / 2);
        const visualDefaultVal = Math.abs(defaultVal - exactMidVal) <= 0.51
            ? exactMidVal
            : defaultVal;
        const thumb = getSliderThumbSize(slider);
        const ratio = (visualDefaultVal - min) / Math.max(1, (max - min));
        const travel = Math.max(0, slider.offsetWidth - thumb);
        const markerX = slider.offsetLeft + (thumb / 2) + (travel * ratio);
        const markerY = slider.offsetTop + (slider.offsetHeight / 2);
        row.style.setProperty("--shadow-default-marker-x", markerX + "px");
        row.style.setProperty("--shadow-default-marker-y", markerY + "px");
    }

    function refreshSliderMarkers() {
        const intensitySlider = document.getElementById("shadowIntensitySlider");
        const speedSlider = document.getElementById("shadowSpeedSlider");
        if (intensitySlider) updateDefaultMarkerPosition(intensitySlider, SNAP_DEFAULT);
        if (speedSlider) updateDefaultMarkerPosition(speedSlider, DEFAULT_SPEED);
    }

    function getDefaultMarkerRow(slider) {
        return slider ? slider.closest(".shadow-intensity-row") : null;
    }

    function isDefaultSnapEnabled(slider) {
        return !!slider && slider.dataset.defaultSnapEnabled !== "0";
    }

    function ensureDefaultMarkerToggle(slider, defaultVal) {
        const row = getDefaultMarkerRow(slider);
        if (!slider || !row) return null;

        let markerBtn = row.querySelector(".default-marker-toggle");
        if (!markerBtn) {
            markerBtn = document.createElement("button");
            markerBtn.type = "button";
            markerBtn.className = "default-marker-toggle";
            markerBtn.setAttribute("aria-label", "Toggle default snap");
            row.appendChild(markerBtn);

            markerBtn.addEventListener("click", function (e) {
                e.preventDefault();
                e.stopPropagation();
                slider.dataset.defaultSnapEnabled = isDefaultSnapEnabled(slider) ? "0" : "1";
                syncDefaultMarkerGlow(slider, defaultVal);
            });
        }

        return markerBtn;
    }

    function syncDefaultMarkerGlow(slider, defaultVal) {
        if (!slider) return;
        const row = getDefaultMarkerRow(slider);
        const markerBtn = ensureDefaultMarkerToggle(slider, defaultVal);
        const snapEnabled = isDefaultSnapEnabled(slider);
        const currentVal = parseInt(slider.value);
        const isAtDefault = currentVal === defaultVal;
        const shouldGlow = snapEnabled && isAtDefault;

        if (row) {
            row.dataset.defaultSnapEnabled = snapEnabled ? "1" : "0";
            row.dataset.defaultSnapActive = shouldGlow ? "1" : "0";
        }

        if (markerBtn) {
            markerBtn.setAttribute("aria-pressed", snapEnabled ? "true" : "false");
            markerBtn.title = snapEnabled
                ? "Default snap on. Click to turn it off."
                : "Default snap off. Click to turn it on.";
        }

        if (shouldGlow) {
            slider.dataset.snapped = "1";
        } else {
            delete slider.dataset.snapped;
        }
    }

    function applySnapBehavior(slider, defaultVal, onSnap) {
        let snapLocked = false;
        slider.addEventListener("input", function () {
            if (!isDefaultSnapEnabled(slider)) {
                snapLocked = false;
                syncDefaultMarkerGlow(slider, defaultVal);
                return;
            }

            const val = parseInt(slider.value);
            const snapX = sliderValueToX(slider, defaultVal);
            const currX = sliderValueToX(slider, val);
            const dist  = Math.abs(currX - snapX);

            if (snapLocked) {
                if (dist < SNAP_RELEASE_ZONE_PX) {
                    slider.value = defaultVal;
                    onSnap(defaultVal);
                    syncDefaultMarkerGlow(slider, defaultVal);
                    return;
                }

                snapLocked = false;
                syncDefaultMarkerGlow(slider, defaultVal);
                return;
            }

            if (dist < SNAP_ZONE_PX) {
                snapLocked = true;
                slider.value = defaultVal;
                onSnap(defaultVal);
                syncDefaultMarkerGlow(slider, defaultVal);
                return;
            }

            syncDefaultMarkerGlow(slider, defaultVal);
        });
    }

    
    document.addEventListener("DOMContentLoaded", function () {
        beginShadowBootSuppression();
        const state = loadState();
        _state      = state;
        applySpeed(state.speed);
        startAnimation(state);
        watchThemeColor();

        const panel   = document.getElementById("shadowFloatingPanel");
        const trigBtn = document.getElementById("shadowControlBtn");
        const titlebar= document.getElementById("shadowPanelTitlebar");
        const dragZone= titlebar ? titlebar.querySelector(".shadow-panel-drag-zone") : null;
        const closeBtn= document.getElementById("shadowPanelClose");
        const slider  = document.getElementById("shadowIntensitySlider");
        const valEl   = document.getElementById("shadowIntensityVal");
        const speedSlider = document.getElementById("shadowSpeedSlider");
        const speedVal    = document.getElementById("shadowSpeedVal");
        const hoverBtn= document.getElementById("shadowHoverModeBtn");
        const addColorBtn = document.getElementById("shadowAddColorBtn");
        const listToggleBtn = document.getElementById("shadowListToggleBtn");
        const itemsList     = document.getElementById("shadowItemsList");

        if (listToggleBtn && itemsList) {
            const savedOpen = localStorage.getItem("shadowListOpen");
            const isOpen = savedOpen === null ? true : savedOpen === "true";
            if (isOpen) {
                itemsList.classList.add("list-visible");
                listToggleBtn.classList.add("list-open");
            }
            listToggleBtn.addEventListener("click", () => {
                const nowOpen = itemsList.classList.toggle("list-visible");
                listToggleBtn.classList.toggle("list-open", nowOpen);
                localStorage.setItem("shadowListOpen", nowOpen);
            });
        }

        if (!panel) return;
        // Only drag when grabbing the designated drag zone, not the whole titlebar
        if (dragZone) makeDraggable(panel, dragZone);

        if (trigBtn) {
            trigBtn.addEventListener("click", () => {
                const open = panel.style.display !== "none";
                if (open) {
                    // Close with animation (respects Anim Speed slider via window.closeWithAnim)
                    if (window.closeWithAnim) {
                        window.closeWithAnim(panel, () => {
                            panel.style.display = "none";
                            trigBtn.classList.remove("shadow-btn-active");
                        });
                    } else {
                        panel.style.display = "none";
                        trigBtn.classList.remove("shadow-btn-active");
                    }
                } else {
                    trigBtn.classList.add("shadow-btn-active");
                    // Open with animation (respects Anim Speed slider via window.panelOpenAnim)
                    if (window.panelOpenAnim) {
                        window.panelOpenAnim(panel, "block");
                    } else {
                        panel.style.display = "block";
                        panel.style.animation = "none";
                        requestAnimationFrame(() => {
                            panel.style.animation = "";
                        });
                    }
                    requestAnimationFrame(() => {
                        updateSwatches(state.colorVariant || DEFAULT_VARIANT);
                        updateAnimBtns(state.animation || "none");
                        updateMasterSwitchUI();
                        refreshSliderMarkers();
                    });
                    setTimeout(refreshSliderMarkers, 40);
                }
            });
        }

        if (closeBtn) {
            closeBtn.addEventListener("click", () => {
                if (window.closeWithAnim) {
                    window.closeWithAnim(panel, () => {
                        panel.style.display = "none";
                        if (trigBtn) trigBtn.classList.remove("shadow-btn-active");
                    });
                } else {
                    panel.style.display = "none";
                    if (trigBtn) trigBtn.classList.remove("shadow-btn-active");
                }
            });
        }

        const masterSwitch = document.getElementById("shadowMasterSwitch");
        function updateMasterSwitchUI() {
            if (masterSwitch) masterSwitch.checked = state.shadowsEnabled !== false;
        }
        if (masterSwitch) {
            masterSwitch.checked = state.shadowsEnabled !== false;
            masterSwitch.addEventListener("change", () => {
                state.shadowsEnabled = masterSwitch.checked;
                applyShadowsNoTransition(state);
                saveState(state);
            });
        }
        updateMasterSwitchUI();

        panel.querySelectorAll(".shadow-quick-btn").forEach(qb => {
            qb.addEventListener("click", () => {
                state.groups = [...(PRESETS[qb.dataset.quick] || ALL_GROUPS)];
                updateCheckboxes(state);
                applyShadowsNoTransition(state);
                saveState(state);
            });
        });

        if (slider) {
            slider.value = state.intensity ?? DEFAULT_INTENSITY;
            if (valEl) valEl.textContent = slider.value + "%";
            updateSliderFill(slider);
            updateDefaultMarkerPosition(slider, SNAP_DEFAULT);
            syncDefaultMarkerGlow(slider, SNAP_DEFAULT);
            applySnapBehavior(slider, SNAP_DEFAULT, (snappedVal) => {
                state.intensity = snappedVal;
                if (valEl) valEl.textContent = snappedVal + "%";
                updateSliderFill(slider);
                applyShadowsNoTransition(state);
                saveState(state);
            });
            slider.addEventListener("input", () => {
                state.intensity = parseInt(slider.value);
                if (valEl) valEl.textContent = slider.value + "%";
                updateSliderFill(slider);
                syncDefaultMarkerGlow(slider, SNAP_DEFAULT);
                applyShadowsNoTransition(state);
                saveState(state);
            });
        }

        if (speedSlider) {
            speedSlider.value = state.speed ?? DEFAULT_SPEED;
            if (speedVal) speedVal.textContent = speedSlider.value + "%";
            updateSliderFill(speedSlider);
            updateDefaultMarkerPosition(speedSlider, DEFAULT_SPEED);
            syncDefaultMarkerGlow(speedSlider, DEFAULT_SPEED);
            applySnapBehavior(speedSlider, DEFAULT_SPEED, (snappedVal) => {
                state.speed = snappedVal;
                if (speedVal) speedVal.textContent = snappedVal + "%";
                updateSliderFill(speedSlider);
                applySpeed(state.speed);
                applyShadowsNoTransition(state);
                saveState(state);
            });
            speedSlider.addEventListener("input", () => {
                state.speed = parseInt(speedSlider.value);
                if (speedVal) speedVal.textContent = speedSlider.value + "%";
                updateSliderFill(speedSlider);
                syncDefaultMarkerGlow(speedSlider, DEFAULT_SPEED);
                applySpeed(state.speed);
                applyShadowsNoTransition(state);
                saveState(state);
            });
        }



        updateSwatches(state.colorVariant || DEFAULT_VARIANT);
        requestAnimationFrame(refreshSliderMarkers);
        window.addEventListener("resize", refreshSliderMarkers);
        window.addEventListener("load", refreshSliderMarkers);
        setTimeout(refreshSliderMarkers, 80);
        setTimeout(refreshSliderMarkers, 260);
        if (document.fonts?.ready) {
            document.fonts.ready
                .then(() => requestAnimationFrame(refreshSliderMarkers))
                .catch(() => {});
        }
        if (typeof ResizeObserver !== "undefined") {
            const markerResizeObserver = new ResizeObserver(() => {
                requestAnimationFrame(refreshSliderMarkers);
            });
            if (slider) markerResizeObserver.observe(slider);
            if (speedSlider) markerResizeObserver.observe(speedSlider);
        }
        if (typeof MutationObserver !== "undefined") {
            const markerMutationObserver = new MutationObserver(() => {
                requestAnimationFrame(refreshSliderMarkers);
            });
            markerMutationObserver.observe(document.documentElement, {
                attributes: true,
                attributeFilter: ["lang", "dir", "class"]
            });
        }
        panel.querySelectorAll(".shadow-swatch[data-variant]").forEach(btn => {
            btn.addEventListener("click", () => {
                state.colorVariant = btn.dataset.variant;
                updateSwatches(state.colorVariant);
                applyShadowsNoTransition(state);
                saveState(state);
                if (window.customColorPickerModal && window.customColorPickerModal.isOpen() && window.customColorPickerModal.isStandalone() && window.customColorPickerModal.getTitle() === "Shadow Color") {
                    window.customColorPickerModal.close();
                }
            });
        });

        if (addColorBtn) {
            addColorBtn.addEventListener("click", () => openShadowCustomColorPicker(-1));
        }

        updateAnimBtns(state.animation || "none");
        panel.querySelectorAll(".shadow-anim-btn[data-anim]").forEach(btn => {
            btn.addEventListener("click", () => {
                state.animation = btn.dataset.anim;

                // Keep hoverOnly state intact when switching animations
                updateAnimBtns(state.animation);
                applyShadowsNoTransition(state);
                saveState(state);
            });
        });

        if (hoverBtn) {
            updateHoverBtn(state.hoverOnly);
            hoverBtn.addEventListener("click", () => {
                state.hoverOnly = !state.hoverOnly;
                updateHoverBtn(state.hoverOnly);
                applyShadowsNoTransition(state);
                saveState(state);
            });
        }

        ALL_GROUPS.forEach(g => {
            const chk = document.getElementById("sh" + GROUP_MAP[g]);
            if (!chk) return;
            chk.checked = state.groups.includes(g);
            chk.addEventListener("change", () => {
                state.groups = chk.checked
                    ? [...new Set([...state.groups, g])]
                    : state.groups.filter(x => x !== g);
                applyShadowsNoTransition(state);
                saveState(state);
            });
        });

        updateCheckboxes(state);

        applyTranslations();
        window._shadowControlApplyTranslations = applyTranslations;
        window._shadowControlState = state;
        window._shadowControlRestart = () => startAnimation(state);

        if (typeof MutationObserver !== "undefined") {
            let perfRestartTimer = null;
            const schedulePerfRestart = () => {
                clearTimeout(perfRestartTimer);
                perfRestartTimer = setTimeout(() => {
                    if (_state?.animation && _state.animation !== "none") {
                        startAnimation(_state);
                    }
                }, 80);
            };
            const videoBg = document.getElementById("videoBg");
            if (videoBg) {
                new MutationObserver(schedulePerfRestart).observe(videoBg, {
                    attributes: true,
                    attributeFilter: ["src", "style", "class"]
                });
                videoBg.addEventListener("playing", schedulePerfRestart);
                videoBg.addEventListener("pause", schedulePerfRestart);
                videoBg.addEventListener("emptied", schedulePerfRestart);
            }
            new MutationObserver(schedulePerfRestart).observe(document.body, {
                attributes: true,
                attributeFilter: ["data-bg"]
            });
        }

        
        const HOVER_DELAY_MS    = 0;

        function buildClockShadow(shadowColor, intensity, isClock) {
            return buildDropShadow(shadowColor,
                isClock ? Math.min(100, intensity * 1.35) : Math.min(100, intensity * 1.5),
                isClock ? 2.0 : 2.4);
        }

        function getCurrentShadowColor() {
            const variant = _state ? (_state.colorVariant || DEFAULT_VARIANT) : DEFAULT_VARIANT;
            const col = getShadowColor(variant);
            return col;
        }

        // ── Pixel-perfect hit testing via canvas ──────────────────────────────────
        // Loads a mask PNG into an offscreen canvas so we can read per-pixel alpha.
        // Returns a tester function: tester(normX, normY) → true if opaque pixel.
        // normX / normY are in [0,1] relative to the *mask element's* bounding box
        // (not the container), mapped via the transform coefficients below.
        function createMaskHitTester(maskSrc) {
            let canvas = null, ctx = null, loaded = false;
            const img = new Image();
            img.onload = function () {
                canvas = document.createElement("canvas");
                canvas.width  = img.naturalWidth;
                canvas.height = img.naturalHeight;
                ctx = canvas.getContext("2d", { willReadFrequently: true });
                ctx.drawImage(img, 0, 0);
                loaded = true;
            };
            img.onerror = function () { loaded = false; };
            img.src = maskSrc;

            // maskNormX / maskNormY are already in [0,1] relative to the image itself
            return function isOpaque(maskNormX, maskNormY) {
                if (!loaded) return true; // image not ready yet → allow hover
                const px = Math.floor(maskNormX * canvas.width);
                const py = Math.floor(maskNormY * canvas.height);
                if (px < 0 || px >= canvas.width || py < 0 || py >= canvas.height) return false;
                try { return ctx.getImageData(px, py, 1, 1).data[3] > 10; }
                catch (e) { return true; }
            };
        }

        // Analog clock default scallop shape
        const _clockMaskTest = createMaskHitTester("./images/clock-shape.png");
        function clockHitTest(normX, normY) {
            const shape = document.body?.dataset?.clockShape || "scallop";
            if (shape === "circle") {
                const dx = normX - 0.5, dy = normY - 0.5;
                return (dx * dx + dy * dy) <= 0.25;
            }
            if (shape === "squircle") {
                const dx = Math.abs(normX - 0.5) / 0.5;
                const dy = Math.abs(normY - 0.5) / 0.5;
                return Math.pow(dx, 4) + Math.pow(dy, 4) <= 1;
            }
            return _clockMaskTest(normX, normY);
        }

        // Weather (.weather-bg):
        //   position: absolute; inset:0; top:-20%; width:130%; height:130%
        //   mask top edge = -20% of container, left = 0
        const _weatherMaskTest = createMaskHitTester("./images/weather-shape.png");
        function weatherHitTest(normX, normY) {
            const maskNormX = normX / 1.3;
            const maskNormY = (normY + 0.20) / 1.3;
            return _weatherMaskTest(maskNormX, maskNormY);
        }

        // Digital clock: follow the rounded-rect SVG body instead of a generic circle.
        // Keep a tiny extra margin so the hover area feels natural without becoming oversized.
        function digitalClockHitTest(normX, normY) {
            const left = 0.0;
            const right = 1.0;
            const top = 0.075;
            const bottom = 0.89;
            const width = right - left;
            const height = bottom - top;
            const radius = Math.min(width * 0.39, height * 0.5);
            const innerLeft = left + radius;
            const innerRight = right - radius;
            const centerY = (top + bottom) * 0.5;

            if (normX < left || normX > right || normY < top || normY > bottom) {
                return false;
            }

            if (normX >= innerLeft && normX <= innerRight) {
                return true;
            }

            const dx = normX < innerLeft ? normX - innerLeft : normX - innerRight;
            const dy = normY - centerY;
            return (dx * dx + dy * dy) <= (radius * radius);
        }

        // ── Hover attachment (pixel-accurate enter/leave via mousemove) ─────────────
        // eventEl  = container that receives mousemove / mouseleave
        // filterEl = element whose inline filter is animated
        // isClock  = true → clock shadow scale, false → weather scale
        // hitTest  = function(normX, normY) → bool; only fires hover over opaque pixels
        function attachClockWeatherHover(eventEl, filterEl, isClock, hitTest) {
            if (!eventEl || !filterEl) return;
            let delayTimer  = null;
            let raf         = null;
            let currentRatio = 0;
            let isOverShape  = false;

            function isHoverOnlyActive() {
                return !!(_state && _state.hoverOnly && (_state.animation || "none") === "none");
            }

            function cancelAll() {
                clearTimeout(delayTimer);
                if (raf) { cancelAnimationFrame(raf); raf = null; }
            }

            function triggerEnter() {
                if (!isHoverOnlyActive()) return;
                if (!_state.groups.includes("widgets")) return;

                cancelAll();

                const _startEnterAnim = () => {
                    const startRatio = currentRatio;
                    let startTs = null;
                    function stepIn(ts) {
                        if (!isHoverOnlyActive()) {
                            filterEl.style.removeProperty("filter");
                            filterEl.style.removeProperty("transition");
                            raf = null;
                            currentRatio = 0;
                            return;
                        }
                        if (!startTs) startTs = ts;
                        const p      = Math.min(1, (ts - startTs) / _hoverFadeInMs);
                        const eased  = 1 - Math.pow(1 - p, 2);
                        currentRatio = startRatio + (1 - startRatio) * eased;
                        if (_state.animation && _state.animation !== "none") {
                            // Animation is running: fade in from zero to the current animated CSS var
                            const animTarget = isClock
                                ? document.body.style.getPropertyValue("--theme-drop-shadow-clock")
                                : document.body.style.getPropertyValue("--theme-drop-shadow-weather");
                            // Simply remove inline override so CSS var shows through,
                            // but cross-fade from zero using the ratio
                            if (p >= 1) {
                                filterEl.style.removeProperty("filter");
                                filterEl.style.removeProperty("transition");
                                raf = null; currentRatio = 1;
                                return;
                            }
                            // Linear fade from DROP_SHADOW_ZERO → remove inline (let animation show)
                            // Approximate: scale the current animated target by ratio
                            const intensity = Math.max(0, Math.min(100,
                                (_state.intensity ?? DEFAULT_INTENSITY) * eased));
                            filterEl.style.filter = buildClockShadow(getCurrentShadowColor(), intensity, isClock);
                        } else {
                            const intensity = Math.max(0, Math.min(100, (_state.intensity ?? DEFAULT_INTENSITY) * currentRatio));
                            filterEl.style.filter = buildClockShadow(getCurrentShadowColor(), intensity, isClock);
                        }
                        if (p < 1) { raf = requestAnimationFrame(stepIn); }
                        else       { raf = null; currentRatio = 1;
                            if (_state.animation && _state.animation !== "none") {
                                filterEl.style.removeProperty("filter");
                                filterEl.style.removeProperty("transition");
                            }
                        }
                    }
                    raf = requestAnimationFrame(stepIn);
                };

                if (HOVER_DELAY_MS > 0) {
                    delayTimer = setTimeout(_startEnterAnim, HOVER_DELAY_MS);
                } else {
                    _startEnterAnim();
                }
            }

            function triggerLeave() {
                cancelAll();
                if (!isHoverOnlyActive()) return;

                const startRatio = currentRatio;
                let startTs = null;
                function stepOut(ts) {
                    if (!isHoverOnlyActive()) {
                        filterEl.style.removeProperty("filter");
                        filterEl.style.removeProperty("transition");
                        raf = null;
                        currentRatio = 0;
                        return;
                    }
                    if (!startTs) startTs = ts;
                    const p      = Math.min(1, (ts - startTs) / _hoverFadeOutMs);
                    const eased  = 1 - Math.pow(1 - p, 2);
                    currentRatio = startRatio * (1 - eased);
                    const intensity = Math.max(0, Math.min(100, (_state.intensity ?? DEFAULT_INTENSITY) * currentRatio));
                    filterEl.style.filter = currentRatio < 0.01
                        ? DROP_SHADOW_ZERO
                        : buildClockShadow(getCurrentShadowColor(), intensity, isClock);
                    if (p < 1) { raf = requestAnimationFrame(stepOut); }
                    else       { raf = null; currentRatio = 0; filterEl.style.removeProperty("filter"); }
                }
                raf = requestAnimationFrame(stepOut);
            }

            // mousemove: track shape enter / leave via per-pixel hit test
            eventEl.addEventListener("mousemove", function (e) {
                const rect   = eventEl.getBoundingClientRect();
                const normX  = (e.clientX - rect.left)  / rect.width;
                const normY  = (e.clientY - rect.top)   / rect.height;
                const onShape = hitTest(normX, normY);

                if (onShape && !isOverShape) {
                    isOverShape = true;
                    triggerEnter();
                } else if (!onShape && isOverShape) {
                    isOverShape = false;
                    triggerLeave();
                }
            });

            // mouseleave: always fire leave when cursor exits the container entirely
            eventEl.addEventListener("mouseleave", function () {
                if (isOverShape) {
                    isOverShape = false;
                    triggerLeave();
                } else {
                    clearTimeout(delayTimer); // cancel any pending enter delay
                }
            });
        }

        // Analog clock: container is event target; .clock-bg-filter receives the filter
        const analogClockContainer = document.getElementById("analogClock");
        if (analogClockContainer)
            attachClockWeatherHover(analogClockContainer, analogClockContainer, true, clockHitTest);

        // Digital clock: container is both event target and filter target
        const digitalClockEl = document.getElementById("digitalClock");
        if (digitalClockEl)
            attachClockWeatherHover(digitalClockEl, digitalClockEl, true, digitalClockHitTest);

        // Weather: .rAndakar is event target; .weather-bg-filter receives the filter
        const weatherContainer = document.querySelector(".rightDiv .topDiv .rAndakar");
        const weatherFilterEl  = document.querySelector(".rightDiv .topDiv .rAndakar .weather-bg-filter");
        if (weatherContainer && weatherFilterEl)
            attachClockWeatherHover(weatherContainer, weatherFilterEl, false, weatherHitTest);
    });
})();

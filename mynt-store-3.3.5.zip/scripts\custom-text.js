/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

// Custom text & Smart Dynamic Greeting
document.addEventListener("DOMContentLoaded", () => {
    const userTextDiv = document.getElementById("userText");
    const userTextCheckbox = document.getElementById("userTextCheckbox");
    if (!userTextDiv) return;

    // Load and apply the checkbox state
    const isUserTextVisible = localStorage.getItem("userTextVisible") !== "false";
    if (userTextCheckbox) {
        userTextCheckbox.checked = isUserTextVisible;
        userTextCheckbox.addEventListener("change", () => {
            const isVisible = userTextCheckbox.checked;
            userTextDiv.style.display = isVisible ? "block" : "none";
            localStorage.setItem("userTextVisible", isVisible);
        });
    }
    userTextDiv.style.display = isUserTextVisible ? "block" : "none";

    // Set the default language to English if no language is saved
    const savedLang = localStorage.getItem("selectedLanguage") || "en";
    if (typeof applyLanguage === "function") {
        applyLanguage(savedLang);
    }

    // Dynamic Time-Aware Smart Greeting
    function getSmartGreeting() {
        const lang = localStorage.getItem("selectedLanguage") || window.currentLanguage || document.documentElement.lang || "en";
        const isAr = lang.startsWith("ar") || lang === "ar_SA";
        const hour = new Date().getHours();
        const rawName = (localStorage.getItem("userName") || "").trim();
        // Capitalize Latin name or use as is
        const name = rawName ? (isAr ? rawName : rawName.charAt(0).toUpperCase() + rawName.slice(1)) : "";

        if (isAr) {
            if (hour >= 4 && hour < 12) {
                return name ? `صباح الخير، ${name} ☀️` : "صباح النور والبركة ✨";
            } else if (hour >= 12 && hour < 17) {
                return name ? `طاب يومك، ${name} 🌤️` : "طاب يومك بكل خير ✨";
            } else if (hour >= 17 && hour < 23) {
                return name ? `مساء الخير، ${name} 🌙` : "مساء الهدوء والإنجاز ✨";
            } else {
                return name ? `ليلة هادئة، ${name} 🌌` : "وقت الراحة والسكينة ✨";
            }
        } else {
            if (hour >= 4 && hour < 12) {
                return name ? `Good morning, ${name} ☀️` : "Good morning ✨";
            } else if (hour >= 12 && hour < 17) {
                return name ? `Good afternoon, ${name} 🌤️` : "Good afternoon ✨";
            } else if (hour >= 17 && hour < 23) {
                return name ? `Good evening, ${name} 🌙` : "Good evening ✨";
            } else {
                return name ? `Restful night, ${name} 🌌` : "Restful night ✨";
            }
        }
    }

    function isLegacyPlaceholder(val) {
        if (!val) return true;
        const v = val.trim().toLowerCase();
        return v === "click here to edit" || v === "انقر هنا للتعديل" || v === (userTextDiv.dataset.placeholder || "").toLowerCase();
    }

    function renderUserText() {
        const storedValue = localStorage.getItem("userText");
        if (storedValue && !isLegacyPlaceholder(storedValue)) {
            userTextDiv.textContent = storedValue;
            userTextDiv.dataset.isCustom = "true";
        } else {
            userTextDiv.textContent = getSmartGreeting();
            userTextDiv.dataset.isCustom = "false";
        }
    }

    renderUserText();

    // Subtle edit indicator tooltip
    userTextDiv.title = (localStorage.getItem("selectedLanguage") || "").startsWith("ar")
        ? "انقر لتعديل النص الشخصي أو كتابة هدفك"
        : "Click to customize greeting or write a personal goal";

    // Handle input event
    userTextDiv.addEventListener("input", function () {
        const current = userTextDiv.textContent.trim();
        if (current && !isLegacyPlaceholder(current)) {
            localStorage.setItem("userText", userTextDiv.textContent);
            userTextDiv.dataset.isCustom = "true";
        } else {
            localStorage.removeItem("userText");
            userTextDiv.dataset.isCustom = "false";
        }
    });

    // Remove text when user clicks to edit if it's the auto smart greeting
    userTextDiv.addEventListener("focus", function () {
        if (userTextDiv.dataset.isCustom !== "true") {
            // Keep existing text selected so they can easily type over or keep it
            const range = document.createRange();
            range.selectNodeContents(userTextDiv);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        }
    });

    userTextDiv.addEventListener("keydown", function (e) {
        if (e.key === "Enter") {
            e.preventDefault();
            userTextDiv.blur();
        } else if (e.key === "Escape") {
            e.preventDefault();
            renderUserText();
            userTextDiv.blur();
        }
    });

    // Restore smart greeting if the user leaves the div empty after editing
    userTextDiv.addEventListener("blur", function () {
        const current = userTextDiv.textContent.trim();
        if (!current || isLegacyPlaceholder(current)) {
            localStorage.removeItem("userText");
            userTextDiv.dataset.isCustom = "false";
            renderUserText();
        }
    });

    // Re-render when onboarding completes, language changes, or storage updates
    window.addEventListener("material-you-onboarding-done", renderUserText);
    window.addEventListener("material-you-language-change", renderUserText);
    window.addEventListener("storage", (e) => {
        if (e.key === "userName" || e.key === "userText" || e.key === "selectedLanguage") {
            renderUserText();
        }
    });
});
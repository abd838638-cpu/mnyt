/* Keep a local monogram visible while remote favicons resolve. MV3 CSP safe. */
(function () {
    "use strict";
    const active = new WeakMap();
    const resolved = new Map();
    const core = window.MyntNavigationCore;
    // Persist successful resolutions across reloads: repeat visits resolve
    // instantly with zero network. Failures stay unpersisted so they retry.
    const LS_KEY = "myntFaviconCacheV1";
    const LS_CAP = 250;
    let _persistTimer = 0;
    try {
        const saved = JSON.parse(localStorage.getItem(LS_KEY) || "{}");
        Object.keys(saved).slice(0, LS_CAP).forEach(k => {
            if (typeof saved[k] === "string" && saved[k]) resolved.set(k, Promise.resolve(saved[k]));
        });
    } catch (_) {}
    function persistResolved(key, src) {
        clearTimeout(_persistTimer);
        _persistTimer = setTimeout(() => {
            try {
                const saved = JSON.parse(localStorage.getItem(LS_KEY) || "{}");
                if (saved[key] === src) return;
                saved[key] = src;
                const keys = Object.keys(saved);
                if (keys.length > LS_CAP) keys.slice(0, keys.length - LS_CAP).forEach(k => delete saved[k]);
                localStorage.setItem(LS_KEY, JSON.stringify(saved));
            } catch (_) {}
        }, 600);
    }
    function load(src) {
        return new Promise(resolve => {
            const probe = new Image();
            const timeout = setTimeout(() => finish(false), 3500);
            function finish(ok) {
                clearTimeout(timeout);
                probe.onload = probe.onerror = null;
                resolve(ok);
            }
            probe.onload = () => finish(probe.naturalWidth > 0);
            probe.onerror = () => finish(false);
            probe.referrerPolicy = "no-referrer";
            probe.src = src;
        });
    }
    async function resolveIcon(candidates) {
        for (const src of candidates) if (await load(src)) return src;
        return "";
    }
    function set(image, pageUrl, options = {}) {
        const token = {};
        active.set(image, token);
        image.alt = "";
        image.referrerPolicy = "no-referrer";
        image.decoding = "async";
        image.classList.add("site-icon-fallback");
        image.src = core.fallbackIcon(pageUrl, options.label);
        const runtimeId = typeof chrome !== "undefined" && chrome.runtime?.id && !(typeof isFirefox !== "undefined" && isFirefox) && !(typeof isOpera !== "undefined" && isOpera) ? chrome.runtime.id : "";
        const candidates = options.src ? [options.src] : core.faviconCandidates(pageUrl, runtimeId, options.size || 64);
        const key = candidates.join("|");
        if (!key) return;
        if (!resolved.has(key)) {
            const promise = resolveIcon(candidates);
            resolved.set(key, promise);
            // Failed requests can be retried after a future render; cache stays bounded.
            // Successful ones persist to localStorage for instant repeat loads.
            promise.then(src => {
                if (!src) resolved.delete(key);
                else persistResolved(key, src);
            });
            if (resolved.size > 256) resolved.delete(resolved.keys().next().value);
        }
        resolved.get(key).then(src => {
            if (active.get(image) !== token || !src) return;
            image.addEventListener("error", () => {
                if (active.get(image) === token) {
                    image.classList.add("site-icon-fallback");
                    image.src = core.fallbackIcon(pageUrl, options.label);
                    options.onResolved?.();
                }
            }, { once: true });
            image.src = src;
            image.classList.remove("site-icon-fallback");
            options.onResolved?.();
        });
    }
    window.MyntSiteIcons = { set };
})();

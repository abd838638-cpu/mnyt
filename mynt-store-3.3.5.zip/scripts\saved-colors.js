/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 *
 * Saved Custom Colors Feature
 * - Automatically saves picked colors to a favorites list
 * - Right-click context menu: "Apply Theme" / "Remove"
 */

const SAVED_COLORS_KEY = "savedCustomColors";
const MAX_SAVED_COLORS = 20;

let _dotAnimating = false;

// -- Shared: play the bounce animation on a dot, optionally run a callback
// after the animation ends.  Suppresses the MutationObserver re-render for
// the duration so the dot isn't destroyed mid-animation.
function playDotAnim(dot, onEnd) {
    _dotAnimating = true;
    document.querySelectorAll(".colorPlate, .colorPlate-grad, .sc-color-dot").forEach(el => {
        el.classList.remove("plate-select-anim");
    });
    void dot.offsetWidth; // force reflow so animation restarts
    dot.classList.add("plate-select-anim");
    dot.addEventListener("animationend", () => {
        dot.classList.remove("plate-select-anim");
        _dotAnimating = false;
        if (typeof onEnd === "function") onEnd();
    }, { once: true });
}

// -- Convert a hex color to an rgba shadow color string (opacity 0.55)
function hexToShadowColor(hex) {
    if (!hex) return null;
    hex = hex.replace("#", "");
    if (hex.length === 3) hex = hex.split("").map(c => c + c).join("");
    const r = parseInt(hex.slice(0, 2), 16);
    const g = parseInt(hex.slice(2, 4), 16);
    const b = parseInt(hex.slice(4, 6), 16);
    if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
    return `rgba(${r},${g},${b},0.65)`;
}

// Each entry is either a hex string "#RRGGBB" OR an object {type:"gradient", c1:"#...", c2:"#...", id:"..."}
function getSavedColors() {
    try {
        return JSON.parse(localStorage.getItem(SAVED_COLORS_KEY)) || [];
    } catch {
        return [];
    }
}

function setSavedColors(arr) {
    localStorage.setItem(SAVED_COLORS_KEY, JSON.stringify(arr));
}

function colorEntryId(entry) {
    if (typeof entry === "string") return entry.toUpperCase();
    return entry.id || (entry.c1 + "_" + entry.c2).toUpperCase();
}

function addSavedColor(hex) {
    hex = hex.toUpperCase();
    let colors = getSavedColors();
    colors = colors.filter(c => colorEntryId(c) !== hex);
    colors.unshift(hex);
    if (colors.length > MAX_SAVED_COLORS) colors = colors.slice(0, MAX_SAVED_COLORS);
    setSavedColors(colors);
}

function addSavedGradient(c1, c2) {
    c1 = c1.toUpperCase(); c2 = c2.toUpperCase();
    const id = c1 + "_" + c2;
    let colors = getSavedColors();
    colors = colors.filter(c => colorEntryId(c) !== id);
    colors.unshift({ type: "gradient", c1, c2, id });
    if (colors.length > MAX_SAVED_COLORS) colors = colors.slice(0, MAX_SAVED_COLORS);
    setSavedColors(colors);
}

function removeSavedColor(entryId) {
    entryId = entryId.toUpperCase();
    const colors = getSavedColors().filter(c => colorEntryId(c) !== entryId);
    setSavedColors(colors);
}

// -- Helper: compute the displayed accent color for a hex in the current mode --
function getDisplayColorForDot(hex) {
    const preferredTheme = localStorage.getItem("preferredTheme") || "light";
    const systemIsDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const isDark = preferredTheme === "dark" || (preferredTheme === "system" && systemIsDark);

    // Near-white ? grey
    const rr=parseInt(hex.slice(1,3)||"80",16), gg=parseInt(hex.slice(3,5)||"80",16), bb=parseInt(hex.slice(5,7)||"80",16);
    const raw = (rr>240 && gg>240 && bb>240) ? "#808080" : hex.toUpperCase();
    const lum = getSimpleLuminance(raw);

    if (isDark) {
        // Return the computed accent color for dark mode
        let accent = raw;
        if (lum < 0.06)      accent = adjustHexColor(raw, 0.45, true);
        else if (lum < 0.12) accent = adjustHexColor(raw, 0.25, true);
        else if (lum > 0.70) accent = adjustHexColor(raw, 0.35, false);
        return accent;
    } else {
        // Return the computed accent for light mode (slightly darkened if needed)
        let accent = raw;
        if (lum > 0.85)      accent = adjustHexColor(raw, 0.50, false);
        else if (lum > 0.70) accent = adjustHexColor(raw, 0.25, false);
        return accent;
    }
}

// -- Helper: compute displayed colors for gradient dot in current mode --
function getDisplayColorsForGradientDot(c1, c2) {
    const preferredTheme = localStorage.getItem("preferredTheme") || "light";
    const systemIsDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const isDark = preferredTheme === "dark" || (preferredTheme === "system" && systemIsDark);

    function surface(rawC1) {
        const lum = getSimpleLuminance(rawC1);
        if (isDark) {
            if (lum > 0.93) rawC1 = "#D8D8D8";
            const l2 = getSimpleLuminance(rawC1);
            if (l2 < 0.12) return rawC1;
            if (l2 < 0.35) return adjustHexColor(rawC1, 0.15, false);
            if (l2 < 0.65) return adjustHexColor(rawC1, 0.52, false);
            return adjustHexColor(rawC1, 0.74, false);
        } else {
            if (getSimpleLuminance(rawC1) < 0.12) rawC1 = adjustHexColor(rawC1, 0.30, true);
            return adjustHexColor(rawC1, 0.72, true);
        }
    }
    function accent(rawC2) {
        const lum = getSimpleLuminance(rawC2);
        let c = rawC2;
        if (isDark) {
            if (lum < 0.06) c = adjustHexColor(rawC2, 0.45, true);
            else if (lum < 0.12) c = adjustHexColor(rawC2, 0.25, true);
        } else {
            if (lum > 0.85) c = adjustHexColor(rawC2, 0.50, false);
            else if (lum > 0.70) c = adjustHexColor(rawC2, 0.25, false);
        }
        return c;
    }
    return { bg: surface(c1), acc: accent(c2) };
}


// -- Context Menu --------------------------------------------------------------

let activeContextMenu = null;

function closeContextMenu() {
    if (activeContextMenu) {
        const menu = activeContextMenu;
        activeContextMenu = null;
        menu.classList.remove("sc-ctx-visible");
        const mult = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")) || 1;
        const dur = Math.round(180 * mult);
        setTimeout(() => {
            menu.remove();
        }, dur + 20);
    }
    // Close all other context menus (from dual-color.js)
    document.querySelectorAll(".sc-context-menu").forEach(menu => {
        if (menu !== activeContextMenu) {
            menu.classList.remove("sc-ctx-visible");
            const mult = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")) || 1;
            const dur = Math.round(180 * mult);
            setTimeout(() => {
                menu.remove();
            }, dur + 20);
        }
    });
}

function getT(key) {
    return translations[currentLanguage]?.[key] || translations["en"]?.[key] || key;
}

function showContextMenu(e, entry) {
    e.preventDefault();
    closeContextMenu();
    // Also close dual-color context menu if open
    if (typeof _closeContextMenuDual === "function") {
        try {
            _closeContextMenuDual();
        } catch(err) {}
    }

    const isGradient = typeof entry === "object" && entry.type === "gradient";
    const entryId = colorEntryId(entry);
    // Capture the dot that was right-clicked so we can animate it on Apply
    const sourceDot = e.target.closest ? e.target.closest(".sc-color-dot") : null;

    const menu = document.createElement("div");
    menu.className = "sc-context-menu";

    // -- Apply Theme button --
    const applyBtn = document.createElement("button");
    applyBtn.className = "sc-ctx-btn sc-ctx-apply";
    applyBtn.innerHTML = `
        <svg class="keep-color" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>
        </svg>
        <span>${getT("savedColorApply")}</span>`;
    applyBtn.addEventListener("click", () => {
        closeContextMenu();

        // Helper: play animation then apply; if dot is gone (already re-rendered), skip anim
        const applyWithAnim = (applyFn) => {
            if (sourceDot && sourceDot.isConnected) {
                playDotAnim(sourceDot, () => {
                    renderSavedColors();
                });
                applyFn();
            } else {
                applyFn();
                renderSavedColors();
            }
        };

        if (isGradient) {
            if (window.dualColorTheme) {
                // If this entry is currently the active dual theme, preserve any picker
                // modifications the user made — don't revert to the entry's original colors.
                const originId = localStorage.getItem("dualColorOriginId");
                let c1ToApply = entry.c1, c2ToApply = entry.c2;
                const isAlreadyActive = originId === entryId &&
                    document.body.getAttribute("data-dual-theme") === "active";
                if (isAlreadyActive) {
                    try {
                        const stored = JSON.parse(localStorage.getItem("dualColorTheme") || "null");
                        if (stored && stored.c1 && stored.c2) {
                            c1ToApply = stored.c1;
                            c2ToApply = stored.c2;
                        }
                    } catch(e) {}
                } else {
                    if (window.dualColorTheme.resetSwap) window.dualColorTheme.resetSwap();
                }
                applyWithAnim(() => {
                    localStorage.setItem("dualColorTheme", JSON.stringify({ c1: c1ToApply, c2: c2ToApply }));
                    localStorage.setItem("dualColorOriginId", entryId);
                    localStorage.removeItem(themeStorageKey);
                    localStorage.removeItem("safePresetTheme");
                    localStorage.removeItem(customThemeStorageKey);
                    window.dualColorTheme.applyDualGradient(c1ToApply, c2ToApply);
                    document.querySelectorAll(".colorPlate").forEach(r => r.checked = false);
                    if (window.dualColorTheme.updateGradPresetActive) window.dualColorTheme.updateGradPresetActive();
                });
            }
        } else {
            // Check if already active to prevent dark?light?dark flash
            const currentActive = (localStorage.getItem(customThemeStorageKey) || "").toUpperCase();
            const isAlreadyActive =
                currentActive === entry.toUpperCase() &&
                document.body.getAttribute("data-custom-theme") === "active" &&
                !localStorage.getItem("safePresetTheme");

            if (isAlreadyActive) {
                if (sourceDot && sourceDot.isConnected) {
                    playDotAnim(sourceDot, renderSavedColors);
                } else {
                    renderSavedColors();
                }
                return;
            }

            applyWithAnim(() => {
                // Uncheck ALL preset radios FIRST before theme changes
                document.querySelectorAll(".colorPlate").forEach(r => r.checked = false);
                document.querySelectorAll(".colorPlate-grad").forEach(b => b.classList.remove("grad-active"));
                // FIX: capture the REAL filter-dark state BEFORE resetDarkTheme removes
                // data-custom-theme. Without this, _smoothThemeSwitch sees wasFilterDark=true
                // (predefined-dark) instead of false (custom-dark), fires Case D instead of
                // Case E, and produces a visible light flash when switching Pick Colors in
                // dark mode.
                const _preResetWasFilterDark = typeof window._isFilterDarkActive === "function"
                    ? window._isFilterDarkActive()
                    : undefined;
                resetDarkTheme();
                localStorage.setItem(customThemeStorageKey, entry);
                localStorage.removeItem(themeStorageKey);
                localStorage.removeItem("safePresetTheme");
                // IMPORTANT: applyCustomTheme BEFORE clearDualTheme — same reason as dot click above.
                // Pass the pre-reset wasFilterDark so Case E fires correctly for Pick Color ? Pick Color in dark mode.
                applyCustomTheme(entry, _preResetWasFilterDark);
                localStorage.removeItem("dualColorTheme");
                if (window.dualColorTheme) window.dualColorTheme.clearDualTheme();
            });
        }
    });

    // -- Remove button --
    const removeBtn = document.createElement("button");
    removeBtn.className = "sc-ctx-btn sc-ctx-remove";
    removeBtn.innerHTML = `
        <svg class="keep-color" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
        </svg>
        <span>${getT("savedColorRemove")}</span>`;
    removeBtn.addEventListener("click", () => {
        removeSavedColor(entryId);
        // If this was the active theme, revert
        if (isGradient) {
            const storedDual = localStorage.getItem("dualColorTheme");
            if (storedDual) {
                try {
                    const d = JSON.parse(storedDual);
                    if ((d.c1 + "_" + d.c2).toUpperCase() === entryId) {
                        // Use _smoothThemeSwitch so the dark?predefined transition
                        // never triggers a white flash (handles filter:invert safely)
                        if (typeof applyPredefinedThemeNow === "function") {
                            applyPredefinedThemeNow("blue");
                        } else {
                            localStorage.removeItem("dualColorTheme");
                            if (window.dualColorTheme) window.dualColorTheme.clearDualTheme();
                            localStorage.setItem(themeStorageKey, "blue");
                            applySelectedTheme("blue");
                        }
                        const dfChecked = document.getElementById("dfChecked");
                        if (dfChecked) dfChecked.checked = true;
                    }
                } catch(e) {}
            }
        } else {
            const current = localStorage.getItem(customThemeStorageKey);
            if (current && current.toUpperCase() === entry.toUpperCase()) {
                // Use _smoothThemeSwitch so the dark custom?predefined transition
                // never triggers a white flash (handles filter:invert safely)
                if (typeof applyPredefinedThemeNow === "function") {
                    applyPredefinedThemeNow("blue");
                } else {
                    localStorage.removeItem(customThemeStorageKey);
                    localStorage.setItem(themeStorageKey, "blue");
                    applySelectedTheme("blue");
                }
                const dfChecked = document.getElementById("dfChecked");
                if (dfChecked) dfChecked.checked = true;
            }
        }
        renderSavedColors();
        closeContextMenu();
    });

    menu.appendChild(applyBtn);
    menu.appendChild(removeBtn);
    document.body.appendChild(menu);
    activeContextMenu = menu;

    // Position the menu
    const menuW = 160;
    const menuH = 84;
    let x = e.clientX;
    let y = e.clientY;
    if (x + menuW > window.innerWidth) x = window.innerWidth - menuW - 8;
    if (y + menuH > window.innerHeight) y = window.innerHeight - menuH - 8;
    menu.style.left = x + "px";
    menu.style.top = y + "px";

    // Force reflow to register starting styles for transition
    void menu.offsetWidth;

    // Animate in
    menu.classList.add("sc-ctx-visible");
}

document.addEventListener("click", closeContextMenu);
document.addEventListener("keydown", e => { if (e.key === "Escape") closeContextMenu(); });

// -- Render Saved Colors -------------------------------------------------------

function renderSavedColors() {
    const container = document.getElementById("colorsContainer");
    const accContainer = document.getElementById("colorsAccContainer");
    if (!container) return;

    // Remove previously rendered saved color circles from both containers
    container.querySelectorAll(".sc-saved-dot").forEach(el => el.remove());
    if (accContainer) accContainer.querySelectorAll(".sc-saved-dot").forEach(el => el.remove());

    const colors = getSavedColors();
    if (colors.length === 0) return;

    const activeCustom = (localStorage.getItem(customThemeStorageKey) || "").toUpperCase();
    
    // Detect the active custom source from persisted theme data + body attributes.
    // A stale checked preset radio must not hide the custom/dual saved-color marker.
    const customAttrActive = document.body.getAttribute("data-custom-theme") === "active";
    const dualAttrActive = document.body.getAttribute("data-dual-theme") === "active";
    const anyRadioChecked = [...document.querySelectorAll(".colorPlate")].some(r => r.checked);
    const safePresetActive = !!localStorage.getItem("safePresetTheme");
    const storedPresetActive = !!localStorage.getItem(themeStorageKey) || safePresetActive;
    const presetThemeActive = !customAttrActive && !dualAttrActive && (storedPresetActive || anyRadioChecked);
    const dualThemeActive = dualAttrActive && !!localStorage.getItem("dualColorTheme");
    const customColorActive = !dualThemeActive && !safePresetActive && !!activeCustom && customAttrActive;

    // Active gradient check
    let activeDualId = "";
    if (dualThemeActive) {
        try {
            const d = JSON.parse(localStorage.getItem("dualColorTheme") || "null");
            if (d && d.c1 && d.c2) activeDualId = (d.c1 + "_" + d.c2).toUpperCase();
        } catch(e) {}
    }

    // Separate saved colors into single-color (? Background section) and gradients (? Colors section)
    const singleColors = colors.filter(c => typeof c === "string");
    const gradientColors = colors.filter(c => typeof c === "object" && c.type === "gradient");

    // -- Render single-color dots in Background container --
    if (singleColors.length > 0) {
        const sep = document.createElement("div");
        sep.className = "sc-separator sc-saved-dot";
        container.appendChild(sep);

        singleColors.forEach(entry => {
            const hex = entry;
            const entryId = colorEntryId(entry);
            const dot = document.createElement("div");
            dot.className = "sc-saved-dot sc-color-dot";
            const displayHex = getDisplayColorForDot(hex);
            dot.style.backgroundColor = displayHex;
            // Use raw hex for shadow so glow is vivid even in dark mode
            const shadowColor = hexToShadowColor(hex);
            if (shadowColor) dot.style.setProperty("--dot-shadow-color", shadowColor);
            dot.title = hex;
            dot.dataset.hex = hex;
            // Show checkmark from the real custom-theme source, not a stale radio state.
            if (customColorActive && hex.toUpperCase() === activeCustom) {
                dot.classList.add("sc-active");
            }
            dot.addEventListener("click", () => {
                // If this dot is already the active theme, only play animation
                const currentActive = (localStorage.getItem(customThemeStorageKey) || "").toUpperCase();
                const isAlreadyActive =
                    currentActive === hex.toUpperCase() &&
                    document.body.getAttribute("data-custom-theme") === "active" &&
                    !localStorage.getItem("safePresetTheme");

                if (isAlreadyActive) {
                    playDotAnim(dot, renderSavedColors);
                    return;
                }

                playDotAnim(dot, renderSavedColors);

                document.querySelectorAll(".colorPlate").forEach(r => r.checked = false);
                document.querySelectorAll(".colorPlate-grad").forEach(b => b.classList.remove("grad-active"));
                // Show checkmark immediately — don't wait for renderSavedColors after anim
                document.querySelectorAll(".sc-saved-dot.sc-active").forEach(d => d.classList.remove("sc-active"));
                dot.classList.add("sc-active");
                // FIX: capture the REAL filter-dark state BEFORE resetDarkTheme removes data-custom-theme
                const _preResetWasFilterDark2 = typeof window._isFilterDarkActive === "function"
                    ? window._isFilterDarkActive()
                    : undefined;
                resetDarkTheme();
                localStorage.setItem(customThemeStorageKey, hex);
                localStorage.removeItem(themeStorageKey);
                localStorage.removeItem("safePresetTheme");
                // IMPORTANT: applyCustomTheme MUST run BEFORE clearDualTheme.
                // clearDualTheme removes data-dual-theme from body, which instantly
                // activates filter:invert on the OLD dark CSS vars ? bright white flash.
                // By running applyCustomTheme first, _smoothThemeSwitch captures the
                // correct wasFilterDark state and shields the transition with
                // anim-suppress-filter before any attribute removal happens.
                applyCustomTheme(hex, _preResetWasFilterDark2);
                localStorage.removeItem("dualColorTheme");
                if (window.dualColorTheme) window.dualColorTheme.clearDualTheme();
                // renderSavedColors is called via playDotAnim onEnd — not here,
                // so the dot lives long enough to finish its bounce animation.
            });
            dot.addEventListener("contextmenu", e => showContextMenu(e, entry));
            container.appendChild(dot);
        });
    }

    // -- Render gradient dots in Colors (accent) container --
    if (gradientColors.length > 0 && accContainer) {
        const sep2 = document.createElement("div");
        sep2.className = "sc-separator sc-saved-dot";
        accContainer.appendChild(sep2);

        gradientColors.forEach(entry => {
            const entryId = colorEntryId(entry);
            const dot = document.createElement("div");
            dot.className = "sc-saved-dot sc-color-dot sc-gradient-dot";

            const presetAlreadyActive = !!document.querySelector('.colorPlate-grad.grad-active[data-c1="' + entry.c1 + '"][data-c2="' + entry.c2 + '"]');
            const isActiveDot = !presetThemeActive && dualThemeActive && entryId === activeDualId && !presetAlreadyActive;
            const isSwapped = isActiveDot && localStorage.getItem("dualColorSwapped") === "1";
            const rawDotC1 = isSwapped ? entry.c2 : entry.c1;
            const rawDotC2 = isSwapped ? entry.c1 : entry.c2;
            const displayDot = getDisplayColorsForGradientDot(rawDotC1, rawDotC2);
            dot.style.background = "linear-gradient(135deg, " + displayDot.bg + ", " + displayDot.acc + ")";
            // Keep shadow vivid even when the visible gradient adapts to dark mode.
            const sc1 = hexToShadowColor(rawDotC1), sc2 = hexToShadowColor(rawDotC2);
            if (sc1) dot.style.setProperty("--dot-shadow-color", sc1);
            dot.title = entry.c1 + " ? " + entry.c2;
            dot.dataset.hex = entryId;
            if (isActiveDot) dot.classList.add("sc-active");

            dot.addEventListener("click", () => {
                if (window.dualColorTheme) {
                    const currentDual = localStorage.getItem("dualColorTheme");
                    let currentId = "";
                    try {
                        const d = JSON.parse(currentDual || "null");
                        if (d && d.c1 && d.c2) currentId = (d.c1 + "_" + d.c2).toUpperCase();
                    } catch(e) {}

                    const isAlreadyActive = currentId === entryId &&
                        document.body.getAttribute("data-dual-theme") === "active";

                    if (isAlreadyActive) {
                        playDotAnim(dot, renderSavedColors);
                        return;
                    }

                    // Show checkmark immediately — don't wait for renderSavedColors after anim
                    document.querySelectorAll(".sc-saved-dot.sc-active").forEach(d => d.classList.remove("sc-active"));
                    dot.classList.add("sc-active");

                    playDotAnim(dot, renderSavedColors);

                    if (window.dualColorTheme.resetSwap) window.dualColorTheme.resetSwap();
                    localStorage.setItem("dualColorTheme", JSON.stringify({ c1: entry.c1, c2: entry.c2 }));
                    localStorage.setItem("dualColorOriginId", entryId);
                    localStorage.removeItem(themeStorageKey);
                    localStorage.removeItem("safePresetTheme");
                    localStorage.removeItem(customThemeStorageKey);
                    window.dualColorTheme.applyDualGradient(entry.c1, entry.c2);
                    document.querySelectorAll(".colorPlate").forEach(r => r.checked = false);
                    if (window.dualColorTheme.updateGradPresetActive) window.dualColorTheme.updateGradPresetActive();
                    // renderSavedColors is called via playDotAnim onEnd — not here,
                    // so the dot lives long enough to finish its bounce animation.
                }
            });
            dot.addEventListener("contextmenu", e => showContextMenu(e, entry));
            accContainer.appendChild(dot);
        });
    }
}

// -- Hook into color picker ----------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
    // Defer render until after theme scripts have initialized body attributes
    setTimeout(renderSavedColors, 50);

    const picker = document.getElementById("colorPicker");
    if (picker) {
        picker.addEventListener("change", (e) => {
            addSavedColor(e.target.value);
            renderSavedColors();
        });
    }

    // When any predefined color is selected, re-render saved colors to remove active mark
    document.querySelectorAll(".colorPlate").forEach(radio => {
        radio.addEventListener("change", () => {
            renderSavedColors();
        });
    });

    // Auto-update Colors section when theme body attributes change
    // (e.g. dual theme activated/deactivated, custom theme applied)
    const bodyObserver = new MutationObserver((mutations) => {
        const relevant = mutations.some(m =>
            m.attributeName === "data-dual-theme" ||
            m.attributeName === "data-custom-theme"
        );
        if (relevant && !_dotAnimating) {
            requestAnimationFrame(renderSavedColors);
        }
    });
    bodyObserver.observe(document.body, {
        attributes: true,
        attributeFilter: ["data-dual-theme", "data-custom-theme"]
    });

    document.addEventListener("theme-colors-changed", () => {
        if (window._colorPickerDragging) return;
        if (!_dotAnimating) requestAnimationFrame(renderSavedColors);
    });

    const modeMedia = window.matchMedia("(prefers-color-scheme: dark)");
    modeMedia.addEventListener("change", () => {
        if ((localStorage.getItem("preferredTheme") || "light") === "system" && !_dotAnimating) {
            requestAnimationFrame(renderSavedColors);
        }
    });
});

/*
 * Material You NewTab — Dual Color Theme
 * Color 1 → surfaces & backgrounds (bg-color, accentLightTint)
 * Color 2 → accents, icons, buttons, clock hands, text (darkColor, darkerColor, textColorDark)
 */

(function () {
    var DUAL_COLOR_KEY = "dualColorTheme";

    // Cache prefers-color-scheme query once (small perf win).
    var _MQL_PREFERS_DARK = (typeof window !== "undefined" && window.matchMedia)
        ? window.matchMedia("(prefers-color-scheme: dark)")
        : { matches: false };

    // Monotonic token to invalidate any pending rAF writes from a previous dual-theme
    // apply. Without this, switching dual -> predefined can run a stale rAF later and
    // "lock" the trigger circle back to the old dual colors.
    var _applySeq = 0;

    // ── Color math ─────────────────────────────────────────────────────────────

    function hexToRgb(hex) {
        hex = hex.replace("#", "");
        if (hex.length === 3) hex = hex.split("").map(function(c){ return c+c; }).join("");
        return {
            r: parseInt(hex.substring(0,2), 16),
            g: parseInt(hex.substring(2,4), 16),
            b: parseInt(hex.substring(4,6), 16)
        };
    }
    function rgbToHex(r, g, b) {
        return "#" + ("000000" + ((r << 16) | (g << 8) | b).toString(16)).slice(-6).toUpperCase();
    }
    function getLuminance(hex) {
        var c = hexToRgb(hex);
        return 0.2126*c.r/255 + 0.7152*c.g/255 + 0.0722*c.b/255;
    }

    function clamp01(value) {
        return Math.max(0, Math.min(1, Number(value) || 0));
    }

    function mixNumber(start, end, amount) {
        return start + (end - start) * clamp01(amount);
    }

    function smoothStep(edge0, edge1, value) {
        if (edge0 === edge1) return value >= edge1 ? 1 : 0;
        var t = clamp01((value - edge0) / (edge1 - edge0));
        return t * t * (3 - 2 * t);
    }

    // Lighten or darken by factor 0-1
    function adjustHex(hex, factor, lighten) {
        if (lighten === undefined) lighten = true;
        hex = hex.replace("#", "");
        if (hex.length === 3) hex = hex.split("").map(function(c){ return c+c; }).join("");
        var r = parseInt(hex.substring(0,2), 16);
        var g = parseInt(hex.substring(2,4), 16);
        var b = parseInt(hex.substring(4,6), 16);
        if (lighten) {
            r = Math.min(255, Math.floor(r + (255-r) * factor));
            g = Math.min(255, Math.floor(g + (255-g) * factor));
            b = Math.min(255, Math.floor(b + (255-b) * factor));
        } else {
            r = Math.max(0, Math.floor(r * (1-factor)));
            g = Math.max(0, Math.floor(g * (1-factor)));
            b = Math.max(0, Math.floor(b * (1-factor)));
        }
        return rgbToHex(r, g, b);
    }

    function shiftHexToLuminance(hex, targetLuminance) {
        var sourceHex = String(hex || "#000000").trim() || "#000000";
        var sourceLum = getLuminance(sourceHex);
        var targetLum = clamp01(targetLuminance);
        if (Math.abs(targetLum - sourceLum) < 0.0005) return adjustHex(sourceHex, 0, true);
        if (targetLum > sourceLum) {
            var remaining = 1 - sourceLum;
            var lightenFactor = remaining <= 0.0005 ? 0 : clamp01((targetLum - sourceLum) / remaining);
            return adjustHex(sourceHex, lightenFactor, true);
        }
        var darkenFactor = sourceLum <= 0.0005 ? 0 : clamp01((sourceLum - targetLum) / sourceLum);
        return adjustHex(sourceHex, darkenFactor, false);
    }

    // Mix two hex colors with a given ratio (0 = all colorA, 1 = all colorB)
    function mixHex(hexA, hexB, ratio) {
        var a = hexToRgb(hexA), b = hexToRgb(hexB);
        return rgbToHex(
            Math.round(a.r + (b.r - a.r) * ratio),
            Math.round(a.g + (b.g - a.g) * ratio),
            Math.round(a.b + (b.b - a.b) * ratio)
        );
    }

    function isNearBlack(hex) {
        var rgb = hexToRgb(hex);
        if (!rgb) return false;
        return (rgb.r <= 12 && rgb.g <= 12 && rgb.b <= 12) || getLuminance(hex) <= 0.012;
    }

    // Build surface palette respecting current mode.
    // No color barriers — every hue is preserved, only luminance is adjusted.
    // Dark colors → get lighter derivatives (visible depth on dark bg)
    // Light colors → get darker derivatives (visible depth on light bg)
    function buildSurfaceFamily(rawC1, dark) {
        var lum = getLuminance(rawC1);

        if (dark) {
            // Dark mode: keep surfaces dark but still visibly tinted by the chosen hue.
            var blackFactor = smoothStep(0.0, 0.12, lum);
            var bgTarget = mixNumber(0.0, mixNumber(0.028, 0.048, smoothStep(0.06, 0.96, lum)), blackFactor);
            var bg = shiftHexToLuminance(rawC1, bgTarget);
            var bgLumVal = getLuminance(bg);
            var tintTarget = Math.min(
                0.19,
                bgLumVal + mixNumber(0.075, 0.045, smoothStep(0.08, 0.90, lum))
            );
            var bgTint = shiftHexToLuminance(rawC1, tintTarget);
            return { bg: bg, bgTint: bgTint };
        } else {
            // Light mode: surfaces must be light.
            var whiteFactor = smoothStep(0.85, 1.0, lum);
            var bgTargetLight = clamp01(
                0.84
                + 0.10 * (1 - smoothStep(0.00, 0.24, lum))
                - 0.18 * smoothStep(0.66, 0.99, lum)
            );
            var bgTargetAdjusted = mixNumber(bgTargetLight, 1.0, whiteFactor);
            var bgLight = shiftHexToLuminance(rawC1, bgTargetAdjusted);
            var tintTargetLight = clamp01(
                Math.min(1.0, bgTargetAdjusted + 0.055 * (1 - whiteFactor))
            );
            var bgTintLight = shiftHexToLuminance(rawC1, tintTargetLight);
            return {
                bg: bgLight,
                bgTint: bgTintLight
            };
        }
    }

    // Build accent palette respecting current mode.
    // No color barriers — every hue is preserved.
    var MAX_ACC_LUM_DARK = 0.78; // prevent stark-white accent in dark mode

    function buildAccentFamily(rawC2, dark, bgHex) {
        var lum = getLuminance(rawC2);
        var c2  = rawC2;

        if (dark) {
            // Dark mode: lighten hue until WCAG 4.5:1 vs bg, cap at 0.78 (no stark white).
            if (bgHex) {
                var bgLum     = getLuminance(bgHex);
                // Lift minAccLum when background is very dark to ensure contrast
                var minAccLum = bgLum * 4.5 + mixNumber(0.45, 0.175, smoothStep(0.0, 0.25, bgLum));
                if (lum < minAccLum) {
                    for (var step = 5; step <= 95; step += 5) {
                        var candidate = adjustHex(rawC2, step / 100, true);
                        if (getLuminance(candidate) >= minAccLum) { c2 = candidate; break; }
                    }
                }
            } else {
                if (lum < 0.08) c2 = adjustHex(rawC2, 0.50, true);
                else if (lum < 0.18) c2 = adjustHex(rawC2, 0.28, true);
            }
            // Cap: prevent stark white / over-bright accents in dark mode
            if (getLuminance(c2) > MAX_ACC_LUM_DARK) {
                for (var ds = 5; ds <= 80; ds += 5) {
                    var dc = adjustHex(rawC2, ds / 100, false);
                    if (getLuminance(dc) <= MAX_ACC_LUM_DARK) { c2 = dc; break; }
                }
            }
        } else {
            // Light mode: ensure accent is dark enough to be visible on light background.
            if (lum > 0.85) c2 = adjustHex(rawC2, 0.55, false);
            else if (lum > 0.70) c2 = adjustHex(rawC2, 0.25, false);
        }

        return {
            accent:     c2,
            accentDark: adjustHex(c2, 0.20, false),
            // Dark mode: text must be near-white; light mode: derive from accent
            textDark:   dark ? "#e4e4e4" : adjustHex(c2, 0.50, false)
        };
    }

    // ── Swap state ────────────────────────────────────────────────────────────
    var SWAP_KEY = "dualColorSwapped";
    var _swapped = false;

    // ── Display color helper ──────────────────────────────────────────────────
    // Mirrors _applyDualGradientCore's btnC1/btnC2 exactly, including swap.
    // Used for the RAF animation: we compute start + end colors before any state
    // change so we can interpolate between them frame-by-frame.
    // Derive a visually representative display color for the large circle and
    // trigger-button halves.  Uses the SAME formula regardless of the color's
    // "role" (surface vs accent) so that swapping is perfectly symmetric:
    //   _deriveDisplay(rawC1) → left,  _deriveDisplay(rawC2) → right
    //   _deriveDisplay(rawC2) → left,  _deriveDisplay(rawC1) → right  (after swap)
    // This guarantees before.c1/c2 and after.c2/c1 are identical — the animation
    // is a pure positional swap with zero color change on any frame or snap.
    function _deriveDisplayColor(hex, dark) {
        if (!dark) return hex;              // light mode: show raw hue as-is
        // Dark mode: lighten the raw hue so it's visible on a dark background,
        // using the same factor for every color regardless of role.
        return adjustHex(hex, 0.45, true);
    }

    function _computeDisplayColors(rawC1, rawC2, dark, swapped) {
        var c1 = swapped ? rawC2 : rawC1;
        var c2 = swapped ? rawC1 : rawC2;
        return {
            c1: _deriveDisplayColor(c1, dark),
            c2: _deriveDisplayColor(c2, dark)
        };
    }

    // Guard: true while the swap RAF animation is running.
    // Prevents _applyDualGradientCore from overwriting the large circle mid-animation.
    var _swapAnimRunning = false;

    // No RAF IDs needed — CSS @property transitions handle the animation.
    // _cancelSwapAnim is kept as a no-op for API compatibility (called by applyDualGradient).
    var _swapRafId = null;
    var _swapRestoreRafId = null;

    function _cancelSwapAnim() {
        // CSS @property transitions self-complete — nothing to cancel.
        // Reset guard in case a previous animation was somehow interrupted.
        _swapAnimRunning = false;
        _swapRafId = null;
        _swapRestoreRafId = null;
    }

    // ── Sync grad-active on preset gradient buttons ───────────────────────────
    // Defined at module scope so applyDualGradient (and any other caller) can
    // always call it — regardless of whether DOMContentLoaded has finished.
    function _updateGradPresetActive() {
        var dualAttr = document.body.getAttribute("data-dual-theme") === "active";
        var stored = null;
        try { stored = JSON.parse(localStorage.getItem("dualColorTheme") || "null"); } catch(e) {}
        document.querySelectorAll(".colorPlate-grad").forEach(function(btn) {
            var c1 = (btn.dataset.c1 || "").toUpperCase();
            var c2 = (btn.dataset.c2 || "").toUpperCase();
            var isActive = dualAttr && stored &&
                           stored.c1.toUpperCase() === c1 &&
                           stored.c2.toUpperCase() === c2;
            btn.classList.toggle("grad-active", !!isActive);

            // Update gradient direction and shadow to reflect current swap state
            var displayC1 = btn.dataset.c1, displayC2 = btn.dataset.c2;
            if (isActive && _swapped) {
                displayC1 = btn.dataset.c2;
                displayC2 = btn.dataset.c1;
            }
            btn.style.background = "linear-gradient(135deg, " + displayC1 + ", " + displayC2 + ")";
            if (typeof hexToShadowColor === "function" && displayC1) {
                var sc = hexToShadowColor(displayC1);
                if (sc) btn.style.setProperty("--dot-shadow-color", sc);
            }
        });
    }

    // ── APPLY ─────────────────────────────────────────────────────────────────
    function applyDualGradient(rawC1, rawC2) {
        // If a swap RAF animation is currently running, cancel it so the mode switch
        // (or any other external call) can take full ownership of the large circle.
        // The swap handler calls _applyDualGradientCore DIRECTLY (bypassing this
        // function), so this cancel never fires during a normal swap click.
        _cancelSwapAnim();

        // Invalidate any pending rAF writes from a previous apply before starting a new one.
        _applySeq++;

        // ── Nesting guard ──────────────────────────────────────────────────────
        // applyThemeMode wraps loadStoredDualColor() inside _smoothThemeSwitch.
        // If we then call _atomicThemeSwitch (= _smoothThemeSwitch) here, the inner
        // call cancels the outer's pending rAF via _cancelPendingAnim().  Worse, the
        // inner then resets CSS vars to startColors; the outer captures endVars AFTER
        // that reset, so outer's rAF-B2 fires LAST and overwrites with stale light-mode
        // values → theme snaps to wrong state / large circle inverts without animation.
        //
        // Fix: if no-theme-transition is already active we are already inside a
        // _smoothThemeSwitch — call the core directly so the outer wrapper owns the
        // full rAF chain and captures correct endVars.
        if (document.documentElement.classList.contains("no-theme-transition")) {
            _applyDualGradientCore(rawC1, rawC2);
            return;
        }

        // Use _atomicThemeSwitch if available (defined in theme.js) so that switching
        // from a predefined-dark theme (filter:invert) to a dual-color theme is instant —
        // no light-mode flash from old light vars transitioning to new dark vars.
        if (typeof _atomicThemeSwitch === "function") {
            _atomicThemeSwitch(function() { _applyDualGradientCore(rawC1, rawC2); });
        } else {
            _applyDualGradientCore(rawC1, rawC2);
        }
    }

    function _applyDualGradientCore(rawC1, rawC2) {
        // Capture a token for this apply. Any pending rAF callbacks from older applies
        // will no-op once _applySeq changes (e.g. when leaving dual theme).
        var _seq = ++_applySeq;
        var _livePickerPreview = !!(window._colorPickerDragging && !window._colorPickerCommitOnly);
        // Also bump the shared theme.js seq counter so any pending rAF from
        // _applyCustomThemeCore or applySelectedTheme (e.g. a leftover color-picker rAF)
        // is invalidated and will not overwrite the dual colors after they are applied.
        if (typeof window._bumpThemeSeq === "function") window._bumpThemeSeq();
        // Respect current mode — apply colors optimized for whichever mode is active
        var dark = (function() {
            var p = localStorage.getItem("preferredTheme") || "light";
            var s = !!_MQL_PREFERS_DARK.matches;
            return p === "dark" || (p === "system" && s);
        })();

        // If swap is active apply visually swapped but keep stored colors intact
        var c1 = _swapped ? rawC2 : rawC1;
        var c2 = _swapped ? rawC1 : rawC2;

        var surf = buildSurfaceFamily(c1, dark);
        var acc  = buildAccentFamily(c2, dark, dark ? surf.bg : null);

        // ── CRITICAL: set data-dual-theme BEFORE CSS vars ──
        // The CSS dark-mode rule applies filter:invert() only when data-dual-theme is NOT "active".
        // Setting vars first while filter is still on causes: dark-vars + invert = light flash.
        // Removing the filter first (via attribute) then animating vars in avoids the flash.
        document.body.setAttribute("data-dual-theme", "active");
        document.body.removeAttribute("data-custom-theme");
        if (dark && (isNearBlack(c1) || isNearBlack(c2))) document.body.setAttribute("data-near-black-theme", "1");
        else document.body.removeAttribute("data-near-black-theme");

        // ── Set CSS variables ──
        document.documentElement.style.setProperty("--bg-color-blue",        surf.bg);
        document.documentElement.style.setProperty("--accentLightTint-blue", surf.bgTint);
        document.documentElement.style.setProperty("--darkColor-blue",       acc.accent);
        document.documentElement.style.setProperty("--darkerColor-blue",     acc.accentDark);
        document.documentElement.style.setProperty("--textColorDark-blue",   acc.textDark);
        document.documentElement.style.setProperty("--shadow-base-color",    c2);

        // ── Fix: whitishColor must adapt to mode ──
        // In dark mode (no inversion applied) widget/card bg must be dark, not white.
        // In light mode keep it white.
        var whitish;
        if (dark) {
            // Slightly stronger lift so the chosen hue remains visible in cards/panels.
            whitish = adjustHex(surf.bg, 0.18, true);
        } else {
            whitish = "#ffffff";
        }
        document.documentElement.style.setProperty("--whitishColor-blue", whitish);

        // Dynamic contrast button text, disabled button bg, and input borders
        var accLumForBtn = getLuminance(acc.accent);
        var btnTextFactor = smoothStep(0.45, 0.65, accLumForBtn);
        var btnTextColor = adjustHex("#FFFFFF", btnTextFactor, false);

        var bgLumForBtn = getLuminance(surf.bg);
        var disabledBtnBgColor = bgLumForBtn < 0.08
            ? adjustHex("#1A1A1A", (0.08 - bgLumForBtn) / 0.08 * 0.45, true)
            : (bgLumForBtn > 0.45 ? "rgba(0, 0, 0, 0.08)" : "rgba(255, 255, 255, 0.14)");

        var inputBorderFactor = 1 - smoothStep(0.0, 0.18, bgLumForBtn);
        var inputBorderColor = "rgba(255, 255, 255, " + (0.22 * inputBorderFactor) + ")";

        document.documentElement.style.setProperty("--savebtn-text-color", btnTextColor);
        document.documentElement.style.setProperty("--savebtn-disabled-bg-color", disabledBtnBgColor);
        document.documentElement.style.setProperty("--input-border-color", inputBorderColor);

        // ── Cache vars for FOUC-free next-page preload ──
        // Mirrors _saveThemeVarsCache() in theme.js.
        // Without this, preload.js reads stale values from a previous predefined theme,
        // causing a blue-flash → dual-color transition animation on every reload.
        if (!_livePickerPreview) try {
            localStorage.setItem("themeVarsCache", JSON.stringify({
                bg:     surf.bg,
                tint:   surf.bgTint,
                dark:   acc.accent,
                darker: acc.accentDark,
                text:   acc.textDark,
                white:  whitish,
            }));
        } catch(e) {}

        // Circle button display colors: use _computeDisplayColors so that:
        //   • Mode change re-derives colors from rawC1/rawC2 correctly (light↔dark adapt).
        //   • Swap is PURELY positional — same derived values, just left↔right.
        //     No color distortion from running through different pipeline branches.
        var _disp = _computeDisplayColors(rawC1, rawC2, dark, _swapped);
        var btnC1 = _disp.c1;
        var btnC2 = _disp.c2;
        document.documentElement.style.setProperty("--dual-color-1", btnC1);
        document.documentElement.style.setProperty("--dual-color-2", btnC2);
        // data-dual-theme and data-custom-theme are set BEFORE CSS vars above — see comment there.

        // No border — colors shown via CSS variables only
        var label = document.getElementById("rangColor");
        if (label) {
            label.style.background  = "";
            label.style.color       = "";
            label.style.borderColor = "";
        }

        // Notify shadow-control and other listeners that theme colors have changed
        document.dispatchEvent(new CustomEvent("theme-colors-changed"));

        // Force-update shortcut SVG circle fills (YouTube/Discord dark-mode fix)
        // ── Update half-half button via @property on html ──
        // • Mode switch (_btnSuppressedNow, not dragging): double-rAF so transition fires after no-theme-transition removed.
        // • Color-picker drag: set immediately — no-theme-transition stays on anyway, and
        //   clearDualTheme() may have run first; we must override it without delay.
        // • All other cases (swap, direct call): set immediately → transition fires at once.
        var _btnSuppressedNow = document.documentElement.classList.contains("no-theme-transition");
        if (_btnSuppressedNow && !window._colorPickerDragging) {
            (function(_c1, _c2) {
                requestAnimationFrame(function() { requestAnimationFrame(function() {
                    if (_applySeq !== _seq) return;
                    document.documentElement.style.setProperty("--btn-half-1-color", _c1);
                    document.documentElement.style.setProperty("--btn-half-2-color", _c2);
                }); });
            })(btnC1, btnC2);
        } else {
            document.documentElement.style.setProperty("--btn-half-1-color", btnC1);
            document.documentElement.style.setProperty("--btn-half-2-color", btnC2);
        }

        var trigBtn = document.getElementById("dualColorTriggerBtn");
        if (trigBtn) {
            trigBtn.classList.add("dualActive");
        }

        // ── Update large circle in the panel to reflect current colors (incl. swap & mode) ──
        // Use CSS custom properties so --lc-left-color and --lc-right-color can be
        // transitioned via @property when swap button is clicked (no-theme-transition
        // suppresses the transition during instant theme changes — only swap clicks animate).
        var largeCircle = document.getElementById("dualColorLargeCircle");
        if (largeCircle) {
            // Mirror the animation fix from _applyCustomThemeCore (theme.js):
            // • no-theme-transition active (mode switch): save old colors, schedule double-rAF
            //   so the @property transition fires AFTER no-theme-transition is removed. ✓
            // • no-theme-transition NOT active (swap click, color-picker change): update immediately. ✓
            // Remove inline background so CSS @property gradient rule drives the visual.
            largeCircle.style.removeProperty("background");

            var _suppressedNow = document.documentElement.classList.contains("no-theme-transition");

            if (_suppressedNow) {
                // Transitions suppressed (mode switch) — freeze circle at current colors,
                // then animate to new colors after no-theme-transition is removed.
                var _oldLeft  = largeCircle.style.getPropertyValue("--lc-left-color")  ||
                                getComputedStyle(largeCircle).getPropertyValue("--lc-left-color").trim();
                var _oldRight = largeCircle.style.getPropertyValue("--lc-right-color") ||
                                getComputedStyle(largeCircle).getPropertyValue("--lc-right-color").trim();
                if (_oldLeft)  largeCircle.style.setProperty("--lc-left-color",  _oldLeft);
                if (_oldRight) largeCircle.style.setProperty("--lc-right-color", _oldRight);

                // Double-rAF: _smoothThemeSwitch removes no-theme-transition in its first rAF.
                // Our second rAF runs after that → transitions live → @property animation fires.
                (function(_lc, _l, _r) {
                    requestAnimationFrame(function() { requestAnimationFrame(function() {
                        if (_applySeq !== _seq) return;
                        _lc.style.setProperty("--lc-left-color",  _l);
                        _lc.style.setProperty("--lc-right-color", _r);
                    }); });
                })(largeCircle, btnC1, btnC2);
            } else {
                // Transitions live (swap click, color-picker change, etc.) — update immediately.
                largeCircle.style.setProperty("--lc-left-color",  btnC1);
                largeCircle.style.setProperty("--lc-right-color", btnC2);
            }
        }

        // ── Show dual swap button; hide custom swap button ──
        _showSwapBtn(rawC1, rawC2);
        var csb = document.getElementById("customSwapBtn");
        if (csb) csb.style.display = "none";

        document.querySelectorAll(".colorPlate").forEach(function(r){ r.checked = false; });
        // data-custom-theme already removed at top of this function before CSS vars were set.
        // Always sync preset gradient button active-markers — this must run here so
        // that every call path (panel Apply, context menu, saved-dot click, swap, etc.)
        // clears any leftover grad-active from a previously selected preset gradient.
        _updateGradPresetActive();
        // FIX: pass acc.accent directly — it is the exact resolved hex just written to
        // --darkColor-blue (line above). Reading that var via getComputedStyle would
        // return a mid-transition interpolated value because it is an @property <color>.
        if (!_livePickerPreview) {
            if (typeof changeFaviconColor  === "function") changeFaviconColor(acc.accent);
            if (typeof ApplyLoadingColor   === "function") ApplyLoadingColor();
        }
    }

    function clearDualTheme() {
        // Invalidate any pending rAF writes from the previous dual-theme apply.
        _applySeq++;

        // FIX: Only bump _themeSeq (which would cancel the deferred rAF from
        // _applyCustomThemeCore) when data-custom-theme is NOT already active.
        //
        // When clearDualTheme() is called AFTER applyCustomTheme() (e.g. from
        // saved-colors.js dot click), data-custom-theme="active" means
        // _applyCustomThemeCore just ran and scheduled a deferred double-rAF to
        // commit the correct circle + favicon colours. Bumping _themeSeq here would
        // invalidate that rAF via the `_themeSeq !== _customFixSeq` guard, leaving
        // the circle stuck on the previous theme's colours.
        //
        // When called in any other context (predefined → dual, dual → dual, etc.)
        // data-custom-theme is NOT active, so the bump runs as before to cancel
        // stale rAFs from applySelectedTheme or an earlier _applyCustomThemeCore.
        if (document.body.getAttribute("data-custom-theme") !== "active") {
            if (typeof window._bumpThemeSeq === "function") window._bumpThemeSeq();
        }

        localStorage.removeItem(DUAL_COLOR_KEY);
        document.body.removeAttribute("data-dual-theme");
        // Remove grad-active from all preset gradient buttons
        document.querySelectorAll(".colorPlate-grad").forEach(function(b) { b.classList.remove("grad-active"); });
        document.documentElement.style.removeProperty("--dual-color-1");
        document.documentElement.style.removeProperty("--dual-color-2");

        // Freeze current btn-half colors instead of removing them.
        // Removing triggers flash to @property initial-value (#e2eeff / #4382ec).
        // Freezing the current computed values lets the next theme transition FROM them.
        //
        // FIX: Skip the freeze when data-custom-theme is already active.
        // When clearDualTheme() runs after applyCustomTheme(), --btn-half-1/2-color
        // is mid-transition from the old colour to the new one. Reading it now via
        // getComputedStyle returns an interpolated (blended) value, not the target.
        // Writing that back "freezes" the circle at the wrong colour, undoing the
        // correct values that _applyCustomThemeCore just set.
        if (document.body.getAttribute("data-custom-theme") !== "active") {
            var _cs = getComputedStyle(document.documentElement);
            var _cur1 = _cs.getPropertyValue("--btn-half-1-color").trim() ||
                        _cs.getPropertyValue("--accentLightTint-blue").trim();
            var _cur2 = _cs.getPropertyValue("--btn-half-2-color").trim() ||
                        _cs.getPropertyValue("--darkColor-blue").trim();
            if (_cur1) document.documentElement.style.setProperty("--btn-half-1-color", _cur1);
            if (_cur2) document.documentElement.style.setProperty("--btn-half-2-color", _cur2);
        }

        var label = document.getElementById("rangColor");
        if (label) { label.style.background = ""; label.style.color = ""; label.style.borderColor = ""; }

        // FIX: In dark mode only, explicitly freeze the large circle vars before clearing.
        // In dark mode, switching gradient->solid can leave a pending double-rAF from
        // _applyDualGradientCore that fires AFTER applySelectedTheme sets solid colors,
        // overwriting them with gradient colors. We cancel that rAF via _applySeq++ above.
        // We do NOT remove --lc-left/right-color here because in light mode that would
        // cause CSS @property to revert to its initial-value (#FFBFA0 / #7B3FF2) and
        // trigger an unwanted transition (the "reversed colors" flash).
        // applySelectedTheme always sets the circle vars directly so no clearing is needed.

        var trigBtn = document.getElementById("dualColorTriggerBtn");
        if (trigBtn) {
            trigBtn.classList.remove("dualActive");
        }

        // Reset swap state and hide swap button
        _swapped = false;
        localStorage.removeItem(SWAP_KEY);
        _hideSwapBtn();
    }

    // ── Swap Button ───────────────────────────────────────────────────────────
    function _getSwapBtn() {
        return document.getElementById("dualSwapBtn");
    }

    function _showSwapBtn(rawC1, rawC2) {
        var btn = _getSwapBtn();
        if (!btn) return;
        btn.style.display = "flex";
        // Update swap icon tint to accent color
        btn.classList.toggle("dualSwapActive", _swapped);
        // Store colors on button for click handler
        btn.dataset.c1 = rawC1;
        btn.dataset.c2 = rawC2;
    }

    function _hideSwapBtn() {
        var btn = _getSwapBtn();
        if (btn) { btn.style.display = "none"; btn.classList.remove("dualSwapActive"); }
    }

    function loadStoredDualColor() {
        try {
            var s = JSON.parse(localStorage.getItem(DUAL_COLOR_KEY));
            if (s && s.c1 && s.c2) {
                // Restore swap state from localStorage
                _swapped = localStorage.getItem(SWAP_KEY) === "1";
                applyDualGradient(s.c1, s.c2);
                return true;
            }
        } catch(e) {}
        return false;
    }

    // ── Panel ──────────────────────────────────────────────────────────────────
    var color1 = "#FFBFA0", color2 = "#7B3FF2";

    function updatePanelPreview() {
        var sw1  = document.getElementById("dualColor1Swatch");
        var sw2  = document.getElementById("dualColor2Swatch");
        var prev = document.getElementById("dualColorPreview");
        var largeCircle = document.getElementById("dualColorLargeCircle");
        if (sw1) sw1.style.background = color1;
        if (sw2) sw2.style.background = color2;
        // Smooth gradient — shows how colors blend together
        if (prev) prev.style.background =
            "linear-gradient(135deg, " + color1 + ", " + color2 + ")";

        // Large circle: always update to reflect current swap state and dark mode.
        var isDark = (function() {
            var p = localStorage.getItem("preferredTheme") || "light";
            var s = window.matchMedia("(prefers-color-scheme: dark)").matches;
            return p === "dark" || (p === "system" && s);
        })();
        // Large circle: use _computeDisplayColors for consistency with applyDualGradientCore.
        // Mode change re-derives both colors; swap is positional only.
        if (largeCircle) {
            var _dispPrev = _computeDisplayColors(color1, color2, isDark, _swapped);
            largeCircle.style.removeProperty("background");

            var _lcSuppressed = document.documentElement.classList.contains("no-theme-transition");
            if (_lcSuppressed) {
                // Freeze current colors as start point, then animate to new after transitions re-enable.
                var _lcOldLeft  = largeCircle.style.getPropertyValue("--lc-left-color")  ||
                                  getComputedStyle(largeCircle).getPropertyValue("--lc-left-color").trim();
                var _lcOldRight = largeCircle.style.getPropertyValue("--lc-right-color") ||
                                  getComputedStyle(largeCircle).getPropertyValue("--lc-right-color").trim();
                if (_lcOldLeft)  largeCircle.style.setProperty("--lc-left-color",  _lcOldLeft);
                if (_lcOldRight) largeCircle.style.setProperty("--lc-right-color", _lcOldRight);
                (function(_lc, _l, _r) {
                    requestAnimationFrame(function() { requestAnimationFrame(function() {
                        _lc.style.setProperty("--lc-left-color",  _l);
                        _lc.style.setProperty("--lc-right-color", _r);
                    }); });
                })(largeCircle, _dispPrev.c1, _dispPrev.c2);
            } else {
                largeCircle.style.setProperty("--lc-left-color",  _dispPrev.c1);
                largeCircle.style.setProperty("--lc-right-color", _dispPrev.c2);
            }
        }
    }

    // Snapshot of theme before panel opened (for cancel restore)
    var _previewSnapshot = null;

    function _snapshotCurrentTheme() {
        return {
            dual: localStorage.getItem(DUAL_COLOR_KEY),
            custom: localStorage.getItem("customThemeColor"),
            predefined: localStorage.getItem("selectedTheme"),
            swapped: localStorage.getItem(SWAP_KEY),
            cssBg: document.documentElement.style.getPropertyValue("--bg-color-blue"),
            cssAccentTint: document.documentElement.style.getPropertyValue("--accentLightTint-blue"),
            cssDark: document.documentElement.style.getPropertyValue("--darkColor-blue"),
            cssDarker: document.documentElement.style.getPropertyValue("--darkerColor-blue"),
            cssText: document.documentElement.style.getPropertyValue("--textColorDark-blue"),
            cssWhitish: document.documentElement.style.getPropertyValue("--whitishColor-blue"),
            bodyDualAttr: document.body.getAttribute("data-dual-theme"),
            bodyCustomAttr: document.body.getAttribute("data-custom-theme"),
            nearBlackAttr: document.body.getAttribute("data-near-black-theme"),
        };
    }

    function _restoreSnapshot(snap) {
        if (!snap) return;
        document.documentElement.style.setProperty("--bg-color-blue",        snap.cssBg);
        document.documentElement.style.setProperty("--accentLightTint-blue", snap.cssAccentTint);
        document.documentElement.style.setProperty("--darkColor-blue",       snap.cssDark);
        document.documentElement.style.setProperty("--darkerColor-blue",     snap.cssDarker);
        document.documentElement.style.setProperty("--textColorDark-blue",   snap.cssText);
        document.documentElement.style.setProperty("--whitishColor-blue",    snap.cssWhitish);
        if (snap.bodyDualAttr) document.body.setAttribute("data-dual-theme", snap.bodyDualAttr);
        else document.body.removeAttribute("data-dual-theme");
        if (snap.bodyCustomAttr) document.body.setAttribute("data-custom-theme", snap.bodyCustomAttr);
        else document.body.removeAttribute("data-custom-theme");
        if (snap.nearBlackAttr) document.body.setAttribute("data-near-black-theme", snap.nearBlackAttr);
        else document.body.removeAttribute("data-near-black-theme");

        // Restore swap button visibility based on which theme was active before panel opened
        var csb = document.getElementById("customSwapBtn");
        var dsb = document.getElementById("dualSwapBtn");
        if (snap.bodyCustomAttr === "active" && !snap.bodyDualAttr) {
            // Was on custom single-color theme — show customSwapBtn, hide dualSwapBtn
            if (csb) {
                csb.style.display = "flex";
                csb.classList.toggle("dualSwapActive", localStorage.getItem("customThemeSwapped") === "1");
            }
            if (dsb) dsb.style.display = "none";
        } else if (snap.bodyDualAttr === "active") {
            // Was on dual gradient theme — show dualSwapBtn, hide customSwapBtn
            if (csb) csb.style.display = "none";
            loadStoredDualColor();
        } else {
            // Was on a predefined color — hide both swap buttons
            if (csb) csb.style.display = "none";
            if (dsb) dsb.style.display = "none";
        }

        // FIX: pass snap.cssDark directly — it is the already-resolved hex that was
        // captured into the snapshot from --darkColor-blue before the panel opened,
        // so it always reflects the correct pre-panel theme without any CSS var read.
        if (typeof changeFaviconColor === "function") changeFaviconColor(snap.cssDark);
        if (typeof ApplyLoadingColor  === "function") ApplyLoadingColor();
    }

    function openPanel() {
        var panel = document.getElementById("dualColorPanel");
        if (!panel) return;
        // Snapshot before showing live preview
        _previewSnapshot = _snapshotCurrentTheme();
        try {
            var s = JSON.parse(localStorage.getItem(DUAL_COLOR_KEY));
            if (s && s.c1 && s.c2) {
                // Dual theme stored — use raw stored colors (before mode adaptation)
                color1 = s.c1;
                color2 = s.c2;
            } else {
                // No dual theme — seed pickers from current applied colors
                var root = document.documentElement;
                // --dual-color-1/2 are set by applyCustomTheme / applySelectedTheme.
                // Since theme.js v17 stores actual hex values here, dc1/dc2 are normally
                // valid hex strings.  Guard against older/cached states where they may
                // still be var() references (e.g. "var(--accentLightTint-blue)"): passing
                // a var() string to hexToRgb() produces NaN channels, which collapses to
                // #000000 in dark mode and shows as the initial-value colour in light mode.
                var dc1 = root.style.getPropertyValue("--dual-color-1").trim();
                var dc2 = root.style.getPropertyValue("--dual-color-2").trim();
                // Resolve any var() references to actual hex values
                if (dc1 && dc1.startsWith("var(")) {
                    dc1 = getComputedStyle(root).getPropertyValue("--accentLightTint-blue").trim();
                }
                if (dc2 && dc2.startsWith("var(")) {
                    dc2 = getComputedStyle(root).getPropertyValue("--darkColor-blue").trim();
                }
                // Only use dc1/dc2 if both are non-empty and are real colour values (not var refs)
                if (dc1 && dc2 && !dc1.startsWith("var(") && !dc2.startsWith("var(")) {
                    color1 = dc1;
                    color2 = dc2;
                } else {
                    // Fallback: read current bg and accent from CSS.
                    // IMPORTANT: predefined themes set --bg-color-blue to a var() reference
                    // (e.g. "var(--bg-color-red)"), not an actual hex value.
                    // Using root.style directly would return the var() string, which is
                    // truthy but not a valid hex — causing hexToRgb to produce garbage colors.
                    // Always resolve through getComputedStyle to get the real computed hex.
                    function _resolveColor(prop) {
                        var inlineVal = root.style.getPropertyValue(prop).trim();
                        // If inline value is a var() reference or empty, use computed style
                        if (!inlineVal || inlineVal.startsWith("var(")) {
                            return getComputedStyle(root).getPropertyValue(prop).trim();
                        }
                        return inlineVal;
                    }
                    var bgVar  = _resolveColor("--bg-color-blue");
                    var accVar = _resolveColor("--darkColor-blue");
                    // When coming from a predefined theme, bgVar is already a heavily-lightened
                    // derivative of the original color. Feeding it back into buildSurfaceFamily
                    // lightens it even further, making the result indistinguishable from the
                    // page background. Seed color1 from the vivid accent color instead so
                    // buildSurfaceFamily can derive proper contrasting surfaces from it.
                    var predefinedTheme = localStorage.getItem("selectedTheme");
                    var customColor = localStorage.getItem("customThemeColor");
                    color1 = (customColor || (predefinedTheme ? (accVar || bgVar) : bgVar) || "#FFBFA0").trim();
                    color2 = (accVar || "#7B3FF2").trim();
                    // If both colors are identical (e.g. both derived from accVar), give
                    // color2 a distinct contrasting default so the panel shows two real colors.
                    if (color1.toUpperCase() === color2.toUpperCase()) {
                        color2 = "#7B3FF2";
                    }
                }
            }
        } catch(e) {
            color1 = "#FFBFA0"; color2 = "#7B3FF2";
        }
        updatePanelPreview();
        panel.style.display = "flex";
        setTimeout(function(){ panel.classList.add("dualPanelVisible"); }, 10);
    }

    // ── Preset-duplicate warning ──────────────────────────────────────────────
    var _presetWarnTimer = null;

    function _showDualPresetWarning() {
        var el = document.getElementById("dualPresetWarning");
        if (!el) return;

        // Clear any existing hide timer
        if (_presetWarnTimer) { clearTimeout(_presetWarnTimer); _presetWarnTimer = null; }

        // Update message text from locale
        var msgEl = el.querySelector(".dual-preset-warn-msg");
        if (msgEl) {
            var msg = (typeof translations !== "undefined" && typeof currentLanguage !== "undefined")
                ? (translations[currentLanguage] && translations[currentLanguage]["dualPresetExists"])
                    || (translations["en"] && translations["en"]["dualPresetExists"])
                    || "This theme already exists in the default themes"
                : "This theme already exists in the default themes";
            msgEl.textContent = msg;
        }

        el.classList.add("dual-preset-warn-visible");
        _presetWarnTimer = setTimeout(function() {
            el.classList.remove("dual-preset-warn-visible");
            _presetWarnTimer = null;
        }, 3500);
    }

    function closePanel() {
        var panel = document.getElementById("dualColorPanel");
        if (!panel) return;
        panel.classList.remove("dualPanelVisible");
        setTimeout(function(){
            if (!panel.classList.contains("dualPanelVisible")) panel.style.display = "none";
        }, 220);
    }

    // ── Init ──────────────────────────────────────────────────────────────────
    document.addEventListener("DOMContentLoaded", function() {
        var hadDual = loadStoredDualColor();

        function seedDualPickerState() {
            _previewSnapshot = _snapshotCurrentTheme();
            try {
                var s = JSON.parse(localStorage.getItem(DUAL_COLOR_KEY));
                if (s && s.c1 && s.c2) {
                    color1 = s.c1;
                    color2 = s.c2;
                } else {
                    var root = document.documentElement;
                    var dc1 = root.style.getPropertyValue("--dual-color-1").trim();
                    var dc2 = root.style.getPropertyValue("--dual-color-2").trim();
                    if (dc1 && dc1.startsWith("var(")) {
                        dc1 = getComputedStyle(root).getPropertyValue("--accentLightTint-blue").trim();
                    }
                    if (dc2 && dc2.startsWith("var(")) {
                        dc2 = getComputedStyle(root).getPropertyValue("--darkColor-blue").trim();
                    }
                    if (dc1 && dc2 && !dc1.startsWith("var(") && !dc2.startsWith("var(")) {
                        color1 = dc1;
                        color2 = dc2;
                    } else {
                        function _resolveColor(prop) {
                            var inlineVal = root.style.getPropertyValue(prop).trim();
                            if (!inlineVal || inlineVal.startsWith("var(")) {
                                return getComputedStyle(root).getPropertyValue(prop).trim();
                            }
                            return inlineVal;
                        }
                        var bgVar  = _resolveColor("--bg-color-blue");
                        var accVar = _resolveColor("--darkColor-blue");
                        var predefinedTheme = localStorage.getItem("selectedTheme");
                        var customColor = localStorage.getItem("customThemeColor");
                        color1 = (customColor || (predefinedTheme ? (accVar || bgVar) : bgVar) || "#FFBFA0").trim();
                        color2 = (accVar || "#7B3FF2").trim();
                        if (color1.toUpperCase() === color2.toUpperCase()) {
                            color2 = "#7B3FF2";
                        }
                    }
                }
            } catch(e) {
                color1 = "#FFBFA0";
                color2 = "#7B3FF2";
            }
            updatePanelPreview();
        }

        function applyDualPickerSelection() {
            var c1Up = color1.toUpperCase(), c2Up = color2.toUpperCase();
            var isPreset = false;
            document.querySelectorAll(".colorPlate-grad").forEach(function(btn) {
                if ((btn.dataset.c1 || "").toUpperCase() === c1Up &&
                    (btn.dataset.c2 || "").toUpperCase() === c2Up) {
                    isPreset = true;
                }
            });
            if (isPreset) {
                _showDualPresetWarning();
                return false;
            }

            _swapped = false;
            localStorage.removeItem(SWAP_KEY);
            localStorage.setItem(DUAL_COLOR_KEY, JSON.stringify({ c1: color1, c2: color2 }));
            localStorage.removeItem("selectedTheme");
            localStorage.removeItem("safePresetTheme");
            localStorage.removeItem("customThemeColor");
            applyDualGradient(color1, color2);
            if (typeof addSavedGradient === "function") addSavedGradient(color1, color2);
            if (typeof renderSavedColors === "function") renderSavedColors();
            _previewSnapshot = null;
            return true;
        }

        function openDualPickerModal() {
            if (!window.customColorPickerModal || typeof window.customColorPickerModal.openDual !== "function") {
                openPanel();
                return;
            }

            seedDualPickerState();
            closePanel();

            var accentLabelEl = document.getElementById("dualLabelAccents");
            var surfaceLabelEl = document.getElementById("dualLabelSurfaces");
            var modalTitle = (typeof translations !== "undefined" && typeof currentLanguage !== "undefined")
                ? (translations[currentLanguage] && translations[currentLanguage]["dualColorTriggerTitle"])
                    || (translations["en"] && translations["en"]["dualColorTriggerTitle"])
                    || "Pick 2-color gradient"
                : "Pick 2-color gradient";

            window.customColorPickerModal.openDual({
                title: modalTitle,
                accentLabel: accentLabelEl ? accentLabelEl.textContent.trim() : "Accents",
                surfaceLabel: surfaceLabelEl ? surfaceLabelEl.textContent.trim() : "Surfaces",
                accentColor: color2,
                surfaceColor: color1,
                onPreview: function(payload) {
                    color1 = payload.surfaceColor;
                    color2 = payload.accentColor;
                    applyDualGradient(color1, color2);
                },
                onApply: function(payload) {
                    color1 = payload.surfaceColor;
                    color2 = payload.accentColor;
                    return applyDualPickerSelection();
                },
                onCancel: function() {
                    _restoreSnapshot(_previewSnapshot);
                    _previewSnapshot = null;
                }
            });
        }

        // If no dual theme was restored but user has a custom single-color theme,
        // ensure customSwapBtn is visible (can be hidden by stale state or panel preview).
        if (!hadDual) {
            var hasCstm   = !!localStorage.getItem("customThemeColor");
            var hasPreset = !!localStorage.getItem("selectedTheme");
            var csb = document.getElementById("customSwapBtn");
            if (csb && hasCstm && !hasPreset) {
                csb.style.display = "flex";
                csb.classList.toggle("dualSwapActive", localStorage.getItem("customThemeSwapped") === "1");
            }
        }

        var trigBtn = document.getElementById("dualColorTriggerBtn");
        if (trigBtn) {
            trigBtn.addEventListener("click", function() {
                var panel = document.getElementById("dualColorPanel");
                if (panel && panel.classList.contains("dualPanelVisible")) {
                    // Closing without Apply → restore snapshot to discard live preview changes
                    _restoreSnapshot(_previewSnapshot);
                    _previewSnapshot = null;
                    closePanel();
                } else {
                    openDualPickerModal();
                }
            });
        }

        // ── Swap button ──
        var swapBtn = document.getElementById("dualSwapBtn");
        if (swapBtn) {
            if (!hadDual) swapBtn.style.display = "none";
            swapBtn.addEventListener("click", function() {
                var c1 = swapBtn.dataset.c1, c2 = swapBtn.dataset.c2;
                if (!c1 || !c2) return;

                // Swap the values physically (Literal swap)
                var temp = c1;
                c1 = c2;
                c2 = temp;

                // Update the datasets
                swapBtn.dataset.c1 = c1;
                swapBtn.dataset.c2 = c2;

                // Persist the swapped colors directly
                localStorage.setItem("dualColorTheme", JSON.stringify({ c1: c1, c2: c2 }));

                // If custom color picker is open in dual mode, swap its internal state and pickers too
                if (window.customColorPickerModal && 
                    typeof window.customColorPickerModal.isOpen === "function" && 
                    window.customColorPickerModal.isOpen() && 
                    typeof window.customColorPickerModal.getMode === "function" && 
                    window.customColorPickerModal.getMode() === "dual" &&
                    typeof window.customColorPickerModal.swapDualColors === "function") {
                    window.customColorPickerModal.swapDualColors();
                }

                // Call _applyDualGradientCore DIRECTLY — bypasses _atomicThemeSwitch /
                // _smoothThemeSwitch which adds `no-theme-transition` (transition:none!important).
                // Without no-theme-transition active, the CSS @property transition on
                // --lc-left-color and --lc-right-color fires, smoothly animating the
                // large circle's two halves to their swapped positions.
                // This works identically in both light and dark mode.
                // Route through the normal wrapper so swapped dual colors apply instantly.
                _applyDualGradientCore(c1, c2);
                if (typeof renderSavedColors === "function") renderSavedColors();
            });
        }

        function bindSwatch(swatchId, pickerId, slot) {
            var sw = document.getElementById(swatchId);
            var pk = document.getElementById(pickerId);
            if (!sw || !pk) return;
            sw.addEventListener("click",  function() { pk.value = slot === 1 ? color1 : color2; pk.click(); });

            // ── RAF throttle: limit live-preview updates to one per animation frame ──
            // The color picker fires "input" many times per second during drag; calling
            // applyDualGradient (heavy color-math + CSS var writes) on every event causes
            // visible lag. Throttling to rAF keeps the UI responsive at ~60 fps.
            var _rafId = null;
            var _inputPreviewing = false;
            function beginInputPreview() {
                if (_inputPreviewing) return;
                _inputPreviewing = true;
                window._colorPickerDragging = true;
                document.documentElement.classList.add("no-theme-transition");
            }
            function endInputPreview() {
                if (!_inputPreviewing) return;
                _inputPreviewing = false;
                window._colorPickerDragging = false;
                requestAnimationFrame(function() {
                    document.documentElement.classList.remove("no-theme-transition");
                    document.dispatchEvent(new CustomEvent("theme-colors-changed"));
                    if (typeof changeFaviconColor === "function") changeFaviconColor();
                });
            }
            pk.addEventListener("input",  function(e) {
                beginInputPreview();
                if (slot===1) color1=e.target.value; else color2=e.target.value;
                updatePanelPreview();
                if (_rafId) return;           // already have a frame scheduled
                _rafId = requestAnimationFrame(function() {
                    _rafId = null;
                    // Live preview: apply without saving to localStorage
                    applyDualGradient(color1, color2);
                });
            });
            pk.addEventListener("change", function(e) {
                if (slot===1) color1=e.target.value; else color2=e.target.value;
                updatePanelPreview();
                if (_rafId) {
                    cancelAnimationFrame(_rafId);
                    _rafId = null;
                }
                // Auto-save modified colors so Apply Theme (context menu) sees the updated values
                if (localStorage.getItem(DUAL_COLOR_KEY)) {
                    localStorage.setItem(DUAL_COLOR_KEY, JSON.stringify({ c1: color1, c2: color2 }));
                }
                var previousCommitOnly = window._colorPickerCommitOnly;
                window._colorPickerCommitOnly = true;
                try {
                    applyDualGradient(color1, color2);
                } finally {
                    window._colorPickerCommitOnly = previousCommitOnly;
                    endInputPreview();
                }
            });
        }
        bindSwatch("dualColor1Swatch", "dualColorPicker1", 1);
        bindSwatch("dualColor2Swatch", "dualColorPicker2", 2);

        var applyBtn = document.getElementById("applyDualColorBtn");
        if (applyBtn) {
            applyBtn.addEventListener("click", function() {
                // ── Preset duplicate check ────────────────────────────────────
                var c1Up = color1.toUpperCase(), c2Up = color2.toUpperCase();
                var isPreset = false;
                document.querySelectorAll(".colorPlate-grad").forEach(function(btn) {
                    if ((btn.dataset.c1 || "").toUpperCase() === c1Up &&
                        (btn.dataset.c2 || "").toUpperCase() === c2Up) {
                        isPreset = true;
                    }
                });
                if (isPreset) {
                    _showDualPresetWarning();
                    return; // Don't apply — user should use the preset directly
                }
                // ─────────────────────────────────────────────────────────────
                _swapped = false; // reset swap when saving a new theme
                localStorage.removeItem(SWAP_KEY);
                localStorage.setItem(DUAL_COLOR_KEY, JSON.stringify({ c1: color1, c2: color2 }));
                localStorage.removeItem("selectedTheme");
                localStorage.removeItem("safePresetTheme");
                localStorage.removeItem("customThemeColor");
                applyDualGradient(color1, color2);
                if (typeof addSavedGradient    === "function") addSavedGradient(color1, color2);
                if (typeof renderSavedColors   === "function") renderSavedColors();
                closePanel();
            });
        }

        var cancelBtn = document.getElementById("cancelDualColorBtn");
        if (cancelBtn) cancelBtn.addEventListener("click", function() {
            // Restore to pre-preview state
            _restoreSnapshot(_previewSnapshot);
            _previewSnapshot = null;
            closePanel();
        });

        document.querySelectorAll(".colorPlate").forEach(function(radio) {
            radio.addEventListener("change", function() { closePanel(); });
        });
        var cp = document.getElementById("colorPicker");
        if (cp) cp.addEventListener("change", function() { clearDualTheme(); });

        // ── Preset gradient circles in colorsContainer ──
        // NOTE: _updateGradPresetActive is defined at module scope (above) and is
        // called automatically by applyDualGradient, so no local redefinition needed.

        // ─── Unified Context Menu for All Themes ───
        var _currentCtxMenu = null;
        
        function _closeContextMenuDual() {
            if (_currentCtxMenu) {
                var menu = _currentCtxMenu;
                _currentCtxMenu = null;
                menu.classList.remove("sc-ctx-visible");
                var mult = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")) || 1;
                var dur = Math.round(180 * mult);
                setTimeout(function() {
                    menu.remove();
                }, dur + 20);
            }
            // Close all other context menus (from saved-colors.js)
            if (typeof closeContextMenu === "function") {
                closeContextMenu();
            }
        }
        
        function _showThemeContextMenu(e, data) {
            e.preventDefault();
            _closeContextMenuDual();

            var isGradient = data.c1 && data.c2;
            // Capture source dot for animation on Apply
            var sourceDot = e.target && e.target.closest ? e.target.closest(".colorPlate-grad, input[type=\"radio\"]") : null;

            var menu = document.createElement("div");
            menu.className = "sc-context-menu";
            
            var applyBtn = document.createElement("button");
            applyBtn.className = "sc-ctx-btn sc-ctx-apply";
            var label = (typeof getT === "function") ? getT("savedColorApply") : "Apply Theme";
            applyBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg><span>' + label + '</span>';
            
            applyBtn.addEventListener("click", function() {
                _closeContextMenuDual();

                // Play bounce animation on the source dot
                if (sourceDot && sourceDot.isConnected) {
                    document.querySelectorAll(".colorPlate, .colorPlate-grad, .sc-color-dot").forEach(el => {
                        el.classList.remove("plate-select-anim");
                    });
                    void sourceDot.offsetWidth;
                    sourceDot.classList.add("plate-select-anim");
                    sourceDot.addEventListener("animationend", () => {
                        sourceDot.classList.remove("plate-select-anim");
                    }, { once: true });
                }

                if (isGradient) {
                    if (window.dualColorTheme) {
                        // Preserve current swap state — don't reset it.
                        // The user right-clicked on the active preset while swap was on;
                        // they want to re-apply (or confirm) the theme as it currently looks.
                        localStorage.setItem("dualColorTheme", JSON.stringify({ c1: data.c1, c2: data.c2 }));
                        localStorage.removeItem("selectedTheme");
                        localStorage.removeItem("safePresetTheme");
                        localStorage.removeItem("customThemeColor");
                        window.dualColorTheme.applyDualGradient(data.c1, data.c2);
                        document.querySelectorAll(".colorPlate").forEach(function(r) { r.checked = false; });
                        _updateGradPresetActive();
                        if (typeof renderSavedColors === "function") renderSavedColors();
                    }
                } else {
                    // Solo color — use applyPredefinedThemeNow so customThemeStorageKey
                    // and dualColorTheme are fully cleared before renderSavedColors runs.
                    // This prevents a stale saved-color dot from keeping its checkmark.
                    if (typeof applyPredefinedThemeNow === "function") {
                        applyPredefinedThemeNow(data.colorName);
                    } else if (typeof applySelectedTheme === "function") {
                        localStorage.setItem("selectedTheme", data.colorName);
                        localStorage.removeItem("customThemeColor");
                        localStorage.removeItem("dualColorTheme");
                        applySelectedTheme(data.colorName);
                        document.querySelectorAll(".colorPlate").forEach(function(r) { r.checked = (r.value === data.colorName); });
                    }
                    if (window.dualColorTheme) window.dualColorTheme.clearDualTheme();
                    _updateGradPresetActive();
                    if (typeof renderSavedColors === "function") renderSavedColors();
                }
            });
            
            menu.appendChild(applyBtn);
            document.body.appendChild(menu);
            _currentCtxMenu = menu;
            
            var mw = 160, mh = 46;
            var x = e.clientX, y = e.clientY;
            if (x + mw > window.innerWidth) x = window.innerWidth - mw - 8;
            if (y + mh > window.innerHeight) y = window.innerHeight - mh - 8;
            menu.style.left = x + "px";
            menu.style.top = y + "px";
            
            // Force reflow to register starting styles for transition
            void menu.offsetWidth;
            
            menu.classList.add("sc-ctx-visible");
        }
        
        document.addEventListener("click", _closeContextMenuDual);
        document.addEventListener("keydown", function(ev) { if (ev.key === "Escape") _closeContextMenuDual(); });

        // Context menu for gradient presets
        document.querySelectorAll(".colorPlate-grad").forEach(function(btn) {
            var c1 = btn.dataset.c1, c2 = btn.dataset.c2;
            // Initial gradient and shadow are set by _updateGradPresetActive() below
            btn.addEventListener("contextmenu", function(e) { 
                _showThemeContextMenu(e, { c1: c1, c2: c2 }); 
            });
            btn.addEventListener("click", function() {
                // Bounce animation feedback
                document.querySelectorAll(".colorPlate, .colorPlate-grad, .sc-color-dot").forEach(el => {
                    el.classList.remove("plate-select-anim");
                });
                var _btn = this;
                void _btn.offsetWidth;
                _btn.classList.add("plate-select-anim");
                _btn.addEventListener("animationend", () => {
                    _btn.classList.remove("plate-select-anim");
                }, { once: true });
                if (!window.dualColorTheme) return;
                // If this gradient is already the active theme, don't re-apply (preserves user changes)
                var storedDual = localStorage.getItem("dualColorTheme");
                if (storedDual && document.body.getAttribute("data-dual-theme") === "active") {
                    try {
                        var d = JSON.parse(storedDual);
                        if (d.c1 && d.c2 &&
                            d.c1.toUpperCase() === c1.toUpperCase() &&
                            d.c2.toUpperCase() === c2.toUpperCase()) {
                            // Already active — just update visual active state without re-applying
                            _updateGradPresetActive();
                            if (typeof renderSavedColors === "function") renderSavedColors();
                            return;
                        }
                    } catch(e) {}
                }
                window.dualColorTheme.resetSwap();
                localStorage.setItem("dualColorTheme", JSON.stringify({ c1: c1, c2: c2 }));
                localStorage.removeItem("selectedTheme");
                localStorage.removeItem("safePresetTheme");
                localStorage.removeItem("customThemeColor");
                window.dualColorTheme.applyDualGradient(c1, c2);
                document.querySelectorAll(".colorPlate").forEach(function(r) { r.checked = false; });
                _updateGradPresetActive();
                if (typeof renderSavedColors === "function") renderSavedColors();
            });
        });

        // Context menu for solo color presets
        // NOTE: we only attach "change" here — contextmenu is handled exclusively by
        // theme.js's container delegation to avoid firing two menus simultaneously.
        document.querySelectorAll(".colorPlate").forEach(function(radio) {
            radio.addEventListener("change", function() {
                document.querySelectorAll(".colorPlate-grad").forEach(function(btn) {
                    btn.classList.remove("grad-active");
                });
            });
        });

        // Restore active state on load
        _updateGradPresetActive();

        // ── Direct mode-switch listener ────────────────────────────────────────
        // theme.js's applyThemeMode already calls loadStoredDualColor() correctly
        // through _smoothThemeSwitch (with no-theme-transition active → double-rAF → animation).
        // We only handle the panel preview here if the panel is open.
        document.querySelectorAll(".themeSegBtn").forEach(function(btn) {
            btn.addEventListener("click", function() {
                // setTimeout(0) fires AFTER the first rAF — at that point no-theme-transition
                // is already removed. Do NOT call loadStoredDualColor() here; it would re-run
                // _applyDualGradientCore with transitions live → snaps the circle instantly.
                // theme.js handles loadStoredDualColor() at the right time internally.
                setTimeout(function() {
                    // Only refresh the panel preview if it is open.
                    var panel = document.getElementById("dualColorPanel");
                    if (panel && panel.classList.contains("dualPanelVisible")) {
                        updatePanelPreview();
                    }
                }, 0);
            });
        });

        // Also handle OS-level system theme changes when mode is "system"
        window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", function() {
            if (localStorage.getItem("preferredTheme") === "system" &&
                localStorage.getItem(DUAL_COLOR_KEY)) {
                loadStoredDualColor();
            }
        });
    });

    window.dualColorTheme = {
        loadStoredDualColor: loadStoredDualColor,
        applyDualGradient:   applyDualGradient,
        clearDualTheme:      clearDualTheme,
        resetSwap: function() { _swapped = false; localStorage.removeItem(SWAP_KEY); },
        // Sync grad-active class on all preset gradient buttons to match current stored theme
        updateGradPresetActive: function() { _updateGradPresetActive(); },
        // Refresh colors for the current active mode — called on mode switch
        refreshForMode: function() {
            var stored = localStorage.getItem(DUAL_COLOR_KEY);
            if (stored) loadStoredDualColor();
        }
    };
})();

/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

// ── Suppress ALL CSS-var and filter transitions during page init ─────────────
// Without this, DOMContentLoaded's applySelectedTheme writes inline-style values that
// differ from the preload <style> :root values in specificity — the browser treats this
// as a value change and fires CSS @property transitions (0.18s ease-out on color vars),
// animating FROM the @property initial-value (#bbd6fd blue) TO the real color = blue flash.
// Also prevents any filter transition flash during the init phase.
// Removed at the start of DOMContentLoaded (theme.js) before LoadingScreen is hidden.
document.documentElement.classList.add("no-theme-transition");

// Set lang early for RTL languages so translations apply from first paint
(function() {
    var savedLang = localStorage.getItem("selectedLanguage") || "en";
    document.documentElement.setAttribute("lang", savedLang);
    document.documentElement.dir = ["ar_SA", "fa", "ur"].includes(savedLang) ? "rtl" : "ltr";
})();

// Set Loading Screen Color before Everything Loads
document.documentElement.style.setProperty('--Loading-Screen-Color', localStorage.getItem('LoadingScreenColor') || "#c2d8fb");

// Apply animation speed multiplier immediately to avoid flash of wrong animation speed
(function() {
    const speed = parseInt(localStorage.getItem("uiAnimSpeed") || "50");
    const s = Math.max(1, Math.min(100, Number.isFinite(speed) ? speed : 50));
    let mult;
    if (s >= 50) {
        mult = 1.0 * Math.pow(0.25, (s - 50) / 50);
    } else {
        mult = 1.0 * Math.pow(3.0, (50 - s) / 49);
    }
    document.documentElement.style.setProperty("--ui-anim-mult", mult.toFixed(3));
})();

// Set data-bg early so dark-mode CSS rules work correctly before wallpaper.js runs
(function() {
    const hasFolder = parseInt(localStorage.getItem("folderWallpaperCount") || "0") > 0;
    const hasSingle = localStorage.getItem("hasSingleWallpaper") === "true";
    if (hasFolder || hasSingle) {
        document.documentElement.setAttribute("data-preload-bg", "wallpaper");
        if (document.body) {
            document.body.setAttribute("data-bg", "wallpaper");
        }
    }
})();

// Apply saved brightness early
(function() {
    var savedBrightness = parseFloat(localStorage.getItem("videoBgOpacity") || "1");
    var clamped = Math.min(1, Math.max(0.1, savedBrightness));
    document.documentElement.style.setProperty("--bg-brightness", clamped);
})();

// ── Pre-hide weather if user disabled it — prevents flash before weather.js runs ──
(function() {
    try {
        var hidden = localStorage.getItem("hideWeatherVisible") === "true";
        if (hidden) document.documentElement.classList.add("pre-hide-weather");
    } catch (e) {}
})();

// ── Apply Layout Editor positions BEFORE first paint ──────────────────────
// Key MUST match STORAGE_KEY in layout-editor.js exactly: "layoutEditorV1"
(function() {
    try {
        var saved = JSON.parse(localStorage.getItem("layoutEditorV1") || "{}");
        var keys = ["clock", "text", "weather", "search", "quotes"];
        var root = document.documentElement;
        var mobile = window.innerWidth < 1201;
        keys.forEach(function(key) {
            var s = saved[key] || {};
            var tx    = (typeof s.tx    === "number" ? s.tx    : 0);
            var ty    = (typeof s.ty    === "number" ? s.ty    : 0);
            var scale = (typeof s.scale === "number" ? s.scale : 1);
            root.style.setProperty("--le-tx-" + key, (mobile ? 0 : tx) + "px");
            root.style.setProperty("--le-ty-" + key, (mobile ? 0 : ty) + "px");
            root.style.setProperty("--le-scale-" + key, scale);
        });
    } catch (e) {}
})();
// ── Apply theme CSS vars + dark mode BEFORE first paint — prevents FOUC ──────
// The @property CSS vars (--bg-color-blue etc.) have initial-value: #bbd6fd (blue).
// theme.js applies the real values on DOMContentLoaded — too late, causing a blue flash.
//
// Strategy: inject a <style> tag into <head> that overrides the @property initial-value
// via a :root {} rule BEFORE the first paint. Because the rule is present from the very
// first style calculation, the browser never "sees" the blue initial-value — it sees our
// cached value from the start. No @property transition fires because the value never changes
// from the browser's perspective. theme.js then sets inline styles (same values) → no change.
//
// Dark mode: add html.dark-preload class → CSS applies filter:invert immediately.
// The class is removed by theme.js after the real selector (.themeSegment[data-active])
// takes over, using rAF so there's no paint between removal and re-application.
(function() {
    try {
        var cache = JSON.parse(localStorage.getItem("themeVarsCache") || "null");
        var pref    = localStorage.getItem("preferredTheme") || "light";
        var sysDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        var isDark  = pref === "dark" || (pref === "system" && sysDark);
        var hasDual   = !!localStorage.getItem("dualColorTheme");
        var hasCustom = !!localStorage.getItem("customThemeColor");

        // Inject a <style> :root rule to override @property initial-value (#bbd6fd)
        // BEFORE first paint. The browser treats this as the "starting" computed value
        // so no @property transition fires from blue → saved color.
        //
        // IMPORTANT (first-run dark-mode fix): the predefined dark-mode white-text override
        // (--textColorDark-blue:#000000, which inverts to white under filter:invert) MUST be
        // injected even when there is NO themeVarsCache yet — i.e. on the very first launch
        // before any theme has been applied/saved. Previously this override lived INSIDE the
        // `if (cache && cache.bg)` block, so on a fresh install switching straight to dark left
        // the text using the un-inverted initial-value (appearing black) until a later, slow
        // CSS :has() recalculation finally applied it. Building the rule unconditionally for
        // dark predefined themes guarantees correct white text from the very first paint.
        var css = ":root{";
        if (cache && cache.bg) {
            if (cache.bg)     css += "--bg-color-blue:"        + cache.bg     + ";";
            if (cache.tint)   css += "--accentLightTint-blue:" + cache.tint   + ";";
            if (cache.dark)   css += "--darkColor-blue:"       + cache.dark   + ";";
            if (cache.darker) css += "--darkerColor-blue:"     + cache.darker + ";";
            if (cache.text)   css += "--textColorDark-blue:"   + cache.text   + ";";
            if (cache.white)  css += "--whitishColor-blue:"    + cache.white  + ";";
            if (cache.sep)    css += "--ui-sep:"               + cache.sep    + ";";
            if (cache.shadow) css += "--shadow-tint-color:"    + cache.shadow + ";";
        }
        // For dark predefined themes, flip text to #000000 (→ white under invert) and
        // --ui-sep to a white tint. Applied regardless of whether a cache exists.
        if (isDark && !hasDual && !hasCustom) {
            css += "--ui-sep:rgba(255,255,255,0.1);";
            css += "--textColorDark-blue:#000000;";
        }
        css += "}";
        // Only append the <style> if we actually produced at least one declaration.
        if (css !== ":root{}") {
            var st = document.createElement("style");
            st.id = "preload-theme-vars";
            st.textContent = css;
            document.head.appendChild(st);
        }

        // ── CRITICAL: set data-preload-override and dark-preload BEFORE any document.body access ──
        // preload.js is a synchronous (non-deferred) script in <head>. At execution time,
        // document.body is null — the HTML parser has not yet reached <body>.
        // Any document.body access inside this try-catch will throw, and the catch will
        // silently swallow it — skipping everything after the throw, including dark-preload!
        //
        // For predefined dark themes dark-preload provides the filter:invert that makes the
        // page appear dark from the very first paint. If it is skipped, the LoadingScreen
        // and page content flash LIGHT before DOMContentLoaded applies the real dark mode.
        //
        // Fix: set both documentElement-only attributes (which never throw) FIRST, then
        // attempt the body accesses afterwards. A body-access failure now only loses the
        // optional body attributes, not the critical dark-preload class.

        // For predefined single-color dark themes: apply filter:invert via dark-preload class
        // (custom/dual themes use direct CSS vars — no filter needed)
        document.documentElement.setAttribute("data-preload-override",
            (hasDual || hasCustom) ? "custom" : "predefined");

        // ── Mirror the selected theme mode onto <html data-pref> BEFORE first paint ──
        // Theme-aware CSS now matches on html[data-pref="light|dark|system"] (+ body[sysTheme])
        // instead of the old, expensive html:has(.themeSegment[data-active="..."]) selectors.
        // Setting it here guarantees correct dark text / bookmark colors from the very first
        // paint on a fresh install, with no double-toggle needed and no slow :has() recalc.
        document.documentElement.setAttribute("data-pref", pref);

        if (isDark) {
            document.documentElement.classList.add("dark-preload");
        }

        // ── Set body attributes early so CSS :has() selectors fire immediately ──
        // data-dual-theme is needed in BOTH light and dark modes so the correct CSS
        // selectors match from the very first paint.
        // data-custom-theme is only needed in dark mode (light mode uses CSS vars directly).
        // NOTE: these may silently fail if document.body is still null (sync script in <head>),
        // but that is acceptable — theme.js will set them again on DOMContentLoaded.
        if (hasDual) {
            document.body.setAttribute("data-dual-theme", "active");
        } else if (isDark && hasCustom) {
            document.body.setAttribute("data-custom-theme", "active");
        }

        // Mark the bg type so dark-mode CSS :has() selectors can match
        // (color bg is the default — only wallpaper needs special marking)
        if (!document.body.getAttribute("data-bg")) {
            document.body.setAttribute("data-bg", "color");
        }

        // Stamp sysTheme on body early (mirrors syncThemeChange in theme.js)
        document.body.setAttribute("sysTheme", sysDark ? "systemDark" : "systemLight");
    } catch(e) {}
})();

// Safety net: theme.js normally hides the loading screen on DOMContentLoaded.
// If any deferred script fails, remove the blocker instead of leaving the page stuck.
setTimeout(function () {
    var loader = document.getElementById("LoadingScreen");
    if (loader && loader.style.display !== "none") {
        loader.style.display = "none";
    }
}, 8000);

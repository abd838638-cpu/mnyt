/* 
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 * You should have received a copy of the GNU General Public License along with this program. 
 * If not, see <https://www.gnu.org/licenses/>.
 */
// ------------------------ Bookmark System -----------------------------------
// DOM Variables
const bookmarkButton = document.getElementById("bookmarkButton");
const bookmarkSidebar = document.getElementById("bookmarkSidebar");
const bookmarkList = document.getElementById("bookmarkList");
const bookmarkSearch = document.getElementById("bookmarkSearch");
const bookmarkSearchClearButton = document.getElementById("clearSearchButton");
const bookmarkViewGrid = document.getElementById("bookmarkViewGrid");
const bookmarkViewList = document.getElementById("bookmarkViewList");
const bookmarksCheckbox = document.getElementById("bookmarksCheckbox");

const editBookmarkModal = document.getElementById("editBookmarkModal");
const editBookmarkName = document.getElementById("editBookmarkName");
const editBookmarkURL = document.getElementById("editBookmarkURL");
const editBookmarkFavicon = document.getElementById("editBookmarkFavicon");
const saveBookmarkChanges = document.getElementById("saveBookmarkChanges");
const cancelBookmarkEdit = document.getElementById("cancelBookmarkEdit");
let currentBookmarkId = null;
let _bmDiscoveryNodes = [];
let _bmSearchOpenBefore = null;
let _bmLoadVersion = 0;
let _bmDiscoveryState = "ready";

function bmDiscoveryText(key) {
    const ar = (window.currentLanguage || localStorage.getItem("selectedLanguage")) === "ar_SA";
    const strings = {
        close: ["Close bookmarks", "إغلاق الإشارات المرجعية"], expand: ["Expand folders", "فتح المجلدات"], collapse: ["Collapse folders", "طيّ المجلدات"],
        saved: ["saved links", "روابط محفوظة"], results: ["matches", "نتائج مطابقة"], loading: ["Loading your bookmarks…", "جارٍ تحميل إشاراتك…"],
        empty: ["Your collection starts here", "مجموعتك تبدأ من هنا"], emptyHelp: ["Save pages in your browser to find them here.", "احفظ صفحات في المتصفح لتصل إليها من هنا."],
        noResults: ["No matching bookmarks", "لا توجد إشارات مطابقة"], noResultsHelp: ["Try a title, a website, or a folder name.", "جرّب عنواناً أو موقعاً أو اسم مجلد."],
        error: ["Couldn't load your bookmarks", "تعذّر تحميل الإشارات المرجعية"], errorHelp: ["Check the extension's bookmarks permission, then try again.", "تحقق من صلاحية الإشارات المرجعية للإضافة، ثم حاول مجدداً."],
        retry: ["Try again", "إعادة المحاولة"], recent: ["Recently Added", "أُضيفت مؤخراً"], clear: ["Clear search", "مسح البحث"]
    };
    return strings[key]?.[ar ? 1 : 0] || key;
}

let _bmLastOpenSig = null;
function bmRefreshDiscovery(summaryArg) {
    const summary = summaryArg || window.MyntNavigationCore.searchBookmarks(_bmDiscoveryNodes, bookmarkSearch.value);
    const querying = Boolean(bookmarkSearch.value.trim());
    const count = querying ? summary.matches.size : summary.linkCount;
    const status = document.getElementById("bookmarkResultsStatus");
    status.textContent = _bmDiscoveryState === "loading" ? bmDiscoveryText("loading") : `${count} ${bmDiscoveryText(querying ? "results" : "saved")}`;
    bookmarkList.setAttribute("aria-busy", String(_bmDiscoveryState === "loading"));
    const empty = document.getElementById("bookmarkEmptyState");
    empty.hidden = _bmDiscoveryState === "loading" || (_bmDiscoveryState !== "error" && (querying ? summary.visible.size > 0 : _bmDiscoveryNodes.length > 0));
    document.getElementById("bookmarkEmptyTitle").textContent = bmDiscoveryText(_bmDiscoveryState === "error" ? "error" : querying ? "noResults" : "empty");
    document.getElementById("bookmarkEmptyDescription").textContent = bmDiscoveryText(_bmDiscoveryState === "error" ? "errorHelp" : querying ? "noResultsHelp" : "emptyHelp");
    const retry = document.getElementById("bookmarkRetry");
    retry.hidden = _bmDiscoveryState !== "error";
    retry.textContent = bmDiscoveryText("retry");
    const folders = [...bookmarkList.querySelectorAll("li.folder")];
    const allOpen = folders.length > 0 && folders.every(folder => folder.classList.contains("open"));
    const expand = document.getElementById("bookmarkExpandAll");
    expand.textContent = bmDiscoveryText(allOpen ? "collapse" : "expand");
    expand.disabled = !folders.length || querying;
    document.getElementById("bookmarkClose").setAttribute("aria-label", bmDiscoveryText("close"));
    bookmarkSearchClearButton.setAttribute("aria-label", bmDiscoveryText("clear"));
    bookmarkViewGrid.setAttribute("aria-pressed", String(bookmarkGridCheckbox.checked));
    bookmarkViewList.setAttribute("aria-pressed", String(!bookmarkGridCheckbox.checked));
    document.querySelectorAll(".bookmark-sort-button").forEach(button => button.setAttribute("aria-pressed", String(button.classList.contains("active"))));
    // Per-folder aria/inert sync is the costliest part of this refresh; skip it
    // when the open-state signature is unchanged (same nodes, same state).
    // New/removed nodes always change the signature, so nothing goes stale.
    const openSig = folders.map(f => f.dataset.id + (f.classList.contains("open") ? ":1" : ":0")).join(",");
    if (openSig !== _bmLastOpenSig) {
        _bmLastOpenSig = openSig;
        folders.forEach(folder => {
            const title = folder.querySelector(":scope > .bm-folder-title");
            title?.setAttribute("aria-expanded", String(folder.classList.contains("open")));
            const inner = folder.querySelector(":scope > ul");
            if (inner) inner.inert = !folder.classList.contains("open");
        });
    }
}

function bmApplySearch() {
    const query = bookmarkSearch.value.trim();
    const result = window.MyntNavigationCore.searchBookmarks(_bmDiscoveryNodes, query);
    // Cached flat list (rebuilt on every render); falls back to a live query
    // if a render happened through a path that bypassed the cache.
    const items = _bmSearchItems && _bmSearchItems.every(n => n.isConnected)
        ? _bmSearchItems
        : (_bmSearchItems = [...bookmarkList.querySelectorAll("li[data-id]")]);
    if (query && !_bmSearchOpenBefore) _bmSearchOpenBefore = _bmGetOpenFolderIds();
    items.forEach(item => {
        // A class is required because old grid rules force display with !important.
        item.classList.toggle("bm-search-hidden", Boolean(query) && !result.visible.has(item.dataset.id));
        if (item.classList.contains("folder")) {
            if (query) item.classList.toggle("open", result.open.has(item.dataset.id));
            else if (_bmSearchOpenBefore) item.classList.toggle("open", _bmSearchOpenBefore.has(item.dataset.id));
        }
    });
    if (!query) _bmSearchOpenBefore = null;
    bookmarkSearchClearButton.style.display = query ? "inline-flex" : "none";
    bmRefreshDiscovery(result);
}

document.getElementById("bookmarkClose").addEventListener("click", () => { toggleBookmarkSidebar(false); bookmarkButton.focus(); });
document.getElementById("bookmarkRetry").addEventListener("click", () => loadBookmarks());
document.getElementById("bookmarkExpandAll").addEventListener("click", () => {
    const folders = [...bookmarkList.querySelectorAll("li.folder")];
    const open = !folders.every(folder => folder.classList.contains("open"));
    folders.forEach(folder => folder.classList.toggle("open", open));
    bmRefreshDiscovery();
});
bookmarkSidebar.setAttribute("role", "region");
bookmarkSidebar.setAttribute("aria-labelledby", "bookmarksHeading");
bookmarkSidebar.addEventListener("keydown", event => {
    if (event.key === "Escape" && !event.defaultPrevented) {
        event.preventDefault();
        if (bookmarkSearch.value) { bookmarkSearch.value = ""; bmApplySearch(); bookmarkSearch.focus(); }
        else { toggleBookmarkSidebar(false); bookmarkButton.focus(); }
    }
});
window.addEventListener("material-you-language-change", bmRefreshDiscovery);

function _bmGetEditBookmarkAnimDur() {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return 0;
    const rawDur = Number(window.getPanelAnimDur?.()) || 220;
    return Math.max(160, Math.round(rawDur));
}

function openEditBookmarkModal() {
    if (!editBookmarkModal) return;
    const dur = _bmGetEditBookmarkAnimDur();
    clearTimeout(editBookmarkModal._openTimer);
    clearTimeout(editBookmarkModal._closeTimer);
    editBookmarkModal.style.setProperty("--edit-bookmark-modal-dur", `${dur}ms`);
    editBookmarkModal.style.left = "50%";
    editBookmarkModal.style.top = "50%";
    editBookmarkModal.style.right = "";
    editBookmarkModal.style.bottom = "";
    editBookmarkModal.style.margin = "";
    editBookmarkModal.classList.remove("edit-bookmark-modal-closing", "edit-bookmark-modal-opening");
    editBookmarkModal.style.display = "block";
    void editBookmarkModal.offsetWidth;
    editBookmarkModal.classList.add("edit-bookmark-modal-opening");
    editBookmarkModal._openTimer = setTimeout(() => {
        editBookmarkModal.classList.remove("edit-bookmark-modal-opening");
    }, dur + 40);
}

function closeEditBookmarkModal(onClosed) {
    if (!editBookmarkModal) {
        if (typeof onClosed === "function") onClosed();
        return;
    }
    const isHidden = editBookmarkModal.style.display === "none" || getComputedStyle(editBookmarkModal).display === "none";
    if (isHidden) {
        editBookmarkModal.classList.remove("edit-bookmark-modal-opening", "edit-bookmark-modal-closing");
        if (typeof onClosed === "function") onClosed();
        return;
    }
    if (editBookmarkModal.classList.contains("edit-bookmark-modal-closing")) return;

    const dur = _bmGetEditBookmarkAnimDur();
    clearTimeout(editBookmarkModal._openTimer);
    clearTimeout(editBookmarkModal._closeTimer);
    editBookmarkModal.style.setProperty("--edit-bookmark-modal-dur", `${dur}ms`);
    editBookmarkModal.style.left = "50%";
    editBookmarkModal.style.top = "50%";
    editBookmarkModal.style.right = "";
    editBookmarkModal.style.bottom = "";
    editBookmarkModal.style.margin = "";
    editBookmarkModal.classList.remove("edit-bookmark-modal-opening");
    void editBookmarkModal.offsetWidth;
    editBookmarkModal.classList.add("edit-bookmark-modal-closing");
    editBookmarkModal._closeTimer = setTimeout(() => {
        editBookmarkModal.classList.remove("edit-bookmark-modal-closing");
        editBookmarkModal.style.display = "none";
        if (typeof onClosed === "function") onClosed();
    }, Math.round(dur * 0.95) + 40);
}

window.openEditBookmarkModal = openEditBookmarkModal;
window.closeEditBookmarkModal = closeEditBookmarkModal;

const sortAlphabetical = document.getElementById("sortAlphabetical");
const sortTimeAdded = document.getElementById("sortTimeAdded");
let currentSortMethod = localStorage.getItem("bookmarkSortMethod") || 'title';
let currentFilter = localStorage.getItem("bookmarkFilterType") || 'all'; // 'all' | 'bookmarks' | 'folders'
let currentFolderOrder = localStorage.getItem("bookmarkFolderOrder") || 'last'; // 'first' | 'last'
const BM_MANUAL_ORDER_KEY = "bmManualOrder";
const BM_VIRTUAL_RECENT_FOLDER_ID = "__bm_recently_added__";
let _bmChildrenByParentId = new Map();
let _bmNodeKindById = new Map();
// Track last explicitly chosen sort so the button stays highlighted in manual mode
let _bmLastExplicitSort = (currentSortMethod !== 'manual') ? currentSortMethod : 'title';

function _bmGetManualOrderStorageKey(filter = currentFilter) {
    const normalizedFilter = ["all", "bookmarks", "folders"].includes(filter)
        ? filter
        : "all";
    return normalizedFilter === "all"
        ? BM_MANUAL_ORDER_KEY
        : `${BM_MANUAL_ORDER_KEY}:${normalizedFilter}`;
}

function _bmReadManualOrder(filter = currentFilter) {
    try {
        const saved = JSON.parse(localStorage.getItem(_bmGetManualOrderStorageKey(filter)) || "[]");
        return Array.isArray(saved)
            ? saved.map(id => String(id)).filter(Boolean)
            : [];
    } catch (e) {
        return [];
    }
}

function _bmWriteManualOrder(ids, filter = currentFilter) {
    const normalizedIds = Array.isArray(ids)
        ? ids.map(id => String(id)).filter(Boolean)
        : [];
    localStorage.setItem(_bmGetManualOrderStorageKey(filter), JSON.stringify(normalizedIds));
}

function _bmClearManualOrder(filter = currentFilter) {
    localStorage.removeItem(_bmGetManualOrderStorageKey(filter));
}

var bookmarksAPI;
if (isFirefox) {
    bookmarksAPI = browser.bookmarks;
} else if (isChromiumBased) {
    bookmarksAPI = chrome.bookmarks;
}

function _bmIsVirtualFolderId(id) {
    return String(id || "") === BM_VIRTUAL_RECENT_FOLDER_ID;
}

function _bmIsVirtualDraggedFolder() {
    return _bmIsVirtualFolderId(DD?.id);
}

function _bmIsVirtualFolderLi(li) {
    return !!li && _bmIsVirtualFolderId(li.dataset?.id);
}

function _bmCacheNodeOrder(node) {
    if (!node?.id) return;
    const id = String(node.id);
    const isFolder = node.children !== undefined;
    _bmNodeKindById.set(id, isFolder ? "folder" : "bookmark");
    if (!isFolder) return;

    const childIds = (node.children || [])
        .filter(child => child?.id)
        .map(child => String(child.id));
    _bmChildrenByParentId.set(id, childIds);
    (node.children || []).forEach(_bmCacheNodeOrder);
}

function _bmGetNodeKindById(id) {
    return _bmNodeKindById.get(String(id || "")) || null;
}

function _bmGetStoredChildIndex(parentId, childId) {
    const childIds = _bmChildrenByParentId.get(String(parentId || "")) || [];
    return childIds.indexOf(String(childId || ""));
}

function _bmSyncManualOrderFromCache(filter = currentFilter) {
    const normalizedFilter = ["all", "bookmarks", "folders"].includes(filter) ? filter : "all";
    const rootIds = (_bmChildrenByParentId.get(String(_bmRootParentId || "")) || [])
        .map(id => String(id))
        .filter(id => id && !_bmIsVirtualFolderId(id));

    let ids = rootIds;
    if (normalizedFilter === "bookmarks") {
        ids = rootIds.filter(id => _bmGetNodeKindById(id) === "bookmark");
    } else if (normalizedFilter === "folders") {
        ids = rootIds.filter(id => _bmGetNodeKindById(id) === "folder");
    }

    _bmWriteManualOrder(ids, normalizedFilter);
}

function _bmUpdateManualOrderForMove(id, nextSiblingId, filter = "all") {
    let ids = _bmReadManualOrder(filter);
    if (!ids || !ids.length) {
        _bmSyncManualOrderFromCache(filter);
        ids = _bmReadManualOrder(filter);
    }
    if (!ids || !ids.length) return;

    const normalizedId = String(id);
    const existingIdx = ids.indexOf(normalizedId);
    if (existingIdx >= 0) {
        ids.splice(existingIdx, 1);
    }

    if (nextSiblingId) {
        const targetIdx = ids.indexOf(String(nextSiblingId));
        if (targetIdx >= 0) {
            ids.splice(targetIdx, 0, normalizedId);
        } else {
            ids.push(normalizedId);
        }
    } else {
        ids.push(normalizedId);
    }
    _bmWriteManualOrder(ids, filter);
}

function _bmUpdateManualOrderForSwap(id1, id2, filter = "all") {
    let ids = _bmReadManualOrder(filter);
    if (!ids || !ids.length) {
        _bmSyncManualOrderFromCache(filter);
        ids = _bmReadManualOrder(filter);
    }
    if (!ids || !ids.length) return;

    const idx1 = ids.indexOf(String(id1));
    const idx2 = ids.indexOf(String(id2));

    if (idx1 >= 0 && idx2 >= 0) {
        const temp = ids[idx1];
        ids[idx1] = ids[idx2];
        ids[idx2] = temp;
        _bmWriteManualOrder(ids, filter);
    }
}

const _bmUndoStack = [];
const _bmRedoStack = [];
const _bmHistoryLimit = 40;
let _bmHistoryBusy = false;

function _bmCreateMoveSnapshot(parentId, index = 0, nextSiblingId = null) {
    const normalizedIndex = Number.isFinite(Number(index)) ? Math.max(0, Number(index)) : 0;
    return {
        parentId: String(parentId || _bmRootParentId),
        index: normalizedIndex,
        nextSiblingId: nextSiblingId ? String(nextSiblingId) : null,
    };
}

function _bmGetSubTree(id) {
    return new Promise((resolve, reject) => {
        if (isFirefox) {
            bookmarksAPI.getSubTree(id).then(resolve).catch(reject);
        } else {
            bookmarksAPI.getSubTree(id, (results) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(results);
                }
            });
        }
    });
}

async function _bmRestoreSubtree(node, parentId, index) {
    const createParams = {
        parentId: parentId,
        title: node.title,
    };
    if (typeof index === "number") {
        createParams.index = index;
    }
    if (node.url) {
        createParams.url = node.url;
    }

    const newNode = await new Promise((resolve, reject) => {
        if (isFirefox) {
            bookmarksAPI.create(createParams).then(resolve).catch(reject);
        } else {
            bookmarksAPI.create(createParams, (result) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(result);
                }
            });
        }
    });

    if (Array.isArray(node.children)) {
        for (let i = 0; i < node.children.length; i++) {
            await _bmRestoreSubtree(node.children[i], newNode.id, i);
        }
    }
    return newNode;
}

function _bmRemoveTreeDirect(id) {
    return new Promise((resolve, reject) => {
        if (isFirefox) {
            bookmarksAPI.removeTree(id).then(resolve).catch(reject);
        } else {
            bookmarksAPI.removeTree(id, () => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve();
                }
            });
        }
    });
}

function _bmInsertManualOrderAt(id, index, parentId) {
    const normalizedParentId = String(parentId || _bmRootParentId);
    const childIds = _bmChildrenByParentId.get(normalizedParentId) || [];
    const idx = Math.max(0, Math.min(index, childIds.length));
    childIds.splice(idx, 0, String(id));
    _bmChildrenByParentId.set(normalizedParentId, childIds);

    if (normalizedParentId === String(_bmRootParentId)) {
        const isFolder = _bmGetNodeKindById(id) === "folder";
        let allIds = _bmReadManualOrder("all");
        if (allIds && allIds.length) {
            allIds.splice(idx, 0, String(id));
            _bmWriteManualOrder(allIds, "all");
        } else {
            _bmSyncManualOrderFromCache("all");
        }

        const filter = isFolder ? "folders" : "bookmarks";
        let typedIds = _bmReadManualOrder(filter);
        if (typedIds && typedIds.length) {
            _bmSyncManualOrderFromCache(filter);
        } else {
            _bmSyncManualOrderFromCache(filter);
        }
    }
}

function _bmPushHistoryEntry(entry) {
    if (_bmHistoryBusy) return;
    const allowedKinds = ["section-move", "section-add", "section-delete", "bookmark-delete", "bookmark-edit"];
    if (!allowedKinds.includes(entry.kind) && !entry?.moves?.length) return;
    _bmUndoStack.push(entry);
    if (_bmUndoStack.length > _bmHistoryLimit) _bmUndoStack.shift();
    _bmRedoStack.length = 0;
}


function _bmUpdateCacheAfterMove(id, fromParentId, toParentId, toIndex) {
    const normalizedId = String(id || "");
    if (!normalizedId) return;

    const normalizedFromParentId = String(fromParentId || _bmRootParentId);
    const normalizedToParentId = String(toParentId || _bmRootParentId);
    const fromChildIds = (_bmChildrenByParentId.get(normalizedFromParentId) || []).map(childId => String(childId));
    const existingIndex = fromChildIds.indexOf(normalizedId);
    if (existingIndex >= 0) fromChildIds.splice(existingIndex, 1);
    _bmChildrenByParentId.set(normalizedFromParentId, fromChildIds);

    const toChildIds = normalizedFromParentId === normalizedToParentId
        ? fromChildIds
        : (_bmChildrenByParentId.get(normalizedToParentId) || []).map(childId => String(childId));
    const insertIndex = Math.max(0, Math.min(Number.isFinite(Number(toIndex)) ? Number(toIndex) : toChildIds.length, toChildIds.length));
    toChildIds.splice(insertIndex, 0, normalizedId);
    _bmChildrenByParentId.set(normalizedToParentId, toChildIds);
}

async function _bmApplyHistoryEntry(direction = "undo") {
    if (_bmHistoryBusy) return false;

    const sourceStack = direction === "undo" ? _bmUndoStack : _bmRedoStack;
    const targetStack = direction === "undo" ? _bmRedoStack : _bmUndoStack;
    const entry = sourceStack.pop();
    if (!entry) return false;

    if (entry.kind === "section-add") {
        _bmHistoryBusy = true;
        try {
            if (direction === "undo") {
                _bmDeleteSectionDirect(entry.section.id);
                bmShowToast("bm_toast_deleted", "delete");
            } else {
                _bmAddSectionDirect(entry.section);
                bmShowToast("bm_toast_added", "add");
            }
            await loadBookmarks();
            targetStack.push(entry);
            return true;
        } catch (error) {
            sourceStack.push(entry);
            loadBookmarks();
            return false;
        } finally {
            _bmHistoryBusy = false;
        }
    }

    if (entry.kind === "section-delete") {
        _bmHistoryBusy = true;
        try {
            if (direction === "undo") {
                _bmAddSectionDirect(entry.section);
                bmShowToast("bm_toast_added", "add");
            } else {
                _bmDeleteSectionDirect(entry.section.id);
                bmShowToast("bm_toast_deleted", "delete");
            }
            await loadBookmarks();
            targetStack.push(entry);
            return true;
        } catch (error) {
            sourceStack.push(entry);
            loadBookmarks();
            return false;
        } finally {
            _bmHistoryBusy = false;
        }
    }

    if (entry.kind === "section-move") {
        _bmHistoryBusy = true;
        try {
            const targetAfterId = direction === "undo" ? entry.fromAfterId : entry.toAfterId;
            _bmUpdateSectionAfterId(entry.sectionId, targetAfterId);
            await loadBookmarks();
            targetStack.push(entry);
            bmShowToast("bm_toast_moved", direction === "undo" ? "undo" : "redo");
            return true;
        } catch (error) {
            sourceStack.push(entry);
            loadBookmarks();
            return false;
        } finally {
            _bmHistoryBusy = false;
        }
    }

    if (entry.kind === "bookmark-delete") {
        _bmHistoryBusy = true;
        try {
            if (direction === "undo") {
                const restoredNode = await _bmRestoreSubtree(entry.node, entry.parentId, entry.index);
                entry.currentId = restoredNode.id;
                _bmNodeKindById.set(restoredNode.id, entry.node.url ? "bookmark" : "folder");
                _bmInsertManualOrderAt(restoredNode.id, entry.index, entry.parentId);
                bmShowToast("bm_toast_added", "add");
            } else {
                await _bmRemoveTreeDirect(entry.currentId);
                bmShowToast("bm_toast_deleted", "delete");
            }
            await loadBookmarks();
            targetStack.push(entry);
            return true;
        } catch (error) {
            console.error(error);
            sourceStack.push(entry);
            loadBookmarks();
            return false;
        } finally {
            _bmHistoryBusy = false;
        }
    }

    if (entry.kind === "bookmark-edit") {
        _bmHistoryBusy = true;
        try {
            const data = direction === "undo" ? entry.oldData : entry.newData;
            await new Promise((resolve, reject) => {
                if (isFirefox) {
                    bookmarksAPI.update(entry.id, data).then(resolve).catch(reject);
                } else {
                    bookmarksAPI.update(entry.id, data, () => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message || "Failed to update bookmark"));
                        } else {
                            resolve();
                        }
                    });
                }
            });
            await loadBookmarks();
            targetStack.push(entry);
            bmShowToast("bm_toast_edited", direction === "undo" ? "undo" : "redo");
            return true;
        } catch (error) {
            console.error(error);
            sourceStack.push(entry);
            loadBookmarks();
            return false;
        } finally {
            _bmHistoryBusy = false;
        }
    }

    if (!entry.moves?.length) return false;

    _bmHistoryBusy = true;
    const scrollTop = DD_getScrollContainer()?.scrollTop || 0;

    try {
        const sequence = direction === "undo"
            ? [...entry.moves].reverse()
            : [...entry.moves];
        let touchedRoot = false;
        let normalizedRootBookmarkId = "";

        for (const move of sequence) {
            const currentSnapshot = direction === "undo" ? move.to : move.from;
            const targetSnapshot = direction === "undo" ? move.from : move.to;
            const params = _bmGetHistoryMoveParams(targetSnapshot);

            await _bmMoveBookmarkNode(move.id, params);
            _bmUpdateCacheAfterMove(move.id, currentSnapshot.parentId, params.parentId, params.index);

            if (String(currentSnapshot.parentId) === String(_bmRootParentId) || String(params.parentId) === String(_bmRootParentId)) {
                touchedRoot = true;
                if (_bmGetNodeKindById(move.id) !== "folder") {
                    normalizedRootBookmarkId = String(move.id || normalizedRootBookmarkId || "");
                }
            }
        }

        if (touchedRoot) {
            _bmSyncManualOrderFromCache("all");
            _bmSyncManualOrderFromCache("bookmarks");
            _bmSyncManualOrderFromCache("folders");
            if (normalizedRootBookmarkId) {
                _bmLastMovedRootBookmarkId = normalizedRootBookmarkId;
                _bmNormalizeSectionsAfterRootBookmarkMove();
            }
        }
        _bmSetManualSortMode();

        _bmSkipNextColumnsRebalance = true;
        await loadBookmarks();
        requestAnimationFrame(() => {
            const scrollContainer = DD_getScrollContainer();
            if (scrollContainer) scrollContainer.scrollTop = scrollTop;
        });

        targetStack.push(entry);
        bmShowToast("bm_toast_moved", direction === "undo" ? "undo" : "redo");
        return true;
    } catch (error) {
        sourceStack.push(entry);
        loadBookmarks();
        return false;
    } finally {
        _bmHistoryBusy = false;
    }
}

function _bmGetHistoryMoveParams(snapshot) {
    const parentId = String(snapshot?.parentId || _bmRootParentId);
    const childIds = (_bmChildrenByParentId.get(parentId) || []).map(id => String(id));

    // Prioritize the recorded index directly as it represents the exact position at drag time.
    // This is precise and avoids sibling resolution bugs during multi-move sequence undo/redo (e.g., swapping adjacent items).
    if (snapshot && Number.isFinite(Number(snapshot.index))) {
        const idx = Number(snapshot.index);
        return {
            parentId,
            index: Math.max(0, Math.min(idx, childIds.length)),
        };
    }

    if (snapshot?.nextSiblingId) {
        const nextIndex = childIds.indexOf(String(snapshot.nextSiblingId));
        if (nextIndex >= 0) {
            return { parentId, index: nextIndex };
        }
    }

    const fallbackIndex = Number.isFinite(Number(snapshot?.index)) ? Number(snapshot.index) : childIds.length;
    return {
        parentId,
        index: Math.max(0, Math.min(fallbackIndex, childIds.length)),
    };
}

// Initialize sort buttons
updateSortButtons();
// Initialize filter buttons
document.addEventListener("DOMContentLoaded", () => { updateFilterButtons(); initFilterButtons(); initSidebarCtxMenu(); });

bookmarkButton.addEventListener("click", function (event) {
    event.preventDefault();
    event.stopPropagation();
    toggleBookmarkSidebar();
    bookmarkSearchClearButton.click();
});

bookmarkViewGrid.addEventListener("click", function () {
    if (!bookmarkGridCheckbox.checked) bookmarkGridCheckbox.click();
});

bookmarkViewList.addEventListener("click", function () {
    if (bookmarkGridCheckbox.checked) bookmarkGridCheckbox.click();
});

function _bmIsClickInsideFloatingUi(target) {
    if (!target) return false;

    const modalSelectors = [
        "#prompt-modal-container",
        "#prompt-modal-blur",
        "#editBookmarkModal",
        ".modal-content",
        "[id$='Modal']",
        ".ai-settings-modal",
        ".ai-modal-overlay",
        ".menuBar",
        ".menuCont",
        ".shadow-floating-panel",
        ".customColorPickerPopover",
        ".customColorPickerCard",
        ".shortcut-icon-popover",
        ".bookmark-ctx-menu",
        ".sc-context-menu",
        ".bm-action-toast",
        "#lePanel",
        "#leToast"
    ];

    return !!target.closest(modalSelectors.join(","));
}

document.addEventListener("click", function (event) {
    // Keep bookmarks open while the user is interacting with any floating panel/modal.
    if (_bmIsClickInsideFloatingUi(event.target)) {
        return;
    }

    // Don't close sidebar when clicking context menu buttons (they live outside sidebar in the DOM)
    if (bookmarkCtxMenu && bookmarkCtxMenu.contains(event.target)) return;
    if (typeof sidebarCtxMenu !== "undefined" && sidebarCtxMenu && sidebarCtxMenu.contains(event.target)) return;

    // Don't close sidebar when AI Tools settings modal or its overlay is clicked
    const aiModal = document.getElementById("aiToolsSettingsModal");
    const aiOverlay = document.getElementById("aiToolsSettingsOverlay");
    if (aiModal && aiModal.contains(event.target)) return;
    if (aiOverlay && aiOverlay.contains(event.target)) return;

    // Don't close sidebar when the Layout Editor panel or its toast is clicked
    const lePanel = document.getElementById("lePanel");
    const leToast = document.getElementById("leToast");
    if (lePanel && lePanel.contains(event.target)) return;
    if (leToast && leToast.contains(event.target)) return;

    if (
        !bookmarkSidebar.contains(event.target) &&
        !bookmarkButton.contains(event.target) &&
        !editBookmarkModal.contains(event.target) &&
        bookmarkSidebar.classList.contains("open")
    ) {
        toggleBookmarkSidebar(false);

        if (editBookmarkModal.style.display !== "none") {
            closeEditBookmarkModal();
        }
    }
});

// Search Functionality (debounced: one model walk per pause, not per keystroke)
let _bmSearchTimer = 0;
function _bmOnSearchInput() {
    clearTimeout(_bmSearchTimer);
    _bmSearchTimer = setTimeout(bmApplySearch, 120);
}
bookmarkSearch.addEventListener("input", _bmOnSearchInput);

// Sorting functionality
sortAlphabetical.addEventListener("click", function () {
    if (!this.classList.contains("active") || currentSortMethod === 'manual') {
        currentSortMethod = 'title';
        _bmLastExplicitSort = 'title';
        localStorage.setItem("bookmarkSortMethod", "title");
        _bmClearManualOrder();
        updateSortButtons();
        updateFilterButtons();
        loadBookmarks();
    }
});

sortTimeAdded.addEventListener("click", function () {
    if (!this.classList.contains("active") || currentSortMethod === 'manual') {
        currentSortMethod = 'date';
        _bmLastExplicitSort = 'date';
        localStorage.setItem("bookmarkSortMethod", "date");
        _bmClearManualOrder();
        updateSortButtons();
        updateFilterButtons();
        loadBookmarks();
    }
});

function updateSortButtons() {
    // In manual mode, keep the last explicitly chosen sort button highlighted
    // so the UI always shows which sort was last used.
    const displaySort = (currentSortMethod === 'manual') ? _bmLastExplicitSort : currentSortMethod;
    sortAlphabetical.classList.toggle("active", displaySort === 'title');
    sortTimeAdded.classList.toggle("active", displaySort === 'date');
}


bookmarkSearchClearButton.addEventListener("click", function () {
    bookmarkSearch.value = "";
    bookmarkSearch.dispatchEvent(new Event("input")); // Trigger input event to clear search results
});

function updateBookmarkUI(enabled) {
    bookmarksCheckbox.checked = enabled;
    bookmarkButton.style.display = enabled ? "flex" : "none";
    saveDisplayStatus("bookmarksDisplayStatus", enabled ? "flex" : "none");
    saveCheckboxState("bookmarksCheckboxState", bookmarksCheckbox);
}

async function verifyBookmarkPermission() {
    // Early exit for unsupported browsers
    let bookmarksPermission;
    if (isFirefox) bookmarksPermission = browser.permissions;
    else if (isChromiumBased) bookmarksPermission = chrome.permissions;

    if (!bookmarksPermission) {
        await alertPrompt(translations[currentLanguage]?.UnsupportedBrowser ||
            translations['en'].UnsupportedBrowser);
        updateBookmarkUI(false);
        return false;
    }

    // Firefox always has permission
    if (isFirefox) {
        updateBookmarkUI(true);
        return true;
    }

    // Chromium-based browsers
    // Opera doesn't have favicon permission yet
    const requiredPermissions = isOpera ? ["bookmarks"] : ["bookmarks", "favicon"];

    const hasPermission = await new Promise(resolve =>
        chrome.permissions.contains({ permissions: requiredPermissions }, resolve));

    if (!hasPermission) {
        const granted = await new Promise(resolve =>
            chrome.permissions.request({ permissions: requiredPermissions }, resolve));

        if (!granted) {
            updateBookmarkUI(false);
            return false;
        }
        bookmarksAPI = chrome.bookmarks; // Initialize if just granted
    }

    // Success case
    updateBookmarkUI(true);
    return true;
}

async function toggleBookmarkSidebar(forceOpen = null) {
    const isClosing = bookmarkSidebar.classList.contains("closing");
    const isOpen = bookmarkSidebar.classList.contains("open") && !isClosing;
    const wantsOpen = typeof forceOpen === "boolean" ? forceOpen : !isOpen;

    clearTimeout(toggleBookmarkSidebar._closeTimer);
    clearTimeout(toggleBookmarkSidebar._openTimer);

    if (!wantsOpen) {
        hideCtxMenu(true);
        hideSidebarCtxMenu(true);
        bookmarkSidebar.classList.add("closing");
        bookmarkSidebar.classList.remove("open");
        bookmarkButton.setAttribute("aria-expanded", "false");
        bookmarkButton.tabIndex = 0;
        bookmarkSidebar.inert = true;
        bookmarkButton.classList.remove("rotate");
        document.body.classList.remove("bm-sidebar-open");
        document.body.classList.add("bm-sidebar-closing");
        const closeDur = Math.max(_bmGetTransitionTotalMs(bookmarkSidebar), 180);
        toggleBookmarkSidebar._closeTimer = setTimeout(() => {
            bookmarkSidebar.classList.remove("closing");
            document.body.classList.remove("bm-sidebar-closing");
        }, closeDur + 20);
        return;
    }

    const hasPermission = await verifyBookmarkPermission();
    if (!hasPermission) {
        bookmarkSidebar.classList.remove("open", "closing");
        bookmarkButton.classList.remove("rotate");
        document.body.classList.remove("bm-sidebar-open", "bm-sidebar-closing");
        return;
    }

    document.body.classList.remove("bm-sidebar-closing");
    bookmarkSidebar.classList.remove("closing");
    bookmarkSidebar.classList.add("open");
    bookmarkSidebar.inert = false;
    bookmarkButton.setAttribute("aria-expanded", "true");
    bookmarkButton.tabIndex = -1;
    bookmarkButton.classList.add("rotate");
    document.body.classList.add("bm-sidebar-open");
    loadBookmarks();
    bookmarkSearch.focus({ preventScroll: true });
}

// ── Root parent ID: needed to move items back to root level ──
let _bmRootParentId = null;

// Function to load bookmarks
// Split a <ul> of bookmark <li> items into a two-column layout.
//
// ── Grid-view (not folders-only) ─────────────────────────────────────────
//   Uses a flat CSS grid (grid-template-columns: 1fr 1fr).
//   All items become DIRECT children of bm-folders-columns.
//   Sections are wrapped in bm-section-fullrow which uses grid-column: 1/-1
//   to span both columns — no counting, no look-ahead, no slot corruption.
//
//   bm-folders-columns  (display: grid; grid-template-columns: 1fr 1fr)
//     ├─ li  (col 1, auto-placed by grid)
//     ├─ li  (col 2, auto-placed by grid)
//     ├─ li  ...
//     ├─ div.bm-section-fullrow  (grid-column: 1/-1 → spans both cols)
//     ├─ li  ...
//
// ── Folders-only-view ────────────────────────────────────────────────────
//   Two bm-col divs as direct children (flex-direction: row in CSS).
//
//   bm-folders-columns  (display: flex; flex-direction: row)
//     ├─ bm-col bm-col-1
//     └─ bm-col bm-col-2
function bmCreateColumnsGroup(items) {
    const groupWrapper = document.createElement("div");
    groupWrapper.className = "bm-folders-columns";

    const col1 = document.createElement("div");
    col1.className = "bm-col bm-col-1";

    const col2 = document.createElement("div");
    col2.className = "bm-col bm-col-2";

    items.forEach((item, i) => {
        item.classList.remove("bm-odd-before-section-span");
        item.classList.remove("bm-solo-stretched");
        item.classList.remove("bm-odd-fullrow-item");
        if (i % 2 === 0) col1.appendChild(item);
        else col2.appendChild(item);
    });

    groupWrapper.appendChild(col1);
    groupWrapper.appendChild(col2);
    return groupWrapper;
}

function bmCreateOddFullRow(item) {
    if (!item) return null;
    item.classList.remove("bm-odd-before-section-span");
    item.classList.add("bm-odd-fullrow-item");

    const oddFullRow = document.createElement("div");
    oddFullRow.className = "bm-section-fullrow bm-odd-fullrow";
    oddFullRow.appendChild(item);
    return oddFullRow;
}

let _bmSkipNextColumnsRebalance = false;
let _bmLastMovedRootBookmarkId = null;

function bmScheduleColumnsRebalance(delay = 0) {
    clearTimeout(bmScheduleColumnsRebalance._timer);
    bmScheduleColumnsRebalance._timer = setTimeout(() => {
        if (_bmSkipNextColumnsRebalance) {
            _bmSkipNextColumnsRebalance = false;
            return;
        }
        requestAnimationFrame(() => bmRebalanceFoldersColumns());
    }, delay);
}

function bmHandleFolderToggleLayout(subList) {
    const shouldRebalanceColumns = bookmarkList.classList.contains("folders-only-view");
    if (!shouldRebalanceColumns) return;
    // Avoid post-open delayed rebalance on toggle, because it causes a visible
    // height jump a fraction of a second after folders open.
}

function _bmReadFolderToggleVar(subList, name, fallback = "0px") {
    if (!subList) return fallback;
    const value = getComputedStyle(subList).getPropertyValue(name).trim();
    return value || fallback;
}

function _bmMeasureFolderState(folderItem, subList, shouldOpen, openSpacing) {
    const prevOpen = folderItem.classList.contains("open");
    const prevFolderMaxHeight = folderItem.style.maxHeight;
    const prevFolderOverflow = folderItem.style.overflow;
    const prevSubMaxHeight = subList.style.maxHeight;
    const prevSubOpacity = subList.style.opacity;
    const prevSubMarginTop = subList.style.marginTop;
    const prevSubPaddingTop = subList.style.paddingTop;
    const prevSubBorderTopWidth = subList.style.borderTopWidth;
    const prevSubOverflow = subList.style.overflow;

    folderItem.classList.toggle("open", shouldOpen);
    folderItem.style.maxHeight = "none";
    folderItem.style.overflow = shouldOpen ? "visible" : "hidden";

    subList.style.overflow = "hidden";
    subList.style.maxHeight = shouldOpen ? "none" : "0px";
    subList.style.opacity = shouldOpen ? "1" : "0";
    subList.style.marginTop = shouldOpen ? openSpacing.marginTop : "0px";
    subList.style.paddingTop = shouldOpen ? openSpacing.paddingTop : "0px";
    subList.style.borderTopWidth = shouldOpen ? openSpacing.borderTopWidth : "0px";

    void folderItem.offsetHeight;

    const folderHeight = Math.max(folderItem.getBoundingClientRect().height, 0);
    const subHeight = Math.max(subList.getBoundingClientRect().height, 0);

    folderItem.classList.toggle("open", prevOpen);
    folderItem.style.maxHeight = prevFolderMaxHeight;
    folderItem.style.overflow = prevFolderOverflow;
    subList.style.maxHeight = prevSubMaxHeight;
    subList.style.opacity = prevSubOpacity;
    subList.style.marginTop = prevSubMarginTop;
    subList.style.paddingTop = prevSubPaddingTop;
    subList.style.borderTopWidth = prevSubBorderTopWidth;
    subList.style.overflow = prevSubOverflow;

    return { folderHeight, subHeight };
}

function bmAnimateFolderToggle(folderItem, subList, shouldOpen, onSettled) {
    if (!folderItem || !subList) {
        folderItem?.classList.toggle("open", shouldOpen);
        if (typeof onSettled === "function") onSettled();
        return;
    }

    if (folderItem._bmFolderToggleCleanup) {
        folderItem._bmFolderToggleCleanup(true);
    }

    const isOpen = folderItem.classList.contains("open");
    if (isOpen === shouldOpen) {
        if (typeof onSettled === "function") onSettled();
        return;
    }

    folderItem.classList.remove("bm-folder-opening", "bm-folder-closing");
    folderItem.classList.add("bm-folder-animating");
    folderItem.classList.add(shouldOpen ? "bm-folder-opening" : "bm-folder-closing");

    if (shouldOpen) {
        folderItem.classList.add("open");
    } else {
        folderItem.classList.remove("open");
    }

    const cleanup = () => {
        folderItem.classList.remove("bm-folder-animating", "bm-folder-opening", "bm-folder-closing");
        bmRefreshDiscovery();
        folderItem._bmFolderToggleCleanup = null;
        if (typeof onSettled === "function") onSettled();
    };

    folderItem._bmFolderToggleCleanup = cleanup;
    const totalMs = shouldOpen ? 300 : 250;
    setTimeout(cleanup, totalMs);
    return totalMs;
}

function splitIntoIndependentColumns(ul) {
    const outerWrapper = document.createElement("div");
    outerWrapper.className = "bm-folders-outer";

    // ── Build segments separated by section dividers ──────────────────────
    const segments = [];
    let currentItems = [];
    for (const child of Array.from(ul.children)) {
        if (child.classList.contains("bm-section-divider")) {
            segments.push({ items: currentItems, section: child });
            currentItems = [];
        } else {
            currentItems.push(child);
        }
    }
    segments.push({ items: currentItems, section: null });

    // ── Enforce even count before each section ─────────────────────────────
    for (let i = 0; i < segments.length - 1; i++) {
        if (segments[i].items.length % 2 !== 0) {
            for (let j = i + 1; j < segments.length; j++) {
                if (segments[j].items.length > 0) {
                    segments[i].items.push(segments[j].items.shift());
                    break;
                }
            }
        }
    }

    // ── Build DOM from segments ─────────────────────────────────
    for (const { items, section } of segments) {
        if (items.length > 0) {
            const evenItems = items.length % 2 === 0 ? items : items.slice(0, -1);
            const oddItem  = items.length % 2 !== 0  ? items[items.length - 1] : null;
            if (evenItems.length > 0) outerWrapper.appendChild(bmCreateColumnsGroup(evenItems));
            if (oddItem) {
                const oddFullRow = bmCreateOddFullRow(oddItem);
                if (oddFullRow) outerWrapper.appendChild(oddFullRow);
            }
        }
        if (section) {
            const fullRow = document.createElement("div");
            fullRow.className = "bm-section-fullrow";
            fullRow.appendChild(section);
            outerWrapper.appendChild(fullRow);
        }
    }

    _bmNormalizeOddItemsBeforeSections(outerWrapper);
    return outerWrapper;
}

function _bmRebuildFoldersOnlyOuterLayout(root = bookmarkList.querySelector(".bm-folders-outer")) {
    if (!root || (!bookmarkList.classList.contains("grid-view") && !bookmarkList.classList.contains("folders-only-view"))) return root;

    const segments = [];
    const rebuiltChildren = [];
    let currentItems = [];
    const measuredHeights = new Map();

    const resetItemLayoutClasses = (item) => {
        if (!item) return;
        item.classList.remove("bm-odd-before-section-span");
        item.classList.remove("bm-solo-stretched");
        item.classList.remove("bm-odd-fullrow-item");
        item.classList.remove("bm-section-span-2");
    };

    const getMeasuredHeight = (item) => {
        if (!item) return 0;
        if (!measuredHeights.has(item)) {
            const rect = item.getBoundingClientRect?.();
            const height = Math.ceil(rect?.height || item.offsetHeight || 48);
            measuredHeights.set(item, height + 8);
        }
        return measuredHeights.get(item) || 0;
    };

    const getSegmentBalance = (items) => {
        let h1 = 0;
        let h2 = 0;
        items.forEach((item) => {
            const height = getMeasuredHeight(item);
            if (h1 <= h2) h1 += height;
            else h2 += height;
        });
        return { h1, h2, gap: Math.abs(h1 - h2) };
    };

    const pushSegment = (sectionRow = null) => {
        segments.push({ items: currentItems, sectionRow });
        currentItems = [];
    };

    Array.from(root.children).forEach((child) => {
        if (child.classList?.contains("bm-folders-columns")) {
            currentItems.push(..._bmGetInterleavedColumnItems(child));
            return;
        }

        if (!child.classList?.contains("bm-section-fullrow")) return;

        const sectionDivider = child.querySelector(":scope > li.bm-section-divider");
        if (sectionDivider) {
            pushSegment(child);
            return;
        }

        const fullRowItem = child.querySelector(":scope > li[data-id]");
        if (fullRowItem && !fullRowItem.classList.contains("bm-section-divider")) {
            resetItemLayoutClasses(fullRowItem);
            currentItems.push(fullRowItem);
        }
    });

    pushSegment();

    for (let i = 0; i < segments.length - 1; i++) {
        for (let j = i + 1; j < segments.length; ) {
            const currentSegment = segments[i];
            const donorSegment = segments[j];
            const donorItem = donorSegment.items[0];
            if (!donorItem) {
                j++;
                continue;
            }

            const needsEvenCount = currentSegment.items.length % 2 !== 0;
            const { gap } = getSegmentBalance(currentSegment.items);
            const donorHeight = getMeasuredHeight(donorItem);
            const canFitGap = gap >= Math.max(24, donorHeight - 10);

            if (!needsEvenCount && !canFitGap) break;

            currentSegment.items.push(donorSegment.items.shift());

            if (!donorSegment.items.length) {
                j++;
                continue;
            }
        }
    }

    segments.forEach(({ items, sectionRow }) => {
        if (items.length) {
            items.forEach(resetItemLayoutClasses);
            const evenItems = items.length % 2 === 0 ? items : items.slice(0, -1);
            const oddItem = items.length % 2 !== 0 ? items[items.length - 1] : null;

            if (evenItems.length) rebuiltChildren.push(bmCreateColumnsGroup(evenItems));
            if (oddItem) {
                const oddFullRow = bmCreateOddFullRow(oddItem);
                if (oddFullRow) rebuiltChildren.push(oddFullRow);
            }
        }

        if (sectionRow) rebuiltChildren.push(sectionRow);
    });

    if (!rebuiltChildren.length) return root;

    root.replaceChildren(...rebuiltChildren);
    _bmNormalizeOddItemsBeforeSections(root);
    return root;
}

function _bmRebalanceSectionedGridLayout(root = bookmarkList.querySelector(".bm-folders-outer")) {
    if (!root) return;
    if (!bookmarkList.classList.contains("grid-view")) return;
    if (bookmarkList.classList.contains("folders-only-view")) {
        _bmRebuildFoldersOnlyOuterLayout(root);
        return;
    }

    const children = Array.from(root.children);
    if (!children.some(child => child.classList?.contains("bm-section-fullrow"))) return;

    const segments = [];
    let currentItems = [];

    const pushCurrentItems = () => {
        segments.push({ items: currentItems, sectionRow: null });
        currentItems = [];
    };

    for (const child of children) {
        if (child.classList?.contains("bm-folders-columns")) {
            const hasCols = !!child.querySelector(":scope > .bm-col");
            currentItems.push(...(hasCols ? _bmGetInterleavedColumnItems(child) : _bmGetDirectWrapperDisplayItems(child)));
            continue;
        }

        if (child.classList?.contains("bm-section-fullrow")) {
            const sectionDivider = child.querySelector(":scope > li.bm-section-divider");
            if (sectionDivider) {
                segments.push({ items: currentItems, sectionRow: child });
                currentItems = [];
                continue;
            }

            const fullRowItem = child.querySelector(":scope > li[data-id]");
            if (fullRowItem) currentItems.push(fullRowItem);
        }
    }

    pushCurrentItems();

    for (let i = 0; i < segments.length - 1; i++) {
        if (segments[i].sectionRow && segments[i].items.length % 2 !== 0) {
            for (let j = i + 1; j < segments.length; j++) {
                if (segments[j].items.length > 0) {
                    segments[i].items.push(segments[j].items.shift());
                    break;
                }
            }
        }
    }

    const frag = document.createDocumentFragment();
    segments.forEach((segment) => {
        if (segment.items.length) {
            frag.appendChild(bmCreateColumnsGroup(segment.items));
        }
        if (segment.sectionRow) {
            frag.appendChild(segment.sectionRow);
        }
    });

    root.replaceChildren(frag);
    const rows = Array.from(root.children);
    for (const row of rows) {
        if (!row.classList?.contains("bm-section-fullrow")) continue;
        const sectionDivider = row.querySelector(":scope > li.bm-section-divider");
        if (!sectionDivider) continue;

        const prevWrapper = row.previousElementSibling;
        if (!prevWrapper?.classList?.contains("bm-folders-columns")) continue;

        const getWrapperItems = (wrapper) => {
            if (!wrapper) return [];
            const hasCols = !!wrapper.querySelector(":scope > .bm-col");
            return hasCols ? _bmGetInterleavedColumnItems(wrapper) : _bmGetDirectWrapperDisplayItems(wrapper);
        };
        const appendItemToWrapper = (wrapper, item) => {
            if (!wrapper || !item) return;
            const col1 = wrapper.querySelector(":scope > .bm-col-1");
            const col2 = wrapper.querySelector(":scope > .bm-col-2");
            if (!col1 || !col2) {
                wrapper.appendChild(item);
                return;
            }

            const col1Count = col1.querySelectorAll(":scope > li[data-id]").length;
            const col2Count = col2.querySelectorAll(":scope > li[data-id]").length;
            if (col1Count <= col2Count) col1.appendChild(item);
            else col2.appendChild(item);
        };

        const prevItems = getWrapperItems(prevWrapper);
        if (prevItems.length % 2 === 0) continue;

        let donorWrapper = row.nextElementSibling;
        let donorItem = null;
        while (donorWrapper) {
            if (donorWrapper.classList?.contains("bm-folders-columns")) {
                const donorItems = getWrapperItems(donorWrapper);
                donorItem = donorItems.find(item => String(item?.dataset?.id || "") !== String(_bmLastMovedRootBookmarkId || ""))
                    || donorItems[0]
                    || null;
                if (donorItem) break;
            }
            donorWrapper = donorWrapper.nextElementSibling;
        }

        if (donorItem) {
            appendItemToWrapper(prevWrapper, donorItem);
            if (getWrapperItems(donorWrapper).length === 0) {
                donorWrapper.remove();
            }
        }
    }
    _bmNormalizeOddItemsBeforeSections(root);
    _bmLastMovedRootBookmarkId = null;
}

function splitIntoColumns(ul) {
    return splitIntoIndependentColumns(ul);



    // ── Folders-only-view: two real independent bm-col divs ──
    // Items distributed alternately: even → col-1, odd → col-2.
    // Each column is an independent flex container so opening a folder
    // in col-1 only pushes col-1 items down — col-2 is completely untouched.
    if (bookmarkList.classList.contains("folders-only-view") || bookmarkList.classList.contains("grid-view")) {
        const outerWrapper = document.createElement("div");
        outerWrapper.className = "bm-folders-outer";

        const items = Array.from(ul.children);
        let currentGroupItems = [];

        const flushGroup = () => {
            if (currentGroupItems.length === 0) return;
            const groupWrapper = document.createElement("div");
            groupWrapper.className = "bm-folders-columns";

            const col1 = document.createElement("div");
            col1.className = "bm-col bm-col-1";
            col1.style.cssText = "display:inline-flex !important;flex-direction:column;vertical-align:top;width:calc(50% - 4px);box-sizing:border-box;height:auto;min-height:0;align-self:unset;margin-right:8px;";
            const col2 = document.createElement("div");
            col2.className = "bm-col bm-col-2";
            col2.style.cssText = "display:inline-flex !important;flex-direction:column;vertical-align:top;width:calc(50% - 4px);box-sizing:border-box;height:auto;min-height:0;align-self:unset;";

            currentGroupItems.forEach((item, i) => {
                if (i % 2 === 0) col1.appendChild(item);
                else col2.appendChild(item);
            });

            groupWrapper.appendChild(col1);
            groupWrapper.appendChild(col2);
            outerWrapper.appendChild(groupWrapper);
            currentGroupItems = [];
        };

        for (const item of items) {
            if (item.classList.contains("bm-section-divider")) {
                flushGroup();
                const fullRow = document.createElement("div");
                fullRow.className = "bm-section-fullrow";
                fullRow.appendChild(item);
                outerWrapper.appendChild(fullRow);
            } else {
                currentGroupItems.push(item);
            }
        }
        flushGroup();

        return outerWrapper;
    }

    const wrapper = document.createElement("div");
    wrapper.className = "bm-folders-columns";

    // ── Grid-view: flat flex-wrap — items as direct children ──
    // Sections get a bm-section-fullrow wrapper (flex-basis:100%) to span both columns.
    // When the item count before a section is ODD, insert a bm-grid-spacer to fill the
    // empty right-column slot — this removes the visual gap above the section.
    let itemCount = 0;
    let prevItem = null;
    Array.from(ul.children).forEach(item => {
        if (item.classList.contains("bm-section-divider")) {
            itemCount = 0;
            prevItem = null;
            const fullRow = document.createElement("div");
            fullRow.className = "bm-section-fullrow";
            fullRow.appendChild(item);
            wrapper.appendChild(fullRow);
        } else {
            // Remove solo class if it had it before (in case of re-render)
            item.classList.remove("bm-solo-stretched");
            wrapper.appendChild(item);
            prevItem = item;
            itemCount++;
        }
    });

    return wrapper;
}



// ═══════════════════════════════════════════════════
// ─── Solo-item stretching after folder toggle ───
// ═══════════════════════════════════════════════════
// When a folder is opened/closed in grid-view, recalculate which items should
// stretch to full width (solo items in an odd column position before a full-width element).
function bmRefreshSoloItems() {
    bookmarkList
        .querySelectorAll(".bm-solo-stretched")
        .forEach(item => item.classList.remove("bm-solo-stretched"));
    if (!bookmarkList.classList.contains("grid-view") || bookmarkList.classList.contains("folders-only-view")) return;
    const wrapper = bookmarkList.querySelector(".bm-folders-columns");
    if (!wrapper) return;

    let count = 0;
    let prevNormalItem = null;

    Array.from(wrapper.children).forEach(item => {
        if (item.classList.contains("bm-drop-indicator")) return;

        // Full-width items: section fullrows only.
        // Open folders stay in their own column (50% width) — do NOT treat them as full-width,
        // otherwise the item above gets bm-solo-stretched and the folder jumps to the left column.
        const isFullWidth = item.classList.contains("bm-section-fullrow");

        if (isFullWidth) {
            if (count % 2 !== 0 && prevNormalItem) {
                prevNormalItem.classList.add("bm-solo-stretched");
            }
            count = 0;
            prevNormalItem = null;
        } else {
            item.classList.remove("bm-solo-stretched");
            count++;
            prevNormalItem = item;
        }
    });
}

// ═══════════════════════════════════════════════════
// ─── Rebalance folders-only columns after open/close ───
// ═══════════════════════════════════════════════════
// When a folder opens/closes in folders-only-view, the two columns can become
// unbalanced (one very tall, the other very short with empty space beside it).
// This function redistributes items between col-1 and col-2 using a greedy
// height-balance algorithm so the two columns stay roughly equal in height.
function bmRebalanceFoldersColumns() {
    if (!bookmarkList.classList.contains("folders-only-view") && !bookmarkList.classList.contains("grid-view")) return;

    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    const wrappers = outerWrapper
        ? Array.from(outerWrapper.children).filter(child => child.classList?.contains("bm-folders-columns"))
        : Array.from(bookmarkList.querySelectorAll(".bm-folders-columns"));

    for (const wrapper of wrappers) {
        const col1 = wrapper.querySelector(":scope > .bm-col-1");
        const col2 = wrapper.querySelector(":scope > .bm-col-2");
        if (!col1 || !col2) continue;

        // Collect items from both columns in their current interleaved visual order
        const c1 = Array.from(col1.children);
        const c2 = Array.from(col2.children);
        const allItems = [];
        const maxLen = Math.max(c1.length, c2.length);
        for (let i = 0; i < maxLen; i++) {
            if (c1[i]) allItems.push(c1[i]);
            if (c2[i]) allItems.push(c2[i]);
        }

        // Measure ACTUAL rendered heights now (animation is done)
        const heights = allItems.map(el => el.getBoundingClientRect().height || el.offsetHeight || 48);

        // Detach all — event listeners stay attached on detached nodes
        allItems.forEach(el => el.remove());

        const isGridNoFolders = bookmarkList.classList.contains("grid-view") && !bookmarkList.classList.contains("folders-only-view");
        const isManualSorting = currentSortMethod === "manual";
        if (isGridNoFolders || isManualSorting) {
            // Grid bookmarks and manually-sorted folders should stay row-packed: if one slot becomes empty
            // we cascade later items upward left/right in visual order.
            allItems.forEach((item, i) => {
                if (i % 2 === 0) col1.appendChild(item);
                else col2.appendChild(item);
            });
        } else {
            // Folders-only view keeps independent masonry-like balancing.
            let h1 = 0, h2 = 0;
            for (let i = 0; i < allItems.length; i++) {
                if (h1 <= h2) {
                    col1.appendChild(allItems[i]);
                    h1 += heights[i];
                } else {
                    col2.appendChild(allItems[i]);
                    h2 += heights[i];
                }
            }
        }

        // ── v16 NUCLEAR JS FIX ──
        // Re-stamp the full inline style after rebalance so no browser quirk
        // can re-introduce a shared height. Explicitly clear height to 'auto'.
        [col1, col2].forEach((col, i) => {
            col.style.cssText = [
                "display:inline-flex !important",
                "flex-direction:column",
                "vertical-align:top",
                "width:calc(50% - 4px)",
                "box-sizing:border-box",
                "height:auto",
                "min-height:0",
                "align-self:unset",
                i === 0 ? "margin-right:8px" : ""
            ].filter(Boolean).join(";");
        });
    }
}

// ═══════════════════════════════════════════════════
// ─── Sections System (visual grouping labels) ───
// ═══════════════════════════════════════════════════
// Sections are NOT Chrome bookmarks. They are stored in localStorage and rendered
// as full-width visual dividers between items in the grid/list.
const _bmSectionsKey = "bookmarkSections_v1";

function _bmGetSections() {
    try { return JSON.parse(localStorage.getItem(_bmSectionsKey) || "[]"); } catch(e) { return []; }
}
function _bmSaveSections(sections) {
    localStorage.setItem(_bmSectionsKey, JSON.stringify(sections));
}

function _bmNormalizeSectionIndexParity(index, bookmarkCount, minIndex = 0, preferHigher = true) {
    const safeBookmarkCount = Math.max(0, Number(bookmarkCount) || 0);
    const safeMinIndex = Math.max(0, Math.min(safeBookmarkCount, Number(minIndex) || 0));
    let nextIndex = Math.max(safeMinIndex, Math.min(safeBookmarkCount, Math.round(Number(index) || 0)));

    if (nextIndex % 2 === 0) return nextIndex;

    const higherIndex = nextIndex + 1;
    const lowerIndex = nextIndex - 1;

    if (preferHigher && higherIndex <= safeBookmarkCount) return higherIndex;
    if (lowerIndex >= safeMinIndex) return lowerIndex;
    if (higherIndex <= safeBookmarkCount) return higherIndex;
    return safeMinIndex;
}

function _bmNormalizeSectionsForEvenSlots(sections, bookmarkItems, preferHigher = true) {
    if (!Array.isArray(sections) || !sections.length) {
        return { sections: Array.isArray(sections) ? sections : [], changed: false };
    }

    const bookmarkCount = Array.isArray(bookmarkItems) ? bookmarkItems.length : 0;
    let minIndex = 0;
    let changed = false;

    const normalized = sections.map((sec) => {
        const originalIndex = Math.max(0, Math.min(bookmarkCount, Math.round(Number(sec?.bookmarkIndex) || 0)));
        const bookmarkIndex = _bmNormalizeSectionIndexParity(originalIndex, bookmarkCount, minIndex, preferHigher);
        const afterId = bookmarkIndex > 0 ? String(bookmarkItems[bookmarkIndex - 1]?.id || "start") : "start";

        if (bookmarkIndex !== originalIndex || String(sec?.afterId || "start") !== afterId) {
            changed = true;
        }

        minIndex = bookmarkIndex;
        return { ...sec, bookmarkIndex, afterId };
    });

    return { sections: normalized, changed };
}

function _bmGetTopLevelSectionAnchorItems() {
    return _bmGetAllDisplayOrderLIs().filter(li =>
        li &&
        li.dataset?.id &&
        !li.classList.contains("bm-section-divider") &&
        !li.classList.contains("bm-drop-indicator") &&
        li.style.display !== "none" &&
        !li.parentElement?.closest("li.folder")
    );
}

function _bmResolveSectionAfterId(afterBookmarkId) {
    const allItems = _bmGetAllDisplayOrderLIs().filter(li =>
        li &&
        li.dataset?.id &&
        !li.classList.contains("bm-section-divider") &&
        !li.classList.contains("bm-drop-indicator") &&
        li.style.display !== "none"
    );
    const bookmarkItems = allItems.filter(li => !li.classList.contains("folder"));

    if (!bookmarkItems.length) return null;
    if (!afterBookmarkId || afterBookmarkId === "start") return "start";

    const normalizedId = String(afterBookmarkId);
    if (bookmarkItems.some(li => String(li.dataset.id) === normalizedId)) {
        return normalizedId;
    }

    let lastBookmarkId = "start";
    for (const li of allItems) {
        if (!li.dataset?.id) continue;
        if (String(li.dataset.id) === normalizedId) return lastBookmarkId;
        if (!li.classList.contains("folder")) lastBookmarkId = li.dataset.id;
    }

    return lastBookmarkId;
}

function _bmResolveSectionBookmarkIndex(afterBookmarkId) {
    const resolvedAfterId = _bmResolveSectionAfterId(afterBookmarkId);
    if (resolvedAfterId === null) return null;
    if (resolvedAfterId === "start") return 0;

    const bookmarkItems = _bmGetTopLevelSectionAnchorItems();
    const anchorIndex = bookmarkItems.findIndex(li => String(li.dataset.id) === String(resolvedAfterId));
    return anchorIndex >= 0 ? anchorIndex + 1 : bookmarkItems.length;
}

function _bmBuildSectionDividerNode(sec) {
    return {
        _isSectionDivider: true,
        id: sec.id,
        title: sec.title,
        color: sec.color || "blue",
        align: sec.align || "left",
        fontSize: sec.fontSize,
        bold: sec.bold,
        italic: sec.italic,
        upper: sec.upper,
        letter: sec.letter,
        wide: true,
    };
}

function _bmDarkenRgbChannels(r, g, b, factor = 0.72) {
    return `rgb(${Math.max(0, Math.round(r * factor))}, ${Math.max(0, Math.round(g * factor))}, ${Math.max(0, Math.round(b * factor))})`;
}

function _bmDarkenHexColor(hex, factor = 0.72) {
    if (typeof hex !== "string") return "";
    const normalized = hex.trim();
    const match = normalized.match(/^#([0-9a-f]{6})$/i);
    if (!match) return "";
    const raw = match[1];
    return _bmDarkenRgbChannels(
        parseInt(raw.slice(0, 2), 16),
        parseInt(raw.slice(2, 4), 16),
        parseInt(raw.slice(4, 6), 16),
        factor
    );
}

function _bmGetSectionInsertIndex(nodes, sectionOrAfterId) {
    let bookmarkIndex = null;
    let afterId = "start";

    if (sectionOrAfterId && typeof sectionOrAfterId === "object") {
        afterId = sectionOrAfterId.afterId || "start";
        const rawBookmarkIndex = Number(sectionOrAfterId.bookmarkIndex);
        if (Number.isFinite(rawBookmarkIndex)) bookmarkIndex = Math.max(0, Math.round(rawBookmarkIndex));
    } else {
        afterId = sectionOrAfterId || "start";
    }

    if (bookmarkIndex === null) {
        if (afterId && afterId !== "start") {
            const anchorIndex = nodes.findIndex(node => node?.dataset?.id === String(afterId));
            if (anchorIndex >= 0) return anchorIndex + 1;
        }
        const firstBookmarkIndex = nodes.findIndex(node => node?.dataset?.url || node?.url);
        return firstBookmarkIndex >= 0 ? firstBookmarkIndex : nodes.length;
    }

    if (bookmarkIndex <= 0) {
        const firstBookmarkIndex = nodes.findIndex(node => node?.dataset?.url || node?.url);
        return firstBookmarkIndex >= 0 ? firstBookmarkIndex : nodes.length;
    }

    let seenBookmarks = 0;
    for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        const isBookmark = !!(node?.dataset?.url || node?.url);
        if (!isBookmark) {
            if (seenBookmarks >= bookmarkIndex) return i;
            continue;
        }
        seenBookmarks++;
        if (seenBookmarks >= bookmarkIndex) {
            let j = i + 1;
            while (j < nodes.length) {
                const nextNode = nodes[j];
                if (nextNode?.dataset?.url || nextNode?.url) break;
                return j;
            }
            return i + 1;
        }
    }

    return nodes.length;
}

function _bmAddSectionDirect(section) {
    const sections = _bmGetSections();
    if (!sections.some(s => s.id === section.id)) {
        sections.push(section);
        _bmSaveSections(sections);
    }
}
function _bmDeleteSectionDirect(sectionId) {
    const sections = _bmGetSections().filter(s => s.id !== sectionId);
    _bmSaveSections(sections);
}

function _bmAddSection(title, afterBookmarkId, color) {
    const resolvedAfterId = _bmResolveSectionAfterId(afterBookmarkId);
    if (resolvedAfterId === null) return;
    const bookmarkIndex = _bmResolveSectionBookmarkIndex(resolvedAfterId);
    const sections = _bmGetSections();
    const id = "section_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    const section = { id, title, afterId: resolvedAfterId, bookmarkIndex, color: color || "blue" };
    sections.push(section);
    _bmSaveSections(sections);

    _bmPushHistoryEntry({
        kind: "section-add",
        section: section
    });

    loadBookmarks();
    bmShowToast("bm_toast_added", "add");
}
function _bmDeleteSection(sectionId) {
    const section = _bmGetSections().find(s => s.id === sectionId);
    if (!section) return;

    _bmDeleteSectionDirect(sectionId);

    _bmPushHistoryEntry({
        kind: "section-delete",
        section: section
    });

    loadBookmarks();
    bmShowToast("bm_toast_deleted", "delete");
}
function _bmRenameSectionById(sectionId, newTitle) {
    const sections = _bmGetSections().map(s => s.id === sectionId ? {...s, title: newTitle} : s);
    _bmSaveSections(sections);
    loadBookmarks();
}
function _bmUpdateSectionAfterId(sectionId, newAfterId) {
    const resolvedAfterId = _bmResolveSectionAfterId(newAfterId);
    if (resolvedAfterId === null) return;
    const bookmarkIndex = _bmResolveSectionBookmarkIndex(resolvedAfterId);
    const sections = _bmGetSections().map(s => s.id === sectionId ? {...s, afterId: resolvedAfterId, bookmarkIndex} : s);
    _bmSaveSections(sections);
}

function _bmCommitSectionMove(sectionId, newAfterId) {
    if (!sectionId) return;
    const currentSection = _bmGetSections().find(s => s.id === sectionId) || null;
    const currentAfterId = String(currentSection?.afterId || "start");
    const resolvedAfterId = String(_bmResolveSectionAfterId(newAfterId) || "start");

    if (currentAfterId !== resolvedAfterId) {
        _bmUpdateSectionAfterId(sectionId, resolvedAfterId);

        _bmPushHistoryEntry({
            kind: "section-move",
            sectionId: sectionId,
            fromAfterId: currentAfterId,
            toAfterId: resolvedAfterId
        });

        const movedLocally = _bmApplySectionMoveLocally(sectionId);
        const reloadPromise = movedLocally ? Promise.resolve() : Promise.resolve(loadBookmarks());
        bmShowToast("bm_toast_moved", "move");
        return reloadPromise;
    }
    return Promise.resolve();
}

function _bmApplySectionMoveLocally(sectionId) {
    if (!sectionId || !bookmarkList) return false;

    const sectionData = _bmGetSections().find(s => s.id === sectionId);
    if (!sectionData) return false;

    const { root, mode, nodes } = _bmFlattenTopLevelDisplayNodes();
    if (!root || !Array.isArray(nodes)) return false;

    const sectionNode = _bmRenderSectionNode(_bmBuildSectionDividerNode(sectionData));
    const filteredNodes = nodes.filter(node =>
        !(node?.classList?.contains("bm-section-divider") && String(node.dataset?.sectionId || "") === String(sectionId))
    );

    const insertIndex = _bmGetSectionInsertIndex(filteredNodes, sectionData);
    filteredNodes.splice(insertIndex, 0, sectionNode);
    _bmRenderSectionPreviewNodes(root, mode, filteredNodes);
    bmRefreshSoloItems();

    if (bookmarkList.classList.contains("grid-view")) {
        requestAnimationFrame(() => bmRebalanceFoldersColumns());
    }

    return true;
}

function _bmGetInterleavedColumnItems(columnsWrapper) {
    if (!columnsWrapper) return [];
    const c1 = Array.from(columnsWrapper.querySelectorAll(":scope > .bm-col-1 > li[data-id]"))
        .filter(li => !li.classList.contains("bm-section-divider"));
    const c2 = Array.from(columnsWrapper.querySelectorAll(":scope > .bm-col-2 > li[data-id]"))
        .filter(li => !li.classList.contains("bm-section-divider"));
    const items = [];
    const maxLen = Math.max(c1.length, c2.length);
    for (let k = 0; k < maxLen; k++) {
        if (k < c1.length) items.push(c1[k]);
        if (k < c2.length) items.push(c2[k]);
    }
    return items;
}

function _bmGetDirectWrapperDisplayItems(wrapper) {
    if (!wrapper) return [];
    return Array.from(wrapper.querySelectorAll(":scope > li[data-id], :scope > .bm-section-fullrow > li[data-id]"))
        .filter(li => !li.classList.contains("bm-section-divider"));
}

function _bmGetOuterWrapperDisplayItems(outerWrapper) {
    if (!outerWrapper) return [];
    const items = [];
    Array.from(outerWrapper.children).forEach(child => {
        if (child.classList?.contains("bm-folders-columns")) {
            const hasCols = !!child.querySelector(":scope > .bm-col");
            items.push(...(hasCols ? _bmGetInterleavedColumnItems(child) : _bmGetDirectWrapperDisplayItems(child)));
            return;
        }
        if (child.classList?.contains("bm-section-fullrow")) {
            const fullRowItem = child.querySelector(":scope > li[data-id]");
            if (fullRowItem && !fullRowItem.classList.contains("bm-section-divider")) {
                items.push(fullRowItem);
            }
        }
    });
    return items;
}

function _bmNormalizeOddItemsBeforeSections(root) {
    if (!root) return;

    root.querySelectorAll(".bm-odd-before-section-span").forEach(item => {
        item.classList.remove("bm-odd-before-section-span");
    });
    root.querySelectorAll(".bm-section-span-2").forEach(item => {
        item.classList.remove("bm-section-span-2");
    });

    root.querySelectorAll(".bm-odd-fullrow-item").forEach(item => {
        item.classList.remove("bm-odd-fullrow-item");
    });

    const rows = Array.from(root.children);
    for (const row of rows) {
        if (!row.classList?.contains("bm-section-fullrow")) continue;

        const sectionDivider = row.querySelector(":scope > li.bm-section-divider");
        if (!sectionDivider) {
            const oddItem = row.querySelector(":scope > li[data-id]");
            if (oddItem) oddItem.classList.add("bm-odd-fullrow-item");
            continue;
        }

        const prev = row.previousElementSibling;
        if (!prev) continue;

        if (prev.classList?.contains("bm-section-fullrow")) {
            const oddItem = prev.querySelector(":scope > li[data-id]");
            if (oddItem) oddItem.classList.add("bm-odd-fullrow-item");
            continue;
        }

        if (!prev.classList?.contains("bm-folders-columns")) continue;

        const hasCols = !!prev.querySelector(":scope > .bm-col");
        const orderedItems = hasCols
            ? _bmGetInterleavedColumnItems(prev)
            : _bmGetDirectWrapperDisplayItems(prev);
        if (!orderedItems.length || orderedItems.length % 2 === 0) continue;

        const stretchedItem = orderedItems[orderedItems.length - 1];
        if (!stretchedItem) continue;

        if (!hasCols) {
            stretchedItem.classList.add("bm-odd-fullrow-item", "bm-section-span-2");
            continue;
        }

        stretchedItem.remove();
        const oddFullRow = bmCreateOddFullRow(stretchedItem);
        if (!oddFullRow) continue;

        const hasRemainingItems = hasCols
            ? !!prev.querySelector(":scope > .bm-col > li[data-id]")
            : !!prev.querySelector(":scope > li[data-id]");
        if (!hasRemainingItems) {
            prev.remove();
        }

        root.insertBefore(oddFullRow, row);
    }
}

// Return all real bookmark LIs in their visual display order (grid or list).
function _bmGetAllDisplayOrderLIs() {
    // Folders-only-view may use bm-folders-outer with multiple bm-folders-columns groups
    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    if (outerWrapper) {
        return _bmGetOuterWrapperDisplayItems(outerWrapper);
    }
    const columnsWrapper = bookmarkList.querySelector(".bm-folders-columns");
    if (columnsWrapper) {
        // Folders-only-view: two bm-col columns — interleave for visual order
        const hasCols = columnsWrapper.querySelector(":scope > .bm-col");
        if (hasCols) {
            return _bmGetInterleavedColumnItems(columnsWrapper);
        }
        // Grid-view flat layout: items are direct children of the wrapper
        return _bmGetDirectWrapperDisplayItems(columnsWrapper);
    }
    return Array.from(bookmarkList.querySelectorAll(":scope > ul > li[data-id]"))
               .filter(li => !li.classList.contains("bm-section-divider"));
}

// Read afterId from the indicator's current DOM position.
// Walks the flat display order to find the bookmark immediately before the indicator.
function _bmGetAfterIdFromIndicator() {
    if (DD.sectionAfterId) return DD.sectionAfterId;

    const ind = DD.indicator;
    if (!ind?.parentElement) return "start";

    let prev = ind.previousElementSibling;
    while (prev) {
        if (prev.dataset.id && !prev.classList.contains("bm-section-divider")
                && !prev.classList.contains("bm-drop-indicator")) {
            return prev.dataset.id;
        }
        prev = prev.previousElementSibling;
    }

    const allLIs = _bmGetAllDisplayOrderLIs();
    const indRect = ind.getBoundingClientRect();
    let lastBefore = null;
    for (const li of allLIs) {
        if (li === DD.el) continue;
        const r = li.getBoundingClientRect();
        if (r.top < indRect.top - 4) lastBefore = li;
    }
    return lastBefore ? lastBefore.dataset.id : "start";
}

function _bmGetSectionPreviewContext() {
    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    if (outerWrapper) return { root: outerWrapper, mode: "outer" };

    const listRoot = bookmarkList.querySelector(":scope > ul");
    if (listRoot) return { root: listRoot, mode: "list" };

    return { root: bookmarkList, mode: "list" };
}

function _bmGetSectionDropItems() {
    return _bmGetTopLevelSectionAnchorItems().filter(li => li !== DD.el);
}

function _bmFlattenTopLevelDisplayNodes() {
    const ctx = _bmGetSectionPreviewContext();
    if (!ctx.root) return { ...ctx, nodes: [] };

    if (ctx.mode === "outer") {
        const nodes = [];
        Array.from(ctx.root.children).forEach(child => {
            if (child.classList?.contains("bm-section-ind-wrapper")) return;

            if (child.classList?.contains("bm-section-fullrow")) {
                const sectionLi = child.querySelector(":scope > li.bm-section-divider");
                if (sectionLi && sectionLi !== DD.el) nodes.push(sectionLi);
                const fullRowItem = child.querySelector(":scope > li[data-id]");
                if (fullRowItem && fullRowItem !== DD.el) nodes.push(fullRowItem);
                return;
            }

            if (!child.classList?.contains("bm-folders-columns")) return;
            const hasCols = !!child.querySelector(":scope > .bm-col");
            if (hasCols) {
                const c1 = Array.from(child.querySelectorAll(":scope > .bm-col-1 > li[data-id]"));
                const c2 = Array.from(child.querySelectorAll(":scope > .bm-col-2 > li[data-id]"));
                const maxLen = Math.max(c1.length, c2.length);
                for (let i = 0; i < maxLen; i++) {
                    if (c1[i] && c1[i] !== DD.el) nodes.push(c1[i]);
                    if (c2[i] && c2[i] !== DD.el) nodes.push(c2[i]);
                }
            } else {
                _bmGetDirectWrapperDisplayItems(child).forEach(node => {
                    if (node !== DD.el) nodes.push(node);
                });
            }
        });
        return { ...ctx, nodes };
    }

    return {
        ...ctx,
        nodes: Array.from(ctx.root.children).filter(node =>
            node !== DD.el && !node.classList?.contains("bm-section-ind-wrapper")
        )
    };
}

function _bmRenderSectionPreviewNodes(root, mode, nodes) {
    if (!root) return;

    if (mode === "outer") {
        const frag = document.createDocumentFragment();
        let groupItems = [];

        const flushGroup = () => {
            if (!groupItems.length) return;
            frag.appendChild(bmCreateColumnsGroup(groupItems));
            groupItems = [];
        };

        for (const node of nodes) {
            if (!node) continue;

            if (node.classList?.contains("bm-section-ind-wrapper")) {
                const oddItem = groupItems.length % 2 !== 0
                    ? groupItems.pop()
                    : null;
                flushGroup();
                const oddFullRow = bmCreateOddFullRow(oddItem);
                if (oddFullRow) frag.appendChild(oddFullRow);
                frag.appendChild(node);
                continue;
            }

            if (node.classList?.contains("bm-section-divider")) {
                const oddItem = groupItems.length % 2 !== 0
                    ? groupItems.pop()
                    : null;
                flushGroup();
                const oddFullRow = bmCreateOddFullRow(oddItem);
                if (oddFullRow) frag.appendChild(oddFullRow);
                const fullRow = document.createElement("div");
                fullRow.className = "bm-section-fullrow";
                fullRow.appendChild(node);
                frag.appendChild(fullRow);
                continue;
            }

            if (node.classList?.contains("bm-odd-fullrow-item")) {
                flushGroup();
                const oddFullRow = document.createElement("div");
                oddFullRow.className = "bm-section-fullrow bm-odd-fullrow";
                oddFullRow.appendChild(node);
                frag.appendChild(oddFullRow);
                continue;
            }

            node.classList?.remove("bm-solo-stretched");
            groupItems.push(node);
        }

        flushGroup();
        root.replaceChildren(frag);
        _bmNormalizeOddItemsBeforeSections(root);
        return;
    }

    root.replaceChildren(...nodes);
}

function DD_placeSectionIndicatorLegacy(clientY) {
    // Remove old indicator + its wrapper if any
    const oldWrapper = bookmarkList.querySelector(".bm-section-ind-wrapper");
    if (oldWrapper) oldWrapper.remove();
    const ind = DD_getIndicator();
    ind.parentElement?.removeChild(ind);

    const root = _bmGetSectionPreviewContext().root || bookmarkList;
    const items = _bmGetSectionDropItems();
    const _existingCardLive = DD.el || items[0] || bookmarkList.querySelector(
        ".bm-folders-columns .bm-col > li[data-id]:not(.bm-drop-indicator)"
    );
    const _cardHLive = DD.elRect?.height || (_existingCardLive ? _existingCardLive.getBoundingClientRect().height : 42);

    ind.dataset.mode = "section";
    ind.style.cssText = [
        `height:${_cardHLive}px`,
        `min-height:${_cardHLive}px`,
        "width:100%",
        "border:1.5px dashed color-mix(in srgb,var(--darkColor-blue) 42%, transparent)",
        "background:color-mix(in srgb,var(--darkColor-blue) 12%, var(--ui-sep))",
        "border-radius:12px",
        "margin:0",
        "box-sizing:border-box",
        "pointer-events:none",
        "list-style:none",
        "box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--darkColor-blue) 16%, transparent)",
        "opacity:1",
        "display:block",
    ].join(";");

    const liveWrapper = document.createElement("div");
    liveWrapper.className = "bm-section-fullrow bm-section-ind-wrapper";
    liveWrapper.style.cssText = "position:absolute;left:0;right:0;width:100%;box-sizing:border-box;padding:3px 0;pointer-events:none;z-index:8;";
    liveWrapper.appendChild(ind);

    if (window.getComputedStyle(root).position === "static") {
        root.style.position = "relative";
    }

    if (!items.length) {
        DD.sectionAfterId = "start";
        liveWrapper.style.top = "0px";
        root.appendChild(liveWrapper);
        return;
    }

    let afterItem = null;
    for (const item of items) {
        const r = item.getBoundingClientRect();
        if (clientY < r.top + r.height / 2) break;
        afterItem = item;
    }

    const rootRect = root.getBoundingClientRect();
    let liveTop = 0;
    if (afterItem) {
        const afterRect = afterItem.getBoundingClientRect();
        liveTop = afterRect.bottom - rootRect.top + 6;
    } else {
        const firstRect = items[0].getBoundingClientRect();
        liveTop = Math.max(0, firstRect.top - rootRect.top - _cardHLive - 6);
    }

    const nextAfterId = afterItem?.dataset.id || "start";
    const hasPreview = !!bookmarkList.querySelector(".bm-section-ind-wrapper")
        || !!(DD.indicator?.dataset?.mode === "section" && DD.indicator?.parentElement);
    if (DD.sectionAfterId === nextAfterId && hasPreview) {
        DD_showSectionDragShield();
        return;
    }
    DD.sectionAfterId = nextAfterId;
    liveWrapper.style.top = `${Math.round(liveTop)}px`;
    root.appendChild(liveWrapper);
    return;

    // ── Match the dragged section's natural size instead of a normal bookmark card ──
    const _sectionRow = DD.el?.closest(".bm-section-fullrow");
    const _sectionRowRect = _sectionRow?.getBoundingClientRect?.();
    const _sectionRect = DD.elRect || DD.el?.getBoundingClientRect?.();
    const _rowH = Math.max(36, Math.round(_sectionRowRect?.height || _sectionRect?.height || 42));

    // ── Style the indicator ──
    // Theme color is automatic: theme.js remaps --darkColor-blue to active theme color
    ind.dataset.mode = "section";
    ind.style.cssText = [
        "height:100%",
        "min-height:100%",
        "width:100%",
        "max-width:100%",
        "border:2.5px dashed var(--darkColor-blue)",
        "background:color-mix(in srgb,var(--darkColor-blue) 12%, var(--ui-sep))",
        "border-radius:12px",
        "margin:0",
        "box-sizing:border-box",
        "pointer-events:none",
        "list-style:none",
        "opacity:0.8",
        "display:block",
    ].join(";");

    // ── Wrap in a full-row div so it always spans BOTH columns ──
    // In grid-view  : inserted as direct child of bm-folders-columns with flex:0 0 100%
    // In folders-view: inserted as direct child of bm-folders-outer
    const wrapper = document.createElement("div");
    wrapper.className = "bm-section-fullrow bm-section-ind-wrapper";
    wrapper.style.cssText = [
        "width:100%",
        "max-width:100%",
        "height:" + _rowH + "px",
        "min-height:" + _rowH + "px",
        "flex:0 0 100%",
        "box-sizing:border-box",
        "padding:0",
        "margin:4px 0 0 0",
        "display:block"
    ].join(";");
    wrapper.appendChild(ind);

    // ── Find the right full-width container ──
    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    const colWrapper   = bookmarkList.querySelector(".bm-folders-columns");
    const fullWidthRoot = outerWrapper || colWrapper;

    // All real bookmark LIs excluding the dragged section
    const allItems = Array.from(
        bookmarkList.querySelectorAll("li[data-id]:not(.bm-section-divider):not(.bm-drop-indicator)")
    ).filter(li => li !== DD.el);

    if (!allItems.length) {
        if (fullWidthRoot) fullWidthRoot.appendChild(wrapper);
        else bookmarkList.appendChild(wrapper);
        return;
    }

    // Find the first item whose vertical midpoint is below clientY
    let insertBefore = null;
    for (const item of allItems) {
        const r = item.getBoundingClientRect();
        if (clientY < r.top + r.height / 2) { insertBefore = item; break; }
    }

    if (fullWidthRoot) {
        // Walk up from insertBefore to find its DIRECT child of fullWidthRoot
        const findDirectChild = (ancestor, el) => {
            let node = el;
            while (node && node.parentElement !== ancestor) node = node.parentElement;
            return node;
        };
        if (insertBefore) {
            const groupEl = findDirectChild(fullWidthRoot, insertBefore);
            fullWidthRoot.insertBefore(wrapper, groupEl || fullWidthRoot.firstChild);
        } else {
            fullWidthRoot.appendChild(wrapper);
        }
    } else {
        if (insertBefore) {
            insertBefore.parentElement.insertBefore(wrapper, insertBefore);
        } else {
            allItems[allItems.length - 1].parentElement.appendChild(wrapper);
        }
    }
}

function DD_placeSectionIndicator(clientY) {
    const items = _bmGetSectionDropItems();
    if (!items.length) {
        DD.sectionAfterId = null;
        DD_clearIndicator();
        return;
    }

    let afterItem = null;
    const firstRect = items[0]?.getBoundingClientRect?.();
    if (!firstRect || clientY > DD_getBeforeThreshold(firstRect, 0.28, 8, 22)) {
        for (const item of items) {
            const r = item.getBoundingClientRect();
            if (DD_shouldInsertBefore(clientY, r, 0.3, 8, 22)) break;
            afterItem = item;
        }
    }

    const nextAfterId = afterItem?.dataset.id || "start";
    const hasPreview = !!bookmarkList.querySelector(".bm-section-ind-wrapper")
        || !!(DD.indicator?.dataset?.mode === "section" && DD.indicator?.parentElement);
    if (DD.sectionAfterId === nextAfterId && hasPreview) {
        DD_showSectionDragShield();
        return;
    }
    DD.sectionAfterId = nextAfterId;

    const { root, mode, nodes } = _bmFlattenTopLevelDisplayNodes();
    if (!root) return;

    const flatNodes = nodes.slice();
    const firstAnchor = items[0];
    const insertIndex = afterItem
        ? Math.max(0, flatNodes.indexOf(afterItem) + 1)
        : Math.max(0, flatNodes.indexOf(firstAnchor));

    const ind = DD_getIndicator();
    const slotHeight = Math.max(
        Math.round(DD.elRect?.height || DD.el?.getBoundingClientRect().height || 34),
        30
    );

    ind.dataset.mode = "section";
    ind.style.cssText = [
        `height:${slotHeight}px`,
        `min-height:${slotHeight}px`,
        "width:100%",
        "margin:0",
        "padding:0",
        "box-sizing:border-box",
        "pointer-events:none",
        "list-style:none",
        "display:block",
    ].join(";");

    const previewNode = mode === "outer"
        ? (() => {
            const wrapper = document.createElement("div");
            wrapper.className = "bm-section-fullrow bm-section-ind-wrapper";
            wrapper.appendChild(ind);
            return wrapper;
        })()
        : ind;

    flatNodes.splice(insertIndex, 0, previewNode);
    _bmRenderSectionPreviewNodes(root, mode, flatNodes);
    if (DD.sectionDragId) {
        DD_showSectionDragShield();
        DD_applySectionNoShadowInlineStyles();
    }
}

function _bmUpdateSectionColor(sectionId, color) {
    const sections = _bmGetSections().map(s => s.id === sectionId ? {...s, color} : s);
    _bmSaveSections(sections);
    loadBookmarks();
}

function _bmUpdateSectionAlign(sectionId, align) {
    const sections = _bmGetSections().map(s => s.id === sectionId ? {...s, align} : s);
    _bmSaveSections(sections);
    loadBookmarks();
}
function _bmUpdateSectionFontSize(sectionId, delta) {
    const sections = _bmGetSections().map(s => {
        if (s.id !== sectionId) return s;
        const cur = parseFloat(s.fontSize) || 11;
        const next = Math.min(28, Math.max(8, Math.round((cur + delta) * 10) / 10));
        return {...s, fontSize: next};
    });
    _bmSaveSections(sections);
    loadBookmarks();
}

function _bmToggleSectionWide(sectionId) {
    const sections = _bmGetSections().map(s => s.id === sectionId ? {...s, wide: !s.wide} : s);
    _bmSaveSections(sections);
    loadBookmarks();
}

// Inject sections into a sorted node list (for displayBookmarks top-level)
function _bmInjectSections(sortedNodes) {
    const sections = _bmGetSections();
    if (!sections.length) return sortedNodes;

    const bookmarkNodes = sortedNodes.filter(node => node?.url);
    if (!bookmarkNodes.length) return sortedNodes;

    const bookmarkIds = new Set(bookmarkNodes.map(node => String(node.id)));
    const sectionsByBookmarkIndex = new Map();
    let migrated = false;
    let normalizedSections = sections.map(sec => {
        let bookmarkIndex = Number(sec?.bookmarkIndex);
        if (!Number.isFinite(bookmarkIndex)) {
            const afterId = sec?.afterId ? String(sec.afterId) : "start";
            if (afterId === "start" || !bookmarkIds.has(afterId)) bookmarkIndex = 0;
            else bookmarkIndex = bookmarkNodes.findIndex(node => String(node.id) === afterId) + 1;
            migrated = true;
        }
        bookmarkIndex = Math.max(0, Math.min(bookmarkNodes.length, Math.round(bookmarkIndex)));
        return { ...sec, bookmarkIndex };
    });

    const parityNormalized = _bmNormalizeSectionsForEvenSlots(normalizedSections, bookmarkNodes, true);
    normalizedSections = parityNormalized.sections;

    if (migrated || parityNormalized.changed) _bmSaveSections(normalizedSections);

    for (const sec of normalizedSections) {
        const bookmarkIndex = Math.max(0, Math.min(bookmarkNodes.length, Math.round(Number(sec.bookmarkIndex) || 0)));
        if (!sectionsByBookmarkIndex.has(bookmarkIndex)) sectionsByBookmarkIndex.set(bookmarkIndex, []);
        sectionsByBookmarkIndex.get(bookmarkIndex).push(sec);
    }

    const pushSectionsAt = (bookmarkIndex, out) => {
        for (const sec of sectionsByBookmarkIndex.get(bookmarkIndex) || []) {
            out.push(_bmBuildSectionDividerNode(sec));
        }
    };

    const result = [];
    let bookmarksSeen = 0;
    pushSectionsAt(0, result);
    for (const node of sortedNodes) {
        result.push(node);
        if (node?.url) {
            bookmarksSeen++;
            pushSectionsAt(bookmarksSeen, result);
        }
    }
    return result;
}

function _bmRenderSectionNode(node) {
    const li = document.createElement("li");
    li.className = "bm-section-divider bm-section-wide";
    li.dataset.sectionId = node.id;
    const _rawColor = node.color || "blue";
    li.dataset.color = _rawColor;
    // For custom hex colors (stored as __hex__#xxxxxx), apply inline CSS variable
    if (_rawColor.startsWith("__hex__")) {
        const _hexVal = _rawColor.slice(7);
        li.style.setProperty("--_sec-color", _hexVal);
    }
    // For dual gradient colors (stored as __grad__#c1__#c2)
    if (_rawColor.startsWith("__grad__")) {
        const _parts = _rawColor.slice(8).split("__");
        li.style.setProperty("--_sec-color", _parts[0]);
        li.style.setProperty("--_sec-color2", _parts[1] || _parts[0]);
        li.dataset.colorType = "gradient";
        // Map known gradient keys to named data-grad for CSS theme rules
        const _gradNameMap = {
            "#ff6b35__#e91e8c":"sunset","#00c9ff__#0057ff":"ocean","#11998e__#38ef7d":"forest",
            "#ff4e50__#f9a825":"fire","#9c27b0__#3f51b5":"galaxy","#00bcd4__#8bc34a":"aurora",
            "#e040fb__#7c4dff":"dusk","#f06292__#ef5350":"rose",
            "#26c6da__#00e676":"mint","#f953c6__#b91d73":"candy",
            "#39ff14__#00d4ff":"neon","#f12711__#f5af19":"lava",
            "#93f9b9__#1d976c":"spring","#8e2de2__#4a00e0":"electric",
            "#ffe259__#ffa751":"mango","#232526__#414345":"midnight",
            "#360033__#0b8793":"deep","#74ebd5__#acb6e5":"ice"
        };
        const _gradKey = _parts.slice(0,2).join("__");
        if (_gradNameMap[_gradKey]) li.dataset.grad = _gradNameMap[_gradKey];
    }

    // Text alignment (left / center / right)
    const _align = node.align || "left";
    li.dataset.align = _align;

    const titleSpan = document.createElement("span");
    titleSpan.className = "bm-section-title";
    titleSpan.style.textAlign = _align;
    if (node.fontSize)  titleSpan.style.fontSize     = node.fontSize + "px";
    if (node.bold)                  titleSpan.style.fontWeight    = "700";
    if (node.italic)                titleSpan.style.fontStyle     = "italic";
    if (node.upper === false)       titleSpan.style.textTransform = "none";
    if (node.letter)                titleSpan.style.letterSpacing = "0.25em";
    // textContent AFTER styles so uppercase transform works visually
    titleSpan.textContent = node.title;

    li.appendChild(titleSpan);

    // Right-click on section → rename / delete
    li.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        e.stopPropagation();
        _showSectionCtxMenu(e.clientX + 4, e.clientY + 4, node.id, node.title, node.wide);
    });

    // ── Drag support: allow sections to be reordered ──
    li.draggable = false;
    li.addEventListener("pointerdown", (e) => {
        if (e.button !== 0) return;
        DD_beginSectionPointerDrag(li, node.id, e);


    });

    return li;
}

// ── Section context menu (simple inline menu) ──
let _sectionCtxMenu = null;
let _sectionCtxTarget = null;

function _clampCtxMenuPosition(x, y, mw, mh) {
    const vw = window.innerWidth || document.documentElement.clientWidth || 0;
    const vh = window.innerHeight || document.documentElement.clientHeight || 0;
    return {
        left: Math.max(0, Math.min(Math.max(0, vw - mw), x)),
        top: Math.max(0, Math.min(Math.max(0, vh - mh), y))
    };
}

function _showSectionCtxMenu(x, y, sectionId, currentTitle, isWide) {
    _hideSectionCtxMenu();
    const t2 = (key) => translations[currentLanguage]?.[key] || translations["en"]?.[key] || key;
    const menu = document.createElement("div");
    menu.className = "bookmark-ctx-menu";
    menu.style.cssText = "display:block;position:fixed;z-index:9999;";

    // Get current section data for active states
    const _secData = _bmGetSections().find(s => s.id === sectionId) || {};
    const _curAlign = _secData.align || "left";
    const _curColor = _secData.color || "blue";

    // Single color palette (18 distinct colors)
    const themeColors = ["blue", "red", "orange", "yellow", "green", "forest", "lime", "cyan", "sage", "slate", "indigo", "purple", "violet", "magenta", "pink", "coral", "brown", "silver"];

    // Translation keys for theme colors
    const themeColorKeys = {
        blue: "colorBlue", red: "colorRed", orange: "colorOrange",
        yellow: "colorYellow", green: "colorGreen", forest: "colorForest",
        lime: "colorLime", cyan: "colorCyan", sage: "colorSage",
        slate: "colorSlate", indigo: "colorIndigo", purple: "colorPurple",
        violet: "colorViolet", magenta: "colorMagenta", pink: "colorPink",
        coral: "colorCoral", brown: "colorBrown", silver: "colorSilver"
    };

    // Dual gradient colors (18 gradients - 15 + 3 new)
    const gradColors = [
        { name: "Sunset",   nameKey: "gradSunset",   c1: "#ff6b35", c2: "#e91e8c" },
        { name: "Ocean",    nameKey: "gradOcean",    c1: "#00c9ff", c2: "#0057ff" },
        { name: "Forest",   nameKey: "gradForest",   c1: "#11998e", c2: "#38ef7d" },
        { name: "Fire",     nameKey: "gradFire",     c1: "#ff4e50", c2: "#f9a825" },
        { name: "Galaxy",   nameKey: "gradGalaxy",   c1: "#9c27b0", c2: "#3f51b5" },
        { name: "Aurora",   nameKey: "gradAurora",   c1: "#00bcd4", c2: "#8bc34a" },
        { name: "Dusk",     nameKey: "gradDusk",     c1: "#e040fb", c2: "#7c4dff" },
        { name: "Rose",     nameKey: "gradRose",     c1: "#f06292", c2: "#ef5350" },
        { name: "Mint",     nameKey: "gradMint",     c1: "#26c6da", c2: "#00e676" },
        { name: "Candy",    nameKey: "gradCandy",    c1: "#f953c6", c2: "#b91d73" },
        { name: "Neon",     nameKey: "gradNeon",     c1: "#39ff14", c2: "#00d4ff" },
        { name: "Lava",     nameKey: "gradLava",     c1: "#f12711", c2: "#f5af19" },
        { name: "Spring",   nameKey: "gradSpring",   c1: "#93f9b9", c2: "#1d976c" },
        { name: "Electric", nameKey: "gradElectric", c1: "#8e2de2", c2: "#4a00e0" },
        { name: "Mango",    nameKey: "gradMango",    c1: "#ffe259", c2: "#ffa751" },
        { name: "Midnight", nameKey: "gradMidnight", c1: "#232526", c2: "#414345" },
        { name: "Deep",     nameKey: "gradDeep",     c1: "#360033", c2: "#0b8793" },
        { name: "Ice",      nameKey: "gradIce",      c1: "#74ebd5", c2: "#acb6e5" },
    ];
    
    // Extra hardcoded colors not in the theme (empty - using only theme colors)
    const extraColors = [];

    const fixedSectionPalette = {
        blue:     "#4382ec",
        red:      "#e03535",
        orange:   "#d86838",
        yellow:   "#c8980a",
        green:    "#38a038",
        forest:   "#2e8830",
        lime:     "#86b817",
        cyan:     "#009898",
        sage:     "#508860",
        slate:    "#506090",
        indigo:   "#4f6bed",
        purple:   "#7e57c2",
        violet:   "#7a4bc2",
        magenta:  "#c01888",
        pink:     "#d84068",
        coral:    "#e05530",
        brown:    "#705347",
        silver:   "#848490",
    };

    const colorDots = [
        ...themeColors.map(c => {
            const isActive = _curColor === c;
            const label = t2(themeColorKeys[c]) || c;
            const swatchColor = fixedSectionPalette[c] || `var(--darkColor-${c})`;
            const ringColor = fixedSectionPalette[c] ? _bmDarkenHexColor(fixedSectionPalette[c]) : "";
            const ringAttr = ringColor ? ` data-ring-color="${ringColor}"` : "";
            return `<button class="ctx-color-dot${isActive ? " active" : ""}" data-color="${c}" data-tooltip="${label}"${ringAttr} style="background:${swatchColor}"></button>`;
        }),
        ...extraColors.map(c => {
            const colorKey = "__hex__" + c.hex;
            const isActive = _curColor === colorKey;
            return `<button class="ctx-color-dot${isActive ? " active" : ""}" data-color="${colorKey}" data-tooltip="${c.name}" style="background:${c.hex}"></button>`;
        })
    ].join("");

    const gradDots = gradColors.map(g => {
        const gradKey = `__grad__${g.c1}__${g.c2}`;
        const isActive = _curColor === gradKey;
        const label = t2(g.nameKey) || g.name;
        return `<button class="ctx-color-dot ctx-grad-dot${isActive ? " active" : ""}" data-color="${gradKey}" data-tooltip="${label}" style="background:linear-gradient(to bottom right,${g.c1},${g.c2})"></button>`;
    }).join("");

    menu.innerHTML = `<div class="ctx-drag-handle" title="${t2("dragToMove")}"><div class="ctx-drag-line"></div><span class="ctx-drag-label">${t2("leDragLabel") || "drag"}</span></div><div class="ctx-menu-inner">
        <div class="ctx-group">
            <button class="ctx-item" id="_secCtxRename">
                <svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                <span>${t2("bm_renameSection")}</span>
            </button>
        </div>
        <div class="ctx-group ctx-group-label"><span class="ctx-group-title">${t2("bm_sectionColor")}</span>
            <div class="ctx-section-colors">${colorDots}</div>
        </div>
        <div class="ctx-group ctx-group-label"><span class="ctx-group-title">${t2("bm_sectionGradient")}</span>
            <div class="ctx-section-colors">${gradDots}</div>
        </div>
        <div class="ctx-group ctx-group-label"><span class="ctx-group-title">${t2("bm_sectionAlign")}</span>
            <div class="ctx-section-align">
                <button class="ctx-align-btn${_curAlign === "left" ? " active" : ""}" data-align="left" title="${t2("alignLeft")}">
                    <svg viewBox="0 0 24 24"><path d="M3 6h18v2H3zm0 4h12v2H3zm0 4h18v2H3zm0 4h12v2H3z"/></svg>
                </button>
                <button class="ctx-align-btn${_curAlign === "center" ? " active" : ""}" data-align="center" title="${t2("alignCenter")}">
                    <svg viewBox="0 0 24 24"><path d="M3 6h18v2H3zm3 4h12v2H6zm-3 4h18v2H3zm3 4h12v2H6z"/></svg>
                </button>
                <button class="ctx-align-btn${_curAlign === "right" ? " active" : ""}" data-align="right" title="${t2("alignRight")}">
                    <svg viewBox="0 0 24 24"><path d="M3 6h18v2H3zm6 4h12v2H9zm-6 4h18v2H3zm6 4h12v2H9z"/></svg>
                </button>
            </div>
        </div>
        <div class="ctx-group ctx-group-label"><span class="ctx-group-title">${t2("bm_sectionFontSize") || "Font Size"}</span>
            <div class="ctx-section-fontsize">
                <button class="ctx-fs-btn" data-delta="-1" title="${t2("fsDecrease")}">
                    <svg viewBox="0 0 24 24"><path d="M19 13H5v-2h14v2z"/></svg>
                </button>
                <span class="ctx-fs-value">${_secData.fontSize || 11}px</span>
                <button class="ctx-fs-btn" data-delta="1" title="${t2("fsIncrease")}">
                    <svg viewBox="0 0 24 24"><path d="M19 13H13v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                </button>
            </div>
        </div>
        <div class="ctx-group ctx-group-label"><span class="ctx-group-title">${t2("bm_sectionStyle")}</span>
            <div class="ctx-section-style">
                <button class="ctx-style-btn${_secData.bold   ? " active" : ""}" data-style="bold"   title="${t2("bm_sectionBold")}"><b>B</b></button>
                <button class="ctx-style-btn${_secData.italic ? " active" : ""}" data-style="italic" title="${t2("bm_sectionItalic")}"><i>I</i></button>
                <button class="ctx-style-btn${_secData.upper  ? " active" : ""}" data-style="upper"  title="${t2("bm_sectionUpper")}">AA</button>
                <button class="ctx-style-btn${_secData.letter ? " active" : ""}" data-style="letter" title="${t2("bm_sectionLetter")}">A·A</button>
            </div>
        </div>
        <div class="ctx-group">
            <button class="ctx-item ctx-danger" id="_secCtxDelete">
                <svg class="section-delete-icon keep-color" viewBox="0 0 24 24"><path class="section-delete-path" d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                <span>${t2("bm_deleteSection")}</span>
            </button>
        </div>
    </div>`;

    document.body.appendChild(menu);
    _sectionCtxMenu = menu;
    _sectionCtxTarget = sectionId;
    // Prevent clicks inside the menu from bubbling to document (would close sidebar)
    menu.addEventListener("click", (e) => e.stopPropagation());

    // ── Drag handle logic ──
    const _dragHandle = menu.querySelector(".ctx-drag-handle");
    _dragHandle.addEventListener("mousedown", (e) => {
        e.stopPropagation();
        e.preventDefault();
        let startX = e.clientX, startY = e.clientY;
        let startLeft = parseInt(menu.style.left) || 0;
        let startTop  = parseInt(menu.style.top)  || 0;
        const onMove = (ev) => {
            const pos = _clampCtxMenuPosition(
                startLeft + ev.clientX - startX,
                startTop + ev.clientY - startY,
                menu.offsetWidth,
                menu.offsetHeight
            );
            menu.style.left = pos.left + "px";
            menu.style.top  = pos.top + "px";
        };
        const onUp = () => {
            document.removeEventListener("mousemove", onMove);
            document.removeEventListener("mouseup",   onUp);
        };
        document.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup",   onUp);
    });

    const sectionMenuPos = _clampCtxMenuPosition(x, y, menu.offsetWidth, menu.offsetHeight);
    menu.style.left = sectionMenuPos.left + "px";
    menu.style.top  = sectionMenuPos.top + "px";

    menu.querySelector("#_secCtxRename").addEventListener("click", async (e) => {
        e.stopPropagation();
        _hideSectionCtxMenu();
        const newTitle = await inputPrompt(t("bm_sectionName"), currentTitle);
        if (newTitle?.trim()) _bmRenameSectionById(sectionId, newTitle.trim());
    });
    menu.querySelector("#_secCtxDelete").addEventListener("click", (e) => {
        e.stopPropagation();
        _hideSectionCtxMenu();
        _bmDeleteSection(sectionId);
    });
    menu.querySelectorAll(".ctx-style-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            const style = btn.dataset.style;
            const sections = _bmGetSections().map(s => {
                if (s.id !== sectionId) return s;
                // For "upper", default is ON (CSS does uppercase), so we track explicit false
            const cur = s[style];
            const next = style === "upper" ? (cur === false ? undefined : false) : !cur;
            const updated = {...s};
            if (next === undefined) delete updated[style]; else updated[style] = next;
            return updated;
            });
            _bmSaveSections(sections);
            const sec = sections.find(s => s.id === sectionId);
            const liveLi = document.querySelector(`[data-section-id="${sectionId}"]`);
            if (liveLi) {
                const span = liveLi.querySelector(".bm-section-title");
                if (span) {
                    span.style.fontWeight    = sec.bold   ? "700" : "";
                    span.style.fontStyle     = sec.italic ? "italic" : "";
                    // upper: CSS default is already uppercase; toggle to none for lowercase look
                    span.style.textTransform = sec.upper === false ? "none" : "";
                    // letter: toggle extra wide spacing beyond CSS default 0.08em
                    span.style.letterSpacing = sec.letter ? "0.25em" : "";
                }
            }
            btn.classList.toggle("active");
        });
    });
    const _darkenSectionRingColor = (colorValue) => {
        if (!colorValue) return "";
        const match = colorValue.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
        if (!match) return "";
        return _bmDarkenRgbChannels(
            parseInt(match[1], 10),
            parseInt(match[2], 10),
            parseInt(match[3], 10)
        );
    };

    const _applySectionDotActiveRing = () => {
        menu.querySelectorAll(".ctx-color-dot").forEach(dot => {
            if (!dot.classList.contains("active")) {
                dot.style.removeProperty("--section-active-ring-color");
                return;
            }
            const ringColor = dot.dataset.ringColor || _darkenSectionRingColor(getComputedStyle(dot).backgroundColor);
            if (ringColor) {
                dot.style.setProperty("--section-active-ring-color", ringColor);
            } else {
                dot.style.removeProperty("--section-active-ring-color");
            }
        });
    };

    _applySectionDotActiveRing();

    menu.querySelectorAll(".ctx-color-dot").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            _bmUpdateSectionColor(sectionId, btn.dataset.color);
            // Update active state without closing menu
            menu.querySelectorAll(".ctx-color-dot").forEach(b => b.classList.toggle("active", b.dataset.color === btn.dataset.color));
            _applySectionDotActiveRing();
        });
    });

    // ── Fixed-position tooltip for color dots (avoids overflow clipping) ──
    const _ctxTip = document.getElementById("ctxColorTooltip");
    if (_ctxTip) {
        menu.querySelectorAll(".ctx-color-dot[data-tooltip]").forEach(dot => {
            dot.addEventListener("mouseenter", () => {
                _ctxTip.textContent = dot.dataset.tooltip;
                const dotBg = getComputedStyle(dot).backgroundImage && getComputedStyle(dot).backgroundImage !== "none"
                    ? getComputedStyle(dot).backgroundImage
                    : getComputedStyle(dot).backgroundColor;
                _ctxTip.style.background = dotBg;
                _ctxTip.style.color = "#ffffff";
                const r = dot.getBoundingClientRect();
                _ctxTip.style.left = (r.left + r.width / 2) + "px";
                _ctxTip.style.top  = (r.top - 38) + "px";
                _ctxTip.style.transform = "translateX(-50%) translateY(0)";
                _ctxTip.style.opacity = "1";
            });
            dot.addEventListener("mouseleave", () => {
                _ctxTip.style.opacity = "0";
                _ctxTip.style.transform = "translateX(-50%) translateY(4px)";
            });
        });
    }
    // ─────────────────────────────────────────────────────────────────
    menu.querySelectorAll(".ctx-align-btn").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            const align = btn.dataset.align;
            // Update storage
            const sections = _bmGetSections().map(s => s.id === sectionId ? {...s, align} : s);
            _bmSaveSections(sections);
            // Update DOM in-place
            const liveLi = document.querySelector(`[data-section-id="${sectionId}"]`);
            if (liveLi) {
                liveLi.dataset.align = align;
                const span = liveLi.querySelector(".bm-section-title");
                if (span) span.style.textAlign = align;
            }
            // Update active state inside the menu
            menu.querySelectorAll(".ctx-align-btn").forEach(b => b.classList.toggle("active", b.dataset.align === align));
        });
    });
    menu.querySelectorAll(".ctx-fs-btn").forEach(btn => {
        let _fsHoldTimer = null;
        let _fsRapidInterval = null;

        // Core step function — applies one delta, updates DOM + display
        const _applyFsDelta = (delta) => {
            const sections = _bmGetSections().map(s => {
                if (s.id !== sectionId) return s;
                const cur = parseFloat(s.fontSize) || 11;
                const next = Math.min(28, Math.max(8, Math.round((cur + delta) * 10) / 10));
                return {...s, fontSize: next};
            });
            _bmSaveSections(sections);
            const liveLi = document.querySelector(`[data-section-id="${sectionId}"]`);
            if (liveLi) {
                const newSize = (sections.find(s => s.id === sectionId)?.fontSize) || 11;
                const span = liveLi.querySelector(".bm-section-title");
                if (span) span.style.fontSize = newSize + "px";
                const display = menu.querySelector(".ctx-fs-value");
                if (display) display.textContent = newSize + "px";
            }
        };

        const _stopHold = () => {
            clearTimeout(_fsHoldTimer);
            clearInterval(_fsRapidInterval);
            _fsHoldTimer = null;
            _fsRapidInterval = null;
            btn.classList.remove("ctx-fs-btn--holding");
        };

        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            // Only fire on quick tap (hold already handled by mousedown)
            if (!_fsRapidInterval) _applyFsDelta(parseInt(btn.dataset.delta));
        });

        btn.addEventListener("mousedown", (e) => {
            e.stopPropagation();
            const delta = parseInt(btn.dataset.delta);
            // After 500ms hold → start rapid repeat every 80ms
            _fsHoldTimer = setTimeout(() => {
                btn.classList.add("ctx-fs-btn--holding");
                _fsRapidInterval = setInterval(() => {
                    _applyFsDelta(delta);
                }, 80);
            }, 500);
        });

        btn.addEventListener("mouseup",    _stopHold);
        btn.addEventListener("mouseleave", _stopHold);
        btn.addEventListener("touchend",   _stopHold);
        btn.addEventListener("touchcancel",_stopHold);

        // Touch long-press support
        btn.addEventListener("touchstart", (e) => {
            e.stopPropagation();
            const delta = parseInt(btn.dataset.delta);
            _fsHoldTimer = setTimeout(() => {
                btn.classList.add("ctx-fs-btn--holding");
                _fsRapidInterval = setInterval(() => _applyFsDelta(delta), 80);
            }, 500);
        }, { passive: true });
    });
}
function _hideSectionCtxMenu() {
    if (!_sectionCtxMenu) return;
    const menu = _sectionCtxMenu;
    _sectionCtxMenu = null;
    _sectionCtxTarget = null;
    // Animate out before removing (same pattern as hideCtxMenu)
    menu.classList.add("ctx-menu-closing");
    const _mult = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")) || 1;
    const dur = Math.round(260 * _mult) + 20;
    setTimeout(() => { menu.remove(); }, dur);
}
document.addEventListener("click", () => _hideSectionCtxMenu());
document.addEventListener("keydown", e => { if (e.key === "Escape") _hideSectionCtxMenu(); });

// ── Preserve open-folder state across loadBookmarks reloads ──
// Collects all folder IDs currently open in the sidebar, then re-opens them
// after a full DOM rebuild so Ctrl+Z (and any reload) doesn't collapse everything.
function _bmGetOpenFolderIds() {
    const ids = new Set();
    document.querySelectorAll("#bookmarkList li.folder.open").forEach(li => {
        if (li.dataset.id) ids.add(li.dataset.id);
    });
    return ids;
}
function _bmRestoreOpenFolders(ids) {
    if (!ids.size) return;
    document.querySelectorAll("#bookmarkList li.folder").forEach(li => {
        if (li.dataset.id && ids.has(li.dataset.id)) li.classList.add("open");
    });
}

function loadBookmarks() {
    const loadVersion = ++_bmLoadVersion;
    _bmDisconnectFavicons(); // drop pending lazy-icon observations for dead nodes
    _bmEnsureListDelegation();
    if (!bookmarksAPI?.getTree) {
        _bmDiscoveryState = "error";
        bmRefreshDiscovery();
        return Promise.resolve();
    }
    _bmDiscoveryState = "loading";
    bmRefreshDiscovery();
    _bmShowSkeleton(loadVersion);

    // In grid view, folders-only should reuse the same folder card layout as "All"
    // and only differ by filtering out bookmark links from the data source.
    const useFoldersOnlyLayout = currentFilter === "folders";
    bookmarkList.classList.toggle("folders-only-view", useFoldersOnlyLayout);

    const treeP   = Promise.resolve().then(() => bookmarksAPI.getTree());
    const recentP = bookmarksAPI.getRecent ? Promise.resolve().then(() => bookmarksAPI.getRecent(8)).catch(() => []) : Promise.resolve([]);

    // Snapshot currently-open folders BEFORE the async fetch resolves,
    // so a reload (e.g. triggered by Ctrl+Z) doesn't collapse them.
    const _openBeforeReload = _bmGetOpenFolderIds();

    return Promise.all([treeP, recentP]).then(([bookmarkTreeNodes, recentBookmarks]) => {
        if (loadVersion !== _bmLoadVersion) return;
        clearTimeout(_bmSkeletonTimer);
        // Toggle the grid-view class here to synchronize it with the new DOM structure
        const useGridLayout = bookmarkGridCheckbox.checked;
        bookmarkList.classList.toggle("grid-view", useGridLayout);

        // Clear the current list
        bookmarkList.innerHTML = "";

        let allItems = [];
        const cacheRoots = [];

        // For Firefox: "Bookmarks Menu" and "Other Bookmarks" are distinct nodes
        if (isFirefox) {
            const toolbarNode = bookmarkTreeNodes[0]?.children?.find(node => node.title === "Bookmarks Toolbar");
            const menuNode    = bookmarkTreeNodes[0]?.children?.find(node => node.title === "Bookmarks Menu");
            const otherNode   = bookmarkTreeNodes[0]?.children?.find(node => node.title === "Other Bookmarks");
            allItems = [
                ...(toolbarNode?.children || []),
                ...(menuNode?.children   || []),
                ...(otherNode?.children  || []),
            ];
            cacheRoots.push(toolbarNode, menuNode, otherNode);
        } else {
            let default_folder = "Bookmarks bar";
            if (isEdge)  default_folder = "Favorites bar";
            if (isBrave) default_folder = "Bookmarks";

            const rootChildren  = bookmarkTreeNodes[0]?.children || [];
            const mainBookmarks = rootChildren.find(node =>
                node.title === default_folder ||
                node.folderType === "bookmarks-bar"
            );
            const extraNodes = rootChildren.filter(node =>
                node !== mainBookmarks && node.id !== "1" && node.children
            );
            allItems = [
                ...(mainBookmarks?.children || []),
                ...extraNodes,
            ];
            _bmRootParentId = mainBookmarks?.id || null;
            cacheRoots.push(mainBookmarks, ...extraNodes);
        }

        _bmChildrenByParentId = new Map();
        _bmNodeKindById = new Map();
        cacheRoots.filter(Boolean).forEach(_bmCacheNodeOrder);

        // Append "Recently Added" virtual folder
        if (recentBookmarks.length > 0) {
            allItems.push({
                id: BM_VIRTUAL_RECENT_FOLDER_ID,
                title: bmDiscoveryText("recent"),
                children: recentBookmarks,
                _isVirtualFolder: true,
            });
        }

        _bmDiscoveryNodes = currentFilter === "bookmarks" ? allItems.filter(node => node.url) : currentFilter === "folders" ? allItems.filter(node => node.children) : allItems;
        if (allItems.length) {
            const ul = displayBookmarks(allItems);
            // Grid-view always uses two columns; list-view always uses plain ul
            if (bookmarkList.classList.contains("grid-view")) {
                bookmarkList.appendChild(splitIntoIndependentColumns(ul));
            } else {
                bookmarkList.appendChild(ul);
            }
        }
        // Restore open folders after DOM rebuild
        _bmRestoreOpenFolders(_openBeforeReload);
        _bmDiscoveryState = "ready";
        // Cache flat item list for debounced search (rebuilt on every render;
        // drag-moves reuse the same nodes so the cache stays valid).
        _bmSearchItems = [...bookmarkList.querySelectorAll("li[data-id]")];
        bmApplySearch();
        _bmRebalanceSectionedGridLayout();
        bmRefreshSoloItems();
        // Entrance motion for freshly rendered top-level items (class removed
        // shortly after so later DOM moves, e.g. drag reflow, never animate).
        bookmarkList.classList.add("bm-list-in");
        clearTimeout(_bmListInTimer);
        _bmListInTimer = setTimeout(() => bookmarkList.classList.remove("bm-list-in"), 550);
        if (bookmarkList.classList.contains("grid-view")) {
            // Single scheduled rebalance (was: immediate rAF + a second delayed
            // pass that measured mid-animation heights and caused a visible jump).
            bmScheduleColumnsRebalance(_openBeforeReload.size > 0 ? 700 : 0);
        }
    }).catch(err => {
        if (loadVersion !== _bmLoadVersion) return;
        clearTimeout(_bmSkeletonTimer);
        _bmDiscoveryState = "error";
        bmRefreshDiscovery();
        console.error("Error loading bookmarks:", err);
    });
}

// Skeleton placeholders while the browser's bookmark tree resolves (>120ms).
// Replaced wholesale by the real render; never carries data-id/DD/listeners.
let _bmSkeletonTimer = 0;
let _bmListInTimer = 0;
let _bmSearchItems = null;
function _bmShowSkeleton(version) {
    clearTimeout(_bmSkeletonTimer);
    _bmSkeletonTimer = setTimeout(() => {
        if (version !== _bmLoadVersion || _bmDiscoveryState !== "loading") return;
        bookmarkList.innerHTML = "";
        bookmarkList.setAttribute("aria-busy", "true");
        const ul = document.createElement("ul");
        ul.className = "bm-skeleton";
        ul.setAttribute("aria-hidden", "true");
        for (let i = 0; i < 8; i++) {
            const li = document.createElement("li");
            li.className = "bm-skel-item";
            li.innerHTML = '<span class="bm-skel-ic"></span><span class="bm-skel-tx"></span>';
            ul.appendChild(li);
        }
        bookmarkList.appendChild(ul);
    }, 120);
}

function bmStartViewSwitchVisualGuard() {
    if (!bookmarkList) return;
    bookmarkList.classList.add("bm-view-switching");
    clearTimeout(bookmarkList._bmViewSwitchGuardTimer);
    bookmarkList._bmViewSwitchGuardTimer = setTimeout(() => {
        bookmarkList.classList.remove("bm-view-switching");
        bookmarkList._bmViewSwitchGuardTimer = null;
    }, Math.max(180, Number(window.getPanelAnimDur?.()) || 220));
}

// Function to set the favicon for a bookmark
function setBookmarkFavicon(faviconElement, pageUrl) {
    const io = _bmFaviconObserver();
    if (io && pageUrl) {
        // Instant local monogram (data URI, zero network) so collapsed/hidden
        // items never fire network probes; upgrade to the real icon when visible.
        try {
            faviconElement.alt = "";
            faviconElement.decoding = "async";
            faviconElement.classList.add("favicon", "site-icon-fallback");
            faviconElement.src = window.MyntNavigationCore.fallbackIcon(pageUrl);
            faviconElement.dataset.bmUrl = pageUrl;
            io.observe(faviconElement);
            return;
        } catch (_) { /* fall through to eager path */ }
    }
    window.MyntSiteIcons.set(faviconElement, pageUrl, { size: 64 });
}

// Lazy favicon upgrades: IntersectionObserver fires only for rendered (visible)
// images, so display:none subtrees (collapsed folders, filtered-out items)
// cost nothing until actually shown. No behavior change — same final icons.
let _bmFaviconIO = null;
function _bmFaviconObserver() {
    if (_bmFaviconIO) return _bmFaviconIO;
    if (typeof IntersectionObserver === "undefined") return null;
    _bmFaviconIO = new IntersectionObserver((entries) => {
        entries.forEach(en => {
            if (!en.isIntersecting) return;
            const img = en.target;
            try { _bmFaviconIO.unobserve(img); } catch (_) {}
            const url = img.dataset && img.dataset.bmUrl;
            if (url && img.isConnected) {
                window.MyntSiteIcons.set(img, url, { size: 64 });
            }
        });
    }, { root: null, rootMargin: "240px", threshold: 0 });
    return _bmFaviconIO;
}
function _bmDisconnectFavicons() {
    if (_bmFaviconIO) { try { _bmFaviconIO.disconnect(); } catch (_) {} }
}

// ═══════════════════════════════════════════════════
// ─── Global Drag & Drop System (v2 — folder-aware) ───
// ═══════════════════════════════════════════════════
// (old _bmDrag replaced by DD below)

// ─────────────── New DD system below ───────────────

// ═══════════════════════════════════════════════════════════════
// ─── DRAG & DROP SYSTEM v3  (List-mode + Grid/Folders-mode) ────
// ═══════════════════════════════════════════════════════════════
//
//  LIST mode  (#bookmarkList:not(.grid-view)):
//    • Shows a thin horizontal LINE between siblings
//    • Hover a closed folder  →  highlight + auto-open after 700 ms
//    • Hover an open folder header strip (top/bottom 14 px)  →  reorder as sibling
//    • Hover folder middle  →  drop INTO folder
//    • Works at any nesting depth
//
//  GRID / FOLDERS mode  (#bookmarkList.folders-only-view  or  grid-view):
//    • Shows a CELL PLACEHOLDER between grid items in the same .bm-col
//    • Drag a card to another column → drops at nearest position
//    • Hover a folder card's middle → drop INTO that folder
//    • Drag OUT of a column → moves to root level at nearest position
// ───────────────────────────────────────────────────────────────

const DD = {
    el:             null,   // LI being dragged
    id:             null,   // bookmark ID
    originParentId: null,   // original chrome parent ID
    originIdx:      null,   // original index in parent
    indicator:      null,   // <li class="bm-drop-indicator">
    elRect:         null,   // saved BoundingRect of dragged el (before display:none)
    folderTarget:   null,   // folder LI currently highlighted
    folderTimer:    null,   // auto-open timer
    sectionDragId:  null,   // section ID when dragging a section divider
    sectionAfterId: null,   // live afterId while dragging a section
    sectionShield:  null,   // transparent overlay blocking native link hover during section drag
    sectionPointerPending: null,
    sectionPointerId: null,
    sectionPointerActive: false,
    sectionPointerLastClientY: null,
    sectionAutoScrollRaf: 0,
    sectionGhost: null,
    sectionGhostOffsetX: 0,
    sectionGhostOffsetY: 0,
    sectionMutedEls: [],
    sectionPrevNoShadowBookmarks: null,
    dragPointerLastClientX: null,
    dragPointerLastClientY: null,
    dragPointerLastTarget: null,
    dragTrackRaf: 0,
    dragNeedsUpdate: false,
    dragNeedsTargetRefresh: false,
    dragAutoScrollActive: false,
    dragSourceMoveHandler: null,
    dragGhost: null,
    dragGhostOffsetX: 0,
    dragGhostOffsetY: 0,
    lastTargetId: null,
    lastTargetIndex: null,
};

const DD_EDGE_SCROLL_ZONE = 88;
const DD_EDGE_SCROLL_MAX_STEP = 42;

// Chrome fires a spurious "click" event on the element under the cursor right after
// dragend. Without this flag the folder toggling open/closed unexpectedly after a drag.
let _bmDragJustEnded = false;
let _bmLastTargetLi = null;
let _bmDragAnimationFrame = null;

// ───── helpers ─────

function DD_isGridMode()  { return bookmarkList.classList.contains("grid-view"); }
// Folder drag should use the special column logic only when the DOM is actually
// rendered in column groups; plain list view falls back to the normal list path.
function DD_isFolderMode(){ return DD_isGridMode() || !!bookmarkList.querySelector(".bm-folders-columns, .bm-folders-outer"); }

function DD_getIndicator() {
    if (!DD.indicator) {
        const el = document.createElement("li");
        el.className  = "bm-drop-indicator";
        el.draggable  = false;
        DD.indicator  = el;
    }
    return DD.indicator;
}

function DD_isPointerInsideCurrentIndicator(clientX, clientY, padX = 18, padY = 14) {
    const ind = DD.indicator;
    if (!ind?.parentElement) return false;
    if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return false;

    const rect = ind.getBoundingClientRect();
    if (!rect || rect.width <= 0 || rect.height <= 0) return false;

    return (
        clientX >= rect.left - padX &&
        clientX <= rect.right + padX &&
        clientY >= rect.top - padY &&
        clientY <= rect.bottom + padY
    );
}

function DD_clearIndicator() {
    const hasSectionPreview = !!bookmarkList.querySelector(".bm-section-ind-wrapper")
        || DD.indicator?.dataset?.mode === "section";
    if (hasSectionPreview) {
        const { root, mode, nodes } = _bmFlattenTopLevelDisplayNodes();
        if (DD.sectionDragId && DD.el?.classList?.contains("bm-section-divider") && !nodes.includes(DD.el)) {
            const originalSection = _bmGetSections().find(s => s.id === DD.sectionDragId) || { afterId: "start", bookmarkIndex: 0 };
            nodes.splice(_bmGetSectionInsertIndex(nodes, originalSection), 0, DD.el);
        }
        if (root) _bmRenderSectionPreviewNodes(root, mode, nodes);
    }
    DD.indicator?.parentElement?.removeChild(DD.indicator);
}

function DD_clearFolderTarget() {
    clearTimeout(DD.folderTimer);
    DD.folderTimer = null;
    if (DD.folderTarget) {
        DD.folderTarget.classList.remove("bm-drag-over");
        DD.folderTarget = null;
        DD_clearDragHints();
    }
}

function DD_clearDragHints() {
    document.querySelectorAll(".bm-drag-into-hover, .bm-drag-swap-hover").forEach(el => {
        el.classList.remove("bm-drag-into-hover", "bm-drag-swap-hover");
        el.removeAttribute("data-drag-hint");
    });
}

const DD_FOLDER_HOVER_DELAY = 400;
const DD_FOLDER_ENTER_GUTTER = 12;
const DD_FOLDER_EXIT_GUTTER = 8;

function DD_isOverFolderDropZone(targetLi, clientX, clientY) {
    if (!targetLi || !targetLi.classList.contains("folder")) return false;
    if (targetLi === DD.el || DD.el.contains(targetLi)) return false;

    const r = targetLi.getBoundingClientRect();
    
    // Split vertically to support all layouts (LTR/RTL) and languages:
    // The middle 50% height of the card is the Drop-into zone (returns true).
    // The top 25% and bottom 25% are the Swap/Reorder zones (returns false).
    const middleTop = r.top + r.height * 0.25;
    const middleBottom = r.bottom - r.height * 0.25;
    return clientY >= middleTop && clientY <= middleBottom;
}

function DD_hoverFolder(folderLi) {
    if (!folderLi || _bmIsVirtualFolderLi(folderLi)) return;
    if (!DD.el || folderLi === DD.el || DD.el.contains(folderLi) || folderLi.contains(DD.el)) return;

    if (_bmLastTargetLi) {
        DD_clearPlaceholders();
    }

    if (DD.folderTarget === folderLi) return;
    DD_clearFolderTarget();
    DD.folderTarget = folderLi;
    
    // Clear sibling drop indicator immediately so we don't display it while hovering over a folder to drop inside
    DD_clearIndicator();

    DD.folderTimer = setTimeout(() => {
        if (DD.folderTarget === folderLi) {
            folderLi.classList.add("bm-drag-over");
        }
    }, DD_FOLDER_HOVER_DELAY);
}

function DD_getScrollContainer() {
    const candidates = [bookmarkList, bookmarkSidebar].filter(Boolean);
    for (const el of candidates) {
        if ((el.scrollHeight - el.clientHeight) > 1 || (el.scrollWidth - el.clientWidth) > 1) {
            return el;
        }
    }
    return bookmarkList || bookmarkSidebar;
}

function DD_unionClientRect(elements, fallbackRect) {
    const rects = elements
        .map(el => el?.getBoundingClientRect?.())
        .filter(rect => rect && rect.width > 0 && rect.height > 0);

    if (!rects.length) return fallbackRect;

    let left = rects[0].left;
    let top = rects[0].top;
    let right = rects[0].right;
    let bottom = rects[0].bottom;

    for (let i = 1; i < rects.length; i++) {
        const rect = rects[i];
        left = Math.min(left, rect.left);
        top = Math.min(top, rect.top);
        right = Math.max(right, rect.right);
        bottom = Math.max(bottom, rect.bottom);
    }

    return {
        left,
        top,
        right,
        bottom,
        width: Math.max(1, right - left),
        height: Math.max(1, bottom - top),
    };
}

function DD_copyComputedStyleProps(sourceEl, targetEl, props) {
    if (!sourceEl || !targetEl || !props?.length) return null;
    const styles = getComputedStyle(sourceEl);
    props.forEach((prop) => {
        const value = styles.getPropertyValue(prop);
        if (value) targetEl.style.setProperty(prop, value, styles.getPropertyPriority(prop));
    });
    return styles;
}

function DD_setNativeDragCursor(active) {
    document.body.classList.toggle("bm-native-bookmark-dragging", !!active);
    document.documentElement.classList.toggle("bm-native-bookmark-dragging", !!active);
}

function DD_getGhostIconNode(sourceLi, isFolder) {
    const iconSource = isFolder
        ? sourceLi.querySelector(":scope > img, :scope > svg, :scope > .favicon")
        : sourceLi.querySelector(":scope > a > .favicon, :scope > a > img, :scope > a > svg");

    if (!iconSource) return null;

    const iconRect = iconSource.getBoundingClientRect();
    const iconStyles = getComputedStyle(iconSource);
    const iconWidth = `${Math.max(16, Math.round(iconRect.width || parseFloat(iconStyles.width) || 18))}px`;
    const iconHeight = `${Math.max(16, Math.round(iconRect.height || parseFloat(iconStyles.height) || 18))}px`;

    if (iconSource.tagName === "IMG") {
        const img = document.createElement("img");
        img.src = iconSource.currentSrc || iconSource.src || "";
        img.alt = "";
        img.draggable = false;
        img.decoding = "async";
        img.style.cssText = [
            `width:${iconWidth}`,
            `height:${iconHeight}`,
            "display:block",
            "object-fit:contain",
            "pointer-events:none",
            "user-select:none",
            "flex:none",
        ].join(";");
        return img;
    }

    const clone = iconSource.cloneNode(true);
    if (clone.nodeType === Node.ELEMENT_NODE) {
        clone.removeAttribute("id");
        clone.removeAttribute("draggable");
        clone.style.cssText = [
            `width:${iconWidth}`,
            `height:${iconHeight}`,
            "display:block",
            "pointer-events:none",
            "flex:none",
            "margin:0",
            "filter:none",
            "box-shadow:none",
            "transform:none",
        ].join(";");
    }
    return clone;
}

function DD_buildFolderDragGhostVisual(sourceLi, fallbackRect) {
    const headerRect = DD_unionClientRect(
        Array.from(sourceLi.children).filter(child =>
            child &&
            child.tagName !== "UL" &&
            !child.classList?.contains("bookmark-delete-button")
        ),
        fallbackRect
    );
    const sourceRect = {
        left: fallbackRect.left,
        top: headerRect.top,
        right: fallbackRect.right,
        bottom: headerRect.bottom,
        width: Math.max(1, fallbackRect.width),
        height: Math.max(1, headerRect.height),
    };

    const titleSource = sourceLi.querySelector(":scope > .bm-folder-title");
    const title = titleSource?.textContent?.trim() || sourceLi.dataset?.title || "Folder";
    const liStyles = getComputedStyle(sourceLi);

    const card = document.createElement("div");
    card.className = "bm-native-drag-card bm-native-drag-card-folder";
    card.style.cssText = [
        "width:100%",
        "height:100%",
        "display:flex",
        "align-items:center",
        `gap:${liStyles.gap || "8px"}`,
        `padding:${liStyles.paddingTop} ${liStyles.paddingRight} ${liStyles.paddingBottom} ${liStyles.paddingLeft}`,
        "box-sizing:border-box",
        "border-radius:16px",
        "border:1px solid color-mix(in srgb, var(--darkColor-blue) 20%, transparent)",
        "background:var(--bg-color-blue)",
        "color:var(--textColorDark-blue)",
        "box-shadow:none",
        "filter:none",
        "backdrop-filter:none",
        "overflow:hidden",
        "pointer-events:none",
        "transform:none",
        "transition:none",
        "animation:none",
    ].join(";");

    const outlineWidth = parseFloat(liStyles.outlineWidth || "0");
    if (liStyles.outlineStyle && liStyles.outlineStyle !== "none" && outlineWidth > 0) {
        card.style.outline = `${liStyles.outlineWidth} ${liStyles.outlineStyle} ${liStyles.outlineColor}`;
        card.style.outlineOffset = liStyles.outlineOffset;
    }

    const iconNode = DD_getGhostIconNode(sourceLi, true);
    if (iconNode) card.appendChild(iconNode);

    const label = document.createElement("span");
    label.textContent = title;
    label.style.cssText = [
        "display:block",
        "min-width:0",
        "flex:1 1 auto",
        "overflow:hidden",
        "text-overflow:ellipsis",
        "white-space:nowrap",
        "pointer-events:none",
        "user-select:none",
    ].join(";");
    DD_copyComputedStyleProps(titleSource || sourceLi, label, [
        "color",
        "font",
        "font-size",
        "font-weight",
        "font-family",
        "line-height",
        "letter-spacing",
        "text-transform",
        "text-align",
    ]);
    card.appendChild(label);

    return {
        rect: sourceRect,
        clone: card,
        radius: "16px",
    };
}

function DD_buildDragGhostVisual(sourceLi) {
    if (!sourceLi) return null;

    const isFolder = sourceLi.classList.contains("folder");
    const fallbackRect = sourceLi.getBoundingClientRect();
    if (isFolder) {
        return DD_buildFolderDragGhostVisual(sourceLi, fallbackRect);
    }

    const sourceRect = sourceLi.querySelector(":scope > a")?.getBoundingClientRect() || fallbackRect;

    const title = (
        sourceLi.querySelector(":scope > a > span")?.textContent
    )?.trim() || sourceLi.dataset?.title || "";

    const card = document.createElement("div");
    card.className = "bm-native-drag-card";
    card.style.cssText = [
        "width:100%",
        "height:100%",
        "display:flex",
        "align-items:center",
        "gap:10px",
        "padding:10px 12px",
        "box-sizing:border-box",
        "border-radius:16px",
        "border:1px solid color-mix(in srgb, var(--darkColor-blue) 20%, transparent)",
        "background:var(--bg-color-blue)",
        "color:var(--textColorDark-blue)",
        "box-shadow:none",
        "filter:none",
        "backdrop-filter:none",
        "overflow:hidden",
        "pointer-events:none",
        "transform:none",
        "transition:none",
        "animation:none",
    ].join(";");

    const iconWrap = document.createElement("div");
    iconWrap.style.cssText = [
        "width:28px",
        "height:28px",
        "display:flex",
        "align-items:center",
        "justify-content:center",
        "border-radius:10px",
        "background:rgba(255,255,255,0.04)",
        "flex:none",
        "overflow:hidden",
        "pointer-events:none",
    ].join(";");

    const iconNode = DD_getGhostIconNode(sourceLi, isFolder);
    if (iconNode) iconWrap.appendChild(iconNode);

    const label = document.createElement("span");
    label.textContent = title || (isFolder ? "Folder" : "Bookmark");
    label.style.cssText = [
        "display:block",
        "min-width:0",
        "flex:1 1 auto",
        "overflow:hidden",
        "text-overflow:ellipsis",
        "white-space:nowrap",
        "font:600 13px/1.25 'Segoe UI', sans-serif",
        "letter-spacing:0",
        "pointer-events:none",
        "user-select:none",
    ].join(";");

    card.appendChild(iconWrap);
    card.appendChild(label);

    return {
        rect: sourceRect,
        clone: card,
        radius: "16px",
    };
}

function DD_createDragGhost(sourceLi, clientX, clientY) {
    DD_removeDragGhost();
    if (!sourceLi) return null;

    const built = DD_buildDragGhostVisual(sourceLi);
    if (!built?.rect || !built?.clone) return null;

    const visualRect = built.rect;
    const width = Math.max(96, Math.round(visualRect.width || sourceLi.getBoundingClientRect().width || 1));
    const height = Math.max(44, Math.round(visualRect.height || sourceLi.getBoundingClientRect().height || 1));
    const offsetX = Number.isFinite(clientX) ? Math.min(Math.max(clientX - visualRect.left, 0), width) : Math.round(width / 2);
    const offsetY = Number.isFinite(clientY) ? Math.min(Math.max(clientY - visualRect.top, 0), height) : Math.round(height / 2);

    const ghost = document.createElement("div");
    ghost.className = "bm-native-drag-ghost";
    ghost.setAttribute("aria-hidden", "true");
    ghost.style.setProperty("position", "fixed", "important");
    ghost.style.setProperty("top", "0", "important");
    ghost.style.setProperty("left", "0", "important");
    ghost.style.setProperty("width", `${width}px`, "important");
    ghost.style.setProperty("height", `${height}px`, "important");
    ghost.style.setProperty("min-height", `${height}px`, "important");
    ghost.style.setProperty("margin", "0", "important");
    ghost.style.setProperty("padding", "0", "important");
    ghost.style.setProperty("pointer-events", "none", "important");
    ghost.style.setProperty("z-index", "100000", "important");
    ghost.style.setProperty("opacity", "0.82", "important");
    ghost.style.setProperty("box-sizing", "border-box", "important");
    ghost.style.setProperty("transition", "none", "important");
    ghost.style.setProperty("animation", "none", "important");
    ghost.style.setProperty("will-change", "transform", "important");
    ghost.style.setProperty("contain", "layout paint style", "important");
    ghost.style.setProperty("transform", "translate3d(-9999px, -9999px, 0)", "important");
    ghost.style.setProperty("backface-visibility", "hidden", "important");
    ghost.style.setProperty("overflow", "hidden", "important");
    ghost.style.setProperty("border-radius", built.radius || "16px", "important");

    const visualClone = built.clone;
    ghost.appendChild(visualClone);
    document.body.appendChild(ghost);

    DD.dragGhost = ghost;
    DD.dragGhostOffsetX = offsetX;
    DD.dragGhostOffsetY = offsetY;
    DD_positionDragGhost(clientX, clientY);
    return ghost;
}

function DD_positionDragGhost(clientX, clientY) {
    if (!DD.dragGhost || !Number.isFinite(clientX) || !Number.isFinite(clientY)) return;
    const left = Math.round(clientX - DD.dragGhostOffsetX);
    const top = Math.round(clientY - DD.dragGhostOffsetY);
    DD.dragGhost.style.transform = `translate3d(${left}px, ${top}px, 0)`;
}

function DD_removeDragGhost() {
    if (DD.dragGhost?.parentElement) DD.dragGhost.parentElement.removeChild(DD.dragGhost);
    DD.dragGhost = null;
    DD.dragGhostOffsetX = 0;
    DD.dragGhostOffsetY = 0;
}

function DD_getSectionDragShield() {
    if (DD.sectionShield) return DD.sectionShield;

    const shield = document.createElement("div");
    shield.className = "bm-section-drag-shield";
    shield.style.cssText = "position:fixed;background:transparent;pointer-events:auto;touch-action:none;z-index:9998;display:none;";

    const stopShieldEvent = (e) => {
        if (!DD.sectionDragId && !DD.sectionPointerActive && !DD.sectionPointerPending) return;
        e.preventDefault();
        e.stopPropagation();
    };

    shield.addEventListener("dragenter", (e) => {
        if (DD.sectionDragId) {
            e.preventDefault();
            e.stopPropagation();
        }
    });
    shield.addEventListener("dragover", (e) => {
        if (DD.sectionDragId) DD_onDragover(e);
    });
    shield.addEventListener("drop", (e) => {
        if (DD.sectionDragId) DD_onDrop(e);
    });
    shield.addEventListener("pointerdown", stopShieldEvent, true);
    shield.addEventListener("pointermove", stopShieldEvent, true);
    shield.addEventListener("pointerup", stopShieldEvent, true);
    shield.addEventListener("pointercancel", stopShieldEvent, true);
    shield.addEventListener("mousemove", stopShieldEvent, true);
    shield.addEventListener("mouseover", stopShieldEvent, true);
    shield.addEventListener("mouseenter", stopShieldEvent, true);
    shield.addEventListener("mouseout", stopShieldEvent, true);
    shield.addEventListener("wheel", (e) => {
        if (!DD.sectionDragId && !DD.sectionPointerActive && !DD.sectionPointerPending) return;
        DD_onSidebarWheel(e);
        e.stopPropagation();
    }, { passive: false });

    document.body.appendChild(shield);
    DD.sectionShield = shield;
    return shield;
}

function DD_showSectionDragShield() {
    if (!bookmarkList) return;
    if (!DD.sectionDragId && !DD.sectionPointerActive && !DD.sectionPointerPending) return;

    const shield = DD_getSectionDragShield();
    const listRect = bookmarkList.getBoundingClientRect();

    shield.style.top = `${Math.round(listRect.top)}px`;
    shield.style.left = `${Math.round(listRect.left)}px`;
    shield.style.width = `${Math.round(listRect.width)}px`;
    shield.style.height = `${Math.round(listRect.height)}px`;
    shield.style.display = "block";
}

function DD_hideSectionDragShield() {
    if (DD.sectionShield) DD.sectionShield.style.display = "none";
}

function DD_applySectionNoShadowInlineStyles() {
    DD.sectionMutedEls = [];
}

function DD_restoreSectionNoShadowInlineStyles() {
    (DD.sectionMutedEls || []).forEach(({ el, saved }) => {
        if (!el) return;
        saved.forEach(({ prop, value, priority }) => {
            if (value) el.style.setProperty(prop, value, priority);
            else el.style.removeProperty(prop);
        });
    });
    DD.sectionMutedEls = [];
}

function DD_createSectionGhost(sourceLi) {
    DD_removeSectionGhost();
    if (!sourceLi) return null;

    const titleSource = sourceLi.querySelector(".bm-section-title");
    const sourceStyles = getComputedStyle(sourceLi);
    const titleStyles = titleSource ? getComputedStyle(titleSource) : null;

    const ghost = document.createElement("div");
    ghost.className = "bm-section-drag-ghost";
    ghost.style.position = "fixed";
    ghost.style.top = "0";
    ghost.style.left = "0";
    ghost.style.width = `${Math.round(DD.elRect?.width || sourceLi.getBoundingClientRect().width)}px`;
    ghost.style.height = `${Math.round(DD.elRect?.height || sourceLi.getBoundingClientRect().height)}px`;
    ghost.style.margin = "0";
    ghost.style.padding = sourceStyles.padding;
    ghost.style.pointerEvents = "none";
    ghost.style.zIndex = "10000";
    ghost.style.opacity = "0.98";
    ghost.style.boxSizing = "border-box";
    ghost.style.background = "color-mix(in srgb, var(--darkColor-blue) 14%, var(--ui-sep))";
    ghost.style.border = "1px solid color-mix(in srgb, var(--darkColor-blue) 24%, transparent)";
    ghost.style.borderRadius = "12px";
    ghost.style.boxShadow = "0 12px 30px color-mix(in srgb, black 28%, transparent)";
    ghost.style.transform = "translate(-9999px, -9999px)";
    ghost.style.overflow = "hidden";

    const title = document.createElement("span");
    title.className = "bm-section-title";
    title.textContent = titleSource?.textContent || "";
    title.style.display = "block";
    title.style.width = "100%";
    title.style.paddingBottom = titleStyles?.paddingBottom || "6px";
    title.style.borderBottom = titleStyles?.borderBottom || `2px solid ${titleStyles?.color || "var(--darkColor-blue)"}`;
    title.style.color = titleStyles?.color || "var(--darkColor-blue)";
    title.style.opacity = titleStyles?.opacity || "1";
    title.style.background = titleStyles?.background || "none";
    title.style.backgroundClip = titleStyles?.backgroundClip || "border-box";
    title.style.webkitBackgroundClip = titleStyles?.webkitBackgroundClip || "border-box";
    title.style.webkitTextFillColor = titleStyles?.webkitTextFillColor || "";
    DD_copyComputedStyleProps(titleSource || sourceLi, title, [
        "font",
        "font-size",
        "font-weight",
        "font-family",
        "line-height",
        "letter-spacing",
        "text-transform",
        "text-align",
    ]);
    ghost.appendChild(title);
    document.body.appendChild(ghost);
    DD.sectionGhost = ghost;
    return ghost;
}

function DD_removeSectionGhost() {
    if (DD.sectionGhost?.parentElement) DD.sectionGhost.parentElement.removeChild(DD.sectionGhost);
    DD.sectionGhost = null;
}

function DD_positionSectionGhost(clientX, clientY) {
    if (!DD.sectionGhost) return;
    const left = Math.round(clientX - DD.sectionGhostOffsetX);
    const top = Math.round(clientY - DD.sectionGhostOffsetY);
    DD.sectionGhost.style.transform = `translate(${left}px, ${top}px)`;
}

function DD_teardownSectionPointerListeners() {
    document.removeEventListener("pointermove", DD_onSectionPointerMove, true);
    document.removeEventListener("pointerup", DD_onSectionPointerUp, true);
    document.removeEventListener("pointercancel", DD_onSectionPointerCancel, true);
    document.removeEventListener("keydown", DD_onSectionPointerKeydown, true);
}

function DD_clearSectionPointerHoldTimer() {
    if (DD.sectionPointerHoldTimer) {
        clearTimeout(DD.sectionPointerHoldTimer);
        DD.sectionPointerHoldTimer = null;
    }
}

function DD_stopSectionAutoScroll() {
    if (DD.sectionAutoScrollRaf) cancelAnimationFrame(DD.sectionAutoScrollRaf);
    DD.sectionAutoScrollRaf = 0;
}

function DD_tickSectionAutoScroll() {
    DD.sectionAutoScrollRaf = 0;
    if (!DD.sectionPointerActive || DD.sectionPointerLastClientY == null) return;
    const delta = DD_autoScrollSidebar(DD.sectionPointerLastClientY);
    if (delta !== 0) {
        DD_placeSectionIndicator(DD.sectionPointerLastClientY);
        DD.sectionAutoScrollRaf = requestAnimationFrame(DD_tickSectionAutoScroll);
    }
}

function DD_queueSectionAutoScroll() {
    if (DD.sectionAutoScrollRaf) return;
    DD.sectionAutoScrollRaf = requestAnimationFrame(DD_tickSectionAutoScroll);
}

function DD_resetSectionPointerState() {
    DD_clearSectionPointerHoldTimer();
    DD_stopSectionAutoScroll();
    DD_teardownSectionPointerListeners();
    DD_removeSectionGhost();
    DD_hideSectionDragShield();
    DD_restoreSectionNoShadowInlineStyles();
    bookmarkList.classList.remove("bm-section-drag-active");
    document.body.classList.remove("bm-section-pointer-dragging");
    DD.sectionPrevNoShadowBookmarks = null;
    DD.sectionPointerPending = null;
    DD.sectionPointerId = null;
    DD.sectionPointerActive = false;
    DD.sectionPointerLastClientY = null;
    DD.sectionGhostOffsetX = 0;
    DD.sectionGhostOffsetY = 0;
}

function DD_finishSectionPointerDrag(commit) {
    const hadActiveDrag = DD.sectionPointerActive;
    const draggedSectionId = DD.sectionDragId || DD.sectionPointerPending?.sectionId || null;
    const newAfterId = commit && DD.sectionDragId ? _bmGetAfterIdFromIndicator() : null;
    const draggedSectionEl = DD.el;

    if (DD.el) {
        DD.el.classList.remove("bm-dragging");
        if (!commit || !draggedSectionId) {
            DD.el.style.display = "";
            DD.el.style.visibility = "";
        }
    }

    DD_clearIndicator();
    DD_clearFolderTarget();
    DD_resetSectionPointerState();

    DD.el = null;
    DD.id = null;
    DD.originParentId = null;
    DD.originIdx = null;
    DD.originNextSiblingId = null;
    DD.elRect = null;
    DD.sectionDragId = null;
    DD.sectionAfterId = null;

    if (hadActiveDrag) {
        _bmDragJustEnded = true;
        setTimeout(() => { _bmDragJustEnded = false; }, 300);
    }

    if (commit && draggedSectionId) {
        Promise.resolve(_bmCommitSectionMove(draggedSectionId, newAfterId)).finally(() => {
            if (draggedSectionEl?.isConnected) {
                draggedSectionEl.style.display = "";
                draggedSectionEl.style.visibility = "";
                draggedSectionEl.classList.remove("bm-dragging");
            }
        });
    }
}

function DD_startSectionPointerDrag(e) {
    const pending = DD.sectionPointerPending;
    if (!pending || DD.sectionPointerActive) return;
    DD_clearSectionPointerHoldTimer();

    const { li, sectionId, offsetX, offsetY } = pending;
    const rect = li.getBoundingClientRect();

    DD.el = li;
    DD.id = null;
    DD.originParentId = null;
    DD.originIdx = null;
    DD.originNextSiblingId = null;
    DD.sectionDragId = sectionId;
    DD.sectionAfterId = null;
    DD.elRect = { width: rect.width, height: rect.height };
    DD.sectionGhostOffsetX = offsetX;
    DD.sectionGhostOffsetY = offsetY;
    DD.sectionPointerActive = true;
    DD.sectionPointerLastClientY = e.clientY;

    bookmarkList.classList.add("bm-section-drag-active");
    document.body.classList.add("bm-section-pointer-dragging");
    DD_showSectionDragShield();

    li.classList.add("bm-dragging");
    li.style.visibility = "hidden";

    DD_createSectionGhost(li);
    DD_positionSectionGhost(e.clientX, e.clientY);
    DD_placeSectionIndicator(e.clientY);
}

function DD_onSectionPointerMove(e) {
    if (DD.sectionPointerId !== null && e.pointerId !== DD.sectionPointerId) return;
    if (!DD.sectionPointerPending && !DD.sectionPointerActive) return;

    if (!DD.sectionPointerActive) {
        const pending = DD.sectionPointerPending;
        if (!pending) return;
        const dx = e.clientX - pending.startX;
        const dy = e.clientY - pending.startY;
        if (Math.hypot(dx, dy) < 6) return;
        DD_clearSectionPointerHoldTimer();
        DD_startSectionPointerDrag(e);
    }

    if (!DD.sectionPointerActive) return;

    e.preventDefault();
    e.stopPropagation();
    DD.sectionPointerLastClientY = e.clientY;
    DD_positionSectionGhost(e.clientX, e.clientY);
    const delta = DD_autoScrollSidebar(e.clientY);
    DD_placeSectionIndicator(e.clientY);
    if (delta !== 0) DD_queueSectionAutoScroll();
    else DD_stopSectionAutoScroll();
}

function DD_onSectionPointerUp(e) {
    if (DD.sectionPointerId !== null && e.pointerId !== DD.sectionPointerId) return;
    e.preventDefault();
    e.stopPropagation();
    DD_finishSectionPointerDrag(DD.sectionPointerActive);
}

function DD_onSectionPointerCancel(e) {
    if (DD.sectionPointerId !== null && e.pointerId !== DD.sectionPointerId) return;
    DD_finishSectionPointerDrag(false);
}

function DD_onSectionPointerKeydown(e) {
    if (e.key !== "Escape") return;
    e.preventDefault();
    DD_finishSectionPointerDrag(false);
}

function DD_beginSectionPointerDrag(li, sectionId, e) {
    if (!li || DD.el || DD.sectionPointerPending) return;

    e.preventDefault();
    e.stopPropagation();

    const rect = li.getBoundingClientRect();
    DD.sectionPointerPending = {
        li,
        sectionId,
        startX: e.clientX,
        startY: e.clientY,
        offsetX: e.clientX - rect.left,
        offsetY: e.clientY - rect.top,
    };
    DD.sectionPointerId = e.pointerId;

    document.addEventListener("pointermove", DD_onSectionPointerMove, true);
    document.addEventListener("pointerup", DD_onSectionPointerUp, true);
    document.addEventListener("pointercancel", DD_onSectionPointerCancel, true);
    document.addEventListener("keydown", DD_onSectionPointerKeydown, true);
    DD_startSectionPointerDrag(e);
}

function DD_captureNativeDragPoint(clientX, clientY, target = null) {
    if ((clientX === 0 && clientY === 0)
            && (DD.dragPointerLastClientX !== null || DD.dragPointerLastClientY !== null)) {
        return;
    }
    let changed = false;
    if (Number.isFinite(clientX) && DD.dragPointerLastClientX !== clientX) {
        DD.dragPointerLastClientX = clientX;
        changed = true;
    }
    if (Number.isFinite(clientY) && DD.dragPointerLastClientY !== clientY) {
        DD.dragPointerLastClientY = clientY;
        changed = true;
    }
    if (target?.nodeType === Node.ELEMENT_NODE && DD.dragPointerLastTarget !== target) {
        DD.dragPointerLastTarget = target;
        changed = true;
    }
    if (DD.el && !DD.sectionDragId) {
        DD_positionDragGhost(DD.dragPointerLastClientX, DD.dragPointerLastClientY);
        if (changed) {
            DD.dragNeedsUpdate = true;
            DD_startNativeDragTracking();
        }
    }
}

function DD_resolveNativeDragTarget() {
    const x = DD.dragPointerLastClientX;
    const y = DD.dragPointerLastClientY;
    let target = DD.dragPointerLastTarget;

    if ((DD.dragNeedsTargetRefresh || !target || !document.documentElement.contains(target) || target === DD.indicator)
            && Number.isFinite(x) && Number.isFinite(y)) {
        target = document.elementFromPoint(x, y) || target;
    }

    if (target === DD.indicator) {
        target = DD.indicator?.parentElement || bookmarkList;
    }

    DD.dragNeedsTargetRefresh = false;
    return target || bookmarkList;
}

function DD_makeSyntheticDragEvent(clientX, clientY, target) {
    return {
        clientX,
        clientY,
        target: target || bookmarkList,
        dataTransfer: { dropEffect: "move" },
        preventDefault() {},
        stopPropagation() {},
    };
}

function DD_tickNativeDragTracking() {
    DD.dragTrackRaf = 0;
    if (!DD.el || DD.sectionDragId) return;

    const clientX = DD.dragPointerLastClientX;
    const clientY = DD.dragPointerLastClientY;
    const shouldProcess = DD.dragNeedsUpdate || DD.dragAutoScrollActive || DD.dragNeedsTargetRefresh;
    DD.dragAutoScrollActive = false;

    if (shouldProcess && Number.isFinite(clientX) && Number.isFinite(clientY)) {
        DD_positionDragGhost(clientX, clientY);
        const target = DD_resolveNativeDragTarget();
        DD.dragNeedsUpdate = false;
        DD_onDragover(DD_makeSyntheticDragEvent(clientX, clientY, target));
    }

    if (DD.el && !DD.sectionDragId && (DD.dragNeedsUpdate || DD.dragAutoScrollActive || DD.dragNeedsTargetRefresh)) {
        DD.dragTrackRaf = requestAnimationFrame(DD_tickNativeDragTracking);
    }
}

function DD_startNativeDragTracking() {
    if (DD.dragTrackRaf || !DD.el || DD.sectionDragId) return;
    DD.dragTrackRaf = requestAnimationFrame(DD_tickNativeDragTracking);
}

function DD_stopNativeDragTracking() {
    if (DD.dragTrackRaf) cancelAnimationFrame(DD.dragTrackRaf);
    DD.dragTrackRaf = 0;
    DD.dragNeedsUpdate = false;
    DD.dragNeedsTargetRefresh = false;
    DD.dragAutoScrollActive = false;
    DD_setNativeDragCursor(false);
    DD_removeDragGhost();
    DD.dragPointerLastClientX = null;
    DD.dragPointerLastClientY = null;
    DD.dragPointerLastTarget = null;
}

function DD_onGlobalDragover(e) {
    if (!DD.el || DD.sectionDragId) return;
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = "move";
    DD_captureNativeDragPoint(e.clientX, e.clientY, e.target);
    if (!bookmarkList.contains(e.target)) {
        DD_clearPlaceholders();
        DD_clearIndicator();
        DD_clearFolderTarget();
    }
}

function DD_autoScrollSidebar(clientY) {
    const scrollContainer = DD_getScrollContainer();
    if (!scrollContainer || !bookmarkSidebar || !bookmarkSidebar.classList.contains("open")) return 0;

    const rect = scrollContainer.getBoundingClientRect();
    const topDistance = clientY - rect.top;
    const bottomDistance = rect.bottom - clientY;
    let delta = 0;

    if (topDistance >= 0 && topDistance < DD_EDGE_SCROLL_ZONE) {
        const intensity = (DD_EDGE_SCROLL_ZONE - topDistance) / DD_EDGE_SCROLL_ZONE;
        delta = -Math.ceil(6 + intensity * DD_EDGE_SCROLL_MAX_STEP);
    } else if (bottomDistance >= 0 && bottomDistance < DD_EDGE_SCROLL_ZONE) {
        const intensity = (DD_EDGE_SCROLL_ZONE - bottomDistance) / DD_EDGE_SCROLL_ZONE;
        delta = Math.ceil(6 + intensity * DD_EDGE_SCROLL_MAX_STEP);
    }

    if (delta !== 0) {
        scrollContainer.scrollTop += delta;
        if (DD.el && !DD.sectionDragId) {
            DD.dragNeedsTargetRefresh = true;
        }
    }
    if (DD.el && !DD.sectionDragId) {
        DD.dragAutoScrollActive = delta !== 0;
    }
    return delta;
}

function DD_onSidebarWheel(e) {
    if (!DD.el) return;
    const scrollContainer = DD_getScrollContainer();
    if (!scrollContainer) return;
    e.preventDefault();
    e.stopPropagation();
    scrollContainer.scrollBy({ top: e.deltaY, left: 0, behavior: "auto" });
    const midX = DD.dragPointerLastClientX ?? (scrollContainer.getBoundingClientRect().left + scrollContainer.clientWidth / 2);
    const midY = DD.dragPointerLastClientY ?? (scrollContainer.getBoundingClientRect().top + scrollContainer.clientHeight / 2);
    if (DD.el && !DD.sectionDragId) {
        DD_captureNativeDragPoint(midX, midY, DD_resolveNativeDragTarget());
        DD.dragNeedsTargetRefresh = true;
        DD.dragNeedsUpdate = true;
        DD_startNativeDragTracking();
    }
    requestAnimationFrame(() => {
        if (DD.sectionPointerActive && DD.sectionPointerLastClientY != null) {
            DD_placeSectionIndicator(DD.sectionPointerLastClientY);
        }
    });
}

function DD_getChildIndex(li, parent) {
    return Array.from(parent.children)
        .filter(c => c !== DD.indicator)
        .indexOf(li);
}

function DD_getLeadBiasPx(height, ratio = 0.34, minPx = 10, maxPx = 26) {
    const safeHeight = Math.max(0, Number(height) || 0);
    return Math.max(minPx, Math.min(maxPx, safeHeight * ratio));
}

function DD_getBeforeThreshold(rect, ratio = 0.34, minPx = 10, maxPx = 26) {
    if (!rect) return 0;
    const bias = Math.min(
        Math.max(6, rect.height - 6),
        DD_getLeadBiasPx(rect.height, ratio, minPx, maxPx)
    );
    return rect.top + bias;
}

function DD_shouldInsertBefore(clientY, rect, ratio = 0.34, minPx = 10, maxPx = 26) {
    return clientY < DD_getBeforeThreshold(rect, ratio, minPx, maxPx);
}

function DD_insertIndicatorAfterItem(item) {
    if (!item?.parentElement) return;
    DD_placeIndicator(item.parentElement, item.nextSibling);
}

function DD_resolvePointerColumn(cols, clientX, clientY, preferredCol = null) {
    if (!cols?.length) return null;

    const colsWithinX = cols.filter(col => {
        const r = col.getBoundingClientRect();
        return clientX >= r.left - 4 && clientX <= r.right + 4;
    });

    const candidates = colsWithinX.length ? colsWithinX : cols;
    let bestCol = candidates[0];
    let bestScore = Infinity;

    for (const col of candidates) {
        const r = col.getBoundingClientRect();
        const dx = clientX < r.left ? (r.left - clientX) : (clientX > r.right ? clientX - r.right : 0);
        const dy = clientY < r.top ? (r.top - clientY) : (clientY > r.bottom ? clientY - r.bottom : 0);
        const bias = (preferredCol && col === preferredCol) ? -15 : 0;
        const centerPenalty = colsWithinX.length
            ? Math.abs(clientX - (r.left + r.width / 2)) * 0.08
            : 0;
        const score = dx + (dy * 0.35) + centerPenalty + bias;
        if (score < bestScore) {
            bestScore = score;
            bestCol = col;
        }
    }

    return bestCol;
}

function DD_findInsertBeforeByPointerY(items, clientY) {
    for (const item of items) {
        const r = item.getBoundingClientRect();
        if (clientY < r.top) return item;
        if (clientY <= r.bottom) {
            const midpoint = r.top + (r.height / 2);
            if (clientY < midpoint) return item;
        }
    }
    return null;
}

function DD_collectReflowElements(parent) {
    if (!parent) return [];
    return Array.from(parent.children).filter(el =>
        el &&
        el !== DD.indicator &&
        el !== DD.el &&
        !el.classList?.contains("bm-dragging") &&
        el.style?.display !== "none"
    );
}

function DD_getReflowOrder(parent) {
    return DD_collectReflowElements(parent);
}

function DD_getDragReflowDurationMs() {
    const root = document.documentElement;
    if (!root) return 180;
    const dur = _bmParseCssTimeToMs(getComputedStyle(root).getPropertyValue("--dur-3"));
    return Math.max(120, dur || 180);
}

function DD_playDragReflow(elements, beforeRects) {
    if (DD.el && !DD.sectionDragId) return;
    if (!elements?.length || !beforeRects?.size) return;
    const durationMs = DD_getDragReflowDurationMs();

    for (const el of elements) {
        const prev = beforeRects.get(el);
        if (!prev) continue;
        const next = el.getBoundingClientRect();
        const dx = prev.left - next.left;
        const dy = prev.top - next.top;
        if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) continue;

        el.style.transition = "none";
        el.style.transform = `translate(${dx}px, ${dy}px)`;
        void el.offsetWidth;
        el.classList.add("bm-drag-reflowing");
        el.style.transition = `transform ${durationMs}ms cubic-bezier(0.22, 1, 0.36, 1)`;
        el.style.transform = "";

        const clear = () => {
            if (!el.classList.contains("bm-drag-reflowing")) return;
            el.classList.remove("bm-drag-reflowing");
            el.style.transition = "";
            el.style.transform = "";
            el.removeEventListener("transitionend", clear);
        };
        el.addEventListener("transitionend", clear);
        setTimeout(clear, durationMs + 60);
    }
}

function DD_placeIndicator(parent, before = null) {
    const ind = DD_getIndicator();
    if (!parent) return false;
    const normalizedBefore = before === ind ? ind.nextSibling : before;
    const sameParent = ind.parentElement === parent;
    const currentNext = sameParent ? ind.nextSibling : null;
    const alreadyLast = sameParent && !normalizedBefore && !currentNext;
    if ((sameParent && currentNext === normalizedBefore) || alreadyLast) {
        return false;
    }

    if (DD.el && !DD.sectionDragId) {
        if (normalizedBefore) parent.insertBefore(ind, normalizedBefore);
        else parent.appendChild(ind);
        return true;
    }

    const affectedParents = Array.from(new Set([ind.parentElement, parent].filter(Boolean)));
    const beforeRects = new Map();
    const beforeOrders = new Map();
    for (const p of affectedParents) {
        const order = DD_getReflowOrder(p);
        beforeOrders.set(p, order);
        for (const el of order) {
            if (!beforeRects.has(el)) beforeRects.set(el, el.getBoundingClientRect());
        }
    }

    if (normalizedBefore) parent.insertBefore(ind, normalizedBefore);
    else parent.appendChild(ind);

    const affectedEls = [];
    const affectedSet = new Set();
    for (const p of affectedParents) {
        const prevOrder = beforeOrders.get(p) || [];
        const nextOrder = DD_getReflowOrder(p);
        const maxLen = Math.max(prevOrder.length, nextOrder.length);
        for (let i = 0; i < maxLen; i++) {
            const prevEl = prevOrder[i] || null;
            const nextEl = nextOrder[i] || null;
            if (prevEl && prevEl !== nextEl && !affectedSet.has(prevEl)) {
                affectedSet.add(prevEl);
                affectedEls.push(prevEl);
            }
            if (nextEl && prevEl !== nextEl && !affectedSet.has(nextEl)) {
                affectedSet.add(nextEl);
                affectedEls.push(nextEl);
            }
        }
    }

    DD_playDragReflow(affectedEls, beforeRects);
    return true;
}

function DD_measureGridRows(items) {
    const measured = items
        .map(item => ({ item, rect: item.getBoundingClientRect() }))
        .filter(entry => entry.rect && entry.rect.width > 0 && entry.rect.height > 0)
        .sort((a, b) => {
            const topDiff = a.rect.top - b.rect.top;
            if (Math.abs(topDiff) > 12) return topDiff;
            return a.rect.left - b.rect.left;
        });

    const rows = [];
    for (const entry of measured) {
        const tol = Math.max(10, Math.min(26, entry.rect.height * 0.35));
        const lastRow = rows[rows.length - 1];
        if (!lastRow || Math.abs(entry.rect.top - lastRow.top) > lastRow.tolerance) {
            rows.push({
                top: entry.rect.top,
                bottom: entry.rect.bottom,
                tolerance: tol,
                entries: [entry],
            });
            continue;
        }
        lastRow.entries.push(entry);
        lastRow.bottom = Math.max(lastRow.bottom, entry.rect.bottom);
        lastRow.tolerance = Math.max(lastRow.tolerance, tol);
    }

    for (const row of rows) {
        row.entries.sort((a, b) => a.rect.left - b.rect.left);
    }
    return rows;
}

function DD_placeAcrossGridItems(items, clientX, clientY) {
    const ind = DD_getIndicator();
    if (DD_isPointerInsideCurrentIndicator(clientX, clientY, 20, 16)) {
        return;
    }
    ind.parentElement?.removeChild(ind);
    DD_sizeIndicator(DD.el || items[0] || null);

    if (!items.length) return;

    const rows = DD_measureGridRows(items);
    if (!rows.length) {
        const lastItem = items[items.length - 1];
        if (lastItem?.parentElement) lastItem.parentElement.appendChild(ind);
        return;
    }

    for (const row of rows) {
        const firstEntry = row.entries[0];
        if (!firstEntry) continue;

        if (clientY < row.top) {
            DD_placeIndicator(firstEntry.item.parentElement, firstEntry.item);
            return;
        }

        if (clientY <= row.bottom) {
            for (const entry of row.entries) {
                const beforeX = entry.rect.left + (entry.rect.width / 2);
                if (clientX < beforeX) {
                    DD_placeIndicator(entry.item.parentElement, entry.item);
                    return;
                }
            }

            DD_insertIndicatorAfterItem(row.entries[row.entries.length - 1].item);
            return;
        }
    }

    DD_insertIndicatorAfterItem(rows[rows.length - 1].entries[rows[rows.length - 1].entries.length - 1].item);
}

// ── globalIndex: position in the flat visual order ──
function DD_globalIndex(li) {
    const wrapper = li.closest(".bm-folders-columns");
    if (!wrapper) return DD_getChildIndex(li, li.parentElement);

    // Folders-only: two bm-col columns — interleave to get flat index
    const hasCols = wrapper.querySelector(":scope > .bm-col");
    if (hasCols) {
        const flatItems = _bmGetInterleavedColumnItems(wrapper)
            .filter(c => c !== DD.indicator && c.style.display !== "none");
        const idx = flatItems.indexOf(li);
        return idx >= 0 ? idx : 0;
    }

    // Grid-view flat layout: items are direct children — index directly
    const flatItems = _bmGetDirectWrapperDisplayItems(wrapper)
        .filter(c => c !== DD.indicator && c.style.display !== "none");
    const idx = flatItems.indexOf(li);
    return idx >= 0 ? idx : 0;
}

// ── commit move to Chrome API ──
function _bmGetVisibleRootOrderIdsByKind(kind) {
    return _bmGetAllDisplayOrderLIs()
        .filter(li =>
            li &&
            li.dataset?.id &&
            !_bmIsVirtualFolderId(li.dataset.id) &&
            !li.classList.contains("bm-section-divider") &&
            !li.classList.contains("bm-drop-indicator") &&
            !li.parentElement?.closest("li.folder") &&
            _bmGetNodeKindById(li.dataset.id) === kind
        )
        .map(li => String(li.dataset.id));
}

function _bmResolveRootIndexForItem(itemId, fallbackIsFolder = false, defaultIdx = 0) {
    const resolvedId = String(itemId || "");
    if (!resolvedId) return defaultIdx;

    const dragKind = _bmGetNodeKindById(resolvedId) || (fallbackIsFolder ? "folder" : "bookmark");
    const rawIds = (_bmChildrenByParentId.get(String(_bmRootParentId)) || []).map(id => String(id));
    if (!dragKind || !rawIds.includes(resolvedId)) return defaultIdx;

    const sameKindRawIds = rawIds.filter(id => _bmGetNodeKindById(id) === dragKind);
    if (!sameKindRawIds.length) return defaultIdx;

    const visibleSameKindIds = _bmGetVisibleRootOrderIdsByKind(dragKind)
        .filter(id => sameKindRawIds.includes(id));

    if (!visibleSameKindIds.includes(resolvedId)) return defaultIdx;

    const visibleSet = new Set(visibleSameKindIds);
    const orderedSameKindIds = [
        ...visibleSameKindIds,
        ...sameKindRawIds.filter(id => !visibleSet.has(id))
    ];

    let sameKindIndex = 0;
    const mergedIds = rawIds.map(id =>
        _bmGetNodeKindById(id) === dragKind
            ? orderedSameKindIds[sameKindIndex++]
            : id
    );

    const resolvedIndex = mergedIds.indexOf(resolvedId);
    return resolvedIndex >= 0 ? resolvedIndex : defaultIdx;
}

function _bmResolveRootMoveIndex(newParentId, defaultIdx) {
    if (String(newParentId) !== String(_bmRootParentId) || !DD.el?.dataset?.id) return defaultIdx;

    return _bmResolveRootIndexForItem(
        DD.el.dataset.id,
        DD.el.classList.contains("folder"),
        defaultIdx
    );
}

function _bmMoveBookmarkNode(id, params) {
    if (isFirefox) {
        return bookmarksAPI.move(id, params);
    }

    return new Promise((resolve, reject) => {
        bookmarksAPI.move(id, params, (moved) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message || "Failed to move bookmark"));
                return;
            }
            resolve(moved);
        });
    });
}

function DD_getItemParentId(li) {
    if (!li?.dataset?.id) return _bmRootParentId;

    const explicitParentId = li.dataset.parentId || null;
    const visibleParentFolderLi = li.parentElement?.closest("li.folder") || null;
    const visibleParentId = visibleParentFolderLi?.dataset?.id || null;

    if (_bmIsVirtualFolderLi(visibleParentFolderLi) && explicitParentId) {
        return explicitParentId;
    }

    return visibleParentId || explicitParentId || _bmRootParentId;
}

function DD_getBookmarkApiIndexForLi(li, parentId = DD_getItemParentId(li)) {
    if (!li?.dataset?.id) return -1;

    if (String(parentId) === String(_bmRootParentId)) {
        const liveIndex = _bmGetVisibleRootDragItems(true).indexOf(li);
        const fallbackIndex = liveIndex >= 0
            ? liveIndex
            : _bmGetStoredChildIndex(parentId, li.dataset.id);
        return _bmResolveRootIndexForItem(
            li.dataset.id,
            li.classList.contains("folder"),
            fallbackIndex
        );
    }

    if (li.parentElement?.tagName === "UL" || li.parentElement?.classList?.contains("bm-col") || li.parentElement?.tagName === "DIV") {
        return DD_getChildIndex(li, li.parentElement);
    }

    const storedIndex = _bmGetStoredChildIndex(parentId, li.dataset.id);
    return storedIndex >= 0 ? storedIndex : -1;
}

function DD_getSwapCandidateSibling(node, direction = "next") {
    let current = node || null;
    while (current) {
        if (
            current !== DD.el &&
            current !== DD.indicator &&
            current.dataset?.id &&
            !current.classList.contains("bm-section-divider") &&
            !current.classList.contains("bm-drop-indicator") &&
            current.style?.display !== "none"
        ) {
            return current;
        }
        current = direction === "prev" ? current.previousElementSibling : current.nextElementSibling;
    }
    return null;
}

function DD_isIndicatorAtOriginSlot(indicator) {
    if (!indicator?.parentElement || !DD.el?.parentElement) return false;
    if (indicator.parentElement !== DD.el.parentElement) return false;

    const nextRealSibling = DD_getSwapCandidateSibling(indicator.nextElementSibling, "next");
    if (DD.originNextSiblingId) {
        return String(nextRealSibling?.dataset?.id || "") === String(DD.originNextSiblingId);
    }

    return !nextRealSibling;
}

function DD_getSwapTargetFromIndicator(indicator) {
    if (!indicator?.parentElement) return null;

    return DD_getSwapCandidateSibling(indicator.nextElementSibling, "next")
        || DD_getSwapCandidateSibling(indicator.previousElementSibling, "prev")
        || null;
}

function DD_swapDomItems(el1, el2) {
    const parent1 = el1.parentElement;
    const parent2 = el2.parentElement;
    
    if (!parent1 || !parent2) return;

    const next1 = el1.nextSibling;
    const next2 = el2.nextSibling;

    // Handle adjacent elements to prevent DOM detachment bugs
    if (next1 === el2) {
        parent1.insertBefore(el2, el1);
    } else if (next2 === el1) {
        parent1.insertBefore(el1, el2);
    } else {
        // Handle distant elements swap
        parent1.insertBefore(el2, next1);
        parent2.insertBefore(el1, next2);
    }
}

function DD_updateCacheAfterSameParentSwap(parentId, sourceId, targetId) {
    const normalizedParentId = String(parentId || "");
    const childIds = _bmChildrenByParentId.get(normalizedParentId);
    if (!Array.isArray(childIds) || !childIds.length) return;

    const sourceIndex = childIds.indexOf(String(sourceId || ""));
    const targetIndex = childIds.indexOf(String(targetId || ""));
    if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;

    [childIds[sourceIndex], childIds[targetIndex]] = [childIds[targetIndex], childIds[sourceIndex]];
    _bmChildrenByParentId.set(normalizedParentId, childIds);
}

function DD_getSourceApiIndexForSameParent(parentId) {
    const normalizedParentId = String(parentId || "");

    if (DD.originNextSiblingId) {
        const originNextLi = bookmarkList.querySelector(`li[data-id="${String(DD.originNextSiblingId)}"]`);
        if (originNextLi) {
            const originNextIndex = DD_getBookmarkApiIndexForLi(originNextLi, normalizedParentId);
            if (originNextIndex >= 0) return Math.max(0, originNextIndex - 1);
        }

        const storedNextIndex = normalizedParentId === String(_bmRootParentId)
            ? _bmResolveRootIndexForItem(
                DD.originNextSiblingId,
                _bmGetNodeKindById(DD.originNextSiblingId) === "folder",
                _bmGetStoredChildIndex(normalizedParentId, DD.originNextSiblingId)
            )
            : _bmGetStoredChildIndex(normalizedParentId, DD.originNextSiblingId);
        if (storedNextIndex >= 0) return Math.max(0, storedNextIndex - 1);
    }

    if (normalizedParentId !== String(_bmRootParentId) && DD.el?.parentElement) {
        const realSiblings = Array.from(DD.el.parentElement.children).filter(child =>
            child &&
            child !== DD.indicator &&
            child.dataset?.id &&
            !child.classList.contains("bm-section-divider") &&
            !child.classList.contains("bm-drop-indicator")
        );
        if (realSiblings.length) return Math.max(0, realSiblings.length - 1);
    }

    const childIds = _bmChildrenByParentId.get(normalizedParentId) || [];
    return Math.max(0, childIds.length ? childIds.length - 1 : 0);
}

function DD_commitSameParentSwap(targetLi, parentId, targetIndexOverride = null, targetBeforeNextSiblingId = null, sourceIndexOverride = null) {
    const sourceId = String(DD.id || "");
    const targetId = String(targetLi?.dataset?.id || "");
    const normalizedParentId = String(parentId || "");
    if (!sourceId || !targetId || !normalizedParentId || sourceId === targetId) {
        loadBookmarks();
        return;
    }

    const sourceIndex = Number.isInteger(sourceIndexOverride)
        ? sourceIndexOverride
        : DD_getSourceApiIndexForSameParent(normalizedParentId);
    const targetIndex = Number.isInteger(targetIndexOverride)
        ? targetIndexOverride
        : DD_getBookmarkApiIndexForLi(targetLi, normalizedParentId);
    if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) {
        loadBookmarks();
        return;
    }

    const shouldPersistManualRootOrder = normalizedParentId === String(_bmRootParentId);
    const shouldNormalizeSections = shouldPersistManualRootOrder && !DD.el?.classList?.contains("folder");
    const shouldReloadLayout = DD_isFolderMode() || (currentFilter === "all" && shouldPersistManualRootOrder);

    if (!shouldPersistManualRootOrder) {
        _bmSaveManualOrder();
    }
    if (shouldNormalizeSections) {
        _bmLastMovedRootBookmarkId = sourceId;
    }
    if (shouldPersistManualRootOrder) {
        _bmUpdateManualOrderForSwap(sourceId, targetId, "all");
        _bmUpdateManualOrderForSwap(sourceId, targetId, "bookmarks");
        _bmUpdateManualOrderForSwap(sourceId, targetId, "folders");
        _bmSetManualSortMode();
    }
    if (shouldNormalizeSections) {
        _bmNormalizeSectionsAfterRootBookmarkMove();
    }
    DD_updateCacheAfterSameParentSwap(normalizedParentId, sourceId, targetId);

    const scrollTop = DD_getScrollContainer()?.scrollTop || 0;
    const sourceBeforeSnapshot = _bmCreateMoveSnapshot(normalizedParentId, sourceIndex, DD.originNextSiblingId);
    const sourceAfterSnapshot = _bmCreateMoveSnapshot(normalizedParentId, targetIndex, DD_getNextSiblingId(DD.el));
    const targetBeforeSnapshot = _bmCreateMoveSnapshot(normalizedParentId, targetIndex, targetBeforeNextSiblingId);
    const targetAfterSnapshot = _bmCreateMoveSnapshot(normalizedParentId, sourceIndex, DD_getNextSiblingId(targetLi));

    _bmMoveBookmarkNode(targetId, { parentId: normalizedParentId, index: sourceIndex })
        .then(() => _bmMoveBookmarkNode(sourceId, { parentId: normalizedParentId, index: targetIndex }))
        .then(() => {
            _bmPushHistoryEntry({
                kind: "bookmark-move",
                moves: [
                    { id: sourceId, from: sourceBeforeSnapshot, to: sourceAfterSnapshot },
                    { id: targetId, from: targetBeforeSnapshot, to: targetAfterSnapshot },
                ],
            });
            bmShowToast("bm_toast_moved", "move");
            if (shouldNormalizeSections) {
                _bmNormalizeSectionsAfterRootBookmarkMove();
            }
            if (shouldReloadLayout) {
                _bmSkipNextColumnsRebalance = true;
                return loadBookmarks().then(() => {
                    requestAnimationFrame(() => {
                        const scrollContainer = DD_getScrollContainer();
                        if (scrollContainer) scrollContainer.scrollTop = scrollTop;
                    });
                });
            }
            return null;
        })
        .catch(() => {
            loadBookmarks();
        });
}

function _bmNormalizeSectionsAfterRootBookmarkMove(preferHigher = true) {
    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    const savedSections = _bmGetSections();
    const movedId = String(_bmLastMovedRootBookmarkId || "");

    if (outerWrapper && savedSections.length) {
        const sectionsById = new Map(savedSections.map(sec => [String(sec.id), sec]));
        const segments = [];
        let currentIds = [];

        const pushSegment = (sectionId = null) => {
            segments.push({ ids: currentIds, sectionId });
            currentIds = [];
        };

        Array.from(outerWrapper.children).forEach((child) => {
            if (child.classList?.contains("bm-folders-columns")) {
                currentIds.push(
                    ..._bmGetInterleavedColumnItems(child)
                        .filter(li => li?.dataset?.id && !li.classList.contains("folder"))
                        .map(li => String(li.dataset.id))
                );
                return;
            }

            if (!child.classList?.contains("bm-section-fullrow")) return;

            const sectionLi = child.querySelector(":scope > li.bm-section-divider");
            if (sectionLi?.dataset?.sectionId) {
                pushSegment(String(sectionLi.dataset.sectionId));
                return;
            }

            const fullRowItem = child.querySelector(":scope > li[data-id]");
            if (fullRowItem?.dataset?.id && !fullRowItem.classList.contains("folder")) {
                currentIds.push(String(fullRowItem.dataset.id));
            }
        });

        pushSegment();

        if (segments.some(segment => segment.sectionId)) {
            let changed = false;

            for (let i = 0; i < segments.length - 1; i++) {
                if (!segments[i].sectionId || segments[i].ids.length % 2 === 0) continue;

                for (let j = i + 1; j < segments.length; j++) {
                    if (!segments[j].ids.length) continue;

                    let donorIndex = segments[j].ids.findIndex(id => id !== movedId);
                    if (donorIndex < 0) donorIndex = 0;

                    const [donorId] = segments[j].ids.splice(donorIndex, 1);
                    if (!donorId) continue;

                    segments[i].ids.push(donorId);
                    changed = true;
                    break;
                }
            }

            const orderedBookmarkIds = [];
            let bookmarkIndex = 0;
            const updatedSectionsById = new Map();

            segments.forEach((segment) => {
                orderedBookmarkIds.push(...segment.ids);
                bookmarkIndex += segment.ids.length;

                if (!segment.sectionId) return;
                const prevSection = sectionsById.get(String(segment.sectionId));
                if (!prevSection) return;

                const afterId = bookmarkIndex > 0
                    ? String(orderedBookmarkIds[bookmarkIndex - 1] || "start")
                    : "start";

                if (Number(prevSection.bookmarkIndex) !== bookmarkIndex ||
                    String(prevSection.afterId || "start") !== afterId) {
                    changed = true;
                }

                updatedSectionsById.set(String(segment.sectionId), {
                    ...prevSection,
                    bookmarkIndex,
                    afterId,
                });
            });

            const finalSections = savedSections.map(sec => updatedSectionsById.get(String(sec.id)) || sec);
            if (changed) {
                _bmSaveSections(finalSections);

                try {
                    const savedOrder = _bmReadManualOrder();
                    const bookmarkSet = new Set(orderedBookmarkIds);
                    const mergedOrder = [
                        ...orderedBookmarkIds,
                        ...savedOrder.filter(id => !bookmarkSet.has(String(id)))
                    ];
                    _bmWriteManualOrder(mergedOrder);
                } catch (e) {}
            }

            return changed;
        }
    }

    const bookmarkItems = _bmGetVisibleRootDragItems(true).filter(li =>
        li &&
        !li.classList.contains("folder")
    );
    const sections = _bmGetSections();
    const normalized = _bmNormalizeSectionsForEvenSlots(sections, bookmarkItems, preferHigher);
    if (normalized.changed) _bmSaveSections(normalized.sections);
    return normalized.changed;
}

function DD_move(newParentId, newIdx) {
    if (!DD.id) return;
    const id = DD.id, oldP = DD.originParentId, oldI = DD.originIdx;
    newIdx = _bmResolveRootMoveIndex(newParentId, newIdx);
    const shouldPersistManualRootOrder = String(newParentId) === String(_bmRootParentId);
    const shouldNormalizeSections =
        shouldPersistManualRootOrder &&
        String(oldP) === String(_bmRootParentId) &&
        !DD.el?.classList?.contains("folder");
    if (shouldNormalizeSections) {
        _bmLastMovedRootBookmarkId = String(id);
    }

    if (_bmIsVirtualFolderId(id)) {
        if (String(newParentId) !== String(_bmRootParentId)) {
            loadBookmarks();
            return;
        }

        if (String(oldP) === String(_bmRootParentId) && Number(oldI) === Number(newIdx)) return;

        bmShowToast("bm_toast_moved", "move");
        _bmSaveManualOrder();

        if (DD_isFolderMode() || (currentFilter === "all" && String(newParentId) === String(_bmRootParentId))) {
            const scrollTop = DD_getScrollContainer()?.scrollTop || 0;
            _bmSkipNextColumnsRebalance = true;
            loadBookmarks().then(() => {
                requestAnimationFrame(() => {
                    const scrollContainer = DD_getScrollContainer();
                    if (scrollContainer) scrollContainer.scrollTop = scrollTop;
                });
            });
        }
        return;
    }

    // Skip only if both parent AND index are exactly the same
    if (String(oldP) === String(newParentId) && Number(oldI) === Number(newIdx)) return;

    // Capture next-sibling at the DROP destination (for accurate redo)
    // At this point DD.el is already in its new DOM position (inserted by DD_onDrop)
    const newNextSiblingId = DD.el ? DD_getNextSiblingId(DD.el) : null;
    const oldSnapshot = _bmCreateMoveSnapshot(oldP, oldI, DD.originNextSiblingId);
    const newSnapshot = _bmCreateMoveSnapshot(newParentId, newIdx, newNextSiblingId);

    if (shouldPersistManualRootOrder) {
        _bmSaveManualOrder();
    }
    if (shouldNormalizeSections) {
        _bmNormalizeSectionsAfterRootBookmarkMove();
    }

    const params = { parentId: newParentId, index: newIdx };
    const shouldReloadLayout = DD_isFolderMode() || (currentFilter === "all" && String(newParentId) === String(_bmRootParentId));
    if (isFirefox) {
        bookmarksAPI.move(id, params)
            .then((moved) => {
                _bmPushHistoryEntry({
                    kind: "bookmark-move",
                    moves: [{ id: String(id), from: oldSnapshot, to: newSnapshot }],
                });
                bmShowToast("bm_toast_moved", "move");
                _bmSaveManualOrder();
                if (shouldNormalizeSections) _bmNormalizeSectionsAfterRootBookmarkMove();
                if (shouldReloadLayout) {
                    const scrollTop = DD_getScrollContainer()?.scrollTop || 0;
                    _bmSkipNextColumnsRebalance = true;
                    loadBookmarks().then(() => {
                        requestAnimationFrame(() => {
                            const scrollContainer = DD_getScrollContainer();
                            if (scrollContainer) scrollContainer.scrollTop = scrollTop;
                        });
                    });
                }
            })
            .catch(() => {
                loadBookmarks();
            });
    } else {
        bookmarksAPI.move(id, params, (moved) => {
            if (chrome.runtime.lastError) {
                loadBookmarks();
                return;
            }
            _bmPushHistoryEntry({
                kind: "bookmark-move",
                moves: [{ id: String(id), from: oldSnapshot, to: newSnapshot }],
            });
            bmShowToast("bm_toast_moved", "move");
            _bmSaveManualOrder();
            if (shouldNormalizeSections) _bmNormalizeSectionsAfterRootBookmarkMove();
            if (shouldReloadLayout) {
                const scrollTop = DD_getScrollContainer()?.scrollTop || 0;
                _bmSkipNextColumnsRebalance = true;
                loadBookmarks().then(() => {
                    requestAnimationFrame(() => {
                        const scrollContainer = DD_getScrollContainer();
                        if (scrollContainer) scrollContainer.scrollTop = scrollTop;
                    });
                });
            }
        });
    }
}

// ── After a successful drag: save the actual DOM order of IDs ──
function _bmSetManualSortMode() {
    currentSortMethod = "manual";
    localStorage.setItem("bookmarkSortMethod", "manual");
    updateSortButtons();
    updateFilterButtons();
}

function _bmSaveManualOrder() {
    let ids = [];
    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    if (outerWrapper) {
        ids = _bmGetOuterWrapperDisplayItems(outerWrapper).map(li => li.dataset.id);
    } else {
    const columnsWrapper = bookmarkList.querySelector(".bm-folders-columns");
    if (columnsWrapper) {
        // Folders-only-view: interleave bm-col-1 and bm-col-2
        if (columnsWrapper.querySelector(":scope > .bm-col")) {
            ids = _bmGetInterleavedColumnItems(columnsWrapper).map(li => li.dataset.id);
        } else {
            // Grid-view flat layout: direct li children in DOM order = visual order
            ids = _bmGetDirectWrapperDisplayItems(columnsWrapper).map(li => li.dataset.id);
        }
    } else {
        ids = Array.from(bookmarkList.querySelectorAll(":scope > ul > li[data-id]"))
                   .map(li => li.dataset.id);
    }
    }
    ids = ids.filter(Boolean);
    if (!ids.length) return;

    _bmWriteManualOrder(ids);
    _bmSetManualSortMode();
}

function _bmApplyManualOrder(nodes) {
    try {
        const saved = _bmReadManualOrder();
        if (!saved || !saved.length) return nodes;
        const rank = new Map(saved.map((id, i) => [String(id), i]));
        return [...nodes].sort((a, b) => {
            const ra = rank.has(String(a.id)) ? rank.get(String(a.id)) : 9999;
            const rb = rank.has(String(b.id)) ? rank.get(String(b.id)) : 9999;
            return ra - rb;
        });
    } catch (e) { return nodes; }
}

function _bmGetVisibleRootTopLevelIds() {
    return _bmGetAllDisplayOrderLIs()
        .filter(li =>
            li &&
            li.dataset?.id &&
            !li.classList.contains("bm-section-divider") &&
            !li.classList.contains("bm-drop-indicator") &&
            !li.parentElement?.closest("li.folder")
        )
        .map(li => String(li.dataset.id));
}

function _bmInsertCreatedRootNodeIntoManualOrder(createdNode) {
    if (currentSortMethod !== "manual") return;
    if (!createdNode?.id) return;
    if (String(createdNode.parentId || "") !== String(_bmRootParentId || "")) return;

    const createdId = String(createdNode.id);
    const isFolder = createdNode.children !== undefined;
    if (currentFilter === "folders" && !isFolder) return;
    if (currentFilter === "bookmarks" && isFolder) return;

    const visibleIds = _bmGetVisibleRootTopLevelIds();
    if (!visibleIds.length) return;

    const visibleItems = _bmGetAllDisplayOrderLIs().filter(li =>
        li &&
        li.dataset?.id &&
        !li.classList.contains("bm-section-divider") &&
        !li.classList.contains("bm-drop-indicator") &&
        !li.parentElement?.closest("li.folder")
    );

    const sameKindItems = visibleItems.filter(li => li.classList.contains("folder") === isFolder);

    let insertAt = visibleIds.length;
    if (sameKindItems.length) {
        const lastSameKindId = String(sameKindItems[sameKindItems.length - 1].dataset.id);
        const lastSameKindIndex = visibleIds.indexOf(lastSameKindId);
        insertAt = lastSameKindIndex >= 0 ? lastSameKindIndex + 1 : visibleIds.length;
    } else if (!isFolder && currentFolderOrder === "last") {
        const firstFolderIndex = visibleItems.findIndex(li => li.classList.contains("folder"));
        insertAt = firstFolderIndex >= 0 ? firstFolderIndex : visibleIds.length;
    }

    const oldSaved = _bmReadManualOrder();

    const nextVisibleIds = visibleIds.filter(id => id !== createdId);
    nextVisibleIds.splice(Math.max(0, Math.min(insertAt, nextVisibleIds.length)), 0, createdId);

    const seen = new Set(nextVisibleIds);
    const mergedIds = [
        ...nextVisibleIds,
        ...oldSaved.filter(id => !seen.has(id))
    ];

    _bmWriteManualOrder(mergedIds);
}

function _bmGetMixedRootConstraint() {
    if (currentFilter !== "all" || !DD.el || DD.sectionDragId) return null;

    const dragIsFolder = DD.el.classList.contains("folder");
    const allowedItems = _bmGetAllDisplayOrderLIs().filter(li =>
        li &&
        li !== DD.el &&
        li.dataset?.id &&
        li.style.display !== "none" &&
        li.classList.contains("folder") === dragIsFolder
    );

    return { dragIsFolder, allowedItems };
}

function _bmHasSectionedRootLayout() {
    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    if (!outerWrapper) return false;
    return Array.from(outerWrapper.children).some(child =>
        child.classList?.contains("bm-section-fullrow")
    );
}

function _bmGetVisibleRootDragItems(includeDragged = false) {
    return _bmGetAllDisplayOrderLIs().filter(li =>
        li &&
        (includeDragged || li !== DD.el) &&
        li.dataset?.id &&
        li.style.display !== "none" &&
        !li.classList.contains("bm-section-divider") &&
        !li.classList.contains("bm-drop-indicator") &&
        !li.parentElement?.closest("li.folder")
    );
}

function _bmGetSectionedRootChildAllowedItems(child, allowedSet) {
    if (!child || !allowedSet?.size) return [];

    if (child.classList?.contains("bm-folders-columns")) {
        const hasCols = !!child.querySelector(":scope > .bm-col");
        const items = hasCols
            ? _bmGetInterleavedColumnItems(child)
            : _bmGetDirectWrapperDisplayItems(child);
        return items.filter(item => allowedSet.has(item));
    }

    if (child.classList?.contains("bm-section-fullrow")) {
        const fullRowItem = child.querySelector(":scope > li[data-id]");
        if (fullRowItem
                && allowedSet.has(fullRowItem)
                && !fullRowItem.classList.contains("bm-section-divider")) {
            return [fullRowItem];
        }
    }

    return [];
}

function DD_findSectionBoundaryPlacement(clientY, allowedItems) {
    if (!DD_isGridMode() || DD.el?.classList?.contains("folder")) return null;

    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    if (!outerWrapper || !allowedItems.length) return null;

    const allowedSet = new Set(allowedItems);
    const children = Array.from(outerWrapper.children);

    for (let i = 0; i < children.length; i++) {
        const child = children[i];
        const sectionLi = child.classList?.contains("bm-section-fullrow")
            ? child.querySelector(":scope > li.bm-section-divider")
            : null;
        if (!sectionLi) continue;

        let prevItem = null;
        for (let j = i - 1; j >= 0 && !prevItem; j--) {
            const items = _bmGetSectionedRootChildAllowedItems(children[j], allowedSet);
            prevItem = items[items.length - 1] || null;
        }

        let nextItem = null;
        for (let j = i + 1; j < children.length && !nextItem; j++) {
            const items = _bmGetSectionedRootChildAllowedItems(children[j], allowedSet);
            nextItem = items[0] || null;
        }

        if (!prevItem && !nextItem) continue;

        const sectionRect = sectionLi.getBoundingClientRect();
        const prevChildRect = children[i - 1]?.getBoundingClientRect?.() || null;
        const nextChildRect = children[i + 1]?.getBoundingClientRect?.() || null;
        const zoneTop = prevChildRect
            ? Math.min(prevChildRect.bottom, sectionRect.top) - 14
            : sectionRect.top - 18;
        const zoneBottom = nextChildRect
            ? Math.max(nextChildRect.top, sectionRect.bottom) + 10
            : sectionRect.bottom + 14;

        if (clientY < zoneTop || clientY > zoneBottom) continue;

        const beforeSectionCaptureBottom = Math.min(
            sectionRect.bottom,
            sectionRect.top + Math.min(28, Math.max(18, sectionRect.height * 0.72))
        );

        if (clientY <= beforeSectionCaptureBottom && prevItem?.parentElement) {
            return {
                parent: prevItem.parentElement,
                before: prevItem.nextSibling,
            };
        }

        if (nextItem?.parentElement) {
            return {
                parent: nextItem.parentElement,
                before: nextItem,
            };
        }
    }

    return null;
}

function DD_placeInSectionedRoot(clientX, clientY, items) {
    const ind = DD_getIndicator();
    ind.parentElement?.removeChild(ind);
    DD_sizeIndicator(DD.el || items[0] || null);

    if (!items.length) return;
    if (DD_isGridMode()) {
        const sectionBoundaryPlacement = DD_findSectionBoundaryPlacement(clientY, items);
        if (sectionBoundaryPlacement?.parent) {
            DD_placeIndicator(sectionBoundaryPlacement.parent, sectionBoundaryPlacement.before || null);
            return;
        }
        DD_placeAcrossGridItems(items, clientX, clientY);
        return;
    }

    let insertBefore = null;
    for (const item of items) {
        const r = item.getBoundingClientRect();
        if (clientY < r.top) {
            insertBefore = item;
            break;
        }
        if (clientY <= r.bottom && DD_shouldInsertBefore(clientY, r, 0.32, 10, 24)) {
            insertBefore = item;
            break;
        }
    }

    if (insertBefore?.parentElement) {
        DD_placeIndicator(insertBefore.parentElement, insertBefore);
        return;
    }

    const lastItem = items[items.length - 1];
    if (!lastItem?.parentElement) return;
    DD_insertIndicatorAfterItem(lastItem);
}

function _bmHasSectionedListRootLayout() {
    const rootUl = bookmarkList.querySelector(":scope > ul");
    if (!rootUl) return false;
    return Array.from(rootUl.children).some(child =>
        child?.classList?.contains("bm-section-divider")
    );
}

function DD_findListSectionBoundaryPlacement(clientY, allowedItems) {
    if (DD_isGridMode() || DD.el?.classList?.contains("folder")) return null;

    const rootUl = bookmarkList.querySelector(":scope > ul");
    if (!rootUl || !allowedItems.length) return null;

    const allowedSet = new Set(allowedItems);
    const children = Array.from(rootUl.children).filter(child =>
        child &&
        child !== DD.el &&
        child !== DD.indicator &&
        child.style?.display !== "none"
    );

    for (let i = 0; i < children.length; i++) {
        const sectionLi = children[i]?.classList?.contains("bm-section-divider")
            ? children[i]
            : null;
        if (!sectionLi) continue;

        let prevItem = null;
        for (let j = i - 1; j >= 0 && !prevItem; j--) {
            if (allowedSet.has(children[j])) prevItem = children[j];
        }

        let nextItem = null;
        for (let j = i + 1; j < children.length && !nextItem; j++) {
            if (allowedSet.has(children[j])) nextItem = children[j];
        }

        if (!prevItem && !nextItem) continue;

        const sectionRect = sectionLi.getBoundingClientRect();
        const prevChildRect = children[i - 1]?.getBoundingClientRect?.() || null;
        const nextChildRect = children[i + 1]?.getBoundingClientRect?.() || null;
        const zoneTop = prevChildRect
            ? Math.min(prevChildRect.bottom, sectionRect.top) - 14
            : sectionRect.top - 18;
        const zoneBottom = nextChildRect
            ? Math.max(nextChildRect.top, sectionRect.bottom) + 10
            : sectionRect.bottom + 14;

        if (clientY < zoneTop || clientY > zoneBottom) continue;

        const beforeSectionCaptureBottom = Math.min(
            sectionRect.bottom,
            sectionRect.top + Math.min(28, Math.max(18, sectionRect.height * 0.72))
        );

        if (clientY <= beforeSectionCaptureBottom) {
            return {
                parent: rootUl,
                before: sectionLi,
            };
        }

        let afterSectionSibling = nextItem || sectionLi.nextElementSibling;
        while (
            afterSectionSibling &&
            (
                afterSectionSibling === DD.el ||
                afterSectionSibling === DD.indicator ||
                afterSectionSibling.style?.display === "none"
            )
        ) {
            afterSectionSibling = afterSectionSibling.nextElementSibling;
        }

        return {
            parent: rootUl,
            before: afterSectionSibling || null,
        };
    }

    return null;
}

function DD_placeWithinAllowedRootItems(clientX, clientY, allowedItems) {
    const ind = DD_getIndicator();
    ind.parentElement?.removeChild(ind);
    DD_sizeIndicator(DD.el || allowedItems[0] || null);

    if (!allowedItems.length) return;
    const dragIsFolder = DD.el?.classList.contains("folder");
    if (_bmHasSectionedRootLayout()) {
        DD_placeInSectionedRoot(clientX, clientY, allowedItems);
        return;
    }
    if (!dragIsFolder && _bmHasSectionedListRootLayout()) {
        const sectionBoundaryPlacement = DD_findListSectionBoundaryPlacement(clientY, allowedItems);
        if (sectionBoundaryPlacement?.parent) {
            DD_placeIndicator(sectionBoundaryPlacement.parent, sectionBoundaryPlacement.before || null);
            return;
        }
    }
    const allowedCols = Array.from(new Set(
        allowedItems
            .map(item => item.parentElement)
            .filter(parent => parent?.classList?.contains("bm-col"))
    ));

    if (allowedCols.length) {
        const targetCol = DD_resolvePointerColumn(allowedCols, clientX, clientY);
        if (!targetCol) return;

        const colItems = Array.from(targetCol.children).filter(c =>
            c !== DD.el &&
            !c.classList.contains("bm-drop-indicator")
        );
        const typedItems = colItems.filter(item => item.classList.contains("folder") === dragIsFolder);

        if (!typedItems.length) {
            if (dragIsFolder) DD_placeIndicator(targetCol, null);
            else DD_placeIndicator(targetCol, colItems[0] || null);
            return;
        }

        const insertBeforeInCol = DD_findInsertBeforeByPointerY(typedItems, clientY);

        if (insertBeforeInCol) {
            DD_placeIndicator(targetCol, insertBeforeInCol);
            return;
        }

        const lastTypedItem = typedItems[typedItems.length - 1];
        DD_insertIndicatorAfterItem(lastTypedItem);
        return;
    }

    if (DD_isGridMode()) {
        DD_placeAcrossGridItems(allowedItems, clientX, clientY);
        return;
    }

    let insertBefore = null;
    for (const item of allowedItems) {
        const r = item.getBoundingClientRect();
        if (clientY < r.top || DD_shouldInsertBefore(clientY, r, 0.32, 10, 24)) {
            insertBefore = item;
            break;
        }
    }

    if (insertBefore) {
        DD_placeIndicator(insertBefore.parentElement, insertBefore);
        return;
    }

    const lastItem = allowedItems[allowedItems.length - 1];
    if (!lastItem?.parentElement) return;
    DD_insertIndicatorAfterItem(lastItem);
}

// ── Size the indicator to exactly match a reference item ──
function DD_sizeIndicator(ref) {
    const ind = DD_getIndicator();
    if (!ref) { ind.style.cssText = ""; ind.dataset.mode = "list"; return; }

    // Always use DD.el for size so indicator exactly matches the dragged item
    const target   = DD.el || ref;
    // Use saved rect if available (element may be display:none)
    const r        = DD.elRect || target.getBoundingClientRect();
    const refStyle = window.getComputedStyle(ref);
    const colSpan  = refStyle.gridColumn || "";

    ind.style.width         = r.width  + "px";
    ind.style.height        = r.height + "px";
    ind.style.minHeight     = r.height + "px";
    ind.style.boxSizing     = "border-box";
    ind.style.margin        = "0";
    ind.style.padding       = "0";
    ind.style.pointerEvents = "none";
    ind.style.listStyle     = "none";
    ind.style.flexShrink    = "0";
    ind.style.gridColumn    = colSpan || "";
    ind.dataset.mode        = "sized";
}

// ── LIST mode: thin line, Y-only ──
function DD_placeLineInUL(ul, clientY) {
    const ind   = DD_getIndicator();
    ind.parentElement?.removeChild(ind);
    const useSizedPlaceholder = !!DD.el?.classList?.contains("folder");
    if (useSizedPlaceholder) {
        DD_sizeIndicator(DD.el);
    } else {
        ind.style.cssText = "";
        ind.dataset.mode  = "list";
    }
    const items = Array.from(ul.children).filter(c => c !== DD.el);
    if (!items.length) { ul.appendChild(ind); return; }
    for (const item of items) {
        const r = item.getBoundingClientRect();
        if (DD_shouldInsertBefore(clientY, r, 0.28, 8, 20)) { ul.insertBefore(ind, item); return; }
    }
    ul.appendChild(ind);
}

// ── FOLDER sub-list mode: sized card placeholder, Y-only (mirrors DD_placeCellInCol) ──
function DD_placeCellInSubUL(ul, clientY) {
    const ind   = DD_getIndicator();
    ind.parentElement?.removeChild(ind);
    const items = Array.from(ul.children).filter(c => c !== DD.el);
    const insertBefore = DD_findInsertBeforeByPointerY(items, clientY);
    const ref = insertBefore ?? items[items.length - 1] ?? DD.el;
    DD_sizeIndicator(ref);
    if (insertBefore) ul.insertBefore(ind, insertBefore);
    else              ul.appendChild(ind);
}

// ── GRID mode: use BOTH X and Y to find correct slot ──
function DD_placeInGrid(ul, clientX, clientY) {
    const ind   = DD_getIndicator();
    if (DD_isPointerInsideCurrentIndicator(clientX, clientY, 18, 14)) {
        return;
    }
    // Remove indicator first so it doesn't skew getBoundingClientRect measurements
    ind.parentElement?.removeChild(ind);

    // Always size the indicator to DD.el — NOT the nearest item.
    // Changing the indicator size mid-drag causes grid reflows that shift all
    // item positions, creating a flicker / feedback loop.
    DD_sizeIndicator(DD.el);

    const items = Array.from(ul.children).filter(c => c !== DD.el);

    if (!items.length) {
        DD_placeIndicator(ul, null);
        return;
    }

    // Measure items AFTER indicator is removed and BEFORE it is re-inserted
    // (indicator already removed above, so rects are stable).
    // Reading order: left→right, top→bottom.
    let insertBefore = null;
    for (const item of items) {
        const r = item.getBoundingClientRect();
        if (clientY < r.top) {
            insertBefore = item; break;
        }
        if (clientY <= r.bottom && DD_shouldInsertBefore(clientY, r, 0.32, 10, 24)) {
            insertBefore = item; break;
        }
    }

    if (insertBefore) DD_placeIndicator(ul, insertBefore);
    else              DD_placeIndicator(ul, null);
}

// ── GRID-VIEW mode: place indicator directly in flat CSS grid ──
// Uses both X and Y so dragging between left/right column works correctly.
function DD_placeInFlatGrid(wrapper, clientX, clientY) {
    const items = _bmGetDirectWrapperDisplayItems(wrapper)
        .filter(c => c !== DD.el && c.style.display !== "none");

    if (!items.length) {
        const ind = DD_getIndicator();
        ind.parentElement?.removeChild(ind);
        DD_sizeIndicator(DD.el);
        DD_placeIndicator(wrapper, null);
        return;
    }

    DD_placeAcrossGridItems(items, clientX, clientY);
}

// ── FOLDERS-ONLY mode: place indicator in the nearest bm-col by X, then Y ──
function DD_placeInFolderCol(clientX, clientY, targetEl = null) {
    // Support both single bm-folders-columns and multiple groups inside bm-folders-outer
    const outerWrapper = bookmarkList.querySelector(".bm-folders-outer");
    let wrapper;
    const pointedEl = targetEl || document.elementFromPoint(clientX, clientY);
    const hoveredWrapper = pointedEl?.closest?.(".bm-folders-columns");
    const hoveredCol = pointedEl?.closest?.(".bm-col");
    if (outerWrapper) {
        const allGroups = Array.from(outerWrapper.querySelectorAll(".bm-folders-columns"));
        wrapper = allGroups.includes(hoveredWrapper) ? hoveredWrapper : null;
        if (!wrapper) {
            const nearbyGroups = allGroups.filter(group => {
                const r = group.getBoundingClientRect();
                return clientY >= r.top - 28 && clientY <= r.bottom + 28;
            });
            const candidateGroups = nearbyGroups.length ? nearbyGroups : allGroups;
            wrapper = candidateGroups[0];
            let bestScore = Infinity;
            for (const group of candidateGroups) {
                const r = group.getBoundingClientRect();
                const horizontalScore = Math.abs(clientX - (r.left + r.width / 2));
                const verticalScore = clientY < r.top ? (r.top - clientY) : (clientY > r.bottom ? clientY - r.bottom : 0);
                const score = horizontalScore + (verticalScore * 0.55);
                if (score < bestScore) {
                    bestScore = score;
                    wrapper = group;
                }
            }
        }
    } else {
        wrapper = hoveredWrapper || bookmarkList.querySelector(".bm-folders-columns");
    }
    if (!wrapper) return;
    const allCols = Array.from(wrapper.querySelectorAll(":scope > .bm-col"));
    if (!allCols.length) return;
    const targetCol = DD_resolvePointerColumn(
        allCols,
        clientX,
        clientY,
        allCols.includes(hoveredCol) ? hoveredCol : null
    );
    if (!targetCol) return;
    DD_placeCellInCol(targetCol, clientY);
}

function DD_placeCellInCol(col, clientY) {
    const ind   = DD_getIndicator();
    const currentRect = ind?.parentElement ? ind.getBoundingClientRect() : null;
    if (
        currentRect &&
        ind.parentElement === col &&
        clientY >= currentRect.top - 12 &&
        clientY <= currentRect.bottom + 12
    ) {
        return;
    }
    ind.parentElement?.removeChild(ind);

    const items = Array.from(col.children).filter(c => c !== DD.el && !c.classList.contains("bm-drop-indicator"));

    // Always size to DD.el so indicator matches the dragged element exactly
    DD_sizeIndicator(DD.el || (items.length ? items[items.length - 1] : null));
    if (!items.length) {
        DD_placeIndicator(col, null);
        return;
    }

    const insertBefore = DD_findInsertBeforeByPointerY(items, clientY);

    if (insertBefore) DD_placeIndicator(col, insertBefore);
    else              DD_placeIndicator(col, null);
}

function DD_findHoveredSibling(clientX, clientY) {
    const listContainer = document.getElementById("bookmarkList");
    if (!listContainer) return null;
    const items = Array.from(listContainer.querySelectorAll("li[data-id]"));
    for (const item of items) {
        if (item.classList.contains("bm-drop-indicator") || item.classList.contains("bm-section-divider")) continue;
        const r = item.getBoundingClientRect();
        if (clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom) {
            return item;
        }
    }
    return null;
}

function DD_clearPlaceholders() {
    DD_clearDragHints();
    if (_bmLastTargetLi) {
        const targetLi = _bmLastTargetLi;
        _bmLastTargetLi = null;
        DD.lastTargetId = null;
        DD.lastTargetIndex = null;
        targetLi.classList.remove("bm-drag-source-placeholder");
        if (DD.el) {
            DD.el.classList.remove("bm-drag-target-placeholder");
            DD.el.classList.add("bm-drag-source-placeholder");
            DD_swapDomItems(DD.el, targetLi);
        }
    }
    if (DD.el) {
        DD.el.classList.remove("bm-drag-target-placeholder");
        DD.el.classList.add("bm-drag-source-placeholder");
        DD.el.style.display = "";
        DD.el.style.visibility = "";
    }
}

function DD_onDragover(e) {
    if (!DD.el) return;
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = "move";
    DD_captureNativeDragPoint(e.clientX, e.clientY, e.target);
    DD_autoScrollSidebar(e.clientY);

    DD_clearDragHints();

    if (DD.el && DD.el.classList.contains("folder")) {
        DD_clearIndicator();
        
        let targetEl = e.target;
        if (targetEl && (targetEl === DD.el || DD.el.contains(targetEl))) {
            const elPointer = DD.el.style.pointerEvents;
            DD.el.style.pointerEvents = "none";
            targetEl = document.elementFromPoint(e.clientX, e.clientY) || targetEl;
            DD.el.style.pointerEvents = elPointer;
        }
        
        let targetFolder = targetEl?.closest?.("li.folder");
        if (DD.folderTarget) {
            const rect = DD.folderTarget.getBoundingClientRect();
            if (rect && rect.width > 0 && rect.height > 0 &&
                e.clientX >= rect.left && e.clientX <= rect.right &&
                e.clientY >= rect.top && e.clientY <= rect.bottom) {
                targetFolder = DD.folderTarget;
            }
        }

        const subUl = targetFolder?.querySelector(":scope > ul");
        const isOverChildren = subUl && subUl.contains(targetEl);

        if (targetFolder 
            && targetFolder.classList.contains("open")
            && !isOverChildren
            && targetFolder !== DD.el 
            && !DD.el.contains(targetFolder) 
            && !_bmIsVirtualFolderLi(targetFolder)) {
            
            if (DD.folderTarget !== targetFolder) {
                DD_clearFolderTarget();
                DD.folderTarget = targetFolder;
                targetFolder.classList.add("bm-drag-into-hover");
                targetFolder.classList.add("bm-drag-over");
                targetFolder.setAttribute("data-drag-hint", t("dragDropInside"));
            }
            DD_clearIndicator();
            return;
        } else {
            if (DD.folderTarget) {
                DD_clearFolderTarget();
            }
        }
    }

    // ── Same parent reordering: perform live visual swap preview ──
    if (DD.el && !DD.sectionDragId) {
        // Strict columns/grid boundary check
        let isInsideGridBounds = false;
        const gridContainers = Array.from(document.querySelectorAll("#bookmarkList .bm-folders-columns, #bookmarkList ul"));
        for (const container of gridContainers) {
            const rect = container.getBoundingClientRect();
            if (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom) {
                isInsideGridBounds = true;
                break;
            }
        }

        if (!isInsideGridBounds) {
            DD_clearPlaceholders();
            return;
        }

        // Find targetParentId of where the cursor is currently pointing
        const hoveredCol = e.target?.closest?.(".bm-col");
        const hoveredUl = e.target?.closest?.("ul");
        
        let targetParentId = null;
        if (hoveredCol || hoveredUl) {
            const parentFolderLi = (hoveredCol || hoveredUl).closest("li.folder");
            targetParentId = _bmIsVirtualFolderLi(parentFolderLi)
                ? _bmRootParentId
                : (parentFolderLi?.dataset?.id || _bmRootParentId);
        }
        
        if (targetParentId && String(targetParentId) === String(DD.originParentId)) {
            // Also check if cursor is over a valid column/sub-ul of this parent
            let isOverValidColumn = false;
            const columns = Array.from(document.querySelectorAll("#bookmarkList .bm-col, #bookmarkList ul"));
            for (const col of columns) {
                const parentFolderLi = col.closest("li.folder");
                const parentId = _bmIsVirtualFolderLi(parentFolderLi)
                    ? _bmRootParentId
                    : (parentFolderLi?.dataset?.id || _bmRootParentId);
                    
                if (String(parentId) === String(DD.originParentId)) {
                    const r = col.getBoundingClientRect();
                    if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) {
                        isOverValidColumn = true;
                        break;
                    }
                }
            }

            if (!isOverValidColumn) {
                DD_clearPlaceholders();
                return;
            }

            // In bounds: restore display style if previously hidden
            DD.el.style.display = "";

            // We are hovering within the same parent! Make sure any default/general indicator is completely removed.
            DD_clearIndicator();
            
            const hoveredSib = DD_findHoveredSibling(e.clientX, e.clientY);

            // SMART SYSTEM: Check if the hovered sibling is a folder and if the cursor is in its drop zone!
            if (hoveredSib && hoveredSib.classList.contains("folder") && hoveredSib !== DD.el && !DD.el.contains(hoveredSib)) {
                const isOverDropZone = DD_isOverFolderDropZone(hoveredSib, e.clientX, e.clientY);
                if (isOverDropZone) {
                    hoveredSib.classList.add("bm-drag-into-hover");
                    hoveredSib.setAttribute("data-drag-hint", t("dragDropInside"));
                    DD_clearPlaceholders();
                    DD_hoverFolder(hoveredSib);
                    return;
                } else {
                    hoveredSib.classList.add("bm-drag-swap-hover");
                    hoveredSib.setAttribute("data-drag-hint", t("dragReorder"));
                }
            }
            DD_clearFolderTarget();
            
            // If we are at the root level, we should restrict sibling swaps to the same type (folder vs bookmark)
            if (String(targetParentId) === String(_bmRootParentId)) {
                if (hoveredSib && hoveredSib.classList.contains("folder") !== DD.el.classList.contains("folder")) {
                    DD_clearPlaceholders();
                    return;
                }
            }
            
            if (hoveredSib === DD.el) {
                // Pointer is hovering over target slot (currently occupied by DD.el); keep swap stable!
                return;
            }
            
            if (hoveredSib && hoveredSib === _bmLastTargetLi) {
                // Pointer is hovering over the target element at the source slot; reset/swap back physically
                DD_clearPlaceholders();
                return;
            }
            
            if (hoveredSib && hoveredSib !== DD.el) {
                const targetLi = hoveredSib;
                // Perform state-memoized visual updates only if the hover target has changed
                if (_bmLastTargetLi !== targetLi) {
                    DD_clearPlaceholders();

                    // Query stable index in memory before swapping
                    const targetIndex = DD_getBookmarkApiIndexForLi(targetLi, targetParentId);
                    
                    if (targetIndex >= 0) {
                        _bmLastTargetLi = targetLi;
                        DD.lastTargetId = targetLi.dataset.id;
                        DD.lastTargetIndex = targetIndex;

                        // Turn original cell (occupied by targetLi) into static gray placeholder,
                        // and target cell (occupied by DD.el) into active theme target placeholder
                        DD.el.classList.remove("bm-drag-source-placeholder");
                        DD.el.classList.add("bm-drag-target-placeholder");
                        targetLi.classList.add("bm-drag-source-placeholder");
                        DD_swapDomItems(DD.el, targetLi); // swap physically
                    }
                }
            } else {
                // Hovering in same parent but not on a specific target element or its swap preview; reset visual swap
                if (_bmLastTargetLi && hoveredSib === null) {
                    DD_clearPlaceholders();
                }
                // If dragging a folder and no sibling is hovered (empty column space),
                // fall through to the FOLDERS MODE handler to place indicator in the target column.
                if (!(DD.el.classList.contains("folder") && DD_isFolderMode() && hoveredSib === null)) {
                    return;
                }
            }
            if (!(DD.el.classList.contains("folder") && DD_isFolderMode() && !hoveredSib)) {
                return;
            }
            // Folder drag to empty column space — fall through to FOLDERS MODE below
        }
    }

    // ── Section dragging: use thin-line indicator across the whole list ──
    if (DD.sectionDragId) {
        DD_showSectionDragShield();
        DD_clearFolderTarget();
        if (!_bmGetTopLevelSectionAnchorItems().length) {
            DD_clearIndicator();
            return;
        }
        DD_placeSectionIndicator(e.clientY);
        return;
    }

    // ══════════════════════════════════════════════
    //  FOLDERS MODE  (.bm-col layout)
    // ══════════════════════════════════════════════
    if (DD_isFolderMode()) {
        const wrapper = bookmarkList.querySelector(".bm-folders-outer") || bookmarkList.querySelector(".bm-folders-columns");
        if (!wrapper) return;

        if (_bmIsVirtualDraggedFolder()) {
            const mixedRootConstraint = _bmGetMixedRootConstraint();
            DD_clearFolderTarget();
            if (mixedRootConstraint) {
                DD_placeWithinAllowedRootItems(e.clientX, e.clientY, mixedRootConstraint.allowedItems);
            } else {
                DD_placeInFolderCol(e.clientX, e.clientY, e.target);
            }
            return;
        }

        // ── Universal nested folder detection ──
        // Walk up from the deepest open folder ancestor to find the right context.
        // This handles ANY depth of nesting (level 1, 2, 3, ...).

        // Collect all open folder ancestors from deepest to shallowest
        const openAncestors = [];
        let node = e.target.closest("li.folder.open");
        while (node) {
            if (node !== DD.el && !DD.el.contains(node) && !_bmIsVirtualFolderLi(node)) {
                openAncestors.push(node);
            }
            node = node.parentElement ? node.parentElement.closest("li.folder.open") : null;
        }

        // Try each open ancestor (deepest first) to find an active sub-list
        let activeSubUl = null;
        let activeOpenFolder = null;
        for (const openFolder of openAncestors) {
            const subUl = openFolder.querySelector(":scope > ul");
            if (!subUl) continue;
            const subRect = subUl.getBoundingClientRect();
            // Keep a small escape gutter around open folders so dragging out feels easy
            // and doesn't get trapped inside the currently-open folder.
            if (e.clientY >= subRect.top + DD_FOLDER_EXIT_GUTTER &&
                e.clientY <= subRect.bottom - DD_FOLDER_EXIT_GUTTER &&
                e.clientX >= subRect.left + DD_FOLDER_EXIT_GUTTER &&
                e.clientX <= subRect.right - DD_FOLDER_EXIT_GUTTER) {
                activeSubUl = subUl;
                activeOpenFolder = openFolder;
                break;
            }
        }

        if (activeSubUl) {
            if (DD.el.classList.contains("folder")) {
                activeOpenFolder.classList.add("bm-drag-into-hover");
                activeOpenFolder.setAttribute("data-drag-hint", t("dragDropInside"));
                DD_hoverFolder(activeOpenFolder);
                DD_clearIndicator();
                return;
            }
            // ── Check if hovering over ANY folder inside the active sub-list ──
            // Works for both open and closed nested folders at any depth
            const targetFolder = e.target.closest("li.folder");
            if (targetFolder
                    && targetFolder !== DD.el
                    && !DD.el.contains(targetFolder)
                    && !targetFolder.contains(DD.el)
                    && !_bmIsVirtualFolderLi(targetFolder)
                    && activeSubUl.contains(targetFolder)) {
                const isOverDropZone = DD_isOverFolderDropZone(targetFolder, e.clientX, e.clientY);
                if (isOverDropZone) {
                    targetFolder.classList.add("bm-drag-into-hover");
                    targetFolder.setAttribute("data-drag-hint", t("dragDropInside"));
                    
                    // Indicator stays visible — only the folder card gets highlighted after delay.
                    DD_hoverFolder(targetFolder);
                    return;
                } else {
                    targetFolder.classList.add("bm-drag-swap-hover");
                    targetFolder.setAttribute("data-drag-hint", t("dragReorder"));
                }
            }
            // ── Reorder items inside the active open folder ──
            DD_clearFolderTarget();
            DD_placeCellInSubUL(activeSubUl, e.clientY);
            return;
        }

        // ── Root-level: check for "drop INTO a root folder" ──
        // Use a narrower zone (middle 40%) so horizontal drags don't accidentally
        // trigger "drop into folder" when passing over a folder card.
        const isOverBookmark = DD_isGridMode() && !!e.target.closest("li:not(.folder)");
        const rootFolderCard = isOverBookmark ? null : e.target.closest("li.folder");
        if (rootFolderCard
                && rootFolderCard !== DD.el
                && !DD.el.contains(rootFolderCard)
                && !rootFolderCard.contains(DD.el)
                && !_bmIsVirtualFolderLi(rootFolderCard)) {
            const isOverDropZone = DD_isOverFolderDropZone(rootFolderCard, e.clientX, e.clientY);
            if (isOverDropZone) {
                rootFolderCard.classList.add("bm-drag-into-hover");
                rootFolderCard.setAttribute("data-drag-hint", t("dragDropInside"));
                
                // Indicator stays visible at its last position throughout.
                // Only add the folder highlight after the delay (timer in DD_hoverFolder).
                DD_hoverFolder(rootFolderCard);
                return;
            } else {
                rootFolderCard.classList.add("bm-drag-swap-hover");
                rootFolderCard.setAttribute("data-drag-hint", t("dragReorder"));
            }
        }

        // ── Default: place indicator in grid or folder columns ──
        const mixedRootConstraint = _bmGetMixedRootConstraint();
        if (mixedRootConstraint) {
            DD_clearFolderTarget();
            DD_placeWithinAllowedRootItems(e.clientX, e.clientY, mixedRootConstraint.allowedItems);
            return;
        }
        if (_bmHasSectionedRootLayout()) {
            DD_clearFolderTarget();
            DD_placeInSectionedRoot(e.clientX, e.clientY, _bmGetVisibleRootDragItems());
            return;
        }
        DD_clearFolderTarget();
        const outerWr = bookmarkList.querySelector(".bm-folders-outer");
        const foldersWr = bookmarkList.querySelector(".bm-folders-columns");
        const rootLayoutWrapper = outerWr || foldersWr;
        if (!rootLayoutWrapper) return;
        const hasCols = !!rootLayoutWrapper.querySelector(":scope > .bm-col, .bm-folders-columns > .bm-col");
        if (DD_isGridMode() && foldersWr && !hasCols) {
            DD_placeInFlatGrid(foldersWr, e.clientX, e.clientY);
        } else {
            DD_placeInFolderCol(e.clientX, e.clientY, e.target);
        }
        return;
    }

    // ══════════════════════════════════════════════
    //  GRID MODE  (View as Grid)
    // ══════════════════════════════════════════════
    if (DD_isGridMode()) {
        const rootUl   = bookmarkList.querySelector(":scope > ul");
        if (!rootUl) return;
        // Skip the indicator itself as a target
        const rawTarget = e.target.closest("#bookmarkList li");
        const targetLi  = (rawTarget === DD.indicator) ? null : rawTarget;

        // Folder handling in grid
        if (targetLi?.classList.contains("folder") && targetLi !== DD.el && !DD.el.contains(targetLi)) {
            const r = targetLi.getBoundingClientRect();
            const zonePadX = Math.max(16, Math.min(40, r.width * 0.22));
            if (e.clientY >= r.top + 12 && e.clientY <= r.bottom - 12
                    && e.clientX >= r.left + zonePadX
                    && e.clientX <= r.right - zonePadX) {
                // Keep indicator — only add folder highlight after timer fires.
                DD_hoverFolder(targetLi);
                return;
            }
        }

        DD_clearFolderTarget();
        // Use the UL the targetLi belongs to, or rootUl
        const ul = targetLi?.parentElement?.tagName === "UL"
            ? targetLi.parentElement
            : rootUl;
        DD_placeInGrid(ul, e.clientX, e.clientY);
        return;
    }

    // ══════════════════════════════════════════════
    //  LIST MODE
    // ══════════════════════════════════════════════
    const rootUl = bookmarkList.querySelector(":scope > ul");
    if (!rootUl) return;

    if (_bmIsVirtualDraggedFolder()) {
        const mixedRootConstraint = _bmGetMixedRootConstraint();
        DD_clearFolderTarget();
        if (mixedRootConstraint) {
            DD_placeWithinAllowedRootItems(e.clientX, e.clientY, mixedRootConstraint.allowedItems);
        } else {
            DD_placeLineInUL(rootUl, e.clientY);
        }
        return;
    }

    const targetLi = e.target.closest("#bookmarkList li");

    if (!targetLi) {
        const mixedRootConstraint = _bmGetMixedRootConstraint();
        if (mixedRootConstraint) {
            DD_clearFolderTarget();
            DD_placeWithinAllowedRootItems(e.clientX, e.clientY, mixedRootConstraint.allowedItems);
            return;
        }
        const ul = e.target.closest("#bookmarkList ul") || rootUl;
        DD_clearFolderTarget();
        DD_placeLineInUL(ul, e.clientY);
        return;
    }

    if (_bmIsVirtualFolderLi(targetLi) || _bmIsVirtualFolderLi(targetLi.closest("li.folder"))) {
        const mixedRootConstraint = _bmGetMixedRootConstraint();
        DD_clearFolderTarget();
        if (mixedRootConstraint) {
            DD_placeWithinAllowedRootItems(e.clientX, e.clientY, mixedRootConstraint.allowedItems);
        } else {
            DD_placeLineInUL(rootUl, e.clientY);
        }
        return;
    }

    if (targetLi.classList.contains("folder") && targetLi !== DD.el && !DD.el.contains(targetLi)) {
        const subUl  = targetLi.querySelector(":scope > ul");
        const isOpen = targetLi.classList.contains("open");

        // If e.target is physically inside the sub-list (link / span / img) → reorder
        if (subUl?.contains(e.target)) {
            if (DD.el.classList.contains("folder")) {
                targetLi.classList.add("bm-drag-into-hover");
                targetLi.setAttribute("data-drag-hint", t("dragDropInside"));
                DD_hoverFolder(targetLi);
                DD_clearIndicator();
                return;
            }
            DD_clearFolderTarget();
            DD_placeLineInUL(subUl, e.clientY);
            return;
        }

        // If the folder is OPEN its bounding rect extends over ALL its children.
        // Check via the sub-ul top: if the cursor is already in the sub-ul area,
        // treat it as reordering within the folder, not as "hover into folder".
        // This prevents the timer from firing and stealing the drop position when
        // the user is dragging an item that lives inside this open folder.
        if (isOpen && subUl) {
            const subRect = subUl.getBoundingClientRect();
            if (
                subRect.height > 0 &&
                e.clientY >= subRect.top + DD_FOLDER_EXIT_GUTTER &&
                e.clientY <= subRect.bottom - DD_FOLDER_EXIT_GUTTER &&
                e.clientX >= subRect.left + DD_FOLDER_EXIT_GUTTER &&
                e.clientX <= subRect.right - DD_FOLDER_EXIT_GUTTER
            ) {
                if (DD.el.classList.contains("folder")) {
                    targetLi.classList.add("bm-drag-into-hover");
                    targetLi.setAttribute("data-drag-hint", t("dragDropInside"));
                    DD_hoverFolder(targetLi);
                    DD_clearIndicator();
                    return;
                }
                DD_clearFolderTarget();
                DD_placeLineInUL(subUl, e.clientY);
                return;
            }
        }

        const r = targetLi.getBoundingClientRect();
        if (e.clientY >= r.top + DD_FOLDER_ENTER_GUTTER && e.clientY <= r.bottom - DD_FOLDER_ENTER_GUTTER) {
            // Indicator stays visible — folder gets highlighted only after timer fires.
            DD_hoverFolder(targetLi);
            return;
        }
    }

    const mixedRootConstraint = _bmGetMixedRootConstraint();
    if (mixedRootConstraint) {
        DD_clearFolderTarget();
        DD_placeWithinAllowedRootItems(e.clientX, e.clientY, mixedRootConstraint.allowedItems);
        return;
    }
    DD_clearFolderTarget();
    const parentUl = targetLi.parentElement;
    if (parentUl?.tagName === "UL") {
        DD_placeLineInUL(parentUl, e.clientY);
    }
}

// ───── drop handler ─────

function DD_onDrop(e) {
    e.preventDefault();
    if (!DD.el) return;

    if (_bmDragAnimationFrame) {
        cancelAnimationFrame(_bmDragAnimationFrame);
        _bmDragAnimationFrame = null;
    }

    const isFolderDrag = DD.el.classList.contains("folder");

    if (_bmLastTargetLi && DD.folderTarget?.classList.contains("bm-drag-over")) {
        DD_clearPlaceholders();
    }

    if (_bmLastTargetLi) {
        const targetLi = _bmLastTargetLi;
        const targetParentLi = targetLi.parentElement?.closest("li.folder");
        const targetParentId = _bmIsVirtualFolderLi(targetParentLi)
            ? _bmRootParentId
            : (targetParentLi?.dataset?.id || _bmRootParentId);

        // Read stable previewed memory indices
        const targetIndex = DD.lastTargetIndex;
        const sourceIndex = DD.originIdx;
        const targetBeforeNextSiblingId = DD_getNextSiblingId(DD.el);

        // Reset memory variables and remove classes (keep DOM swapped)
        _bmLastTargetLi = null;
        DD.lastTargetId = null;
        DD.lastTargetIndex = null;

        targetLi.classList.remove("bm-drag-source-placeholder");
        if (DD.el) {
            DD.el.classList.remove("bm-drag-target-placeholder");
            DD.el.classList.remove("bm-drag-source-placeholder");
            DD.el.style.display = "";
            DD.el.style.visibility = "";
        }

        const rootOuterWrapper = bookmarkList.querySelector(".bm-folders-outer");
        const droppedAtSectionedRoot =
            !!rootOuterWrapper &&
            _bmHasSectionedRootLayout() &&
            !DD.el.parentElement?.closest("li.folder") &&
            (
                DD.el.parentElement.classList.contains("bm-col") ||
                DD.el.parentElement.classList.contains("bm-folders-columns") ||
                DD.el.parentElement.classList.contains("bm-section-fullrow") ||
                DD.el.parentElement.classList.contains("bm-folders-outer")
            );

        DD_clearIndicator();

        requestAnimationFrame(() => {
            const parent = DD.el?.parentElement;
            if (parent) {
                // Force CSS Grid layout reflow
                const _ = parent.offsetHeight;
            }

            if (droppedAtSectionedRoot) {
                _bmLastMovedRootBookmarkId = String(DD.id || "");
                _bmRebalanceSectionedGridLayout(rootOuterWrapper);
            }
        });

        // Commit the swap in storage and browser bookmarks API
        DD_commitSameParentSwap(targetLi, targetParentId, targetIndex, targetBeforeNextSiblingId, sourceIndex);
        return;
    }

    // ── drop a SECTION (update its afterId) ──
    if (DD.sectionDragId) {
        // Compute new afterId BEFORE clearing the indicator
        const newAfterId = _bmGetAfterIdFromIndicator();
        DD_hideSectionDragShield();
        DD_clearIndicator();
        DD_clearFolderTarget();
        const draggedSectionEl = DD.el;
        Promise.resolve(_bmCommitSectionMove(DD.sectionDragId, newAfterId)).finally(() => {
            if (draggedSectionEl?.isConnected) {
                draggedSectionEl.style.display = "";
                draggedSectionEl.style.visibility = "";
                draggedSectionEl.classList.remove("bm-dragging");
            }
        });
        return;
    }

    // ── drop INTO folder ──
    if (DD.folderTarget) {
        if (_bmIsVirtualDraggedFolder()) {
            DD_clearFolderTarget();
        } else {
            const folder = DD.folderTarget;
            const isCommitted = isFolderDrag || folder.classList.contains("bm-drag-over");
            if (!isCommitted) {
                // Timer hasn't fired — treat as normal sibling reorder at indicator position.
                DD_clearFolderTarget();
                // Fall through to indicator-based drop below.
            } else {
                DD_clearFolderTarget();
                DD_clearIndicator();    // safe to clear now — we have a committed target

                if (folder === DD.el || DD.el.contains(folder)) return;

                DD.el.style.display = "";
                DD.el.style.visibility = "";
                const subUl = folder.querySelector(":scope > ul");
                if (!subUl) { loadBookmarks(); return; }

                subUl.appendChild(DD.el);
                const newParentId = folder.dataset.id;
                const newIdx      = DD_getChildIndex(DD.el, subUl);
                DD_move(newParentId, newIdx);
                return;
            }
        }
    }


    const ind = DD.indicator;
    if (!ind?.parentElement) { DD_clearIndicator(); return; }

    const container = ind.parentElement;
    DD.el.style.display = "";   // restore before re-inserting at new position
    DD.el.style.visibility = "";

    // Resolve parent ID first to check for same parent
    let newParentId = _bmRootParentId;
    const finalContainer = container;
    const rootOuterWrapper = bookmarkList.querySelector(".bm-folders-outer");
    const droppedAtSectionedRoot =
        !!rootOuterWrapper &&
        _bmHasSectionedRootLayout() &&
        !DD.el.parentElement?.closest("li.folder") &&
        (
            container.classList.contains("bm-col") ||
            container.classList.contains("bm-folders-columns") ||
            container.classList.contains("bm-section-fullrow") ||
            container.classList.contains("bm-folders-outer")
        );

    if (droppedAtSectionedRoot) {
        newParentId = _bmRootParentId;
    } else if (finalContainer.classList.contains("bm-col") || finalContainer.classList.contains("bm-folders-columns")) {
        newParentId = _bmRootParentId;
    } else if (finalContainer.classList.contains("bm-section-fullrow") || finalContainer.classList.contains("bm-folders-outer")) {
        newParentId = _bmRootParentId;
    } else if (finalContainer.tagName === "UL") {
        const parentFolderLi = finalContainer.closest("li.folder");
        newParentId = _bmIsVirtualFolderLi(parentFolderLi)
            ? _bmRootParentId
            : (parentFolderLi?.dataset?.id || _bmRootParentId);
    } else {
        newParentId = null;
    }



    // Swap logic for same parent reordering
    let targetLi = e.target?.closest?.("li[data-id]:not(.bm-drop-indicator)");
    if (!targetLi && e.clientX && e.clientY) {
        targetLi = document.elementFromPoint(e.clientX, e.clientY)?.closest("li[data-id]:not(.bm-drop-indicator)");
    }
    if (!targetLi) {
        targetLi = DD_getSwapTargetFromIndicator(ind);
    }

    if (targetLi && targetLi !== DD.el && targetLi.dataset?.id) {
        const targetParentLi = targetLi.parentElement?.closest("li.folder");
        const targetParentId = _bmIsVirtualFolderLi(targetParentLi)
            ? _bmRootParentId
            : (targetParentLi?.dataset?.id || _bmRootParentId);

        if (String(targetParentId) === String(DD.originParentId) && String(newParentId) === String(DD.originParentId)) {
            const targetBeforeNextSiblingId = DD_getNextSiblingId(targetLi);
            const targetIndexOverride = DD_getBookmarkApiIndexForLi(targetLi, newParentId);
            const sourceIndexOverride = DD_getSourceApiIndexForSameParent(newParentId);

            DD.el.style.display = "";
            DD.el.style.visibility = "";
            
            // Swap DOM elements visually
            DD_swapDomItems(DD.el, targetLi);
            DD_clearIndicator();

            requestAnimationFrame(() => {
                const parent = DD.el?.parentElement;
                if (parent) {
                    // Force CSS Grid layout reflow
                    const _ = parent.offsetHeight;
                }

                if (droppedAtSectionedRoot) {
                    _bmLastMovedRootBookmarkId = String(DD.id || "");
                    _bmRebalanceSectionedGridLayout(rootOuterWrapper);
                }
            });

            // Commit the swap in storage and browser bookmarks API
            DD_commitSameParentSwap(targetLi, newParentId, targetIndexOverride, targetBeforeNextSiblingId, sourceIndexOverride);
            return;
        }
    }

    container.insertBefore(DD.el, ind);
    DD_clearIndicator();

    if (droppedAtSectionedRoot) {
        _bmLastMovedRootBookmarkId = String(DD.id || "");
        _bmRebalanceSectionedGridLayout(rootOuterWrapper);
    }

    let newIdx;

    if (droppedAtSectionedRoot) {
        newIdx = Math.max(0, _bmGetVisibleRootDragItems(true).indexOf(DD.el));
    } else if (finalContainer.classList.contains("bm-col") || finalContainer.classList.contains("bm-folders-columns")) {
        // Folders mode — root level
        newIdx      = DD_globalIndex(DD.el);
    } else if (finalContainer.classList.contains("bm-section-fullrow") || finalContainer.classList.contains("bm-folders-outer")) {
        newIdx = Math.max(0, _bmGetVisibleRootDragItems(true).indexOf(DD.el));
    } else if (finalContainer.tagName === "UL") {
        newIdx      = DD_getChildIndex(DD.el, finalContainer);
    } else {
        return;
    }

    DD_move(newParentId, newIdx);
}

// ───── dragend cleanup ─────

function DD_onDragend() {
    if (_bmDragAnimationFrame) {
        cancelAnimationFrame(_bmDragAnimationFrame);
        _bmDragAnimationFrame = null;
    }
    bookmarkList.classList.remove("bm-drag-active");
    DD_clearPlaceholders();
    if (DD.secondaryIndicator?.parentElement) {
        DD.secondaryIndicator.remove();
    }
    if (DD.el) {
        if (DD.dragSourceMoveHandler) {
            DD.el.removeEventListener("drag", DD.dragSourceMoveHandler);
            DD.el.dragSourceMoveHandler = null;
        }
        DD.el.classList.remove("bm-dragging");
        DD.el.classList.remove("bm-drag-target-placeholder");
        DD.el.classList.remove("bm-drag-source-placeholder");
        DD.el.style.display    = "";   // restore if drag was cancelled (no drop)
        DD.el.style.visibility = "";
    }
    DD_stopNativeDragTracking();
    DD_resetSectionPointerState();
    bookmarkList.classList.remove("bm-section-drag-active");
    DD_hideSectionDragShield();
    DD.el = DD.id = DD.originParentId = DD.originIdx = DD.elRect = DD.originNextSiblingId = DD.sectionDragId = DD.sectionAfterId = null;
    DD.lastTargetId = null;
    DD.lastTargetIndex = null;
    DD_clearIndicator();
    DD_clearFolderTarget();
    _bmDragJustEnded = true;
    setTimeout(() => { _bmDragJustEnded = false; }, 300);
}

function DD_onRootNativeDragover(e) {
    if (!DD.el || DD.sectionDragId) return;
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = "move";
}

// ───── make a single LI draggable ─────

function DD_make(li) {
    if (li.classList.contains("bm-section-divider")) return; // sections use their own drag (see _bmRenderSectionNode)
    li.setAttribute("draggable", "true");

    li.addEventListener("dragstart", (e) => {
        e.stopPropagation();
        bookmarkList.classList.add("bm-drag-active");
        DD.el   = li;
        DD.id   = li.dataset.id;
        DD.sectionAfterId = null;
        DD_setNativeDragCursor(true);
        DD_captureNativeDragPoint(e.clientX, e.clientY, e.target);
        const explicitParentId = li.dataset.parentId || null;
        const visibleParentFolderLi = li.parentElement?.closest("li.folder") || null;
        const draggingFromVirtualFolder = _bmIsVirtualFolderLi(visibleParentFolderLi);

        if (DD_isFolderMode()) {
            if (draggingFromVirtualFolder && explicitParentId) {
                DD.originParentId = explicitParentId;
            } else if (visibleParentFolderLi) {
                DD.originParentId = visibleParentFolderLi.dataset.id;
            } else {
                DD.originParentId = _bmRootParentId;
            }
        } else {
            if (draggingFromVirtualFolder && explicitParentId) {
                DD.originParentId = explicitParentId;
            } else {
                DD.originParentId = visibleParentFolderLi?.dataset?.id || explicitParentId || _bmRootParentId;
            }
        }
        const cachedIdx = _bmGetStoredChildIndex(DD.originParentId, li.dataset.id);
        DD.originIdx = cachedIdx >= 0 ? cachedIdx : 0;

        // ── Capture the next sibling ID in Chrome order (for accurate undo) ──
        // Must be done BEFORE li is hidden (setTimeout below), while DOM is intact.
        DD.originNextSiblingId = DD_getNextSiblingId(li);

        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("bm-id", li.dataset.id);
        DD.dragSourceMoveHandler = (ev) => {
            if (!DD.el || DD.el !== li || DD.sectionDragId) return;
            const liveTarget = (Number.isFinite(ev.clientX) && Number.isFinite(ev.clientY))
                ? document.elementFromPoint(ev.clientX, ev.clientY)
                : ev.target;
            DD_captureNativeDragPoint(ev.clientX, ev.clientY, liveTarget || ev.target);
        };
        li.addEventListener("drag", DD.dragSourceMoveHandler);
        DD_startNativeDragTracking();

        // ── Custom drag ghost: dashed box matching element size ──
        const r = li.getBoundingClientRect();
        // Save rect NOW before element is hidden — used by DD_sizeIndicator
        DD.elRect = { width: r.width, height: r.height };
        DD_createDragGhost(li, e.clientX, e.clientY);
        const ghost = document.createElement("div");
        ghost.style.cssText = `
            position: fixed;
            top: -9999px;
            left: -9999px;
            width: 1px;
            height: 1px;
            opacity: 0;
            pointer-events: none;
        `;
        document.body.appendChild(ghost);
        e.dataTransfer.setDragImage(ghost, 0, 0);
        // Remove after drag starts — delay enough for browser to capture
        setTimeout(() => ghost.remove(), 500);

        // 1. تثبيت كلاس الـ Source متزامناً لتجهيز الشكل قبل التيك القادمة
        li.classList.remove("bm-drag-target-placeholder");

        if (li.classList.contains("folder")) {
            // Defer class additions to the next tick to prevent Chrome from cancelling the drag session due to pointer-events: none,
            // but do NOT hide the element with display:none to avoid visual flashing/glitch!
            setTimeout(() => {
                if (!DD.el || DD.el !== li) return;
                li.classList.add("bm-drag-source-placeholder"); 
                li.classList.add("bm-dragging");
                li.classList.remove("bm-solo-stretched");
            }, 0);
        } else {
            li.classList.add("bm-drag-source-placeholder");
            li.offsetHeight; 

            // Defer drag visual state and pointer-events (bm-dragging) to the next tick
            // فك الحظر عن السحب عبر تأجيل الـ display والـ dragging ليتمكن كروم من بدء السحب بنجاح
            setTimeout(() => {
                if (!DD.el || DD.el !== li) return;

                // 2. خدعة الـ display لإجبار كروم على التحديث الرسومي
                li.style.display = "none";
                li.offsetHeight;
                li.style.display = "";

                // 3. التحديث الحرج للمظهر هنا: نضع كلاس الخطوط مع كلاس الـ dragging معاً فور الإظهار
                li.classList.add("bm-drag-source-placeholder"); 
                li.classList.add("bm-dragging");
                li.classList.remove("bm-solo-stretched"); 
                li.style.visibility = "";
                li.offsetHeight; 
            }, 0);
        }
    });

    li.addEventListener("dragend", DD_onDragend);
}
// ── Get the Chrome-ordered next sibling bookmark ID of a given LI ──
function DD_getNextSiblingId(li) {
    let orderedSiblings;

    const rootOuterWrapper = bookmarkList.querySelector(".bm-folders-outer");
    if (rootOuterWrapper && rootOuterWrapper.contains(li)) {
        orderedSiblings = _bmGetOuterWrapperDisplayItems(rootOuterWrapper)
            .filter(c => c !== DD.indicator && c.dataset?.id);
    } else if (DD_isFolderMode()) {
        const wrapper = li.closest(".bm-folders-columns");
        if (wrapper) {
            const hasCols = wrapper.querySelector(":scope > .bm-col");
            if (hasCols) {
                // Folders-only: interleave bm-col-1 / bm-col-2
                orderedSiblings = _bmGetInterleavedColumnItems(wrapper)
                    .filter(c => c !== DD.indicator && c.dataset?.id);
            } else {
                // Grid-view flat layout: direct li children in DOM order
                orderedSiblings = _bmGetDirectWrapperDisplayItems(wrapper)
                    .filter(c => c !== DD.indicator && c.dataset?.id);
            }
        }
    }

    if (!orderedSiblings) {
        // Normal list / nested folder: siblings share the same parent UL
        orderedSiblings = Array.from(li.parentElement.children)
            .filter(c => c !== DD.indicator && !c.classList.contains("bm-section-divider") && c.dataset?.id);
    }

    const myPos = orderedSiblings.indexOf(li);
    if (myPos < 0 || myPos >= orderedSiblings.length - 1) return null;
    return orderedSiblings[myPos + 1].dataset.id;
}

// ───── init: ONE listener on the root container ─────

function DD_init() {
    document.addEventListener("dragover", DD_onGlobalDragover, true);
    document.addEventListener("wheel", DD_onSidebarWheel, { passive: false, capture: true });
    bookmarkList.addEventListener("dragenter", (e) => { if (DD.el) e.preventDefault(); });
    bookmarkList.addEventListener("dragover", DD_onRootNativeDragover);
    bookmarkSidebar.addEventListener("wheel", DD_onSidebarWheel, { passive: false });
    bookmarkList.addEventListener("dragleave", (e) => {
        // e.relatedTarget can be null when moving over empty space inside bookmarkList
        // (e.g. the area below "Recently Added"). We must not clear the indicator in that case.
        if (e.relatedTarget !== null && !bookmarkList.contains(e.relatedTarget) && e.relatedTarget !== DD.sectionShield) {
            DD_clearPlaceholders();
            DD_clearIndicator();
            DD_clearFolderTarget();
        }
    });
    bookmarkList.addEventListener("drop", DD_onDrop);
}

DD_init();
// ─────────────── End Drag & Drop v3 ───────────────

// ── Delegated list events (installed once on #bookmarkList) ───────────────
// Replaces ~3 listeners per item (folder click, title keydown, link nav).
// Semantics mirror the old per-item handlers exactly; drag & drop (DD_make)
// keeps its own per-item listeners untouched.
let _bmListDelegated = false;
function _bmEnsureListDelegation() {
    if (_bmListDelegated || !bookmarkList) return;
    _bmListDelegated = true;
    // Capture phase: runs before descendant bubble handlers. Folder toggles
    // stopPropagation here, exactly like the old li-level handler did, so the
    // per-ul context-menu closers below never see the event. Link nav does NOT
    // stop propagation, also exactly like before.
    bookmarkList.addEventListener("click", _bmOnBookmarkListClick, true);
    bookmarkList.addEventListener("keydown", _bmOnBookmarkListKeydown);
}
function _bmDelegatedFolderToggle(folderItem) {
    // Suppress the spurious click Chrome fires right after dragend —
    // without this the folder would toggle open/closed unexpectedly after every drag.
    if (_bmDragJustEnded) return;
    const subList = folderItem.querySelector(":scope > ul");
    const nextOpen = !folderItem.classList.contains("open");
    bmAnimateFolderToggle(folderItem, subList, nextOpen, () => {
        bmRefreshSoloItems();
    });
    bmRefreshDiscovery();
    bmHandleFolderToggleLayout(subList);
}
function _bmOnBookmarkListClick(event) {
    // ── Leaf bookmark navigation (was per-link listener) ──
    const anchor = event.target.closest("a[href]");
    if (anchor && bookmarkList.contains(anchor)) {
        const li = anchor.closest("li[data-id]");
        const url = (li && li.dataset.url) || anchor.getAttribute("href");
        if (url) {
            event.preventDefault();
            if (event.ctrlKey || event.metaKey) {
                if (isFirefox)            browser.tabs.create({ url, active: false });
                else if (isChromiumBased) chrome.tabs.create({ url, active: false });
                else                      window.open(url, "_blank");
            } else {
                if (isFirefox)            browser.tabs.update({ url });
                else if (isChromiumBased) chrome.tabs.update({ url }, () => {});
                else                      window.location.href = url;
            }
        }
        return;
    }
    // ── Folder toggle (was per-folder li listener) ──
    const folderItem = event.target.closest("li.folder");
    if (!folderItem || !bookmarkList.contains(folderItem)) return;
    if (event.target.closest(".bookmark-delete-button")) return;
    if (_bmDragJustEnded) return;
    // Only toggle when clicking directly on this folder's title row
    // (not on a nested ul or any element inside a nested ul)
    const innerUl = folderItem.querySelector(":scope > ul");
    if (event.target !== folderItem && innerUl && innerUl.contains(event.target)) return;
    event.stopPropagation();
    _bmDelegatedFolderToggle(folderItem);
}
function _bmOnBookmarkListKeydown(event) {
    if (event.key !== "Enter" && event.key !== " ") return;
    const title = event.target.closest(".bm-folder-title");
    if (!title || !bookmarkList.contains(title)) return;
    event.preventDefault();
    event.stopPropagation();
    const folderItem = title.closest("li.folder");
    if (folderItem) _bmDelegatedFolderToggle(folderItem);
}

function displayBookmarks(bookmarkNodes, parentIdForItems, isSubContent = false) {
    let list = document.createElement("ul");

    // Apply filter only at the top level, not inside opened folders
    let filteredNodes = bookmarkNodes;
    if (!isSubContent) {
        if (currentFilter === "bookmarks") {
            filteredNodes = bookmarkNodes.filter(n => n.url);
        } else if (currentFilter === "folders") {
            filteredNodes = bookmarkNodes.filter(n => n.children !== undefined);
        }
    }

    // Separate folders and bookmarks
    const folders   = filteredNodes.filter(node => node.children !== undefined);
    const bookmarks = filteredNodes.filter(node => node.url);

    let sortedNodes;

    if (currentSortMethod === 'manual' && !isSubContent) {
        // Mixed root view keeps folders and bookmarks in separate zones.
        // Manual order still applies inside each zone, but links are never allowed
        // to drift down into the folders area.
        if (currentFilter === 'all') {
            const orderedFolders = _bmApplyManualOrder([...folders]);
            const orderedBookmarks = _bmApplyManualOrder([...bookmarks]);
            sortedNodes = currentFolderOrder === 'first'
                ? [...orderedFolders, ...orderedBookmarks]
                : [...orderedBookmarks, ...orderedFolders];
        } else {
            sortedNodes = _bmApplyManualOrder([...filteredNodes]);
        }
    } else if (currentSortMethod === 'manual' && isSubContent) {
        // Inside folders: preserve Chrome's stored order so drag-and-drop indices stay correct.
        // (The else/date branch was incorrectly applied here, causing DOM ↔ Chrome index mismatch.)
        sortedNodes = [...filteredNodes];
    } else if (currentSortMethod === 'title') {
        folders.sort((a, b)   => a.title.localeCompare(b.title));
        bookmarks.sort((a, b) => a.title.localeCompare(b.title));
        // Folder order only meaningful when showing mixed (all); ignored for single-type filter
        if (!isSubContent && currentFilter === 'all') {
            sortedNodes = currentFolderOrder === 'first'
                ? [...folders, ...bookmarks]
                : [...bookmarks, ...folders];
        } else {
            sortedNodes = [...folders, ...bookmarks];
        }
    } else {
        // date sort
        folders.sort((a, b)   => (a.dateAdded || 0) - (b.dateAdded || 0));
        bookmarks.sort((a, b) => (a.dateAdded || 0) - (b.dateAdded || 0));
        if (!isSubContent && currentFilter === 'all') {
            sortedNodes = currentFolderOrder === 'first'
                ? [...folders, ...bookmarks]
                : [...bookmarks, ...folders];
        } else {
            sortedNodes = [...folders, ...bookmarks];
        }
    }

    // Inject section dividers (top-level only, not inside sub-folders)
    if (!isSubContent) {
        sortedNodes = _bmInjectSections(sortedNodes);
    }

    for (let node of sortedNodes) {
        if (node.id === "1") continue;

        // ── Section divider node ──
        if (node._isSectionDivider) {
            list.appendChild(_bmRenderSectionNode(node));
            continue;
        }

        if (node.children !== undefined) {
            let folderItem = document.createElement("li");
            folderItem.dataset.id = node.id;
            if (parentIdForItems) folderItem.dataset.parentId = parentIdForItems;
            if (_bmIsVirtualFolderId(node.id)) {
                folderItem.dataset.virtualFolder = "true";
                folderItem.classList.add("bm-virtual-folder");
            }

            const folderIcon = document.getElementById("folderIconTemplate").cloneNode(true);
            folderIcon.removeAttribute("id");
            const folderTitle = document.createElement("span");
            folderTitle.className = "bm-folder-title";
            folderTitle.textContent = node.title;
            folderTitle.dir = "auto";
            folderTitle.tabIndex = 0;
            folderTitle.setAttribute("role", "button");
            folderTitle.setAttribute("aria-expanded", "false");
            // (keydown handled by delegated _bmOnBookmarkListKeydown — no per-item listener)
            folderItem.appendChild(folderIcon);
            folderItem.appendChild(folderTitle);
            // Always start collapsed — user opens manually
            folderItem.classList.add("folder");

            let subList = displayBookmarks(node.children, node.id, true);
            folderItem.appendChild(subList);
            list.appendChild(folderItem);

        } else if (node.url) {
            let item = document.createElement("li");
            item.dataset.id  = node.id;
            item.dataset.url = node.url;
            const itemParentId = node.parentId || parentIdForItems;
            if (itemParentId) item.dataset.parentId = itemParentId;

            let link = document.createElement("a");
            link.href = node.url;
            link.title = `${node.title}\n${node.url}`;
            let span = document.createElement("span");
            span.textContent = node.title;
            span.dir = "auto";

            const favicon = document.createElement("img");
            setBookmarkFavicon(favicon, node.url);
            favicon.classList.add("favicon");

            link.appendChild(favicon);
            link.appendChild(span);
            item.appendChild(link);

            list.appendChild(item);
        }
    }

    list.addEventListener("click", (e) => {
        // Close any open context menus when clicking inside the list
        // (stopPropagation below prevents the document-level close handlers from firing)
        if (bookmarkCtxMenu && !bookmarkCtxMenu.contains(e.target)) hideCtxMenu();
        if (typeof sidebarCtxMenu !== "undefined" && sidebarCtxMenu && !sidebarCtxMenu.contains(e.target)) hideSidebarCtxMenu();
        e.stopPropagation();
    });

    // ── Make every direct-child LI draggable ──
    Array.from(list.children).forEach(li => DD_make(li));

    return list;
}

// ─────────────── Bookmark Context Menu System ───────────────

// ── Shared drag helper for context menus ──
function _makeMenuDraggable(menu) {
    var handle = menu.querySelector(".ctx-drag-handle");
    if (!handle) return;
    handle.addEventListener("mousedown", function(e) {
        e.stopPropagation();
        e.preventDefault();
        var startX = e.clientX, startY = e.clientY;
        var startLeft = parseInt(menu.style.left) || 0;
        var startTop  = parseInt(menu.style.top)  || 0;
        function onMove(ev) {
            var pos = _clampCtxMenuPosition(
                startLeft + ev.clientX - startX,
                startTop + ev.clientY - startY,
                menu.offsetWidth,
                menu.offsetHeight
            );
            menu.style.left = pos.left + "px";
            menu.style.top  = pos.top + "px";
        }
        function onUp() {
            document.removeEventListener("mousemove", onMove);
            document.removeEventListener("mouseup",   onUp);
        }
        document.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup",   onUp);
    });
}

const bookmarkCtxMenu = document.getElementById("bookmarkContextMenu");
let ctxTargetItem = null;
let ctxIsFolder = false;
let _bookmarkCtxHideTimer = null;

const t = (key) => (translations[currentLanguage]?.[key] || translations['en']?.[key] || key);

function updateCtxLabels() {
    const set = (id, key) => { const el = document.getElementById(id); if (el) el.textContent = t(key); };
    set("ctxOpenLabel",          "bm_open");
    set("ctxOpenNewTabLabel",    "bm_openNewTab");
    set("ctxEditLabel",          "bm_edit");
    set("ctxCopyURLLabel",       "bm_copyURL");
    set("ctxDeleteLabel",        "bm_delete");
    set("ctxOpenAllLabel",       "bm_openAll");
    set("ctxRenameFolderLabel",  "bm_renameFolder");
    set("ctxDeleteFolderLabel",  "bm_deleteFolder");
    set("ctxAddPageLabel",       "bm_addPage");
    set("ctxAddFolderLabel",     "bm_addFolder");
}

function showCtxMenu(x, y, item, isFolder) {
    // Close sidebar ctx menu if open
    hideSidebarCtxMenu(true);
    if (_bookmarkCtxHideTimer) {
        clearTimeout(_bookmarkCtxHideTimer);
        _bookmarkCtxHideTimer = null;
    }
    bookmarkCtxMenu.classList.remove("ctx-menu-closing");
    ctxTargetItem = item;
    ctxIsFolder = isFolder;
    const isVirtualFolder = isFolder && _bmIsVirtualFolderId(item?.dataset?.id);
    updateCtxLabels();

    // Toggle bookmark vs folder sections
    document.querySelectorAll(".ctx-bookmark-only").forEach(el => {
        el.style.display = isFolder ? "none" : "";
    });
    document.querySelectorAll(".ctx-folder-only").forEach(el => {
        el.style.display = isFolder ? "" : "none";
    });
    [
        ["ctxRenameFolder", !isVirtualFolder],
        ["ctxDeleteFolder", !isVirtualFolder],
        ["ctxAddPage", !isVirtualFolder],
        ["ctxAddFolder", !isVirtualFolder],
    ].forEach(([id, shouldShow]) => {
        const el = document.getElementById(id);
        if (el) el.style.display = shouldShow ? "" : "none";
    });

    const ctxAddSectionBtn = document.getElementById("ctxAddSection");
    if (ctxAddSectionBtn) {
        const canAddSection = !isFolder && _bmResolveSectionAfterId(item?.dataset?.id || "start") !== null;
        ctxAddSectionBtn.style.display = canAddSection ? "" : "none";
    }

    // Position menu smartly
    bookmarkCtxMenu.style.display = "block";
    _makeMenuDraggable(bookmarkCtxMenu);
    bookmarkCtxMenu.style.left = "0px";
    bookmarkCtxMenu.style.top  = "0px";
    const bookmarkMenuPos = _clampCtxMenuPosition(
        x,
        y,
        bookmarkCtxMenu.offsetWidth,
        bookmarkCtxMenu.offsetHeight
    );
    bookmarkCtxMenu.style.left = bookmarkMenuPos.left + "px";
    bookmarkCtxMenu.style.top  = bookmarkMenuPos.top + "px";
}

function hideCtxMenu(animated = true) {
    if (_bookmarkCtxHideTimer) {
        clearTimeout(_bookmarkCtxHideTimer);
        _bookmarkCtxHideTimer = null;
    }
    if (animated && bookmarkCtxMenu.style.display !== "none") {
        bookmarkCtxMenu.classList.add("ctx-menu-closing");
        const _mult = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")) || 1;
        const dur = Math.round(260 * _mult) + 20;
        _bookmarkCtxHideTimer = setTimeout(() => {
            bookmarkCtxMenu.style.display = "none";
            bookmarkCtxMenu.classList.remove("ctx-menu-closing");
            _bookmarkCtxHideTimer = null;
        }, dur);
    } else {
        bookmarkCtxMenu.style.display = "none";
        bookmarkCtxMenu.classList.remove("ctx-menu-closing");
    }
    ctxTargetItem = null;
}

// Dismiss menu on outside click / scroll / Escape
document.addEventListener("click", (e) => {
    if (!bookmarkCtxMenu.contains(e.target)) hideCtxMenu();
});
document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") hideCtxMenu();
});
bookmarkList.addEventListener("scroll", hideCtxMenu);

// Right-click to open context menu
bookmarkList.addEventListener("contextmenu", function (event) {
    event.preventDefault();
    const item = event.target.closest("li[data-id]");
    if (!item) { hideCtxMenu(); return; }
    const isFolder = item.classList.contains("folder");
    showCtxMenu(event.clientX + 4, event.clientY + 4, item, isFolder);
});

// ── ctx: Open current tab ──
document.getElementById("ctxOpen").addEventListener("click", () => {
    if (!ctxTargetItem) return;
    const url = ctxTargetItem.dataset.url;
    if (!url) return;
    hideCtxMenu();
    if (isFirefox)         browser.tabs.update({ url });
    else if (isChromiumBased) chrome.tabs.update({ url });
    else                   window.location.href = url;
});

// ── ctx: Open in new tab ──
document.getElementById("ctxOpenNewTab").addEventListener("click", () => {
    if (!ctxTargetItem) return;
    const url = ctxTargetItem.dataset.url;
    if (!url) return;
    hideCtxMenu();
    if (isFirefox)         browser.tabs.create({ url, active: false });
    else if (isChromiumBased) chrome.tabs.create({ url, active: false });
    else                   window.open(url, "_blank");
});

// ── ctx: Edit bookmark ──
document.getElementById("ctxEdit").addEventListener("click", () => {
    if (!ctxTargetItem) return;
    currentBookmarkId = ctxTargetItem.dataset.id;
    const link = ctxTargetItem.querySelector("a");
    editBookmarkName.value = link ? link.querySelector("span")?.textContent?.trim() || link.textContent.trim() : "";
    editBookmarkURL.value  = ctxTargetItem.dataset.url || "";
    if (ctxTargetItem.dataset.url) setBookmarkFavicon(editBookmarkFavicon, ctxTargetItem.dataset.url);
    saveBookmarkChanges.disabled = false;
    openEditBookmarkModal();
    hideCtxMenu();
});

// ── ctx: Copy URL ──
document.getElementById("ctxCopyURL").addEventListener("click", () => {
    if (!ctxTargetItem) return;
    const url = ctxTargetItem.dataset.url;
    if (url) {
        navigator.clipboard.writeText(url)
            .then(() => bmShowToast("bm_toast_copied", "copy"))
            .catch(() => bmShowToast("bm_toast_copied", "copy"));
    }
    hideCtxMenu();
});

// ── ctx: Delete bookmark ──
document.getElementById("ctxDelete").addEventListener("click", async () => {
    if (!ctxTargetItem) return;
    const id = ctxTargetItem.dataset.id;
    const titleEl = ctxTargetItem.querySelector("span") || ctxTargetItem.querySelector("a");
    const title = titleEl ? titleEl.textContent.trim() : "";
    const url = ctxTargetItem.dataset.url || "";
    const confirmMsg = t("deleteBookmark").replace("{title}", title || url || "");

    // Capture element reference BEFORE hideCtxMenu nullifies ctxTargetItem
    const targetEl = ctxTargetItem;
    hideCtxMenu();
    if (!await confirmPrompt(confirmMsg)) return;

    // Get index before deleting for undo
    const parentLi = targetEl.closest("li.folder");
    const parentId = parentLi ? parentLi.dataset.id : "1";
    const oldIndex = DD_getBookmarkApiIndexForLi(targetEl, parentId);

    try {
        const subtrees = await _bmGetSubTree(id);
        const subtreeNode = subtrees[0];

        if (isFirefox) {
            bookmarksAPI.remove(id).then(() => {
                targetEl.remove();
                _bmPushHistoryEntry({
                    kind: "bookmark-delete",
                    parentId: parentId,
                    index: oldIndex,
                    node: subtreeNode,
                    currentId: id
                });
                bmShowToast("bm_toast_deleted", "delete");
            }).catch(console.error);
        } else {
            bookmarksAPI.remove(id, () => {
                targetEl.remove();
                _bmPushHistoryEntry({
                    kind: "bookmark-delete",
                    parentId: parentId,
                    index: oldIndex,
                    node: subtreeNode,
                    currentId: id
                });
                bmShowToast("bm_toast_deleted", "delete");
            });
        }
    } catch (e) {
        console.error(e);
    }
});

// ── ctx: Open all in new tabs (folder) ──
document.getElementById("ctxOpenAll").addEventListener("click", async () => {
    if (!ctxTargetItem) return;
    const links = Array.from(ctxTargetItem.querySelectorAll("a[href]")).map(a => a.href).filter(Boolean);
    if (!links.length) { hideCtxMenu(); return; }
    const confirmMsg = t("bm_openAllConfirm").replace("{count}", links.length);
    hideCtxMenu();
    if (!await confirmPrompt(confirmMsg)) return;
    links.forEach(url => {
        if (isFirefox)         browser.tabs.create({ url, active: false });
        else if (isChromiumBased) chrome.tabs.create({ url, active: false });
        else                   window.open(url, "_blank");
    });
});

// ── ctx: Rename folder ──
document.getElementById("ctxRenameFolder").addEventListener("click", async () => {
    if (!ctxTargetItem) return;
    const id = ctxTargetItem.dataset.id;
    const titleNode = Array.from(ctxTargetItem.childNodes).find(n => n.nodeType === Node.TEXT_NODE && n.textContent.trim());
    const oldName = titleNode ? titleNode.textContent.trim() : "";
    hideCtxMenu();
    const newName = await inputPrompt(t("bm_renameFolder"), oldName);
    if (!newName || newName.trim() === oldName) return;
    const upd = { title: newName.trim() };
    const historyEntry = {
        kind: "bookmark-edit",
        id: id,
        oldData: { title: oldName },
        newData: { title: newName.trim() }
    };
    if (isFirefox) {
        bookmarksAPI.update(id, upd).then(() => {
            if (titleNode) titleNode.textContent = " " + newName.trim();
            _bmPushHistoryEntry(historyEntry);
        }).catch(console.error);
    } else {
        bookmarksAPI.update(id, upd, () => {
            if (chrome.runtime.lastError) {
                return;
            }
            if (titleNode) titleNode.textContent = " " + newName.trim();
            _bmPushHistoryEntry(historyEntry);
        });
    }
});

// ── ctx: Delete folder ──
document.getElementById("ctxDeleteFolder").addEventListener("click", async () => {
    if (!ctxTargetItem) return;
    const id = ctxTargetItem.dataset.id;
    const titleNode = Array.from(ctxTargetItem.childNodes).find(n => n.nodeType === Node.TEXT_NODE && n.textContent.trim());
    const title = titleNode ? titleNode.textContent.trim() : "";
    const confirmMsg = t("deleteBookmark").replace("{title}", title);

    // Capture element reference BEFORE hideCtxMenu nullifies ctxTargetItem
    const targetEl = ctxTargetItem;
    hideCtxMenu();
    if (!await confirmPrompt(confirmMsg)) return;

    try {
        const subtrees = await _bmGetSubTree(id);
        const subtreeNode = subtrees[0];

        const parentLi = targetEl.parentElement?.closest("li.folder");
        const parentId = parentLi ? parentLi.dataset.id : "1";
        const oldIndex = DD_getBookmarkApiIndexForLi(targetEl, parentId);

        if (isFirefox) {
            bookmarksAPI.removeTree(id).then(() => {
                targetEl.remove();
                _bmPushHistoryEntry({
                    kind: "bookmark-delete",
                    parentId: parentId,
                    index: oldIndex,
                    node: subtreeNode,
                    currentId: id
                });
                bmShowToast("bm_toast_deleted", "delete");
            }).catch(console.error);
        } else {
            bookmarksAPI.removeTree(id, () => {
                targetEl.remove();
                _bmPushHistoryEntry({
                    kind: "bookmark-delete",
                    parentId: parentId,
                    index: oldIndex,
                    node: subtreeNode,
                    currentId: id
                });
                bmShowToast("bm_toast_deleted", "delete");
            });
        }
    } catch (e) {
        console.error(e);
    }
});

// ── ctx: Add page ──
document.getElementById("ctxAddPage").addEventListener("click", async () => {
    const targetItem = ctxTargetItem;
    const parentItem = targetItem?.closest("li.folder") || null;
    let parentId = parentItem ? parentItem.dataset.id : await _getDefaultParentId();
    hideCtxMenu();
    await _bmAddPageManual(parentId);
});

// ── ctx: Add folder ──
document.getElementById("ctxAddFolder").addEventListener("click", async () => {
    const targetItem = ctxTargetItem;
    const parentItem = targetItem?.closest("li.folder") || null;
    let parentId = parentItem ? parentItem.dataset.id : await _getDefaultParentId();
    hideCtxMenu();

    const name = await inputPrompt(t("bm_newFolderName"), "");
    if (!name || !name.trim()) return;

    const newFolder = { parentId, title: name.trim() };
    if (isFirefox) {
        bookmarksAPI.create(newFolder).then((created) => {
            loadBookmarks();
            bmShowToast("bm_toast_added", "add");
        }).catch(console.error);
    } else {
        bookmarksAPI.create(newFolder, (created) => {
            loadBookmarks();
            bmShowToast("bm_toast_added", "add");
        });
    }
});

// ── ctx: Add Section ──
document.getElementById("ctxAddSection")?.addEventListener("click", async () => {
    const anchor = ctxTargetItem;
    hideCtxMenu();
    const title = await inputPrompt(t("bm_sectionName"), "");
    if (!title?.trim()) return;
    const afterId = _bmResolveSectionAfterId(anchor?.dataset?.id || "start");
    if (afterId === null) return;
    _bmAddSection(title.trim(), afterId);
});

// ── Helper: fetch page title from a URL via content script ──
async function _bmFetchPageTitle(url) {
    return new Promise((resolve) => {
        try {
            if (isChromiumBased) {
                chrome.tabs.create({ url, active: false }, (tab) => {
                    const tabId = tab.id;
                    // Wait for tab to load, then grab title
                    const listener = (changedTabId, changeInfo, updatedTab) => {
                        if (changedTabId === tabId && changeInfo.status === "complete") {
                            chrome.tabs.onUpdated.removeListener(listener);
                            const title = updatedTab.title || new URL(url).hostname;
                            chrome.tabs.remove(tabId, () => {});
                            resolve(title);
                        }
                    };
                    chrome.tabs.onUpdated.addListener(listener);
                    // Fallback timeout
                    setTimeout(() => {
                        chrome.tabs.onUpdated.removeListener(listener);
                        chrome.tabs.get(tabId, (t) => {
                            const title = t?.title || new URL(url).hostname;
                            chrome.tabs.remove(tabId, () => {});
                            resolve(title);
                        });
                    }, 5000);
                });
            } else if (isFirefox) {
                browser.tabs.create({ url, active: false }).then((tab) => {
                    const tabId = tab.id;
                    const listener = (changedTabId, changeInfo, updatedTab) => {
                        if (changedTabId === tabId && changeInfo.status === "complete") {
                            browser.tabs.onUpdated.removeListener(listener);
                            const title = updatedTab.title || new URL(url).hostname;
                            browser.tabs.remove(tabId);
                            resolve(title);
                        }
                    };
                    browser.tabs.onUpdated.addListener(listener);
                    setTimeout(() => {
                        browser.tabs.onUpdated.removeListener(listener);
                        browser.tabs.get(tabId).then(t => {
                            const title = t?.title || new URL(url).hostname;
                            browser.tabs.remove(tabId);
                            resolve(title);
                        });
                    }, 5000);
                });
            } else {
                resolve(new URL(url).hostname);
            }
        } catch (e) {
            resolve(url);
        }
    });
}

// ── Shared Auto logic ──
// ── _bmSaveBookmark: create bookmark and show toast ──
function _bmSaveBookmark(parentId, title, url) {
    const newBm = { parentId, title: title.trim(), url };
    if (isFirefox) {
        bookmarksAPI.create(newBm).then((created) => {
            _bmInsertCreatedRootNodeIntoManualOrder(created);
            loadBookmarks();
            bmShowToast("bm_toast_added", "add");
        }).catch(console.error);
    } else {
        bookmarksAPI.create(newBm, (created) => {
            _bmInsertCreatedRootNodeIntoManualOrder(created);
            loadBookmarks();
            bmShowToast("bm_toast_added", "add");
        });
    }
}

// ── _bmAddPageManual: Add Page with Auto button inside the modal ──
const BM_AUTO_SENTINEL = "__BM_AUTO__";
async function _bmAddPageManual(parentId) {
    const autoText = translations[currentLanguage]?.bm_addPageAuto || translations["en"]?.bm_addPageAuto || "Auto";
    const autoBtn = { text: autoText, value: BM_AUTO_SENTINEL };

    // Step 1: Ask for page name (with Auto button)
    const nameResult = await inputPrompt(t("bm_newPageName"), "", [autoBtn]);

    if (nameResult === BM_AUTO_SENTINEL) {
        // Auto mode: ask URL only, then fetch title automatically
        const rawUrl = await inputPrompt(t("bm_newPageURL"), "https://");
        if (!rawUrl || !rawUrl.trim() || rawUrl.trim() === "https://") return;
        let url = rawUrl.trim();
        if (!/^https?:\/\//i.test(url)) url = "https://" + url;
        bmShowToast("bm_autoFetching", "edit");
        let title;
        try { title = await _bmFetchPageTitle(url); }
        catch (e) { title = new URL(url).hostname; }
        _bmSaveBookmark(parentId, title, url);
        return;
    }

    // Manual mode: user typed a name (or clicked cancel)
    if (!nameResult || !nameResult.trim()) return;
    const url = await inputPrompt(t("bm_newPageURL"), "https://");
    if (!url || !url.trim() || url.trim() === "https://") return;
    _bmSaveBookmark(parentId, nameResult.trim(), url.trim());
}

// ─────────────── End Context Menu System ───────────────

// ═══════════════════════════════════════════════════
// ─── Bookmark Toast Notification System ───
// ═══════════════════════════════════════════════════
let _bmToastTimer = null;
let _bmToastProgressTimer = null;

function _bmParseCssTimeToMs(value) {
    const raw = String(value || "").trim();
    if (!raw) return 0;
    if (raw.endsWith("ms")) return parseFloat(raw) || 0;
    if (raw.endsWith("s")) return (parseFloat(raw) || 0) * 1000;
    return parseFloat(raw) || 0;
}

function _bmGetTransitionTotalMs(el) {
    if (!el) return 0;
    const styles = getComputedStyle(el);
    const durations = styles.transitionDuration.split(",");
    const delays = styles.transitionDelay.split(",");
    const transitionTotal = Math.max(durations.length, delays.length, 1);
    let maxMs = 0;

    for (let i = 0; i < transitionTotal; i++) {
        const duration = _bmParseCssTimeToMs(durations[i] ?? durations[durations.length - 1]);
        const delay = _bmParseCssTimeToMs(delays[i] ?? delays[delays.length - 1]);
        maxMs = Math.max(maxMs, duration + delay);
    }

    const animationDurations = styles.animationDuration.split(",");
    const animationDelays = styles.animationDelay.split(",");
    const animationTotal = Math.max(animationDurations.length, animationDelays.length, 1);

    for (let i = 0; i < animationTotal; i++) {
        const duration = _bmParseCssTimeToMs(animationDurations[i] ?? animationDurations[animationDurations.length - 1]);
        const delay = _bmParseCssTimeToMs(animationDelays[i] ?? animationDelays[animationDelays.length - 1]);
        maxMs = Math.max(maxMs, duration + delay);
    }

    return Math.round(maxMs);
}

function bmShowToast(msgKey, iconType) {
    const DURATION = 3000;

    // Create toast if not existing
    let toast = document.getElementById("bmActionToast");
    if (!toast) {
        toast = document.createElement("div");
        toast.id = "bmActionToast";
        toast.className = "bm-action-toast";
        toast.innerHTML = `
            <div class="bm-toast-progress"></div>
            <div class="bm-toast-inner">
                <div class="bm-toast-icon-wrap" id="bmToastIconWrap"></div>
                <span class="bm-toast-text" id="bmToastText"></span>
            </div>`;
        document.body.appendChild(toast);
    }

    const iconWrap = document.getElementById("bmToastIconWrap");
    const textEl   = document.getElementById("bmToastText");
    const progress = toast.querySelector(".bm-toast-progress");

    // Set icon based on type
    const icons = {
        copy:    `<svg viewBox="0 0 24 24"><path d="M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z"/></svg>`,
        edit:    `<svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>`,
        delete:  `<svg viewBox="0 0 24 24"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>`,
        add:     `<svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>`,
        move:    `<svg viewBox="0 0 24 24"><path d="M20 9V7H4v2l8 8 8-8z"/></svg>`,
        undo:    `<svg viewBox="0 0 24 24"><path d="M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z"/></svg>`,
        redo:    `<svg viewBox="0 0 24 24"><path d="M18.4 10.6C16.55 8.99 14.15 8 11.5 8c-4.65 0-8.58 3.03-9.96 7.22L3.9 16c1.05-3.19 4.05-5.5 7.6-5.5 1.95 0 3.73.72 5.12 1.88L13 16h9V7l-3.6 3.6z"/></svg>`,
        pin:     `<svg viewBox="0 0 24 24"><path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2z"/></svg>`,
        unpin:   `<svg viewBox="0 0 24 24"><path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2zm-4 5.17V16h-1v1.17L9.83 16H8v-.17L10 14V4h4v10l2 1.83V16h-1.17L12 17.17z"/></svg>`,
    };

    const toastMsgKey = msgKey || "bm_toast_done";
    iconWrap.innerHTML = icons[iconType] || icons["edit"];
    textEl.textContent = t(toastMsgKey);

    // Reset + start progress
    progress.style.transition = "none";
    progress.style.width = "100%";
    toast.classList.remove("bm-toast-show", "bm-toast-out");
    void toast.offsetWidth;
    toast.classList.add("bm-toast-show");

    clearTimeout(_bmToastTimer);
    clearTimeout(_bmToastProgressTimer);
    cancelAnimationFrame(_bmToastProgressTimer);

    _bmToastProgressTimer = requestAnimationFrame(() => {
        progress.style.transition = `width ${DURATION}ms linear`;
        progress.style.width = "0%";
    });

    _bmToastTimer = setTimeout(() => {
        toast.classList.remove("bm-toast-show");
        void toast.offsetWidth;
        toast.classList.add("bm-toast-out");
        const hideDuration = Math.max(_bmGetTransitionTotalMs(toast), 180);
        setTimeout(() => toast.classList.remove("bm-toast-show", "bm-toast-out"), hideDuration + 20);
    }, DURATION);
}


// Disable save button if URL is empty
editBookmarkURL.addEventListener("input", () => {
    saveBookmarkChanges.disabled = editBookmarkURL.value.trim() === "";
});

// Save button action
saveBookmarkChanges.onclick = function () {
    if (!currentBookmarkId) return;

    const updatedTitle = editBookmarkName.value.trim();
    const updatedURL = encodeURI(editBookmarkURL.value.trim());
    const updatedData = { title: updatedTitle, url: updatedURL };

    // Get old values for undo
    const bmItem = document.querySelector(`#bookmarkList li[data-id="${currentBookmarkId}"]`);
    const oldTitle = bmItem?.querySelector("span")?.textContent?.trim() || bmItem?.querySelector("a")?.textContent?.trim() || "";
    const oldURL   = bmItem?.dataset?.url || "";

    const historyEntry = {
        kind: "bookmark-edit",
        id: currentBookmarkId,
        oldData: { title: oldTitle, url: oldURL },
        newData: { title: updatedTitle, url: updatedURL }
    };

    if (isFirefox) {
        bookmarksAPI.update(currentBookmarkId, updatedData).then(() => {
            updateBookmark(currentBookmarkId, updatedTitle, updatedURL);
            _bmPushHistoryEntry(historyEntry);
            closeEditBookmarkModal(() => {
                bmShowToast("bm_toast_edited", "edit");
                loadBookmarks();
            });
        }).catch(err => {
            console.error("Error updating bookmark:", err);
        });
    } else {
        bookmarksAPI.update(currentBookmarkId, updatedData, function () {
            if (chrome.runtime.lastError) {
                console.error("Error updating bookmark:", chrome.runtime.lastError);
                return;
            }
            updateBookmark(currentBookmarkId, updatedTitle, updatedURL);
            _bmPushHistoryEntry(historyEntry);
            closeEditBookmarkModal(() => {
                bmShowToast("bm_toast_edited", "edit");
                loadBookmarks();
            });
        });
    }
};

// Cancel button action
cancelBookmarkEdit.onclick = function () {
    closeEditBookmarkModal();
};

// Function to update after edit
function updateBookmark(bookmarkId, title, url) {
    const bookmarkItem = document.querySelector(`li[data-id="${bookmarkId}"]`);
    if (bookmarkItem) {
        const link = bookmarkItem.querySelector("a");
        const span = bookmarkItem.querySelector("span");
        if (span) {
            span.textContent = title; // Update only the text span, preserving the favicon img
        } else if (link) {
            link.textContent = title; // Fallback if no span
        }
        if (link) link.href = url;
        bookmarkItem.dataset.url = url;
    }
}

// Move focus to URL field when Enter is pressed in Name field
editBookmarkName.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        event.preventDefault();
        editBookmarkURL.focus();
    }
});

// Trigger Save button when Enter is pressed in URL field
editBookmarkURL.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        event.preventDefault();
        if (!saveBookmarkChanges.disabled) {
            saveBookmarkChanges.click();
        }
    }
});

// ------------------------ End of Bookmark System -----------------------------------

// Save and load the state of the bookmarks toggle
document.addEventListener("DOMContentLoaded", function () {
    bookmarksCheckbox.addEventListener("change", async function () {
        if (!bookmarksCheckbox.checked) {
            updateBookmarkUI(false);
            return;
        }
        await verifyBookmarkPermission();
    });

    bookmarkGridCheckbox.addEventListener("change", function () {
        saveCheckboxState("bookmarkGridCheckboxState", bookmarkGridCheckbox);
        
        // Toggle class immediately only if sidebar is closed.
        // If open, let loadBookmarks handle it inside the promise resolution to prevent flickers.
        if (!bookmarkSidebar.classList.contains("open") || !bookmarksAPI?.getTree) {
            bookmarkList.classList.toggle("grid-view", bookmarkGridCheckbox.checked);
        }

        // Rebuild DOM only if sidebar is open and API is ready
        // (this event also fires during page load from loadCheckboxState — skip then)
        bmStartViewSwitchVisualGuard();
        if (bookmarkSidebar.classList.contains("open") && bookmarksAPI?.getTree) {
            Promise.resolve(loadBookmarks()).finally(() => {
                requestAnimationFrame(() => {
                    requestAnimationFrame(() => {
                        bookmarkList.classList.remove("bm-view-switching");
                    });
                });
            });
        }
    });

    loadCheckboxState("bookmarksCheckboxState", bookmarksCheckbox);
    loadDisplayStatus("bookmarksDisplayStatus", bookmarkButton);
    loadCheckboxState("bookmarkGridCheckboxState", bookmarkGridCheckbox);
});

// ═══════════════════════════════════════════════════
// ─── Filter Bar System ───
// ═══════════════════════════════════════════════════
function updateFilterButtons() {
    document.querySelectorAll(".bm-filter-btn").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.filter === currentFilter);
    });
    // Sync sidebar ctx menu checkmarks
    ["all","bookmarks","folders"].forEach(f => {
        const checkEl = document.getElementById(`sctxFilter${f.charAt(0).toUpperCase() + f.slice(1)}Check`);
        if (checkEl) checkEl.style.display = f === currentFilter ? "block" : "none";
    });
    // special case for "all"
    const allCheck = document.getElementById("sctxFilterAllCheck");
    if (allCheck) allCheck.style.display = currentFilter === "all" ? "block" : "none";
    const bmCheck = document.getElementById("sctxFilterBmCheck");
    if (bmCheck) bmCheck.style.display = currentFilter === "bookmarks" ? "block" : "none";
    const flCheck = document.getElementById("sctxFilterFoldersCheck");
    if (flCheck) flCheck.style.display = currentFilter === "folders" ? "block" : "none";
}

function initFilterButtons() {
    document.querySelectorAll(".bm-filter-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            currentFilter = btn.dataset.filter;
            localStorage.setItem("bookmarkFilterType", currentFilter);
            updateFilterButtons();
            loadBookmarks();
        });
    });
}

// ─── Sync sort/view checkmarks in sidebar ctx menu ───
function updateSidebarCtxChecks() {
    // Sort
    const azCheck   = document.getElementById("sctxSortAZCheck");
    const dateCheck = document.getElementById("sctxSortDateCheck");
    if (azCheck)   azCheck.style.display   = currentSortMethod === "title" ? "block" : "none";
    if (dateCheck) dateCheck.style.display = currentSortMethod === "date"  ? "block" : "none";
    // View
    const isGrid = bookmarkGridCheckbox?.checked;
    const listChk = document.getElementById("sctxViewListCheck");
    const gridChk = document.getElementById("sctxViewGridCheck");
    if (listChk) listChk.style.display = !isGrid ? "block" : "none";
    if (gridChk) gridChk.style.display = isGrid  ? "block" : "none";
    // Filter
    updateFilterButtons();
}

// ═══════════════════════════════════════════════════
// ─── Sidebar Empty-Space Context Menu ───
// ═══════════════════════════════════════════════════
const sidebarCtxMenu = document.getElementById("sidebarCtxMenu");
let _sidebarCtxVisible = false;
let _sidebarCtxHideTimer = null;

function showSidebarCtxMenu(x, y) {
    // Close item ctx menu if open
    hideCtxMenu(true);
    if (_sidebarCtxHideTimer) {
        clearTimeout(_sidebarCtxHideTimer);
        _sidebarCtxHideTimer = null;
    }
    sidebarCtxMenu.classList.remove("ctx-menu-closing");
    updateSidebarCtxChecks();
    sidebarCtxMenu.style.display = "block";
    _makeMenuDraggable(sidebarCtxMenu);
    sidebarCtxMenu.style.left = "0px";
    sidebarCtxMenu.style.top  = "0px";
    const sidebarMenuPos = _clampCtxMenuPosition(
        x,
        y,
        sidebarCtxMenu.offsetWidth,
        sidebarCtxMenu.offsetHeight
    );
    sidebarCtxMenu.style.left = sidebarMenuPos.left + "px";
    sidebarCtxMenu.style.top  = sidebarMenuPos.top + "px";
    _sidebarCtxVisible = true;
}

function hideSidebarCtxMenu(animated = true) {
    if (!sidebarCtxMenu) return;
    if (_sidebarCtxHideTimer) {
        clearTimeout(_sidebarCtxHideTimer);
        _sidebarCtxHideTimer = null;
    }
    if (animated && sidebarCtxMenu.style.display !== "none") {
        sidebarCtxMenu.classList.add("ctx-menu-closing");
        const _mult = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")) || 1;
        const dur = Math.round(260 * _mult) + 20;
        _sidebarCtxHideTimer = setTimeout(() => {
            sidebarCtxMenu.style.display = "none";
            sidebarCtxMenu.classList.remove("ctx-menu-closing");
            _sidebarCtxHideTimer = null;
        }, dur);
    } else {
        sidebarCtxMenu.style.display = "none";
        sidebarCtxMenu.classList.remove("ctx-menu-closing");
    }
    _sidebarCtxVisible = false;
}

// Dismiss on outside click
document.addEventListener("click", (e) => {
    if (_sidebarCtxVisible && !sidebarCtxMenu.contains(e.target)) hideSidebarCtxMenu();
});
document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") hideSidebarCtxMenu();
});

// Right-click on bookmarkSidebar empty space
bookmarkSidebar.addEventListener("contextmenu", (e) => {
    const onItem = e.target.closest("li[data-id]");
    const onControls = e.target.closest(".bookmark-controls-container, .bookmark-search-container, .bm-filter-bar, .bookmark-sidebar-header");
    if (onItem || onControls) return; // let item ctx menu handle it
    e.preventDefault();
    hideCtxMenu(); // hide item menu if open
    showSidebarCtxMenu(e.clientX + 4, e.clientY + 4);
});

function initSidebarCtxMenu() {
    const t2 = (key) => translations[currentLanguage]?.[key] || translations["en"]?.[key] || key;

    function updateSidebarCtxLabels() {
        const set = (id, key) => { const el = document.getElementById(id); if (el) el.textContent = t2(key); };
        set("sctxAddPageLabel",        "bm_addPage");
        set("sctxAddFolderLabel",      "bm_addFolder");
        set("sctxSortLabel",           "bookmarkSortBy");
        set("sctxSortAZLabel",         "bm_sortAZ");
        set("sctxSortDateLabel",       "bm_sortDate");
        set("sctxViewLabel",           "bookmarkViewAs");
        set("sctxViewListLabel",       "bookmarkViewList");
        set("sctxViewGridLabel",       "bookmarkViewGrid");
        set("sctxFilterLabel",         "bm_filterLabel");
        set("sctxFilterAllLabel",      "bm_filterAll");
        set("sctxFilterBmLabel",       "bm_filterBm");
        set("sctxFilterFoldersLabel",  "bm_filterFolders");
        set("sctxFolderOrderLabel",    "bm_folderPosLabel");
        set("sctxFolderOrderFirstLabel", "bm_folderFirst");
        set("sctxFolderOrderLastLabel",  "bm_folderLast");
        set("ctxAddSectionLabel",      "bm_addSection");
        // Also update filter bar labels
        set("bfAllLabel",       "bm_filterAll");
        set("bfBookmarksLabel", "bm_filterBm");
        set("bfFoldersLabel",   "bm_filterFolders");
        // Header labels
        set("bookmarkFilterBy", "bookmarkFilterBy");
    }

    updateSidebarCtxLabels();
    updateSidebarCtxChecks();

    // ── sctx: Add page ──
    document.getElementById("sctxAddPage").addEventListener("click", async () => {
        hideSidebarCtxMenu();
        const rootParentId = await _getDefaultParentId();
        await _bmAddPageManual(rootParentId);
    });

    // ── sctx: Add folder ──
    document.getElementById("sctxAddFolder").addEventListener("click", async () => {
        hideSidebarCtxMenu();
        const name = await inputPrompt(t2("bm_newFolderName"), "");
        if (!name?.trim()) return;
        const rootParentId = await _getDefaultParentId();
        const newFolder = { parentId: rootParentId, title: name.trim() };
        if (isFirefox) {
            bookmarksAPI.create(newFolder).then(created => {
                loadBookmarks();
                bmShowToast("bm_toast_added", "add");
            }).catch(console.error);
        } else {
            bookmarksAPI.create(newFolder, created => {
                loadBookmarks();
                bmShowToast("bm_toast_added", "add");
            });
        }
    });

    // ── sctx: Sort A-Z ──
    document.getElementById("sctxSortAZ").addEventListener("click", () => {
        currentSortMethod = "title";
        _bmLastExplicitSort = "title";
        localStorage.setItem("bookmarkSortMethod", "title");
        updateSortButtons();
        updateSidebarCtxChecks();
        loadBookmarks();
        hideSidebarCtxMenu();
    });

    // ── sctx: Sort Date ──
    document.getElementById("sctxSortDate").addEventListener("click", () => {
        currentSortMethod = "date";
        _bmLastExplicitSort = "date";
        localStorage.setItem("bookmarkSortMethod", "date");
        updateSortButtons();
        updateSidebarCtxChecks();
        loadBookmarks();
        hideSidebarCtxMenu();
    });

    // ── sctx: View List ──
    document.getElementById("sctxViewList").addEventListener("click", () => {
        if (bookmarkGridCheckbox?.checked) bookmarkGridCheckbox.click();
        updateSidebarCtxChecks();
        hideSidebarCtxMenu();
    });

    // ── sctx: View Grid ──
    document.getElementById("sctxViewGrid").addEventListener("click", () => {
        if (!bookmarkGridCheckbox?.checked) bookmarkGridCheckbox.click();
        updateSidebarCtxChecks();
        hideSidebarCtxMenu();
    });

    // ── sctx: Filter buttons ──
    ["All","Bm","Folders"].forEach(suffix => {
        const filterMap = { All: "all", Bm: "bookmarks", Folders: "folders" };
        const btn = document.getElementById(`sctxFilter${suffix}`);
        if (!btn) return;
        btn.addEventListener("click", () => {
            currentFilter = filterMap[suffix];
            localStorage.setItem("bookmarkFilterType", currentFilter);
            updateFilterButtons();
            loadBookmarks();
            hideSidebarCtxMenu();
        });
    });

    // ── sctx: Folder Order ──
    const sctxFolderFirst = document.getElementById("sctxFolderOrderFirst");
    const sctxFolderLast  = document.getElementById("sctxFolderOrderLast");

    function updateFolderOrderChecks() {
        const firstCheck = document.getElementById("sctxFolderOrderFirstCheck");
        const lastCheck  = document.getElementById("sctxFolderOrderLastCheck");
        if (firstCheck) firstCheck.style.display = currentFolderOrder === "first" ? "block" : "none";
        if (lastCheck)  lastCheck.style.display  = currentFolderOrder === "last"  ? "block" : "none";
    }
    updateFolderOrderChecks();

    if (sctxFolderFirst) {
        sctxFolderFirst.addEventListener("click", () => {
            currentFolderOrder = "first";
            localStorage.setItem("bookmarkFolderOrder", "first");
            // Exit manual mode so folder grouping is applied
            if (currentSortMethod === "manual") {
                currentSortMethod = "title";
                localStorage.setItem("bookmarkSortMethod", "title");
                _bmClearManualOrder();
                updateSortButtons();
            }
            updateFolderOrderChecks();
            loadBookmarks();
            hideSidebarCtxMenu();
        });
    }
    if (sctxFolderLast) {
        sctxFolderLast.addEventListener("click", () => {
            currentFolderOrder = "last";
            localStorage.setItem("bookmarkFolderOrder", "last");
            // Exit manual mode so folder grouping is applied
            if (currentSortMethod === "manual") {
                currentSortMethod = "title";
                localStorage.setItem("bookmarkSortMethod", "title");
                _bmClearManualOrder();
                updateSortButtons();
            }
            updateFolderOrderChecks();
            loadBookmarks();
            hideSidebarCtxMenu();
        });
    }
}

// Helper: get the best parentId for adding new items (bookmarks bar root)
async function _getDefaultParentId() {
    return new Promise((resolve) => {
        if (!bookmarksAPI?.getTree) { resolve("1"); return; }
        bookmarksAPI.getTree().then(tree => {
            const rootChildren = tree[0]?.children || [];
            let default_folder = "Bookmarks bar";
            if (isEdge)  default_folder = "Favorites bar";
            if (isBrave) default_folder = "Bookmarks";
            const bar = rootChildren.find(n => n.title === default_folder || n.folderType === "bookmarks-bar");
            resolve(bar?.id || rootChildren[0]?.id || "1");
        }).catch(() => resolve("1"));
    });
}

// ─── Also fix ctx Add Page/Folder to append at end ───
// Override the existing ctxAddPage and ctxAddFolder to use _getDefaultParentId

// ─────────────────────────────────────────────────────

function _bmCanHandleHistoryShortcut(event) {
    // Check if bookmarks feature is enabled
    if (!bookmarksCheckbox || !bookmarksCheckbox.checked) return false;

    // Do not trigger undo/redo if the shortcut settings panel is active to avoid conflict
    const shortcutList = document.getElementById("shortcutList");
    const isShortcutSettingsActive = shortcutList && !shortcutList.closest(".inactive") && shortcutList.offsetParent !== null;
    if (isShortcutSettingsActive) {
        return false;
    }

    // Do not trigger undo/redo if user is editing text in an input or textarea
    const activeEl = document.activeElement;
    if (activeEl) {
        const tagName = activeEl.tagName.toLowerCase();
        if (tagName === "input" || tagName === "textarea" || activeEl.isContentEditable) {
            return false;
        }
    }

    // Do not trigger undo/redo if a prompt modal is open
    // (alert-modal.js toggles classes, not inline styles)
    const modalContainer = document.getElementById("prompt-modal-container");
    if (modalContainer) {
        return false;
    }

    return true;
}

// Keyboard shortcut for bookmarks
document.addEventListener("keydown", function (event) {
    const primaryModifier = event.ctrlKey || event.metaKey;
    if (!primaryModifier || event.altKey) return;
    if (!_bmCanHandleHistoryShortcut(event)) return;

    const code = String(event.code || "").toLowerCase();
    const key = String(event.key || "").toLowerCase();
    if (code !== "keyz" && code !== "keyy" && key !== "z" && key !== "y") return;

    const isZ = code === "keyz" || key === "z";
    const isY = code === "keyy" || key === "y";

    if (isY || (isZ && event.shiftKey)) {
        event.preventDefault();
        event.stopPropagation();
        _bmApplyHistoryEntry("redo");
        return;
    }

    if (isZ) {
        event.preventDefault();
        event.stopPropagation();
        _bmApplyHistoryEntry("undo");
    }
});

document.addEventListener("keydown", function (event) {
    // Prevent shortcut if modal or menu is open
    // (alert-modal.js toggles classes, not inline styles)
    const modalContainer = document.getElementById("prompt-modal-container");
    if (modalContainer || menuBar.style.display !== "none") {
        return;
    }

    if (bookmarksCheckbox.checked &&
        event.key === "ArrowRight" &&
        !event.repeat &&
        event.target.tagName !== "INPUT" &&
        event.target.tagName !== "TEXTAREA" &&
        event.target.isContentEditable !== true
    ) {
        bookmarkButton.click();
    }
});

// ── Marquee: set up data-marquee on long bookmark names (hover triggers animation via CSS) ──
const BM_GAP = "\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"; // gap between copies

function bmSetupMarquees() {
    const links = document.querySelectorAll(
        "#bookmarkList.folders-only-view .bm-col > li.folder.open ul li:not(.folder) a"
    );
    links.forEach(link => {
        const span = link.querySelector("span");
        if (!span || span.dataset.marquee) return;
        const overflow = span.scrollWidth - span.clientWidth;
        if (overflow <= 2) return;
        const original = span.dataset.original || span.textContent;
        span.dataset.original = original;
        span.textContent = original + BM_GAP + original;
        span.dataset.marquee = "1";
        const totalScrollPx = span.scrollWidth / 2;
        const dur = Math.max(2.5, totalScrollPx / 60);
        span.style.setProperty("--bm-scroll-dur", `${dur.toFixed(1)}s`);
    });
}

// Run only when a folder is opened/closed — NOT on drag events
document.addEventListener("click", function(e) {
    const folder = e.target.closest(
        "#bookmarkList.folders-only-view .bm-col > li.folder"
    );
    if (folder) setTimeout(bmSetupMarquees, 50);
});

// Run once after initial bookmark load
document.addEventListener("DOMContentLoaded", () => setTimeout(bmSetupMarquees, 200));

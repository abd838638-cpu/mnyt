/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

// ── API Configuration ──────────────────────────────────────────────────────
const TRANSLATIONS_API_BASE = "https://your-api.com/api/translations";

// ── English fallback (bundled so the page always works) ─────────────────────
const en = {
    "github": "GitHub",
    "feedback": "Feedback",
    "personalizationSectionTitle": "Personalization",
    "clockSectionTitle": "Clock",
    "searchSectionTitle": "Search",
    "weatherSectionTitle": "Weather",
    "appearanceSectionTitle": "Appearance",
    "settingsSectionTitle": "Settings",
    "shortcutsText": "Shortcuts",
    "enableShortcutsText": "Show saved shortcuts",
    "editShortcutsText": "Edit Shortcuts",
    "shortcutsInfoText": "Choose which shortcuts get shown",
    "editShortcutsList": "Saved Shortcuts",
    "editShortcutsListInfo": "You can add new shortcuts by clicking the \"+\" icon or edit existing ones by clicking on the shortcut name or URL.",
    "adaptiveIconText": "Adaptive Icons",
    "adaptiveIconInfoText": "Make default shortcut icons smaller and match the theme",
    "bookmarksText": "Bookmarks",
    "bookmarksInfo": "Show bookmarks sidebar",
    "ai_tools_button": "AI Tools",
    "enable_ai_tools": "Show shortcuts for AI tools",
    "aiToolsSettingsText": "AI Tools Settings",
    "aiToolsSettingsInfo": "Manage AI tools shortcuts",
    "googleAppsMenuText": "Google Apps",
    "googleAppsMenuInfo": "Show shortcuts for Google Apps",
    "googleAppsHover": "Google Apps",
    "todoListText": "To Do List",
    "todoListInfo": "Show a daily To Do list",
    "todoListHover": "ToDo List",
    "todoPlaceholder": "Add task...",
    "hideClockBox": "Hide Clock",
    "hideClockBoxInfo": "Hide the clock and date",
    "digitalclocktitle": "Digital Clock",
    "digitalclockinfo": "Switch to the digital clock",
    "timeformattitle": "12-Hour Format",
    "timeformatinfo": "Use 12-hour time format",
    "greetingtitle": "Greeting",
    "greetinginfo": "Show greeting below custom text",
    "userTextTitle": "Customizable Text",
    "userTextInfo": "Show custom text below the clock",
    "fahrenheitCelsiusCheckbox": "Switch to Fahrenheit",
    "fahrenheitCelsiusText": "Refresh the page to apply changes",
    "hideWeatherTitle": "Hide Weather",
    "hideWeatherInfo": "Disable the weather widgets",
    "hideWeatherBox": "Hide Weather Card",
    "hideWeatherBoxInfo": "Show only temperature pill",
    "minMaxTempText": "Min-Max Temperature",
    "minMaxTempSubText": "Replace 'Feels Like' with minimum and maximum temperature",
    "micIconTitle": "Hide Microphone Icon",
    "micIconInfo": "If voice typing is not working",
    "hideSearchWith": "Hide Search Engines",
    "hideSearchWithInfo": "Switch between search engines by clicking its icon",
    "motivationalQuotesText": "Motivational Quotes",
    "motivationalQuotesInfo": "Show quotes below the searchbar",
    "search_suggestions_button": "Search Suggestions",
    "search_suggestions_text": "Enable search suggestions",
    "useproxytitletext": "Proxy Bypass",
    "useproxyText": "If search suggestions aren't working",
    "ProxyText": "CORS Bypass Proxy",
    "ProxySubtext": "Add your own CORS bypass proxy",
    "HostproxyButton": "Host your own proxy",
    "useGPS": "Use GPS",
    "useGPSInfo": "Enable GPS for live location updates",
    "UserLocText": "Enter your Location",
    "UserLocSubtext": "If the weather location isn't correct",
    "userLoc": "Your City or Coordinates (Latitude, Longitude)",
    "PrivacyPolicy": "Privacy policy",
    "WeatherApiText": "Enter your WeatherAPI key",
    "WeatherApiSubtext": "If the weather functionality isn't working",
    "userAPI": "Your weatherAPI key",
    "LearnMoreButton": "Learn more",
    "saveAPI": "Save",
    "days": ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    "months": ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    "bookmarksHeading": "Bookmarks",
    "bookmarkSortBy": "Sort by",
    "sortAlphabetical": "A-Z",
    "sortTimeAdded": "Old-New",
    "bookmarkViewAs": "View as",
    "bookmarkViewGrid": "Grid",
    "bookmarkViewList": "List",
    "bookmarkSearch": "Search bookmark",
    "editBookmarkHeading": "Edit Bookmark",
    "editBookmarkName": "Bookmark Name",
    "editBookmarkURL": "Bookmark URL",
    "conditionText": "Hello! How are you today?",
    "humidityLevel": "Humidity",
    "feelsLike": "Feels",
    "minMaxTemp": "Min ~ Max",
    "location": "Earth",
    "enterBtn": "Search",
    "searchPlaceholder": "Type here...",
    "listenPlaceholder": "Listening...",
    "searchWithHint": "Search With",
    "searchOnHint": "Search On",
    "userText": "Click here to edit",
    greeting: {
        "morning": "Good Morning!",
        "afternoon": "Good Afternoon!",
        "evening": "Good Evening!"
    },
    "defaultEngine": "Default",
    "googleEngine": "Google",
    "duckEngine": "Duck",
    "bingEngine": "Bing",
    "braveEngine": "Brave",
    "youtubeEngine": "YouTube",
    "gImagesEngine": "Images",
    "redditEngine": "Reddit",
    "wikipediaEngine": "Wikipedia",
    "quoraEngine": "Quora",
    "ai_tools": "AI Tools",
    "chatGPT": "ChatGPT",
    "gemini": "Gemini",
    "copilot": "Copilot",
    "claude": "Claude",
    "grok": "Grok",
    "qwen": "Qwen",
    "perplexity": "Perplexity",
    "deepseek": "DeepSeek",
    "metaAI": "Meta AI",
    "firefly": "Adobe Firefly",
    "hishamAgent": "Hisham Agent ✦",
    "aiSettingsIntro": "Select which AI tools to display",
    "resetAISettingsBtn": "Reset",
    "lightThemed": "Light",
    "darkThemed": "Dark",
    "systemThemed": "System",
    "uploadWallpaperText": "Upload Wallpaper",
    "rangColor": "Pick color",
    "opacityTitle": "Opacity",
    "adjustOpacityDesc": "Adjust interface transparency",
    "backupText": "Backup",
    "restoreText": "Restore",
    "resetsettings": "Reset Settings",
    "menuCloseText": "Close",
    "switchSearchModes": "Switch Search Modes",
    "switchSearchModesInfo": "Click on 'Search With' to change the mode.",
    "adjustZoom": "Adjust Zoom",
    "adjustZoomInfo": "Press Ctrl + \"+\" or Ctrl + \"-\" to adjust the zoom.",
    "changeBrowserTheme": "Change Browser Theme",
    "chromeThemeInfo": "Click the three dots (\u22ee) > More tools > Customize Chrome, then choose a color that matches the extension theme.",
    "edgeThemeInfo": "Goto Settings > Appearance, then choose a color that matches the extension theme.",
    "braveThemeInfo": "Visit <a href=\"https://chromewebstore.google.com/category/themes/\" target=\"_blank\">Chrome Theme Store</a>, download and apply the theme that matches the extension.",
    "firefoxThemeInfo": "Visit <a href=\"https://addons.mozilla.org/firefox/themes/\" target=\"_blank\">Firefox Themes</a>, download and apply the theme that matches the extension.",
    "updateFirefoxHomepage": "Update Homepage",
    "updateFirefoxHomepageInfo": "To change your homepage like the new tab as well, visit <a href=\"https://github.com/prem-k-r/MaterialYouNewTab#-firefox\" target=\"_blank\">this link</a> and follow the instructions.",
    "dontShowTips": "Don't show it again",
    "footerToastTitle": "Seeing a banner at the bottom?",
    "footerToastMessage": "To hide it, right-click it and select 'Hide Footer on New Tab Page'.",
    "okText": "OK",
    "yesText": "Yes",
    "noText": "No",
    "agreeText": "I Agree",
    "cancelText": "Cancel",
    "confirmWallpaper": "Would you like to set a new image as your wallpaper for the day?",
    "confirmRestore": "Are you sure you want to reset your settings? This action cannot be undone.",
    "Nobackgroundset": "No background image is currently set.",
    "NoFolderSelected": "You have a wallpaper set, but no folder is selected. Please select a folder to use the shuffle or pin features.",
    "clearbackgroundimage": "Are you sure you want to clear the background image?",
    "ProxyDisclaimer": "All proxy features are off by default.\n\nIf you enable search suggestions and CORS bypass proxy, it is strongly recommended to host your own proxy for enhanced privacy.\n\nBy default, the proxy will be set to https://mynt-proxy.rhythmcorehq.com, meaning all your data will go through this service, which may pose privacy concerns.",
    "GPSDisclaimer": "Your location data is used solely to provide accurate weather updates. It is temporarily stored within the browser and neither shared with any third-party services nor accessible to us.\n\nBy enabling GPS, you consent to sharing your location with the extension locally.",
    "failedbackup": "Backup failed: ",
    "restorecompleted": "Restore completed successfully!",
    "restorefailed": "Restore failed: ",
    "invalidBackup": "Invalid backup file selected.",
    "deleteBookmark": "Are you sure you want to delete the bookmark \"{title}\"?",
    "bm_open": "Open",
    "bm_openNewTab": "Open in new tab",
    "bm_edit": "Edit",
    "bm_copyURL": "Copy URL",
    "bm_delete": "Delete",
    "bm_addPage": "Add page...",
    "bm_addPageAuto": "Auto",
    "bm_autoFetching": "Fetching page title...",
    "bm_addFolder": "Add folder...",
    "bm_newPageName": "Page name",
    "bm_newPageURL": "Page URL",
    "bm_newFolderName": "Folder name",
    "bm_renameFolder": "Rename folder",
    "bm_deleteFolder": "Delete folder",
    "bm_openAll": "Open all in new tabs",
    "bm_openAllConfirm": "Open {count} tabs?",
    "bm_toast_copied": "URL copied!",
    "bm_toast_edited": "Bookmark updated",
    "bm_toast_deleted": "Bookmark deleted",
    "bm_toast_added": "Added successfully",
    "bm_toast_moved": "Order updated",
    "bm_toast_undo": "Undo done",
    "bm_toast_redo": "Redo done",
    "wallpaper_pinned": "Wallpaper pinned",
    "wallpaper_unpinned": "Wallpaper unpinned",
    "bm_nothing_to_undo": "Nothing to undo",
    "bm_nothing_to_redo": "Nothing to redo",
    "bm_filterLabel": "Show",
    "bm_filterAll": "All",
    "bm_filterBm": "Bookmarks",
    "bm_filterFolders": "Folders",
    "bm_sortAZ": "A\u2013Z",
    "bm_sortDate": "Old\u2013New",
    "bm_filterBmOnly": "Bookmarks only",
    "bm_filterFoldersOnly": "Folders only",
    "bm_folderPosLabel": "Folders position",
    "bm_folderFirst": "Folders first",
    "bm_folderLast": "Folders last",
    "bm_addSection": "Add section...",
    "bm_sectionName": "Section name",
    "bm_renameSection": "Rename section",
    "bm_deleteSection": "Delete section",
    "bm_sectionWide": "Full width",
    "bm_sectionNarrow": "Half width",
    "bm_sectionColor": "Section color",
    "bm_sectionAlign": "Text align",
    "bm_sectionGradient": "Gradient",
    "bm_sectionFontSize": "Font size",
    "bm_sectionStyle": "Text style",
    "bm_sectionBold": "Bold",
    "bm_sectionItalic": "Italic",
    "bm_sectionUpper": "UPPERCASE",
    "bm_sectionLetter": "Letter spacing",
    "bookmarkFilterBy": "Filter by",
    "UnsupportedBrowser": "Bookmarks are not supported in your browser.",
    "resetShortcutsPrompt": "All saved shortcuts will be deleted and reset to default. Do you want to continue?",
    "blurTitle": "Blur",
    "adjustBlurDesc": "Adjust background blur",
    "videoBackgroundTitle": "Video Background",
    "videoBackgroundDesc": "Controls for video wallpaper",
    "videoBrightnessTitle": "Brightness",
    "brightnessTitle": "Brightness",
    "adjustBrightnessDesc": "Adjust background brightness",
    "savedColorApply": "Apply Theme",
    "savedColorRemove": "Remove",
    "folderWallpaperBtn": "Wallpaper Folder",
    "dualLabelSurfaces": "Surfaces",
    "dualPresetExists": "This theme already exists in the default themes",
    "dualLabelAccents": "Accents",
    "shadowControl":       "Shadow Control",
    "shadowIntensity":     "Intensity",
    "shadowSpeed":         "Speed",
    "shadowColor":         "Color",
    "shadowAnimation":     "Animation",
    "shadowAnimOff":       "Off",
    "shadowAnimPulse":     "Pulse",
    "shadowAnimBreathe":   "Breathe",
    "shadowAnimOrbit":     "Orbit",
    "shadowAnimColorShift":"Color Shift",
    "shadowAnimWave":      "Wave",
    "shadowAnimFlicker":   "Flicker",
    "shadowAnimThunder":   "Thunder",
    "shadowElements":      "Elements",
    "shadowMaster":        "Shadows",
    "shadowHoverOnly":     "Hover Only",
    "shadowAlways":        "Always On",
    "sqAll":           "All",
    "sqNone":          "None",
    "sqImportant":     "Important",
    "sqCards":         "Cards",
    "sqLarge":         "Large",
    "sqMinimal":       "Minimal",
    "shSearch":        "Search Bar",
    "shMenu":          "Menu Panel",
    "shBookmarks":     "Bookmarks",
    "shWidgets":       "Widgets",
    "shModals":        "Modals",
    "shContextMenu":   "Context Menus",
    "shButtons":       "Buttons",
    "shPalette":       "Color Palette",
    "shShortcuts":     "Shortcuts",
    "lePanelTitle":    "Layout Editor",
    "lePanelHint":     "Drag elements on the page to move them. Hold \u2212/+ to resize faster.",
    "leResetAll":      "Reset All",
    "leDone":          "\u2713 Done",
    "leLabelClock":    "Clock",
    "leLabelText":     "Custom Text",
    "leLabelWeather":  "Weather",
    "leLabelSearch":   "Search Bar",
    "leLabelQuotes":   "Quotes",
    "leDragLabel":     "drag",
    "themeLabel": "Theme",
    "animSpeedLabel": "Anim Speed",
    "applyThemeBtn": "Apply Theme",
    "celsiusSymbol": "\u00b0C",
    "fahrenheitSymbol": "\u00b0F",
    "layoutEditorTitle": "Layout Editor",
    "layoutEditorInfo": "Move & resize page elements",
    "openLayoutEditor": "Open Layout Editor",
    "gradSunset": "Sunset",
    "gradOcean": "Ocean",
    "gradFire": "Fire",
    "gradJungle": "Jungle",
    "gradMango": "Mango",
    "gradGalaxy": "Galaxy",
    "gradLava": "Lava",
    "gradAurora": "Aurora",
    "gradCandy": "Candy",
    "gradBlood": "Blood",
    "gradMidnight": "Midnight",
    "gradCrimson": "Crimson",
    "colorBlue": "Blue",
    "colorTeal": "Teal",
    "colorIndigo": "Indigo",
    "colorSky": "Sky",
    "colorAmber": "Amber",
    "colorOrange": "Orange",
    "colorRed": "Red",
    "colorCoral": "Coral",
    "colorPink": "Pink",
    "colorMagenta": "Magenta",
    "colorPurple": "Purple",
    "colorViolet": "Violet",
    "colorOlive": "Olive",
    "colorYellow": "Yellow",
    "colorForest": "Forest",
    "colorSage": "Sage",
    "colorSlate": "Slate",
    "colorBrown": "Brown",
    "colorSilver": "Silver",
    "pickGradientTitle": "Pick 2-color gradient",
    "swapThemeTitle": "Swap theme colors",
    "swapLightDarkTitle": "Swap light/dark color mode",
    "applyTitle": "Apply",
    "cancelTitle": "Cancel",
    "shuffleWallpaperTitle": "Random Wallpaper",
    "freezeWallpaperTitle": "Freeze current wallpaper",
    "videoPlayPauseTitle": "Play / Pause",
    "videoMuteTitle": "Mute / Unmute",
    "videoHideTitle": "Hide / Show Video",
    "dragToMoveTitle": "Drag to move",
    "dragLabel": "drag",
    "gradientSectionLabel": "Gradient",
    "dragToMove": "Drag to move",
    "dualColorTriggerTitle": "Pick 2-color gradient",
    "dualSwapTitle": "Swap theme colors",
    "customSwapTitle": "Swap light/dark color mode",
    "dualSlotSurfaceTitle": "Click to pick surface/background color",
    "dualSlotAccentTitle": "Click to pick accent/button/text color",
    "dualApplyTitle": "Apply",
    "dualCancelTitle": "Cancel",
    "pinWallpaperTitle": "Freeze current wallpaper",
    "shadowPanelTitle": "Shadow Control",
    "shadowPanelClose": "Close",
    "alignLeft": "Left",
    "alignCenter": "Center",
    "alignRight": "Right",
    "fsDecrease": "Decrease font size",
    "fsIncrease": "Increase font size",
    "colorGreen": "Green",
    "colorCyan": "Cyan",
    "colorMint": "Mint",
    "colorGold": "Gold",
    "colorRose": "Rose",
    "colorLavender": "Lavender",
    "colorLime": "Lime",
    "gradForest": "Forest",
    "gradDusk": "Dusk",
    "gradRose": "Rose",
    "gradMint": "Mint",
    "gradNeon": "Neon",
    "gradSpring": "Spring",
    "gradElectric": "Electric",
    "gradDeep": "Deep",
    "gradIce": "Ice",
    "clockShapeTitle": "Clock Shape",
    "clockShapeInfo": "Choose the clock background shape",
    "shapeScallop": "Scallop",
    "shapeCircle": "Circle",
    "shapeRounded": "Rounded",
    "shapeSquircle": "Squircle",
    "shapeHexagon": "Hexagon",
    "shapeStar": "Star",
    "leTabElements":           "\ud83c\udf9b Elements",
    "leTabPresets":            "\ud83d\uddc2 Presets",
    "leBuiltInPresetsLabel":   "Built-in Presets",
    "leMyPresetsLabel":        "My Presets",
    "leNameLayoutPlaceholder": "Name this layout\u2026",
    "leSaveBtnText":           "Save",
    "leApplyBtnText":          "Apply",
    "leDeleteBtnTitle":        "Delete",
    "leNoCustomPresets":       "No saved layouts yet.",
    "leToastEnterName":        "Enter a name for the layout first",
    "leToastSaved":            "saved \u2713",
    "leToastApplied":          "applied",
    "leToastDeleted":          "Deleted",
    "leToastDeletedActive":    "Deleted (Set to Default)",
    "leToastDuplicate":      "already exists",
    "leToastResetAll":      "Layout reset to default",
    "leToastNameExists":    "name already exists",
    "leToastSaveFirst":     "Please save your layout changes first",
    "lePresetDefaultLabel":      "Default",
    "lePresetDefaultDesc":       "Original positions",
    "lePresetBigClockLabel":     "Big Clock",
    "lePresetBigClockDesc":      "Clock is the hero, rest compressed",
    "lePresetCompactLabel":      "Compact",
    "lePresetCompactDesc":       "Everything smaller, organized",
    "lePresetFocusLabel":        "Focus",
    "lePresetFocusDesc":         "Clock and search stand out",
    "lePresetWeatherHeroLabel":  "Weather Hero",
    "lePresetWeatherHeroDesc":   "Weather front and center",
    "lePresetMinimalLabel":      "Minimal",
    "lePresetMinimalDesc":       "Just the essentials",
    "lePresetSpreadLabel":       "Spread",
    "lePresetSpreadDesc":        "Elements spread with more spacing",
    "lePresetCozyLabel":         "Cozy",
    "lePresetCozyDesc":          "Close elements, balanced sizes",

    // ── Welcome Onboarding ──
    "onbTitle":              "Welcome to<br>Material You NewTab",
    "onbSubtitle":           "Let's set up your experience",
    "onbNamePlaceholder":    "Enter your name",
    "onbContinueBtn":        "Continue",
    "onbFeatTitle":          "Everything you need",
    "onbFeatSub":            "A beautiful new tab page, crafted for you",
    "onbFeat1Title":         "Custom Themes",
    "onbFeat1Desc":          "Stunning colors, gradients & wallpapers",
    "onbFeat2Title":         "Quick Shortcuts",
    "onbFeat2Desc":          "Bookmarks & speed dial at your fingertips",
    "onbFeat3Title":         "Live Weather",
    "onbFeat3Desc":          "Real-time forecasts & beautiful clock",
    "onbFeat4Title":         "To-Do & More",
    "onbFeat4Desc":          "Stay organized with built-in tools",
    "onbBackBtn":            "Back",
    "onbNextBtn":            "Next",
    "onbReadyTitle":         "You're all set!",
    "onbReadySub":           "Everything is ready. Let's start exploring.",
    "onbReadySubNamed":      "Everything is ready, {name}. Let's start exploring.",
    "onbStartBtn":           "Start Exploring",
    "onbSkipBtn":            "Skip",

    // ── Wallpaper Gallery ──
    "galleryTrigger":        "Browse Gallery",
    "galleryTitle":          "Browse Wallpapers",
    "gallerySearchPlaceholder": "Search wallpapers...",
    "galleryLoadMore":       "Load More",
    "galleryUseAs":          "Use as Wallpaper",
    "galleryLoading":        "Loading...",
    "galleryNoMore":         "No more wallpapers.",
    "galleryError":          "Failed to load. Check your connection.",
    "galleryApplying":       "Applying wallpaper...",
    "galleryDone":           "Done!",
    "galleryFailed":         "Failed to apply. Try again.",
    "gallerySearching":      "Searching...",

    // ── About ──
    "aboutTitle":            "About",
    "aboutDesc":             "Developed with love by",
    "aboutCredits":          "Laith Al-Nasr / Hesham Shalaby",

    // ── I'm Feeling Lucky ──
    "luckyTitle":            "I'm Feeling Lucky",
    "luckyDesc":             "Random theme with one click",
    "luckyBtnText":          "Try Luck",
    "luckyWallpaperText":    "Include random wallpaper",
    "luckyApplying":         "Applying...",
};

// ── Translation cache ──────────────────────────────────────────────────────
// ── Bundled Arabic translations (fallback when API is unavailable) ──────────
const ar_SA = {
    "github": "GitHub",
    "feedback": "ملاحظات",
    "personalizationSectionTitle": "التخصيص",
    "clockSectionTitle": "الساعة",
    "searchSectionTitle": "البحث",
    "weatherSectionTitle": "الطقس",
    "appearanceSectionTitle": "المظهر",
    "settingsSectionTitle": "الإعدادات",
    "shortcutsText": "الاختصارات",
    "enableShortcutsText": "إظهار الاختصارات المحفوظة",
    "editShortcutsText": "تعديل الاختصارات",
    "shortcutsInfoText": "اختر الاختصارات التي تظهر",
    "editShortcutsList": "الاختصارات المحفوظة",
    "editShortcutsListInfo": "يمكنك إضافة اختصارات جديدة بالنقر على أيقونة \"+\" أو تعديل اختصارات موجودة بالنقر على اسم الاختصار أو الرابط.",
    "adaptiveIconText": "الأيقونات التكيفية",
    "adaptiveIconInfoText": "تصغير أيقونات الاختصار الافتراضية وجعلها تتطابق مع السمة",
    "bookmarksText": "الإشارات المرجعية",
    "bookmarksInfo": "إظهار شريط الإشارات المرجعية الجانبية",
    "ai_tools_button": "أدوات الذكاء الاصطناعي",
    "enable_ai_tools": "إظهار اختصارات أدوات الذكاء الاصطناعي",
    "aiToolsSettingsText": "إعدادات أدوات الذكاء الاصطناعي",
    "aiToolsSettingsInfo": "إدارة اختصارات أدوات الذكاء الاصطناعي",
    "googleAppsMenuText": "تطبيقات جوجل",
    "googleAppsMenuInfo": "إظهار اختصارات تطبيقات جوجل",
    "googleAppsHover": "تطبيقات جوجل",
    "todoListText": "قائمة المهام",
    "todoListInfo": "إظهار قائمة مهام يومية",
    "todoListHover": "قائمة المهام",
    "todoPlaceholder": "أضف مهمة...",
    "hideClockBox": "إخفاء الساعة",
    "hideClockBoxInfo": "إخفاء الساعة والتاريخ",
    "digitalclocktitle": "الساعة الرقمية",
    "digitalclockinfo": "التبديل إلى الساعة الرقمية",
    "timeformattitle": "تنسيق 12 ساعة",
    "timeformatinfo": "استخدام تنسيق الوقت بـ 12 ساعة",
    "greetingtitle": "التحية",
    "greetinginfo": "إظهار التحية أسفل النص المخصص",
    "userTextTitle": "نص قابل للتخصيص",
    "userTextInfo": "إظهار النص المخصص أسفل الساعة",
    "fahrenheitCelsiusCheckbox": "التبديل إلى فهرنهايت",
    "fahrenheitCelsiusText": "قم بتحديث الصفحة لتطبيق التغييرات",
    "hideWeatherTitle": "إخفاء الطقس",
    "hideWeatherInfo": "تعطيل عناصر الطقس",
    "hideWeatherBox": "إخفاء بطاقة الطقس",
    "hideWeatherBoxInfo": "إظهار حبة درجة الحرارة فقط",
    "minMaxTempText": "درجة الحرارة الدنيا والقصوى",
    "minMaxTempSubText": "استبدال 'الإحساس بـ' بالحد الأدنى والأقصى لدرجة الحرارة",
    "micIconTitle": "إخفاء أيقونة الميكروفون",
    "micIconInfo": "إذا لم يكن الكتابة بالصوت تعمل",
    "hideSearchWith": "إخفاء محركات البحث",
    "hideSearchWithInfo": "التبديل بين محركات البحث بالنقر على أيقونتها",
    "motivationalQuotesText": "اقتباسات تحفيزية",
    "motivationalQuotesInfo": "إظهار الاقتباسات أسفل شريط البحث",
    "search_suggestions_button": "اقتراحات البحث",
    "search_suggestions_text": "تفعيل اقتراحات البحث",
    "useproxytitletext": "تجاوز الوكيل",
    "useproxyText": "إذا لم تكن اقتراحات البحث تعمل",
    "ProxyText": "وكيل تجاوز CORS",
    "ProxySubtext": "أضف وكيل تجاوز CORS الخاص بك",
    "HostproxyButton": "استضافة وكيلك الخاص",
    "useGPS": "استخدام GPS",
    "useGPSInfo": "تفعيل GPS لتحديثات الموقع المباشرة",
    "UserLocText": "أدخل موقعك",
    "UserLocSubtext": "إذا لم يكن موقع الطقس صحيحاً",
    "userLoc": "مدينتك أو الإحداثيات (خط العرض، خط الطول)",
    "WeatherApiText": "أدخل مفتاح WeatherAPI الخاص بك",
    "WeatherApiSubtext": "إذا لم تكن وظيفة الطقس تعمل",
    "userAPI": "مفتاح weatherAPI الخاص بك",
    "LearnMoreButton": "اعرف المزيد",
    "saveAPI": "حفظ",
    "days": ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
    "months": ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
    "bookmarksHeading": "الإشارات المرجعية",
    "bookmarkSortBy": "ترتيب حسب",
    "sortAlphabetical": "أ-ي",
    "sortTimeAdded": "الأقدم-الأحدث",
    "bookmarkViewAs": "عرض كـ",
    "bookmarkViewGrid": "شبكة",
    "bookmarkViewList": "قائمة",
    "bookmarkSearch": "بحث في الإشارات المرجعية",
    "editBookmarkHeading": "تعديل الإشارة المرجعية",
    "editBookmarkName": "اسم الإشارة المرجعية",
    "editBookmarkURL": "رابط الإشارة المرجعية",
    "conditionText": "مرحباً! كيف حالك اليوم؟",
    "humidityLevel": "الرطوبة",
    "feelsLike": "الإحساس",
    "minMaxTemp": "الدنيا ~ القصوى",
    "location": "الكرة الأرضية",
    "enterBtn": "بحث",
    "searchPlaceholder": "اكتب هنا...",
    "listenPlaceholder": "جاري الاستماع...",
    "searchWithHint": "بحث بـ",
    "searchOnHint": "بحث على",
    "userText": "انقر هنا للتعديل",
    greeting: {
        "morning": "صباح الخير!",
        "afternoon": "مساء الخير!",
        "evening": "مساء الخير!"
    },
    "defaultEngine": "الافتراضي",
    "googleEngine": "جوجل",
    "duckEngine": "دك دك",
    "bingEngine": "بينج",
    "braveEngine": "شجاع",
    "youtubeEngine": "يوتيوب",
    "gImagesEngine": "الصور",
    "redditEngine": "ريديت",
    "wikipediaEngine": "ويكيبيديا",
    "quoraEngine": "كورا",
    "ai_tools": "أدوات الذكاء الاصطناعي",
    "chatGPT": "شات جي بي تي",
    "gemini": "جيمناي",
    "copilot": "كوبيلوت",
    "claude": "كلود",
    "grok": "جروك",
    "qwen": "كوان",
    "perplexity": "بيربلكسيتي",
    "deepseek": "ديب سيك",
    "metaAI": "ميٹا AI",
    "firefly": "أدوبي فايرفلاي",
    "hishamAgent": "Hisham Agent ✦",
    "aiSettingsIntro": "اختر أدوات الذكاء الاصطناعي لعرضها",
    "resetAISettingsBtn": "إعادة تعيين",
    "lightThemed": "فاتح",
    "darkThemed": "داكن",
    "systemThemed": "النظام",
    "uploadWallpaperText": "رفع خلفية",
    "rangColor": "اختر لوناً",
    "opacityTitle": "الشفافية",
    "adjustOpacityDesc": "ضبط شفافية الواجهة",
    "backupText": "نسخ احتياطي",
    "restoreText": "استعادة",
    "resetsettings": "إعادة تعيين الإعدادات",
    "menuCloseText": "إغلاق",
    "switchSearchModes": "تبديل أوضاع البحث",
    "switchSearchModesInfo": "انقر على 'بحث بـ' لتغيير الوضع.",
    "adjustZoom": "ضبط التكبير",
    "adjustZoomInfo": "اضغط Ctrl + \"+\" أو Ctrl + \"-\" لضبط التكبير.",
    "changeBrowserTheme": "تغيير سمة المتصفح",
    "dontShowTips": "لا تظهر هذا مرة أخرى",
    "footerToastTitle": "هل ترى شريطاً في الأسفل؟",
    "footerToastMessage": "لإخفائه، انقر بالزر الأيمن عليه واختر 'إخفاء التذييل في صفحة علامة التبويب الجديدة'.",
    "okText": "موافق",
    "yesText": "نعم",
    "noText": "لا",
    "agreeText": "أوافق",
    "cancelText": "إلغاء",
    "confirmWallpaper": "هل تريد تعيين صورة جديدة كخلفية لليوم؟",
    "confirmRestore": "هل أنت متأكد أنك تريد إعادة تعيين إعداداتك؟ لا يمكن التراجع عن هذا الإجراء.",
    "lePanelTitle": "محرر التخطيط",
    "lePanelHint": "اسحب العناصر على الصفحة لتحريكها. اضغط على \u2212/+ للتكبير بشكل أسرع.",
    "leResetAll": "إعادة تعيين الكل",
    "leDone": "\u2713 تم",
    "leLabelClock": "الساعة",
    "leLabelText": "نص مخصص",
    "leLabelWeather": "الطقس",
    "leLabelSearch": "شريط البحث",
    "leLabelQuotes": "الاقتباسات",
    "leDragLabel": "اسحب",
    "themeLabel": "السمة",
    "animSpeedLabel": "سرعة الحركة",
    "applyThemeBtn": "تطبيق السمة",
    "shadowControl": "التحكم بالظل",
    "shadowIntensity": "الشدة",
    "shadowSpeed": "السرعة",
    "shadowColor": "اللون",
    "shadowAnimation": "الحركة",
    "shadowAnimOff": "إيقاف",
    "shadowMaster": "الظلال",
    "shadowHoverOnly": "عند التمرير فقط",
    "shadowAlways": "دائماً",
    "layoutEditorTitle": "محرر التخطيط",
    "layoutEditorInfo": "نقل وتغيير حجم عناصر الصفحة",
    "openLayoutEditor": "فتح محرر التخطيط",
    "gradSunset": "الغروب",
    "gradOcean": "المحيط",
    "gradFire": "النار",
    "gradJungle": "الأدغال",
    "gradMango": "المانجو",
    "gradGalaxy": "المجرة",
    "gradLava": "الحمم",
    "gradAurora": "الشفق",
    "gradCandy": "الحلوى",
    "gradBlood": "الدم",
    "gradMidnight": "منتصف الليل",
    "gradCrimson": "القرمزي",
    "colorBlue": "أزرق",
    "colorTeal": "أزرق مخضر",
    "colorIndigo": "نيلي",
    "colorSky": "سماوي فاتح",
    "colorAmber": "عنبري",
    "colorOrange": "برتقالي",
    "colorRed": "أحمر",
    "colorCoral": "مرجاني",
    "colorPink": "زهري",
    "colorMagenta": "أرجواني",
    "colorPurple": "بنفسجي",
    "colorViolet": "بنفسجي فاتح",
    "colorOlive": "زيتوني",
    "blurTitle": "ضبابية",
    "adjustBlurDesc": "ضبط ضبابية الخلفية",
    "videoBackgroundTitle": "خلفية فيديو",
    "videoBackgroundDesc": "التحكم في خلفية الفيديو",
    "videoBrightnessTitle": "السطوع",
    "brightnessTitle": "السطوع",
    "adjustBrightnessDesc": "ضبط سطوع الخلفية",

    // ── Welcome Onboarding ──
    "onbTitle":              "مرحباً بك في<br>Material You NewTab",
    "onbSubtitle":           "لنقم بإعداد تجربتك",
    "onbNamePlaceholder":    "أدخل اسمك",
    "onbContinueBtn":        "متابعة",
    "onbFeatTitle":          "كل ما تحتاجه",
    "onbFeatSub":            "صفحة تبويب جديدة جميلة، صممت لك",
    "onbFeat1Title":         "ثيمات مخصصة",
    "onbFeat1Desc":          "ألوان مذهلة، تدرجات وخلفيات",
    "onbFeat2Title":         "اختصارات سريعة",
    "onbFeat2Desc":          "إشارات مرجعية واتصال سريع في متناول يدك",
    "onbFeat3Title":         "طقس حي",
    "onbFeat3Desc":          "توقعات فورية وساعة جميلة",
    "onbFeat4Title":         "مهام والمزيد",
    "onbFeat4Desc":          "تنظم أدواتك المدمجة",
    "onbBackBtn":            "رجوع",
    "onbNextBtn":            "التالي",
    "onbReadyTitle":         "كل شيء جاهز!",
    "onbReadySub":           "كل شيء جاهز. لنبدأ الاستكشاف.",
    "onbReadySubNamed":      "كل شيء جاهز، {name}. لنبدأ الاستكشاف.",
    "onbStartBtn":           "ابدأ الاستكشاف",
    "onbSkipBtn":            "تخطي",

    // ── Wallpaper Gallery ──
    "galleryTrigger":        "تصفح المعرض",
    "galleryTitle":          "تصفح الخلفيات",
    "gallerySearchPlaceholder": "ابحث عن خلفيات...",
    "galleryLoadMore":       "تحميل المزيد",
    "galleryUseAs":          "استخدام كخلفية",
    "galleryLoading":        "جارٍ التحميل...",
    "galleryNoMore":         "لا يوجد المزيد من الخلفيات.",
    "galleryError":          "فشل التحميل. تحقق من اتصالك.",
    "galleryApplying":       "جارٍ تطبيق الخلفية...",
    "galleryDone":           "تم!",
    "galleryFailed":         "فشل التطبيق. حاول مرة أخرى.",
    "gallerySearching":      "جارٍ البحث...",

    // ── About ──
    "aboutTitle":            "حول الإضافة",
    "aboutDesc":             "تم التطوير بحب بواسطة",
    "aboutCredits":          "ليث النسر / هشام شلبي",

    "chromeThemeInfo": "انقر على النقاط الثلاث (⋮) > أدوات إضافية > تخصيص Chrome، ثم اختر لوناً يتطابق مع سمة الإضافة.",
    "edgeThemeInfo": "انتقل إلى الإعدادات > المظهر، ثم اختر لوناً يتطابق مع سمة الإضافة.",
    "braveThemeInfo": "قم بزيارة <a href=\"https://chromewebstore.google.com/category/themes/\" target=\"_blank\">متجر ثيمات Chrome</a>، وقم بتنزيل وتطبيق الثيم الذي يتطابق مع الإضافة.",
    "firefoxThemeInfo": "قم بزيارة <a href=\"https://addons.mozilla.org/firefox/themes/\" target=\"_blank\">ثيمات Firefox</a>، وقم بتنزيل وتطبيق الثيم الذي يتطابق مع الإضافة.",
    "updateFirefoxHomepage": "تحديث الصفحة الرئيسية",
    "updateFirefoxHomepageInfo": "لتغيير صفحتك الرئيسية مثل علامة التبويب الجديدة أيضًا، قم بزيارة <a href=\"https://github.com/prem-k-r/MaterialYouNewTab#-firefox\" target=\"_blank\">هذا الرابط</a> واتبع التعليمات.",
    "Nobackgroundset": "لا توجد صورة خلفية محددة حاليًا.",
    "NoFolderSelected": "لديك خلفية محددة، لكن لم يتم اختيار مجلد. يرجى اختيار مجلد لاستخدام ميزة الترتيب العشوائي أو التثبيت.",
    "clearbackgroundimage": "هل أنت متأكد أنك تريد مسح صورة الخلفية؟",
    "ProxyDisclaimer": "جميع ميزات الوكيل معطلة بشكل افتراضي.\n\nإذا قمت بتفعيل اقتراحات البحث ووكيل تجاوز CORS، يُوصى بشدة باستضافة وكيلك الخاص لخصوصية أفضل.\n\nافتراضيًا، سيتم تعيين الوكيل على https://mynt-proxy.rhythmcorehq.com، مما يعني أن جميع بياناتك ستمر عبر هذه الخدمة، مما قد يشكل مخاوف تتعلق بالخصوصية.",
    "GPSDisclaimer": "تُستخدم بيانات موقعك فقط لتقديم تحديثات طقس دقيقة. يتم تخزينها مؤقتًا في المتصفح ولا تُشارك مع أي خدمات طرف ثالث ولا يمكن الوصول إليها من قبلنا.\n\nبتفعيل GPS، أنت توافق على مشاركة موقعك مع الإضافة محليًا.",
    "failedbackup": "فشل النسخ الاحتياطي: ",
    "restorecompleted": "تمت الاستعادة بنجاح!",
    "restorefailed": "فشلت الاستعادة: ",
    "invalidBackup": "ملف نسخ احتياطي غير صالح.",
    "deleteBookmark": "هل أنت متأكد أنك تريد حذف الإشارة المرجعية \"{title}\"؟",
    "bm_open": "فتح",
    "bm_openNewTab": "فتح في علامة تبويب جديدة",
    "bm_openAll": "فتح الكل في علامات تبويب جديدة",
    "bm_openAllConfirm": "فتح {count} علامات تبويب؟",
    "bm_edit": "تعديل",
    "bm_copyURL": "نسخ الرابط",
    "bm_delete": "حذف",
    "bm_addPage": "إضافة صفحة...",
    "bm_addPageAuto": "تلقائي",
    "bm_autoFetching": "جارٍ جلب عنوان الصفحة...",
    "bm_addFolder": "إضافة مجلد...",
    "bm_newPageName": "اسم الصفحة",
    "bm_newPageURL": "رابط الصفحة",
    "bm_newFolderName": "اسم المجلد",
    "bm_renameFolder": "إعادة تسمية المجلد",
    "bm_deleteFolder": "حذف المجلد",
    "bm_toast_copied": "تم نسخ الرابط!",
    "bm_toast_edited": "تم تحديث الإشارة المرجعية",
    "bm_toast_deleted": "تم حذف الإشارة المرجعية",
    "bm_toast_added": "تمت الإضافة بنجاح",
    "bm_toast_moved": "تم تحديث الترتيب",
    "bm_toast_undo": "تم التراجع",
    "bm_toast_redo": "تم الإعادة",
    "bm_nothing_to_undo": "لا شيء للتراجع عنه",
    "bm_nothing_to_redo": "لا شيء للإعادة",
    "wallpaper_pinned": "تم تثبيت الخلفية",
    "wallpaper_unpinned": "تم إلغاء تثبيت الخلفية",
    "bm_filterLabel": "عرض",
    "bm_filterAll": "الكل",
    "bm_filterBm": "الإشارات المرجعية",
    "bm_filterFolders": "المجلدات",
    "bm_sortAZ": "أ–ي",
    "bm_sortDate": "الأقدم–الأحدث",
    "bm_filterBmOnly": "الإشارات المرجعية فقط",
    "bm_filterFoldersOnly": "المجلدات فقط",
    "bm_folderPosLabel": "موضع المجلدات",
    "bm_folderFirst": "المجلدات أولاً",
    "bm_folderLast": "المجلدات أخيراً",
    "bm_addSection": "إضافة قسم...",
    "bm_sectionName": "اسم القسم",
    "bm_renameSection": "إعادة تسمية القسم",
    "bm_deleteSection": "حذف القسم",
    "bm_sectionWidth": "العرض",
    "bm_sectionWide": "عرض كامل",
    "bm_sectionNarrow": "نصف عرض",
    "bm_sectionColor": "لون القسم",
    "bm_sectionAlign": "محاذاة النص",
    "bm_sectionGradient": "تدرج",
    "bm_sectionFontSize": "حجم الخط",
    "bm_sectionStyle": "نمط النص",
    "bm_sectionBold": "عريض",
    "bm_sectionItalic": "مائل",
    "bm_sectionUpper": "أحرف كبيرة",
    "bm_sectionLetter": "تباعد الأحرف",
    "bookmarkFilterBy": "تصفية حسب",
    "UnsupportedBrowser": "الإشارات المرجعية غير مدعومة في متصفحك.",
    "resetShortcutsPrompt": "سيتم حذف جميع الاختصارات المحفوظة وإعادة تعيينها إلى الافتراضي. هل تريد المتابعة؟",
    "savedColorApply": "تطبيق السمة",
    "savedColorRemove": "إزالة",
    "folderWallpaperBtn": "مجلد الخلفية",
    "dualLabelSurfaces": "الأسطح",
    "dualPresetExists": "هذه السمة موجودة بالفعل في السمات الافتراضية",
    "dualLabelAccents": "التمييزات",
    "shadowAnimPulse": "نبض",
    "shadowAnimBreathe": "تنفس",
    "shadowAnimOrbit": "مدار",
    "shadowAnimColorShift": "تحوّل اللون",
    "shadowAnimWave": "موجة",
    "shadowAnimFlicker": "وميض",
    "shadowAnimThunder": "رعد",
    "shadowElements": "العناصر",
    "sqAll": "الكل",
    "sqNone": "لا شيء",
    "sqImportant": "مهم",
    "sqCards": "البطاقات",
    "sqLarge": "كبير",
    "sqMinimal": "بسيط",
    "shSearch": "شريط البحث",
    "shMenu": "لوحة القائمة",
    "shBookmarks": "الإشارات المرجعية",
    "shWidgets": "العناصر",
    "shModals": "النوافذ المنبثقة",
    "shContextMenu": "القوائم السياقية",
    "shButtons": "الأزرار",
    "shPalette": "لوحة الألوان",
    "shShortcuts": "الاختصارات",
    "celsiusSymbol": "\u00b0م",
    "fahrenheitSymbol": "\u00b0ف",
    "pickGradientTitle": "اختر تدرج لونين",
    "swapThemeTitle": "تبديل ألوان السمة",
    "swapLightDarkTitle": "تبديل وضع الألوان الفاتح/الداكن",
    "applyTitle": "تطبيق",
    "cancelTitle": "إلغاء",
    "shuffleWallpaperTitle": "خلفية عشوائية",
    "freezeWallpaperTitle": "تثبيت الخلفية الحالية",
    "videoPlayPauseTitle": "تشغيل / إيقاف",
    "videoMuteTitle": "كتم / إلغاء الكتم",
    "videoHideTitle": "إخفاء / إظهار الفيديو",
    "dragToMoveTitle": "اسحب للتحريك",
    "dragLabel": "اسحب",
    "gradientSectionLabel": "تدرج",
    "dragToMove": "اسحب للتحريك",
    "dualColorTriggerTitle": "اختر تدرج لونين",
    "dualSwapTitle": "تبديل ألوان السمة",
    "customSwapTitle": "تبديل وضع الألوان الفاتح/الداكن",
    "dualSlotSurfaceTitle": "انقر لاختيار لون السطح/الخلفية",
    "dualSlotAccentTitle": "انقر لاختيار لون التمييز/الزر/النص",
    "dualApplyTitle": "تطبيق",
    "dualCancelTitle": "إلغاء",
    "pinWallpaperTitle": "تثبيت الخلفية الحالية",
    "shadowPanelTitle": "التحكم بالظل",
    "shadowPanelClose": "إغلاق",
    "alignLeft": "يسار",
    "alignCenter": "وسط",
    "alignRight": "يمين",
    "fsDecrease": "تصغير حجم الخط",
    "fsIncrease": "تكبير حجم الخط",
    "colorGreen": "أخضر",
    "colorCyan": "سماوي",
    "colorMint": "نعناعي",
    "colorGold": "ذهبي",
    "colorRose": "وردي",
    "colorLavender": "لافندر",
    "colorLime": "ليموني",
    "colorYellow": "أصفر",
    "colorForest": "غابي",
    "colorSage": "مريمية",
    "colorSlate": "أردوزي",
    "colorBrown": "بني",
    "colorSilver": "فضي",
    "gradForest": "غابة",
    "gradDusk": "غسق",
    "gradRose": "وردة",
    "gradMint": "نعناع",
    "gradNeon": "نيون",
    "gradSpring": "ربيع",
    "gradElectric": "كهربائي",
    "gradDeep": "عميق",
    "gradIce": "جليد",
    "clockShapeTitle": "شكل الساعة",
    "clockShapeInfo": "اختر شكل خلفية الساعة",
    "shapeScallop": "محارة",
    "shapeCircle": "دائرة",
    "shapeRounded": "دائري",
    "shapeSquircle": "squircle",
    "shapeHexagon": "سداسي",
    "shapeStar": "نجمة",
    "leTabElements":           "\ud83c\udf9b العناصر",
    "leTabPresets":            "\ud83d\uddc2 الجاهز",
    "leBuiltInPresetsLabel":   "الجاهز المدمج",
    "leMyPresetsLabel":        "جاهزي",
    "leNameLayoutPlaceholder": "اسم هذا التخطيط\u2026",
    "leSaveBtnText":           "حفظ",
    "leApplyBtnText":          "تطبيق",
    "leDeleteBtnTitle":        "حذف",
    "leNoCustomPresets":       "لا توجد تخطيطات محفوظة بعد.",
    "leToastEnterName":        "أدخل اسم التخطيط أولاً",
    "leToastSaved":            "تم الحفظ \u2713",
    "leToastApplied":          "تم التطبيق",
    "leToastDeleted":          "تم الحذف",
    "leToastDeletedActive":    "تم الحذف (تعيين إلى الافتراضي)",
    "leToastDuplicate":        "موجود بالفعل",
    "leToastResetAll":         "تمت إعادة تعيين التخطيط إلى الافتراضي",
    "leToastNameExists":       "الاسم موجود بالفعل",
    "leToastSaveFirst":        "يرجى حفظ تغييرات التخطيط أولاً",
    "lePresetDefaultLabel":      "افتراضي",
    "lePresetDefaultDesc":       "المواقع الأصلية",
    "lePresetBigClockLabel":     "ساعة كبيرة",
    "lePresetBigClockDesc":      "الساعة هي البطلة، الباقي مضغوط",
    "lePresetCompactLabel":      "مضغوط",
    "lePresetCompactDesc":       "كل شيء أصغر، منظم",
    "lePresetFocusLabel":        "تركيز",
    "lePresetFocusDesc":         "الساعة وشريط البحث يبرزان",
    "lePresetWeatherHeroLabel":  "بطل الطقس",
    "lePresetWeatherHeroDesc":   "الطقس في المقدمة والمركز",
    "lePresetMinimalLabel":      "بسيط",
    "lePresetMinimalDesc":       "الأساسيات فقط",
    "lePresetSpreadLabel":       "منتشر",
    "lePresetSpreadDesc":        "عناصر منتشرة بمسافات أكبر",
    "lePresetCozyLabel":         "مريح",
    "lePresetCozyDesc":          "عناصر قريبة، أحجام متوازنة",
    "PrivacyPolicy": "سياسة الخصوصية",

    // ── I'm Feeling Lucky ──
    "luckyTitle":            "أنا محظوظ",
    "luckyDesc":             "ثيم عشوائي بنقرة واحدة",
    "luckyBtnText":          "جرب حظك",
    "luckyWallpaperText":    "إضافة خلفية عشوائية",
    "luckyApplying":         "جاري التطبيق...",
};

const translations = { en: en, ar_SA: ar_SA };

// Set currentLanguage early so all scripts can use it on DOMContentLoaded
window.currentLanguage = localStorage.getItem("selectedLanguage") || "en";

// Load cached translations from localStorage immediately (synchronous)
try {
    const savedLang = localStorage.getItem("selectedLanguage") || "en";
    const cacheKey = "translation_cache_" + savedLang;
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
        const data = JSON.parse(cached);
        if (translations[savedLang]) {
            translations[savedLang] = { ...translations[savedLang], ...data };
        } else {
            translations[savedLang] = data;
        }
    }
} catch (_) {}

/**
 * Fetch translations for a given language code from the API.
 * Results are cached in localStorage to avoid repeated network requests.
 * Falls back to English if the requested language fails.
 */
async function fetchTranslations(lang) {
    const cacheKey = "translation_cache_" + lang;
    try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
            const data = JSON.parse(cached);
            if (translations[lang]) {
                translations[lang] = { ...translations[lang], ...data };
            } else {
                translations[lang] = data;
            }
            return data;
        }
    } catch (_) {}

    // The remote translations API is optional scaffolding; the bundled strings are
    // the source of truth. Skip the placeholder endpoint so every tab load does not
    // fire failed network requests (and console warnings) against a domain that
    // does not exist. Set TRANSLATIONS_API_BASE to a real endpoint to enable it.
    if (!TRANSLATIONS_API_BASE || TRANSLATIONS_API_BASE.includes("your-api.com")) {
        return translations[lang] || {};
    }

    try {
        const url = TRANSLATIONS_API_BASE + "/" + encodeURIComponent(lang);
        const res = await fetch(url, { signal: AbortSignal.timeout(4500) });
        if (!res.ok) throw new Error("HTTP " + res.status);
        const data = await res.json();
        if (translations[lang]) {
            translations[lang] = { ...translations[lang], ...data };
        } else {
            translations[lang] = data;
        }
        try { localStorage.setItem(cacheKey, JSON.stringify(data)); } catch (_) {}
        return data;
    } catch (err) {
        console.warn("Translation fetch failed for", lang, err);
        if (lang !== "en") {
            return fetchTranslations("en");
        }
        return {};
    }
}

// ── Shortcut extra translations (bundled locally) ──────────────────────────
const shortcutExtraTranslations = {
    en: {
        shortcutIconResourceLink: "Get icons from this site (only SVG file)",
        shortcutUploadIcon: "Upload SVG icon",
        shortcutReplaceUploadedIcon: "Replace SVG icon",
        shortcutRestoreOriginalIcon: "Restore original icon",
        shortcutSvgOnlyWarning: "Only SVG icons are supported.",
        shortcutIconPopoverButtonText: "Icon Size",
        shortcutIconPopoverTitle: "Icon Size",
        dragReorder: "Reorder",
        dragDropInside: "Drop Inside"
    },
    ar_SA: {
        shortcutIconResourceLink: "احصل على أيقونات من هذا الموقع (ملفات SVG فقط)",
        shortcutUploadIcon: "ارفع أيقونة SVG",
        shortcutReplaceUploadedIcon: "استبدل أيقونة SVG",
        shortcutRestoreOriginalIcon: "استرجع الأيقونة الأصلية",
        shortcutSvgOnlyWarning: "يتم دعم أيقونات SVG فقط.",
        shortcutIconPopoverButtonText: "حجم الأيقونة",
        shortcutIconPopoverTitle: "حجم الأيقونة",
        dragReorder: "ترتيب",
        dragDropInside: "إدخل بالداخل"
    },
    az: { shortcutIconResourceLink: "Bu saytdan ikonlar \u0259ld\u0259 edin" },
    bn: { shortcutIconResourceLink: "\u098f\u0987 \u09b8\u09be\u0987\u099f \u09a5\u09c7\u0995\u09c7 \u0986\u0987\u0995\u09a8 \u09a8\u09bf\u09a8" },
    cs: { shortcutIconResourceLink: "Z\u00edskejte ikony z tohoto webu" },
    de: { shortcutIconResourceLink: "Icons von dieser Website holen" },
    el: { shortcutIconResourceLink: "\u03a0\u03ac\u03c1\u03c4\u03b5 \u03b5\u03b9\u03ba\u03bf\u03bd\u03af\u03b4\u03b9\u03b1 \u03b1\u03c0\u03cc \u03b1\u03c5\u03c4\u03cc\u03bd \u03c4\u03bf\u03bd \u03b9\u03c3\u03c4\u03cc\u03c4\u03bf\u03c0\u03bf" },
    es: { shortcutIconResourceLink: "Obt\u00e9n iconos de este sitio" },
    fa: { shortcutIconResourceLink: "\u0622\u06cc\u06a9\u0648\u0646\u200c\u0647\u0627 \u0631\u0627 \u0627\u0632 \u0627\u06cc\u0646 \u0633\u0627\u06cc\u062a \u0628\u06af\u06cc\u0631\u06cc\u062f" },
    fr: { shortcutIconResourceLink: "Obtenez des ic\u00f4nes depuis ce site" },
    hi: { shortcutIconResourceLink: "\u0907\u0938 \u0938\u093e\u0907\u091f \u0938\u0947 \u0906\u0907\u0915\u0928 \u092a\u094d\u0930\u0627\u092a\u094d\u0924 \u0915\u0930\u0947\u0902" },
    hu: { shortcutIconResourceLink: "Szerezz ikonokat err\u0151l az oldalr\u00f3l" },
    idn: { shortcutIconResourceLink: "Dapatkan ikon dari situs ini" },
    it: { shortcutIconResourceLink: "Ottieni icone da questo sito" },
    ja: { shortcutIconResourceLink: "\u3053\u306e\u30b5\u30a4\u30c8\u304b\u3089\u30a2\u30a4\u30b3\u30f3\u3092\u5165\u624b" },
    ko: { shortcutIconResourceLink: "\uc774 \uc0ac\uc774\ud2b8\uc5d0\uc11c \uc544\uc774\ucf58 \ubc1b\uae30" },
    mr: { shortcutIconResourceLink: "\u092f\u093e \u0938\u093e\u0907\u091f\u0935\u0930\u0942\u0928 \u0906\u092f\u0915\u0949\u0928\u094d\u0938 \u092e\u093f\u0933\u0935\u093e" },
    np: { shortcutIconResourceLink: "\u092f\u0938 \u0938\u093e\u0907\u091f\u092c\u093e\u091f \u0906\u0907\u0915\u0928 \u092a\u094d\u0930\u093e\u092a\u094d\u0924 \u0917\u0930\u094d\u0928\u0941\u0939\u094b\u0938\u094d" },
    pl: { shortcutIconResourceLink: "Pobierz ikony z tej strony" },
    pt: { shortcutIconResourceLink: "Obtenha \u00edcones deste site" },
    ru: { shortcutIconResourceLink: "\u041f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u0438\u043a\u043e\u043d\u043a\u0438 \u0441 \u044d\u0442\u043e\u0433\u043e \u0441\u0430\u0439\u0442\u0430" },
    sl: { shortcutIconResourceLink: "Pridobi ikone s te strani" },
    ta: { shortcutIconResourceLink: "\u0b87\u0ba8\u0bcd\u0ba4 \u0ba4\u0bb3\u0ba4\u0bcd\u0ba4\u0bbf\u0bb2\u0bcd \u0b87\u0bb0\u0bc1\u0ba8\u0bcd\u0ba4\u0bc1 \u0b90\u0b95\u0bbe\u0ba9\u0bcd\u0b95\u0bb3\u0bc8 \u0baa\u0bc6\u0bb1\u0bc1\u0b99\u0bcd\u0b95\u0bb3\u0bcd" },
    th: { shortcutIconResourceLink: "\u0e23\u0e31\u0e1a\u0e44\u0e2d\u0e04\u0e2d\u0e19\u0e08\u0e32\u0e01\u0e40\u0e27\u0e47\u0e1a\u0e44\u0e0b\u0e15\u0e4c\u0e19\u0e35\u0e49" },
    tr: { shortcutIconResourceLink: "Bu siteden ikon al" },
    uk: { shortcutIconResourceLink: "\u041e\u0442\u0440\u0438\u043c\u0430\u0442\u0438 \u0456\u043a\u043e\u043d\u043a\u0438 \u0437 \u0446\u044c\u043e\u0433\u043e \u0441\u0430\u0439\u0442\u0443" },
    ur: { shortcutIconResourceLink: "\u0627\u0633 \u0633\u0627\u0626\u0679 \u0633\u06d2 \u0622\u0626\u06cc\u06a9\u0646\u0632 \u062d\u0627\u0635\u0644 \u06a9\u0631\u06cc\u06ba" },
    uz: { shortcutIconResourceLink: "Ushbu saytdan ikonlar oling" },
    vi: { shortcutIconResourceLink: "L\u1ea5y bi\u1ec3u t\u01b0\u1ee3ng t\u1eeb trang n\u00e0y" },
    zh: { shortcutIconResourceLink: "\u4ece\u6b64\u7f51\u7ad9\u83b7\u53d6\u56fe\u6807" },
    zh_TW: { shortcutIconResourceLink: "\u5f9e\u9019\u500b\u7db2\u7ad9\u53d6\u5f97\u5716\u793a" }
};

// Merge shortcut extras into any language that exists in translations
function applyShortcutExtras(lang) {
    const bundle = shortcutExtraTranslations[lang];
    if (bundle && translations[lang]) {
        Object.assign(translations[lang], bundle);
    }
}

window.materialYouTranslations = translations;
// alert-modal.js resolves button labels from window.translations — keep it in sync
// so prompt/confirm dialogs are translated instead of always falling back to English.
window.translations = translations;

// Define the width of the menu container for each language
const menuWidths = {
    en: "443px",
    ta: "522px",
    pt: "512px",
    bn: "458px",
    uz: "497px",
    vi: "487px",
    cs: "494px",
    es: "488px",
    hi: "450px",
    hu: "487px",
    ja: "486px",
    ru: "442px",
    it: "479px",
    idn: "477px",
    tr: "472px",
    fr: "517px",
    az: "460px",
    sl: "512px",
    np: "472px",
    de: "502px",
    fa: "502px",
    ar_SA: "482px",
    el: "497px",
    th: "497px",
    pl: "497px",
    uk: "497px",
};

const numberMappings = {
    "bn": { "0": "\u09e6", "1": "\u09e7", "2": "\u09e8", "3": "\u09e9", "4": "\u09ea", "5": "\u09eb", "6": "\u09ec", "7": "\u09ed", "8": "\u09ee", "9": "\u09ef" },
    "ta": { "0": "\u0be6", "1": "\u0be7", "2": "\u0be8", "3": "\u0be9", "4": "\u0bea", "5": "\u0beb", "6": "\u0bec", "7": "\u0bed", "8": "\u0bee", "9": "\u0bef" },
    "mr": { "0": "\u0966", "1": "\u0967", "2": "\u0968", "3": "\u0969", "4": "\u096a", "5": "\u096b", "6": "\u096c", "7": "\u096d", "8": "\u096e", "9": "\u096f" },
    "np": { "0": "\u0966", "1": "\u0967", "2": "\u0968", "3": "\u0969", "4": "\u096a", "5": "\u096b", "6": "\u096c", "7": "\u096d", "8": "\u096e", "9": "\u096f" },
    "fa": { 0: "\u06f0", 1: "\u06f1", 2: "\u06f2", 3: "\u06f3", 4: "\u06f4", 5: "\u06f5", 6: "\u06f6", 7: "\u06f7", 8: "\u06f8", 9: "\u06f9" },
};

const LRM = "\u200E";

function localizeNumbers(text, language) {
    const map = numberMappings[language];
    const specialDecimalLanguages = ["cs", "it", "pt", "ru", "tr", "vi", "uz", "es", "ko", "idn", "fr", "az", "sl", "hu", "de", "fa", "el", "uk"];

    if (specialDecimalLanguages.includes(language)) {
        text = text.replace(".", ",");
    }
    if (map) {
        text = text.replace(/\d/g, (digit) => map[digit] || digit);
    }

    const rtlFlipLanguages = ["ar_SA"];
    if (rtlFlipLanguages.includes(language)) {
        text = `${LRM}${text}${LRM}`;
    }

    return text;
}

// Right-to-left languages
const rtlLanguages = ["ur", "fa", "ar_SA"];

function applyLanguage(lang) {
    window.currentLanguage = lang;

    const translationMap = [
        "feedback",
        "resetsettings",
        "shortcutsText",
        "enableShortcutsText",
        "editShortcutsText",
        "shortcutsInfoText",
        "editShortcutsList",
        "editShortcutsListInfo",
        "adaptiveIconText",
        "adaptiveIconInfoText",
        "ai_tools_button",
        "enable_ai_tools",
        "aiToolsSettingsText",
        "aiToolsSettingsInfo",
        "googleAppsMenuText",
        "googleAppsMenuInfo",
        "todoListText",
        "todoListInfo",
        "fahrenheitCelsiusCheckbox",
        "fahrenheitCelsiusText",
        "minMaxTempText",
        "minMaxTempSubText",
        "hideWeatherTitle",
        "hideWeatherInfo",
        "hideWeatherBox",
        "hideWeatherBoxInfo",
        "micIconTitle",
        "micIconInfo",
        "hideSearchWith",
        "hideSearchWithInfo",
        "motivationalQuotesText",
        "motivationalQuotesInfo",
        "search_suggestions_button",
        "search_suggestions_text",
        "hideClockBox",
        "hideClockBoxInfo",
        "digitalclocktitle",
        "digitalclockinfo",
        "timeformattitle",
        "timeformatinfo",
        "greetingtitle",
        "greetinginfo",
        "userTextTitle",
        "userTextInfo",
        "useproxytitletext",
        "useproxyText",
        "ProxyText",
        "ProxySubtext",
        "HostproxyButton",
        "UserLocText",
        "UserLocSubtext",
        "useGPS",
        "useGPSInfo",
        "PrivacyPolicy",
        "WeatherApiText",
        "WeatherApiSubtext",
        "LearnMoreButton",
        "saveAPI",
        "enterBtn",
        "ai_tools",
        "defaultEngine",
        "googleEngine",
        "duckEngine",
        "bingEngine",
        "braveEngine",
        "youtubeEngine",
        "gImagesEngine",
        "redditEngine",
        "wikipediaEngine",
        "quoraEngine",
        "chatGPT",
        "gemini",
        "copilot",
        "claude",
        "grok",
        "qwen",
        "perplexity",
        "deepseek",
        "metaAI",
        'firefly',
        "hishamAgent",
        "github",
        "googleAppsHover",
        "todoListHover",
        "uploadWallpaperText",
        "backupText",
        "restoreText",
        "rangColor",
        "bookmarksText",
        "bookmarksInfo",
        "bookmarksHeading",
        "bookmarkSortBy",
        "sortAlphabetical",
        "sortTimeAdded",
        "bookmarkViewAs",
        "bookmarkViewGrid",
        "bookmarkViewList",
        "editBookmarkHeading",
        "lightThemed",
        "darkThemed",
        "systemThemed",
        "switchSearchModes",
        "switchSearchModesInfo",
        "adjustZoom",
        "changeBrowserTheme",
        "updateFirefoxHomepage",
        "dontShowTips",
        "aiSettingsIntro",
        "resetAISettingsBtn",
        "opacityTitle",
        "adjustOpacityDesc",
        "footerToastTitle",
        "footerToastMessage",
        "personalizationSectionTitle",
        "clockSectionTitle",
        "searchSectionTitle",
        "weatherSectionTitle",
        "appearanceSectionTitle",
        "settingsSectionTitle",
        "blurTitle",
        "adjustBlurDesc",
        "videoBackgroundTitle",
        "videoBackgroundDesc",
        "videoBrightnessTitle",
        "brightnessTitle",
        "adjustBrightnessDesc"
    ];

    const placeholderMap = [
        { id: "userLoc", key: "userLoc" },
        { id: "userAPI", key: "userAPI" },
        { id: "searchQ", key: "searchPlaceholder" },
        { id: "todoInput", key: "todoPlaceholder" },
        { id: "bookmarkSearch", key: "bookmarkSearch" },
        { id: "editBookmarkName", key: "editBookmarkName" },
        { id: "editBookmarkURL", key: "editBookmarkURL" }
    ];

    const elementsMap = [
        { id: "todoListHeading", key: "todoListText" },
        { id: "defaultEngineDD", key: "defaultEngine" },
        { id: "googleEngineDD", key: "googleEngine" },
        { id: "duckEngineDD", key: "duckEngine" },
        { id: "bingEngineDD", key: "bingEngine" },
        { id: "braveEngineDD", key: "braveEngine" },
        { id: "youtubeEngineDD", key: "youtubeEngine" },
        { id: "gImagesEngineDD", key: "gImagesEngine" },
        { id: "redditEngineDD", key: "redditEngine" },
        { id: "wikipediaEngineDD", key: "wikipediaEngine" },
        { id: "quoraEngineDD", key: "quoraEngine" },
        { id: "bookmarksHover", key: "bookmarksHeading" },
        { id: "saveproxy", key: "saveAPI" },
        { id: "saveLoc", key: "saveAPI" },
        { id: "saveBookmarkChanges", key: "saveAPI" },
        { id: "cancelBookmarkEdit", key: "cancelText" },
        { id: "aiSettingsHeader", key: "aiToolsSettingsText" },
        { id: "saveAISettingsBtn", key: "saveAPI" },
        { id: "editBookmarkNameLabel", key: "editBookmarkName" },
        { id: "editBookmarkURLLabel", key: "editBookmarkURL" },
        { id: "shortcutsSectionTitle", key: "shortcutsText" },
        { id: "shortcutIconResourceLink", key: "shortcutIconResourceLink" },
        { id: "shortcutIconPopoverButtonText", key: "shortcutIconPopoverButtonText" },
        { id: "shortcutIconPopoverTitle", key: "shortcutIconPopoverTitle" },
        { id: "dualLabelSurfaces", key: "dualLabelSurfaces" },
        { id: "dualLabelAccents", key: "dualLabelAccents" },
        { id: "colorsBgLabel", key: "themeLabel" },
        { id: "animSpeedLabel", key: "animSpeedLabel" },
        { id: "animSpeedLabelText", key: "animSpeedLabel" },
        { id: "applyPredefinedThemeBtnText", key: "applyThemeBtn" },
        { id: "lePanelTitle", key: "lePanelTitle" },
        { id: "lePanelHint", key: "lePanelHint" },
        { id: "leResetAllBtn", key: "leResetAll" },
        { id: "leDoneBtn", key: "leDone" },
        { id: "layoutEditorTitle", key: "layoutEditorTitle" },
        { id: "layoutEditorInfo", key: "layoutEditorInfo" },
        { id: "clockShapeTitle", key: "clockShapeTitle" },
        { id: "clockShapeInfo", key: "clockShapeInfo" },
        { id: "shadowPanelTitle", key: "shadowPanelTitle" },
        { id: "shadowPanelClose", key: "shadowPanelClose" },
    ];

    function applyTranslations(items, isPlaceholder) {
        items.forEach(item => {
            const element = document.getElementById(item.id || item);
            if (element) {
                const key = item.key || item;
                const translation = translations[lang]?.[key] || translations["en"]?.[key];

                if (isPlaceholder) {
                    element.placeholder = translation;
                } else {
                    if (item.id === "shadowPanelClose") {
                        element.setAttribute("title", translation || "Close");
                        element.setAttribute("aria-label", translation || "Close");
                    } else if (item.id === "shortcutIconResourceLink") {
                        element.innerText = translation;
                        element.setAttribute("title", translation || "Get icons from this site");
                        element.setAttribute("aria-label", translation || "Get icons from this site");
                    } else if (item.id === "rangColor") {
                        const labelText = element.querySelector(".colorPickerLabelText");
                        if (labelText) {
                            labelText.innerText = translation;
                        } else {
                            element.innerText = translation;
                        }
                    } else {
                        element.innerText = translation;
                    }
                }
            }
        });
    }

    applyTranslations(placeholderMap, true);
    applyTranslations(elementsMap, false);
    applyTranslations(translationMap, false);

    const userTextDiv = document.getElementById("userText");
    if (translations[lang]) {
        const placeholder = translations[lang]?.userText || translations["en"].userText;
        userTextDiv.dataset.placeholder = placeholder;
        if (!localStorage.getItem("userText")) {
            userTextDiv.innerText = placeholder;
        }
    }

    const menuCloseButton = document.getElementById("menuCloseButton");
    if (menuCloseButton) {
        const hoverText = translations[lang]?.menuCloseText || translations["en"].menuCloseText;
        menuCloseButton.setAttribute("data-lang", hoverText);
    }

    const menuCont = document.querySelector(".menuBar .menuCont");
    if (menuCont) {
        menuCont.style.width = menuWidths[lang] || menuWidths["en"];
        // Let the panel fit through CSS. Scaling also scaled every control and
        // remained stale after resizing or zooming the desktop browser.
        document.getElementById("menuStyle")?.remove();
    }

    function loadFont(fontUrl) {
        if (!document.querySelector(`link[href="${fontUrl}"]`)) {
            const link = document.createElement("link");
            link.rel = "stylesheet";
            link.href = fontUrl;
            document.head.appendChild(link);
        }
    }

    const root = document.documentElement;
    const commonFontStack = "'poppins', 'Poppins', sans-serif";
    if (lang === "vi") {
        loadFont("https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro&display=swap");
        root.style.setProperty("--main-font-family", `"Be Vietnam Pro", ${commonFontStack}`);
    } else if (lang === "ur" || lang === "ar_SA") {
        loadFont("https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@400;700;800;900&display=swap");
        root.style.setProperty("--main-font-family", `"Noto Sans Arabic", ${commonFontStack}`);
    } else if (lang === "fa") {
        loadFont("https://fonts.googleapis.com/css2?family=Vazirmatn&display=swap");
        root.style.setProperty("--main-font-family", `"Vazirmatn", ${commonFontStack}`);
    } else {
        root.style.setProperty("--main-font-family", commonFontStack);
    }

    const feelsLikeElement = document.getElementById("feelsLike");
    if (feelsLikeElement) {
        feelsLikeElement.style.left = "";
        feelsLikeElement.style.paddingRight = "";
        feelsLikeElement.style.width = "";
        feelsLikeElement.style.textAlign = "";
    }

    const quotesText = document.querySelector(".quotesContainer");
    if (quotesText) {
        quotesText.style.fontFamily = "";
        quotesText.style.removeProperty("font-family");
    }

    const folderBtn = document.getElementById("folderWallpaperTrigger");
    if (folderBtn) {
        folderBtn.title = translations[lang]?.folderWallpaperBtn || translations["en"].folderWallpaperBtn;
    }

    const galleryBtn = document.getElementById("galleryTrigger");
    if (galleryBtn) {
        galleryBtn.title = translations[lang]?.galleryTrigger || translations["en"].galleryTrigger;
    }

    const aboutTitleEl = document.getElementById("aboutTitle");
    if (aboutTitleEl) aboutTitleEl.textContent = translations[lang]?.aboutTitle || translations["en"].aboutTitle;

    const aboutDescEl = document.getElementById("aboutDesc");
    if (aboutDescEl) aboutDescEl.textContent = translations[lang]?.aboutDesc || translations["en"].aboutDesc;

    const aboutCreditsEl = document.getElementById("aboutCredits");
    if (aboutCreditsEl) aboutCreditsEl.textContent = translations[lang]?.aboutCredits || translations["en"].aboutCredits;

    const luckyTitleEl = document.getElementById("luckyTitle");
    if (luckyTitleEl) luckyTitleEl.textContent = translations[lang]?.luckyTitle || translations["en"].luckyTitle;

    const luckyDescEl = document.getElementById("luckyDesc");
    if (luckyDescEl) luckyDescEl.textContent = translations[lang]?.luckyDesc || translations["en"].luckyDesc;

    const luckyBtnTextEl = document.getElementById("luckyBtnText");
    if (luckyBtnTextEl) luckyBtnTextEl.textContent = translations[lang]?.luckyBtnText || translations["en"].luckyBtnText;

    const luckyWallpaperTextEl = document.getElementById("luckyWallpaperText");
    if (luckyWallpaperTextEl) luckyWallpaperTextEl.textContent = translations[lang]?.luckyWallpaperText || translations["en"].luckyWallpaperText;

    const leBtn = document.getElementById("layoutEditorBtn");
    if (leBtn) {
        leBtn.title = translations[lang]?.openLayoutEditor || translations["en"].openLayoutEditor;
    }

    const shapeKeyMap = {
        scallop: "shapeScallop", circle: "shapeCircle",
        squircle: "shapeSquircle",
    };
    document.querySelectorAll(".shape-btn[data-shape]").forEach(btn => {
        const key = shapeKeyMap[btn.dataset.shape];
        if (key) btn.title = translations[lang]?.[key] || translations["en"][key] || btn.dataset.shape;
    });

    const gradLabel = document.getElementById("gradientSectionLabel");
    if (gradLabel) {
        gradLabel.textContent = translations[lang]?.gradientSectionLabel || translations["en"].gradientSectionLabel;
    }

    document.querySelectorAll(".ctx-drag-label, .ctx-drag-label-text, .shadow-panel-drag-zone .ctx-drag-label, .drag-label").forEach(el => {
        el.textContent = translations[lang]?.leDragLabel || "drag";
    });
    document.querySelectorAll(".ctx-drag-handle, .shadow-panel-drag-zone, .panel-drag-bar").forEach(el => {
        el.title = translations[lang]?.dragToMove || translations["en"].dragToMove;
    });

    const colorMap = {
        blue: "colorBlue", teal: "colorTeal", indigo: "colorIndigo",
        sky: "colorSky", amber: "colorAmber", orange: "colorOrange",
        red: "colorRed", coral: "colorCoral", pink: "colorPink",
        magenta: "colorMagenta", purple: "colorPurple", olive: "colorOlive", violet: "colorViolet",
    };
    document.querySelectorAll(".colorPlate[value]").forEach(el => {
        const key = colorMap[el.value];
        const label = key ? (translations[lang]?.[key] || translations["en"][key] || el.value) : el.value;
        el.title = label;
        el.dataset.tooltip = label;
    });

    const gradMap = {
        "Sunset": "gradSunset", "Ocean": "gradOcean", "Fire": "gradFire",
        "Jungle": "gradJungle", "Mango": "gradMango", "Galaxy": "gradGalaxy",
        "Lava": "gradLava", "Aurora": "gradAurora", "Candy": "gradCandy",
        "Blood": "gradBlood", "Midnight": "gradMidnight", "Crimson": "gradCrimson",
    };
    document.querySelectorAll(".colorPlate-grad[title]").forEach(el => {
        if (!el.dataset.origTitle) el.dataset.origTitle = el.title;
        const key = gradMap[el.dataset.origTitle];
        const label = key ? (translations[lang]?.[key] || el.dataset.origTitle) : el.dataset.origTitle;
        el.title = label;
        el.dataset.tooltip = label;
    });

    if (typeof window.reTranslateLayoutEditor === "function") {
        window.reTranslateLayoutEditor();
    }

    const dualBtnMap = {
        "dualColorTriggerBtn": "dualColorTriggerTitle",
        "dualSwapBtn":         "dualSwapTitle",
        "customSwapBtn":       "customSwapTitle",
        "applyDualColorBtn":   "dualApplyTitle",
        "cancelDualColorBtn":  "dualCancelTitle",
        "shuffleWallpaperTrigger": "shuffleWallpaperTitle",
        "pinWallpaperTrigger":     "pinWallpaperTitle",
        "videoPlayPauseBtn":       "videoPlayPauseTitle",
        "videoMuteBtn":            "videoMuteTitle",
        "videoHideBtn":            "videoHideTitle",
    };
    Object.entries(dualBtnMap).forEach(([id, key]) => {
        const el = document.getElementById(id);
        if (el) el.title = translations[lang]?.[key] || translations["en"][key] || el.title;
    });

    const slots = document.querySelectorAll(".dualColorSlot");
    if (slots[0]) slots[0].title = translations[lang]?.dualSlotSurfaceTitle || translations["en"].dualSlotSurfaceTitle;
    if (slots[1]) slots[1].title = translations[lang]?.dualSlotAccentTitle  || translations["en"].dualSlotAccentTitle;

    document.documentElement.lang = lang;
    document.documentElement.dir = rtlLanguages.includes(lang) ? "rtl" : "ltr";
    saveLanguageStatus("selectedLanguage", lang);
    window.dispatchEvent(new CustomEvent("material-you-language-change", {
        detail: { lang }
    }));
}

document.getElementById("languageSelector").addEventListener("change", (event) => {
    const lang = event.target.value;
    applyLanguage(lang);
    location.reload();
});

async function initLanguage() {
    const savedLanguage = getLanguageStatus("selectedLanguage") || "en";
    applyShortcutExtras(savedLanguage);
    document.getElementById("languageSelector").value = savedLanguage;
    initCustomLanguageDropdown();
    applyLanguage(savedLanguage);
    // Bundled/cached text is usable immediately, including while offline.
    await fetchTranslations(savedLanguage);
    applyShortcutExtras(savedLanguage);
    applyLanguage(savedLanguage);
}

window.onload = function () {
    initLanguage();
};

function saveLanguageStatus(key, languageStatus) {
    localStorage.setItem(key, languageStatus);
}

function getLanguageStatus(key) {
    return localStorage.getItem(key);
}

function initCustomLanguageDropdown() {
    const select = document.getElementById("languageSelector");
    const dropdown = document.getElementById("languageDropdown");
    const trigger = document.getElementById("languageDropdownTrigger");
    const valueLabel = document.getElementById("languageDropdownValue");
    const menu = document.getElementById("languageDropdownMenu");

    if (!select || !dropdown || !trigger || !valueLabel || !menu) {
        return;
    }

    const checkIcon = `
        <svg class="languageDropdownOptionCheck" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M20 6 9 17l-5-5"></path>
        </svg>
    `;

    const closeMenu = () => {
        dropdown.classList.remove("language-open");
        trigger.setAttribute("aria-expanded", "false");
    };

    const openMenu = () => {
        dropdown.classList.add("language-open");
        trigger.setAttribute("aria-expanded", "true");
    };

    const syncSelectedLanguage = () => {
        const currentOption = select.options[select.selectedIndex];
        valueLabel.textContent = currentOption?.textContent || "English";

        menu.querySelectorAll(".languageDropdownOption").forEach(optionBtn => {
            const isSelected = optionBtn.dataset.value === select.value;
            optionBtn.classList.toggle("is-selected", isSelected);
            optionBtn.setAttribute("aria-selected", isSelected ? "true" : "false");
        });
    };

    const buildOptions = () => {
        menu.innerHTML = "";
        Array.from(select.options).forEach(option => {
            const optionButton = document.createElement("button");
            optionButton.type = "button";
            optionButton.className = "languageDropdownOption";
            optionButton.dataset.value = option.value;
            optionButton.setAttribute("role", "option");
            optionButton.setAttribute("aria-selected", "false");
            optionButton.innerHTML = `<span class="languageDropdownOptionLabel">${option.textContent}</span>${checkIcon}`;
            optionButton.addEventListener("click", () => {
                if (select.value === option.value) {
                    closeMenu();
                    return;
                }

                select.value = option.value;
                syncSelectedLanguage();
                select.dispatchEvent(new Event("change", { bubbles: true }));
            });
            menu.appendChild(optionButton);
        });
        syncSelectedLanguage();
    };

    trigger.addEventListener("click", () => {
        if (dropdown.classList.contains("language-open")) {
            closeMenu();
        } else {
            openMenu();
        }
    });

    document.addEventListener("click", (event) => {
        if (!dropdown.contains(event.target)) {
            closeMenu();
        }
    });

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
            closeMenu();
        }
    });

    buildOptions();
    select.addEventListener("change", syncSelectedLanguage);
}

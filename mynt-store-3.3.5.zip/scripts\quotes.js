(function() {
    "use strict";

    var HADITH_STORAGE_VERSION = "hadith-v1";
    var fallbackQuote = { quote: "إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.", author: "متفق عليه" };
    var currentPayload = null;

    var hadiths = [
        { quote: "إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.", author: "متفق عليه" },
        { quote: "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت.", author: "متفق عليه" },
        { quote: "الدين النصيحة.", author: "رواه مسلم" },
        { quote: "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.", author: "متفق عليه" },
        { quote: "المسلم من سلم المسلمون من لسانه ويده.", author: "متفق عليه" },
        { quote: "الكلمة الطيبة صدقة.", author: "متفق عليه" },
        { quote: "تبسمك في وجه أخيك لك صدقة.", author: "رواه الترمذي" },
        { quote: "خيركم من تعلم القرآن وعلمه.", author: "رواه البخاري" },
        { quote: "يسروا ولا تعسروا، وبشروا ولا تنفروا.", author: "متفق عليه" },
        { quote: "من دل على خير فله مثل أجر فاعله.", author: "رواه مسلم" },
        { quote: "الطهور شطر الإيمان.", author: "رواه مسلم" },
        { quote: "اتق الله حيثما كنت.", author: "رواه الترمذي" },
        { quote: "من حسن إسلام المرء تركه ما لا يعنيه.", author: "رواه الترمذي" },
        { quote: "المؤمن القوي خير وأحب إلى الله من المؤمن الضعيف.", author: "رواه مسلم" },
        { quote: "إن الله رفيق يحب الرفق في الأمر كله.", author: "متفق عليه" },
        { quote: "لا يرحم الله من لا يرحم الناس.", author: "متفق عليه" },
        { quote: "الحياء لا يأتي إلا بخير.", author: "متفق عليه" },
        { quote: "خيركم خيركم لأهله، وأنا خيركم لأهلي.", author: "رواه الترمذي" },
        { quote: "الساعي على الأرملة والمسكين كالمجاهد في سبيل الله.", author: "متفق عليه" },
        { quote: "إياكم والظن، فإن الظن أكذب الحديث.", author: "متفق عليه" },
        { quote: "لا تحقرن من المعروف شيئاً.", author: "رواه مسلم" },
        { quote: "أحب الأعمال إلى الله أدومها وإن قل.", author: "متفق عليه" },
        { quote: "من غشنا فليس منا.", author: "رواه مسلم" },
        { quote: "اعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك.", author: "رواه مسلم" },
        { quote: "لا يدخل الجنة من كان في قلبه مثقال ذرة من كبر.", author: "رواه مسلم" },
        { quote: "الصدقة تطفئ الخطيئة كما يطفئ الماء النار.", author: "رواه الترمذي" },
        { quote: "بلغوا عني ولو آية.", author: "رواه البخاري" },
        { quote: "الحلال بيّن والحرام بيّن.", author: "متفق عليه" },
        { quote: "من سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة.", author: "رواه مسلم" },
        { quote: "الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء.", author: "رواه الترمذي" }
    ];

    // ── Hadith translations: Arabic text → translated { quote, author } ──────
    var translations = {
        en: {}
    };

    translations.en = {
        "إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.":
            { quote: "Actions are judged by intentions, and every person will have what they intended.", author: "Agreed upon" },
        "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت.":
            { quote: "Whoever believes in Allah and the Last Day, let them speak good or remain silent.", author: "Agreed upon" },
        "الدين النصيحة.":
            { quote: "The religion is sincerity and good advice.", author: "Narrated by Muslim" },
        "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.":
            { quote: "None of you truly believes until they love for their brother what they love for themselves.", author: "Agreed upon" },
        "المسلم من سلم المسلمون من لسانه ويده.":
            { quote: "A Muslim is one from whose tongue and hand other Muslims are safe.", author: "Agreed upon" },
        "الكلمة الطيبة صدقة.":
            { quote: "A good word is an act of charity.", author: "Agreed upon" },
        "تبسمك في وجه أخيك لك صدقة.":
            { quote: "Your smile for your brother is an act of charity.", author: "Narrated by At-Tirmidhi" },
        "خيركم من تعلم القرآن وعلمه.":
            { quote: "The best among you are those who learn the Quran and teach it.", author: "Narrated by Al-Bukhari" },
        "يسروا ولا تعسروا، وبشروا ولا تنفروا.":
            { quote: "Make things easy and do not make them difficult; give glad tidings and do not drive people away.", author: "Agreed upon" },
        "من دل على خير فله مثل أجر فاعله.":
            { quote: "Whoever guides someone to goodness will have a reward like the one who did it.", author: "Narrated by Muslim" },
        "الطهور شطر الإيمان.":
            { quote: "Purity is half of faith.", author: "Narrated by Muslim" },
        "اتق الله حيثما كنت.":
            { quote: "Fear Allah wherever you are.", author: "Narrated by At-Tirmidhi" },
        "من حسن إسلام المرء تركه ما لا يعنيه.":
            { quote: "Part of the perfection of one's Islam is leaving that which does not concern them.", author: "Narrated by At-Tirmidhi" },
        "المؤمن القوي خير وأحب إلى الله من المؤمن الضعيف.":
            { quote: "The strong believer is better and more beloved to Allah than the weak believer.", author: "Narrated by Muslim" },
        "إن الله رفيق يحب الرفق في الأمر كله.":
            { quote: "Allah is gentle and loves gentleness in all matters.", author: "Agreed upon" },
        "لا يرحم الله من لا يرحم الناس.":
            { quote: "Allah will not show mercy to one who does not show mercy to people.", author: "Agreed upon" },
        "الحياء لا يأتي إلا بخير.":
            { quote: "Modesty brings nothing but good.", author: "Agreed upon" },
        "خيركم خيركم لأهله، وأنا خيركم لأهلي.":
            { quote: "The best among you is the one who is best to their family, and I am the best among you to my family.", author: "Narrated by At-Tirmidhi" },
        "الساعي على الأرملة والمسكين كالمجاهد في سبيل الله.":
            { quote: "One who strives for the widow and the poor is like one who strives in the cause of Allah.", author: "Agreed upon" },
        "إياكم والظن، فإن الظن أكذب الحديث.":
            { quote: "Beware of suspicion, for suspicion is the most false of speech.", author: "Agreed upon" },
        "لا تحقرن من المعروف شيئاً.":
            { quote: "Do not belittle any act of kindness, no matter how small.", author: "Narrated by Muslim" },
        "أحب الأعمال إلى الله أدومها وإن قل.":
            { quote: "The most beloved deeds to Allah are the most consistent, even if they are few.", author: "Agreed upon" },
        "من غشنا فليس منا.":
            { quote: "Whoever cheats us is not one of us.", author: "Narrated by Muslim" },
        "اعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك.":
            { quote: "Worship Allah as though you see Him, for even if you do not see Him, He sees you.", author: "Narrated by Muslim" },
        "لا يدخل الجنة من كان في قلبه مثقال ذرة من كبر.":
            { quote: "No one who has an atom's weight of arrogance in their heart will enter Paradise.", author: "Narrated by Muslim" },
        "الصدقة تطفئ الخطيئة كما يطفئ الماء النار.":
            { quote: "Charity extinguishes sin just as water extinguishes fire.", author: "Narrated by At-Tirmidhi" },
        "بلغوا عني ولو آية.":
            { quote: "Convey from me, even if it is a single verse.", author: "Narrated by Al-Bukhari" },
        "الحلال بيّن والحرام بيّن.":
            { quote: "What is lawful is clear and what is unlawful is clear.", author: "Agreed upon" },
        "من سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة.":
            { quote: "Whoever takes a path seeking knowledge, Allah will make easy for them a path to Paradise.", author: "Narrated by Muslim" },
        "الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء.":
            { quote: "The merciful are shown mercy by the Most Merciful. Show mercy to those on earth, and the One above the heavens will show mercy to you.", author: "Narrated by At-Tirmidhi" }
    };

    // ── French translations ──────────────────────────────────────────────────
    translations.fr = {
        "إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.":
            { quote: "Les actions ne valent que par leurs intentions, et chacun aura selon ce qu'il a prévu.", author: "Unanimement rapporté" },
        "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت.":
            { quote: "Que celui qui croit en Allah et au Jour dernier dise du bien ou qu'il se taise.", author: "Unanimement rapporté" },
        "الدين النصيحة.":
            { quote: "La religion, c'est le conseil sincère.", author: "Rapporté par Mouslim" },
        "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.":
            { quote: "Aucun de vous ne croit vraiment tant qu'il n'aime pas pour son frère ce qu'il aime pour lui-même.", author: "Unanimement rapporté" },
        "المسلم من سلم المسلمون من لسانه ويده.":
            { quote: "Le musulman est celui dont les autres musulmans sont à l'abri de sa langue et de sa main.", author: "Unanimement rapporté" },
        "الكلمة الطيبة صدقة.":
            { quote: "Une bonne parole est une aumône.", author: "Unanimement rapporté" },
        "تبسمك في وجه أخيك لك صدقة.":
            { quote: "Ton sourire adressé à ton frère est une aumône.", author: "Rapporté par At-Tirmidhi" },
        "خيركم من تعلم القرآن وعلمه.":
            { quote: "Les meilleurs d'entre vous sont ceux qui apprennent le Coran et l'enseignent.", author: "Rapporté par Al-Bukhari" },
        "يسروا ولا تعسروا، وبشروا ولا تنفروا.":
            { quote: "Facilitez et ne rendez pas les choses difficiles ; annoncez la bonne nouvelle et ne repoussez pas les gens.", author: "Unanimement rapporté" },
        "من دل على خير فله مثل أجر فاعله.":
            { quote: "Celui qui guide vers le bien aura une récompense égale à celui qui l'accomplit.", author: "Rapporté par Mouslim" },
        "الطهور شطر الإيمان.":
            { quote: "La pureté est la moitié de la foi.", author: "Rapporté par Mouslim" },
        "اتق الله حيثما كنت.":
            { quote: "Crains Allah où que tu sois.", author: "Rapporté par At-Tirmidhi" },
        "من حسن إسلام المرء تركه ما لا يعنيه.":
            { quote: "La perfection de l'islam d'une personne est de laisser ce qui ne la concerne pas.", author: "Rapporté par At-Tirmidhi" },
        "المؤمن القوي خير وأحب إلى الله من المؤمن الضعيف.":
            { quote: "Le croyant fort est meilleur et plus aimé d'Allah que le croyant faible.", author: "Rapporté par Mouslim" },
        "إن الله رفيق يحب الرفق في الأمر كله.":
            { quote: "Allah est doux et aime la douceur dans toutes les choses.", author: "Unanimement rapporté" },
        "لا يرحم الله من لا يرحم الناس.":
            { quote: "Allah ne fait pas miséricorde à celui qui ne fait pas miséricorde aux gens.", author: "Unanimement rapporté" },
        "الحياء لا يأتي إلا بخير.":
            { quote: "La pudeur n'apporte que du bien.", author: "Unanimement rapporté" },
        "خيركم خيركم لأهله، وأنا خيركم لأهلي.":
            { quote: "Le meilleur d'entre vous est le meilleur envers sa famille, et je suis le meilleur d'entre vous envers ma famille.", author: "Rapporté par At-Tirmidhi" },
        "الساعي على الأرملة والمسكين كالمجاهد في سبيل الله.":
            { quote: "Celui qui œuvre pour la veuve et le pauvre est comme celui qui lutte dans la cause d'Allah.", author: "Unanimement rapporté" },
        "إياكم والظن، فإن الظن أكذب الحديث.":
            { quote: "Méfiez-vous des soupçons, car le soupçon est le discours le plus mensonger.", author: "Unanimement rapporté" },
        "لا تحقرن من المعروف شيئاً.":
            { quote: "Ne méprisez aucun acte de bienfaisance, si petit soit-il.", author: "Rapporté par Mouslim" },
        "أحب الأعمال إلى الله أدومها وإن قل.":
            { quote: "Les actions les plus aimées d'Allah sont les plus constantes, même si elles sont peu nombreuses.", author: "Unanimement rapporté" },
        "من غشنا فليس منا.":
            { quote: "Celui qui nous trompe n'est pas des nôtres.", author: "Rapporté par Mouslim" },
        "اعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك.":
            { quote: "Adore Allah comme si tu Le voyais, car si tu ne Le vois pas, Lui te voit.", author: "Rapporté par Mouslim" },
        "لا يدخل الجنة من كان في قلبه مثقال ذرة من كبر.":
            { quote: "N'entrera pas au Paradis celui qui a dans son cœur le poids d'un atome d'orgueil.", author: "Rapporté par Mouslim" },
        "الصدقة تطفئ الخطيئة كما يطفئ الماء النار.":
            { quote: "L'aumône éteint le péché comme l'eau éteint le feu.", author: "Rapporté par At-Tirmidhi" },
        "بلغوا عني ولو آية.":
            { quote: "Transmettez de ma part, ne serait-ce qu'un verset.", author: "Rapporté par Al-Bukhari" },
        "الحلال بيّن والحرام بيّن.":
            { quote: "Ce qui est licite est clair et ce qui est illicite est clair.", author: "Unanimement rapporté" },
        "من سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة.":
            { quote: "Quiconque emprunte un chemin pour y chercher un savoir, Allah lui facilitera par là un chemin vers le Paradis.", author: "Rapporté par Mouslim" },
        "الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء.":
            { quote: "Les miséricordieux sont l'objet de la miséricorde du Tout-Miséricordieux. Faites miséricorde à ceux qui sont sur terre, Celui qui est au ciel vous fera miséricorde.", author: "Rapporté par At-Tirmidhi" }
    };

    // ── German translations ──────────────────────────────────────────────────
    translations.de = {
        "إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.":
            { quote: "Die Taten werden nur nach den Absichten beurteilt, und jeder bekommt nur das, was er beabsichtigt hat.", author: "Einstimmig überliefert" },
        "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت.":
            { quote: "Wer an Allah und den Jüngsten Tag glaubt, soll Gutes sagen oder schweigen.", author: "Einstimmig überliefert" },
        "الدين النصيحة.":
            { quote: "Die Religion ist ehrlicher Rat und Aufrichtigkeit.", author: "Überliefert von Muslim" },
        "لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.":
            { quote: "Keiner von euch glaubt wirklich, bis er für seinen Bruder das wünscht, was er für sich selbst wünscht.", author: "Einstimmig überliefert" },
        "المسلم من سلم المسلمون من لسانه ويده.":
            { quote: "Ein Muslim ist jemand, vor dessen Zunge und Hand die anderen Muslime sicher sind.", author: "Einstimmig überliefert" },
        "الكلمة الطيبة صدقة.":
            { quote: "Ein gutes Wort ist eine wohltätige Spende.", author: "Einstimmig überliefert" },
        "تبسمك في وجه أخيك لك صدقة.":
            { quote: "Dein Lächeln gegenüber deinem Bruder ist eine wohltätige Spende.", author: "Überliefert von At-Tirmidhi" },
        "خيركم من تعلم القرآن وعلمه.":
            { quote: "Die Besten unter euch sind diejenigen, die den Quran lernen und ihn lehren.", author: "Überliefert von Al-Bukhari" },
        "يسروا ولا تعسروا، وبشروا ولا تنفروا.":
            { quote: "Macht es leicht und erschwert es nicht; verkündet gute Nachrichten und stoßt die Menschen nicht zurück.", author: "Einstimmig überliefert" },
        "من دل على خير فله مثل أجر فاعله.":
            { quote: "Wer jemanden zum Guten anleitet, hat eine Belohnung gleich dem, der es getan hat.", author: "Überliefert von Muslim" },
        "الطهور شطر الإيمان.":
            { quote: "Die Reinheit ist die Hälfte des Glaubens.", author: "Überliefert von Muslim" },
        "اتق الله حيثما كنت.":
            { quote: "Fürchte Allah, wo immer du bist.", author: "Überliefert von At-Tirmidhi" },
        "من حسن إسلام المرء تركه ما لا يعنيه.":
            { quote: "Zur Vollkommenheit des Islams einer Person gehört, das zu lassen, was sie nichts angeht.", author: "Überliefert von At-Tirmidhi" },
        "المؤمن القوي خير وأحب إلى الله من المؤمن الضعيف.":
            { quote: "Der starke Gläubige ist besser und Allah lieber als der schwache Gläubige.", author: "Überliefert von Muslim" },
        "إن الله رفيق يحب الرفق في الأمر كله.":
            { quote: "Allah ist sanftmütig und liebt die Sanftmütigkeit in allen Angelegenheiten.", author: "Einstimmig überliefert" },
        "لا يرحم الله من لا يرحم الناس.":
            { quote: "Allah zeigt keine Barmherzigkeit gegenüber dem, der den Menschen keine Barmherzigkeit zeigt.", author: "Einstimmig überliefert" },
        "الحياء لا يأتي إلا بخير.":
            { quote: "Bescheidenheit bringt nichts als Gutes.", author: "Einstimmig überliefert" },
        "خيركم خيركم لأهله، وأنا خيركم لأهلي.":
            { quote: "Der Beste unter euch ist der, der am besten zu seiner Familie ist, und ich bin der Beste unter euch zu meiner Familie.", author: "Überliefert von At-Tirmidhi" },
        "الساعي على الأرملة والمسكين كالمجاهد في سبيل الله.":
            { quote: "Wer sich für die Witwe und den Bedürftigen einsetzt, ist wie jemand, der auf dem Wege Allahs kämpft.", author: "Einstimmig überliefert" },
        "إياكم والظن، فإن الظن أكذب الحديث.":
            { quote: "Hütet euch vor Verdacht, denn Verdacht ist das falsche Reden.", author: "Einstimmig überliefert" },
        "لا تحقرن من المعروف شيئاً.":
            { quote: "Verachte keine gute Tat, auch wenn sie klein ist.", author: "Überliefert von Muslim" },
        "أحب الأعمال إلى الله أدومها وإن قل.":
            { quote: "Die bei Allah beliebtesten Taten sind die beständigsten, auch wenn sie wenige sind.", author: "Einstimmig überliefert" },
        "من غشنا فليس منا.":
            { quote: "Wer uns betrügt, gehört nicht zu uns.", author: "Überliefert von Muslim" },
        "اعبد الله كأنك تراه، فإن لم تكن تراه فإنه يراك.":
            { quote: "Verehre Allah, als ob du Ihn siehst; denn wenn du Ihn nicht siehst, so sieht Er dich.", author: "Überliefert von Muslim" },
        "لا يدخل الجنة من كان في قلبه مثقال ذرة من كبر.":
            { quote: "Es wird nicht ins Paradies eingehen, wer in seinem Herzen das Gewicht eines Staubkorns Hochmut trägt.", author: "Überliefert von Muslim" },
        "الصدقة تطفئ الخطيئة كما يطفئ الماء النار.":
            { quote: "Das Almoschen löscht die Sünde aus, wie das Wasser das Feuer löscht.", author: "Überliefert von At-Tirmidhi" },
        "بلغوا عني ولو آية.":
            { quote: "Übermittelt von mir, auch wenn es nur ein Vers ist.", author: "Überliefert von Al-Bukhari" },
        "الحلال بيّن والحرام بيّن.":
            { quote: "Das Erlaubte ist klar und das Verbotene ist klar.", author: "Einstimmig überliefert" },
        "من سلك طريقاً يلتمس فيه علماً سهل الله له به طريقاً إلى الجنة.":
            { quote: "Wer einen Weg geht, um darauf Wissen zu suchen, dem macht Allah dadurch einen Weg ins Paradies leicht.", author: "Überliefert von Muslim" },
        "الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء.":
            { quote: "Die Barmherzigen erbarmt der Allerbarmer. Erbarmt euch derer auf der Erde, so erbarmt sich eurer der über dem Himmel.", author: "Überliefert von At-Tirmidhi" }
    };

    // ── RTL languages (Arabic family + Urdu + Persian) ────────────────────────
    var rtlLanguages = ["ar", "ar_SA", "ur", "fa"];
    function isRtl(lang) {
        return rtlLanguages.indexOf(lang) >= 0;
    }

    function ensureHadithMode() {
        if (localStorage.getItem("quotesContentVersion") === HADITH_STORAGE_VERSION) return;
        clearQuotesStorage();
        localStorage.setItem("quotesContentVersion", HADITH_STORAGE_VERSION);
    }

    function adjustSavedQuoteLayout() {
        if (localStorage.getItem("hadithQuotesLayoutFixed") === "true") return;
        try {
            var saved = JSON.parse(localStorage.getItem("layoutEditorV1") || "{}");
            var current = saved.quotes || {};
            // Repair a previous bug that forced the quotes box up by 130px, causing it
            // to overlap the search bar instead of sitting just below it.
            if (typeof current.ty === "number" && current.ty <= -100) {
                saved.quotes = {
                    tx: typeof current.tx === "number" ? current.tx : 0,
                    ty: 0,
                    scale: typeof current.scale === "number" ? current.scale : 1
                };
                localStorage.setItem("layoutEditorV1", JSON.stringify(saved));
                document.documentElement.style.setProperty("--le-tx-quotes", saved.quotes.tx + "px");
                document.documentElement.style.setProperty("--le-ty-quotes", "0px");
                document.documentElement.style.setProperty("--le-scale-quotes", saved.quotes.scale);
            }
        } catch (e) {}
        localStorage.setItem("hadithQuotesLayoutFixed", "true");
    }

    function fetchQuotesForLanguage(lang) {
        return Promise.resolve({ quotes: hadiths, sourceLang: "ar", targetLang: lang || "en" });
    }

    function pickQuote(payload) {
        var quotes = payload && payload.quotes;
        var targetLang = (payload && payload.targetLang) || "en";
        if (!quotes || !quotes.length) return fallbackQuote;
        
        // Try to find a translated quote first
        for (var i = 0; i < 12; i++) {
            var candidate = quotes[Math.floor(Math.random() * quotes.length)];
            var arText = candidate.quote;
            var langDict = translations[targetLang];
            
            if (langDict && langDict[arText]) {
                var translated = langDict[arText];
                var totalLength = translated.quote.length + translated.author.length;
                if (totalLength <= 140) {
                    return {
                        quote: translated.quote,
                        author: translated.author,
                        isTranslation: true
                    };
                }
            }
            
            // Fall back to Arabic if translation is too long or not found
            if ((arText || "").length + (candidate.author || "").length <= 140) {
                return {
                    quote: arText,
                    author: candidate.author,
                    isTranslation: false
                };
            }
        }
        
        // Last resort: random quote (Arabic or translated)
        var randomCandidate = quotes[Math.floor(Math.random() * quotes.length)] || fallbackQuote;
        var arText = randomCandidate.quote;
        var langDict = translations[targetLang];
        if (langDict && langDict[arText]) {
            return {
                quote: langDict[arText].quote,
                author: langDict[arText].author,
                isTranslation: true
            };
        }
        return {
            quote: arText,
            author: randomCandidate.author,
            isTranslation: false
        };
    }

    var currentActiveQuote = fallbackQuote;

    function renderQuoteActions() {
        var cont = document.getElementById("motivationalQuotesCont");
        if (!cont || cont.querySelector(".ux-quote-toolbar")) return;

        var toolbar = document.createElement("div");
        toolbar.className = "ux-quote-toolbar";
        toolbar.setAttribute("role", "toolbar");
        toolbar.setAttribute("aria-label", "Quote actions");

        var isAr = (window.currentLanguage || localStorage.getItem("selectedLanguage") || "en").startsWith("ar");

        toolbar.innerHTML = `
            <button type="button" class="ux-quote-action-btn" id="quoteCopyBtn" title="${isAr ? "نسخ الاقتباس" : "Copy quote"}" aria-label="Copy quote">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
                    <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
                </svg>
            </button>
            <button type="button" class="ux-quote-action-btn" id="quoteShuffleBtn" title="${isAr ? "اقتباس آخر" : "Next quote"}" aria-label="Next quote">
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/>
                </svg>
            </button>
        `;

        cont.appendChild(toolbar);

        var copyBtn = toolbar.querySelector("#quoteCopyBtn");
        var shuffleBtn = toolbar.querySelector("#quoteShuffleBtn");

        copyBtn.addEventListener("click", function(e) {
            e.stopPropagation();
            var textToCopy = `"${currentActiveQuote.quote}" — ${currentActiveQuote.author}`;
            navigator.clipboard.writeText(textToCopy).then(function() {
                copyBtn.classList.add("copied");
                copyBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>`;
                if (typeof window.uxToast === "function") {
                    window.uxToast(isAr ? "تم نسخ الاقتباس إلى الحافظة ✨" : "Quote copied to clipboard ✨");
                }
                setTimeout(function() {
                    copyBtn.classList.remove("copied");
                    copyBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`;
                }, 2000);
            }).catch(function() {
                if (typeof window.uxToast === "function") {
                    window.uxToast(isAr ? "تعذّر النسخ إلى الحافظة" : "Couldn't copy to clipboard");
                }
            });
        });

        shuffleBtn.addEventListener("click", function(e) {
            e.stopPropagation();
            shuffleBtn.classList.add("spinning");
            refreshQuote().finally(function() {
                setTimeout(function() { shuffleBtn.classList.remove("spinning"); }, 350);
            });
        });
    }

    function setQuote(quote) {
        var quoteEl = document.querySelector(".quotesContainer");
        var authorEl = document.querySelector(".authorName span");
        var authorWrapper = document.querySelector(".authorName");
        var lang = window.currentLanguage || "en";
        var dir = isRtl(lang) ? "rtl" : "ltr";
        currentActiveQuote = quote || fallbackQuote;
        
        if (quoteEl) quoteEl.textContent = quote.quote || fallbackQuote.quote;
        if (authorEl) authorEl.textContent = quote.author || "";
        if (quoteEl) {
            quoteEl.setAttribute("dir", dir);
            quoteEl.setAttribute("lang", lang);
        }
        if (authorWrapper && authorEl) {
            authorWrapper.setAttribute("dir", dir);
            requestAnimationFrame(function() {
                authorWrapper.style.width = (authorEl.scrollWidth + 32) + "px";
            });
        }
        renderQuoteActions();
    }

    async function refreshQuote() {
        var lang = window.currentLanguage || "en";
        var quoteEl = document.querySelector(".quotesContainer");
        var authorEl = document.querySelector(".authorName");
        if (quoteEl) {
            quoteEl.classList.add("quote-fading");
            if (authorEl) authorEl.classList.add("quote-fading");
        }
        currentPayload = await fetchQuotesForLanguage(lang);
        setTimeout(function() {
            setQuote(pickQuote(currentPayload));
            if (quoteEl) {
                quoteEl.classList.remove("quote-fading");
                if (authorEl) authorEl.classList.remove("quote-fading");
            }
        }, 160);
    }

    function clearQuotesStorage() {
        Object.keys(localStorage).forEach(function(key) {
            if (key.indexOf("quotes_") === 0) localStorage.removeItem(key);
        });
    }

    function updateQuoteVisibility() {
        var hideSearchWith = document.getElementById("shortcut_switchcheckbox");
        var searchWithContainer = document.getElementById("search-with-container");
        var checkbox = document.getElementById("motivationalQuotesCheckbox");
        var container = document.getElementById("motivationalQuotesCont");
        var toggle = document.getElementById("quotesToggle");
        if (!checkbox) return;

        var enabled = checkbox.checked;
        localStorage.setItem("motivationalQuotesVisible", String(enabled));
        if (toggle) toggle.classList.toggle("inactive", !enabled);
        if (searchWithContainer && hideSearchWith) {
            searchWithContainer.style.display = hideSearchWith.checked && enabled ? "none" : "";
        }
        if (container) container.style.display = enabled ? "flex" : "none";
        if (enabled) refreshQuote();
        if (!enabled) clearQuotesStorage();
    }

    document.addEventListener("DOMContentLoaded", function() {
        ensureHadithMode();
        adjustSavedQuoteLayout();

        var checkbox = document.getElementById("motivationalQuotesCheckbox");
        var hideSearchWith = document.getElementById("shortcut_switchcheckbox");
        var quoteContainer = document.getElementById("motivationalQuotesCont");

        if (checkbox) {
            checkbox.checked = localStorage.getItem("motivationalQuotesVisible") !== "false";
            checkbox.addEventListener("change", updateQuoteVisibility);
        }
        if (hideSearchWith) hideSearchWith.addEventListener("change", updateQuoteVisibility);
        if (quoteContainer) {
            quoteContainer.addEventListener("click", function(event) {
                if (event.target.closest(".ux-quote-toolbar")) return;
                event.stopPropagation();
                refreshQuote();
            });
        }
        updateQuoteVisibility();
    });
})();

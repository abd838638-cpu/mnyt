/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 */

const themeStorageKey = "selectedTheme";
const customSwapKey = "customThemeSwapped"; // "1" = show opposite mode palette
const customThemeStorageKey = "customThemeColor";
const safePresetThemeStorageKey = "safePresetTheme";
const darkModeCheckboxKey = "enableDarkModeCheckboxState";
const normalizeThemePlateValue = (colorValue) => colorValue === "violet" ? "violet" : colorValue;
const storedTheme = normalizeThemePlateValue(localStorage.getItem(themeStorageKey));
const storedCustomColor = localStorage.getItem(customThemeStorageKey);
const radioButtons = document.querySelectorAll(".colorPlate");
const colorPicker = document.getElementById("colorPicker");
const colorPickerLabel = document.getElementById("rangColor");

const SAFE_PRESET_THEME_COLORS = Object.freeze({
    blue: "#4A8EEB",
    teal: "#24B5A7",
    indigo: "#8193FF",
    sky: "#50A5F6",
    amber: "#D98B14",
    orange: "#F0834F",
    red: "#FF7E8A",
    coral: "#FF8868",
    pink: "#FF74A6",
    magenta: "#EC79F4",
    purple: "#B78CFF",
    olive: "#7FAF2C",
    violet: "#7a4bc2"
});

function isSafePresetTheme(colorValue) {
    return Object.prototype.hasOwnProperty.call(SAFE_PRESET_THEME_COLORS, normalizeThemePlateValue(colorValue));
}

function getSafePresetThemeColor(colorValue) {
    return SAFE_PRESET_THEME_COLORS[normalizeThemePlateValue(colorValue)] || "";
}

function clearSafePresetTheme() {
    localStorage.removeItem(safePresetThemeStorageKey);
}

function clearGradientThemeIndicators() {
    document.querySelectorAll(".colorPlate-grad").forEach((button) => {
        button.classList.remove("grad-active");
    });
}

function clearPresetThemeIndicators() {
    radioButtons.forEach((radio) => {
        radio.checked = false;
    });
    clearGradientThemeIndicators();
}

function setCheckedThemePlate(colorValue) {
    const normalizedColorValue = normalizeThemePlateValue(colorValue);
    clearGradientThemeIndicators();
    radioButtons.forEach((radio) => {
        radio.checked = radio.value === normalizedColorValue;
    });
}

window.clearPresetThemeIndicators = clearPresetThemeIndicators;

function _isPreferredDarkMode() {
    const preferredTheme = localStorage.getItem("preferredTheme") || "light";
    const systemIsDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    return preferredTheme === "dark" || (preferredTheme === "system" && systemIsDark);
}

function _getSafePresetSourceVars(themeName) {
    const normalizedThemeName = normalizeThemePlateValue(themeName);
    const root = document.documentElement;
    const computed = getComputedStyle(root);
    if (normalizedThemeName === "blue") {
        return {
            bg: "#C2D8FB",
            tint: "#E6F0FF",
            darker: "#1A5FC8",
            dark: "#2979E8",
            text: "#1B3041",
            white: "#ffffff"
        };
    }

    return {
        bg: computed.getPropertyValue(`--bg-color-${normalizedThemeName}`).trim(),
        tint: computed.getPropertyValue(`--accentLightTint-${normalizedThemeName}`).trim(),
        darker: computed.getPropertyValue(`--darkerColor-${normalizedThemeName}`).trim(),
        dark: computed.getPropertyValue(`--darkColor-${normalizedThemeName}`).trim(),
        text: computed.getPropertyValue(`--textColorDark-${normalizedThemeName}`).trim(),
        white: computed.getPropertyValue(`--whitishColor-${normalizedThemeName}`).trim()
    };
}

function _deriveDarkThemeFromColorSeed(rawColor, options = {}) {
    const lum = getSimpleLuminance(rawColor);
    const bgColor = shiftHexToLuminance(
        rawColor,
        mixNumber(
            options.bgStart ?? 0.022,
            options.bgEnd ?? 0.032,
            smoothStep(0.06, 0.96, lum)
        )
    );

    const bgLum = getSimpleLuminance(bgColor);
    const tintDelta = mixNumber(
        options.tintDeltaStart ?? 0.052,
        options.tintDeltaEnd ?? 0.028,
        smoothStep(0.08, 0.90, lum)
    );
    const bgTintColor = shiftHexToLuminance(
        rawColor,
        Math.min(options.tintMax ?? 0.11, bgLum + tintDelta)
    );

    const accentMax = options.accentMax ?? 0.82;
    const accentFloor = Math.min(
        accentMax,
        bgLum + mixNumber(
            options.accentLiftStart ?? 0.34,
            options.accentLiftEnd ?? 0.18,
            smoothStep(0.08, 0.78, lum)
        )
    );
    const accentColor = shiftHexToLuminance(rawColor, Math.min(accentMax, Math.max(lum, accentFloor)));

    const accentLum = getSimpleLuminance(accentColor);
    const accentDarkColor = shiftHexToLuminance(
        accentColor,
        Math.max(bgLum + (options.accentDarkGap ?? 0.065), accentLum * (options.accentDarkRatio ?? 0.62))
    );

    return {
        bgColor,
        bgTintColor,
        accentColor,
        accentDarkColor,
        textDarkColor: options.textDarkColor || "#E4E4E4",
        whitishColor: shiftHexToLuminance(
            bgColor,
            Math.min(options.whitishMax ?? 0.14, bgLum + (options.whitishLift ?? 0.035))
        )
    };
}

function _applySafePresetThemeCore(themeName) {
    const isDarkMode = _isPreferredDarkMode();
    const safeColor = getSafePresetThemeColor(themeName);

    if (isDarkMode && safeColor) {
        const derived = _deriveDarkThemeFromColorSeed(safeColor, {
            bgStart: 0.022,
            bgEnd: 0.032,
            tintDeltaStart: 0.052,
            tintDeltaEnd: 0.028,
            tintMax: 0.11,
            accentLiftStart: 0.34,
            accentLiftEnd: 0.18,
            accentMax: 0.82,
            accentDarkGap: 0.065,
            accentDarkRatio: 0.62,
            whitishMax: 0.14,
            whitishLift: 0.035
        });

        localStorage.setItem(customThemeStorageKey, safeColor);
        localStorage.removeItem(customSwapKey);

        document.body.setAttribute("data-custom-theme", "active");
        document.body.removeAttribute("data-dual-theme");

        document.documentElement.style.setProperty("--bg-color-blue", derived.bgColor);
        document.documentElement.style.setProperty("--accentLightTint-blue", derived.bgTintColor);
        document.documentElement.style.setProperty("--darkerColor-blue", derived.accentDarkColor);
        document.documentElement.style.setProperty("--darkColor-blue", derived.accentColor);
        document.documentElement.style.setProperty("--textColorDark-blue", derived.textDarkColor);
        document.documentElement.style.setProperty("--whitishColor-blue", derived.whitishColor);
        document.documentElement.style.setProperty("--shadow-base-color", derived.accentColor);
        _saveThemeVarsCache();

        colorPickerLabel.style.borderColor = "";

        window._circleOrderFixed = true;
        document.documentElement.style.setProperty("--dual-color-1", derived.bgTintColor);
        document.documentElement.style.setProperty("--dual-color-2", derived.accentColor);
        document.documentElement.style.setProperty("--btn-half-1-color", derived.bgTintColor);
        document.documentElement.style.setProperty("--btn-half-2-color", derived.accentColor);

        const largeCircle = document.getElementById("dualColorLargeCircle");
        if (largeCircle) {
            largeCircle.style.removeProperty("background");
            largeCircle.style.setProperty("--lc-left-color", derived.bgTintColor);
            largeCircle.style.setProperty("--lc-right-color", derived.accentColor);
        }

        const trigBtn = document.getElementById("dualColorTriggerBtn");
        if (trigBtn) trigBtn.classList.remove("dualActive");

        const customSwapBtn = document.getElementById("customSwapBtn");
        if (customSwapBtn) {
            customSwapBtn.style.display = "none";
            customSwapBtn.classList.remove("dualSwapActive");
        }

        const dualSwapBtn = document.getElementById("dualSwapBtn");
        if (dualSwapBtn) dualSwapBtn.style.display = "none";

        changeFaviconColor(derived.accentColor);
        ApplyLoadingColor();

        setTimeout(() => {
            if (typeof renderSavedColors === "function") renderSavedColors();
            document.dispatchEvent(new CustomEvent("theme-colors-changed"));
        }, 30);
        return;
    }

    if (safeColor) localStorage.setItem(customThemeStorageKey, safeColor);
    localStorage.removeItem(customSwapKey);

    const source = _getSafePresetSourceVars(themeName);
    const mapVisual = (value, fallback) => {
        const resolved = _resolveColor(value || "") || fallback;
        return isDarkMode ? _filterInvertHueRotate(resolved) : resolved;
    };

    const bgColor = mapVisual(source.bg, "#bbd6fd");
    const bgTintColor = mapVisual(source.tint, "#e2eeff");
    const accentDarkColor = mapVisual(source.darker, "#3569b2");
    const accentColor = mapVisual(source.dark, "#4382ec");
    const textDarkColor = mapVisual(source.text, "#1b3041");
    const whitishColor = mapVisual(source.white, "#ffffff");

    document.body.setAttribute("data-custom-theme", "active");
    document.body.removeAttribute("data-dual-theme");

    document.documentElement.style.setProperty("--bg-color-blue", bgColor);
    document.documentElement.style.setProperty("--accentLightTint-blue", bgTintColor);
    document.documentElement.style.setProperty("--darkerColor-blue", accentDarkColor);
    document.documentElement.style.setProperty("--darkColor-blue", accentColor);
    document.documentElement.style.setProperty("--textColorDark-blue", textDarkColor);
    document.documentElement.style.setProperty("--whitishColor-blue", whitishColor);
    document.documentElement.style.setProperty("--shadow-base-color", accentColor);
    _saveThemeVarsCache();

    colorPickerLabel.style.borderColor = "";

    window._circleOrderFixed = true;
    document.documentElement.style.setProperty("--dual-color-1", bgTintColor);
    document.documentElement.style.setProperty("--dual-color-2", accentColor);
    document.documentElement.style.setProperty("--btn-half-1-color", bgTintColor);
    document.documentElement.style.setProperty("--btn-half-2-color", accentColor);

    const largeCircle = document.getElementById("dualColorLargeCircle");
    if (largeCircle) {
        largeCircle.style.removeProperty("background");
        largeCircle.style.setProperty("--lc-left-color", bgTintColor);
        largeCircle.style.setProperty("--lc-right-color", accentColor);
    }

    const trigBtn = document.getElementById("dualColorTriggerBtn");
    if (trigBtn) trigBtn.classList.remove("dualActive");

    const customSwapBtn = document.getElementById("customSwapBtn");
    if (customSwapBtn) {
        customSwapBtn.style.display = "none";
        customSwapBtn.classList.remove("dualSwapActive");
    }

    const dualSwapBtn = document.getElementById("dualSwapBtn");
    if (dualSwapBtn) dualSwapBtn.style.display = "none";

    changeFaviconColor(accentColor);
    ApplyLoadingColor();

    setTimeout(() => {
        if (typeof renderSavedColors === "function") renderSavedColors();
        document.dispatchEvent(new CustomEvent("theme-colors-changed"));
    }, 30);
}

function applySafePresetTheme(themeName, _overrideWasFilterDark) {
    _atomicThemeSwitch(() => _applySafePresetThemeCore(themeName), _overrideWasFilterDark);
}

// Cache prefers-color-scheme media query once (tiny perf win, especially on mobile).
const _MQL_PREFERS_DARK = (typeof window !== "undefined" && window.matchMedia)
    ? window.matchMedia("(prefers-color-scheme: dark)")
    : { matches: false };

// ── Theme-switch animation helpers ──────────────────────────────────────────
//
// PROBLEM: The CSS dark mode works via filter:invert(1) hue-rotate(180deg) on <html>.
// CSS vars hold LIGHT values; the filter makes them look dark visually.
//
// When switching between filter-dark ↔ custom/dual-dark, the CSS transition
// animates from the RAW light values (not the visual dark appearance), causing:
//   A) predefined-dark → custom-dark: no-flash but NO animation (v23 snap fix)
//   B) custom-dark → predefined-dark: light-mode flash during transition
//
// SOLUTION: compute the VISUAL equivalent of current vars under the filter,
// use those as the animation START point, then animate to the target.
// This gives a smooth DARK→DARK animation with zero light-mode flash.

const _THEME_VARS = [
    "--bg-color-blue", "--accentLightTint-blue", "--darkColor-blue",
    "--darkerColor-blue", "--textColorDark-blue", "--whitishColor-blue",
    "--shadow-base-color"
];

// Apply CSS filter:invert(1) hue-rotate(180deg) to a hex color in JS.
//
// IMPORTANT: CSS hue-rotate does NOT use HSL rotation. It uses the W3C color matrix:
//   https://www.w3.org/TR/filter-effects/#feColorMatrixElement (type="hueRotate")
//
// For hue-rotate(180deg): cos(180°)=-1, sin(180°)=0
// Matrix (applied in LINEAR sRGB [0,1] space):
//   R' = clamp(-0.574*R + 1.430*G + 0.144*B)
//   G' = clamp( 0.426*R + 0.430*G + 0.144*B)
//   B' = clamp( 0.426*R + 1.430*G - 0.856*B)
//
// Using the correct matrix (not HSL) eliminates the residual mismatched frame that
// caused a visible flash on Case B transitions for saturated custom/dual colors.
function _filterInvertHueRotate(color) {
    // ── Parse input: supports #rrggbb, #rgb, and rgb()/rgba() formats ──
    // Chrome returns rgb() from getComputedStyle for @property <color> vars, not hex.
    color = (color || "").trim();
    let r, g, b;
    if (color.startsWith("rgb")) {
        const m = color.match(/(-?[\d.]+)/g);
        if (!m || m.length < 3) return "#808080";
        r = Math.max(0, Math.min(255, Math.round(parseFloat(m[0]))));
        g = Math.max(0, Math.min(255, Math.round(parseFloat(m[1]))));
        b = Math.max(0, Math.min(255, Math.round(parseFloat(m[2]))));
    } else {
        let hex = color.replace("#", "").replace(/\s/g, "");
        if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
        if (hex.length !== 6) return "#808080";
        r = parseInt(hex.slice(0, 2), 16);
        g = parseInt(hex.slice(2, 4), 16);
        b = parseInt(hex.slice(4, 6), 16);
    }

    // Step 1: invert(1) — maps each channel: c' = 255 - c
    r = 255 - r;
    g = 255 - g;
    b = 255 - b;

    // Step 2: hue-rotate(180deg) using the W3C CSS color matrix (NOT HSL rotation).
    // Normalize to [0,1], apply matrix, clamp, return to [0,255].
    const rn = r / 255, gn = g / 255, bn = b / 255;
    const clamp01 = v => Math.max(0, Math.min(1, v));
    const r2 = clamp01(-0.5740 * rn + 1.4300 * gn + 0.1440 * bn);
    const g2 = clamp01( 0.4260 * rn + 0.4300 * gn + 0.1440 * bn);
    const b2 = clamp01( 0.4260 * rn + 1.4300 * gn - 0.8560 * bn);

    const hex2 = v => Math.round(v * 255).toString(16).padStart(2, "0");
    return "#" + hex2(r2) + hex2(g2) + hex2(b2);
}

function _isFilterDarkActive() {
    const preferredTheme = localStorage.getItem("preferredTheme") || "light";
    const systemIsDark = !!_MQL_PREFERS_DARK.matches;
    const modeIsDark = preferredTheme === "dark" || (preferredTheme === "system" && systemIsDark);
    const customOverride = document.body.getAttribute("data-custom-theme") === "active"
                        || document.body.getAttribute("data-dual-theme") === "active";
    return modeIsDark && !customOverride;
}

// ── Animation helpers ────────────────────────────────────────────────────────
// Returns the effective CSS transition duration in ms, respecting --ui-anim-mult.
// Reads from documentElement (html) because that is where applyAnimMult() sets the value.

// Stores the cancel fn of any in-flight Case B animation so that a new theme
// switch can cleanly abort the old one before starting fresh.
let _pendingAnimCancel = null;

// Monotonic token shared by ALL theme-apply paths (applySelectedTheme, _applyCustomThemeCore).
// Incrementing before any apply invalidates deferred rAF callbacks from ANY prior apply,
// preventing stale rAFs (e.g. from a previous color-picker drag) from overwriting the
// correct new-theme colors on the large circle or trigger-button halves.
let _themeSeq = 0;
// Exposed so dual-color.js can bump the counter when applying/clearing a dual theme,
// which invalidates any pending rAFs from applySelectedTheme or _applyCustomThemeCore.
window._bumpThemeSeq = function() { return ++_themeSeq; };

function _cancelPendingAnim() {
    if (_pendingAnimCancel) {
        _pendingAnimCancel();
        _pendingAnimCancel = null;
    }
}

// Called before ANY theme switch that might cross the filter boundary.
//
// Six cases handled:
//   A) light → light                         : applyFn() directly, CSS transitions animate ✓
//   B) custom/dual-dark → predefined-dark    : snap to light-equivalents, restore filter, animate ✓
//   C) predefined-dark → predefined-dark     : animate raw vars UNDER filter (dark→dark) ✓
//   D) predefined-dark → custom/dual-dark    : visual-dark start, animate to new dark vars ✓
//   E) custom/dual-dark → custom/dual-dark   : dark→dark without filter dance ✓
//   F) predefined-light ↔ predefined-dark    : handled via pre-switch wasFilterDark param ✓
//
// Optional second arg _overrideWasFilterDark: pass the pre-switch filter state when the
// caller has already mutated localStorage/DOM before calling us (e.g. applyThemeMode).
function _smoothThemeSwitch(applyFn, _overrideWasFilterDark) {
    // Cancel any in-flight animation so rapid clicks never stack concurrent animations.
    _cancelPendingAnim();

    const root = document.documentElement;

    // Theme color changes touch many CSS variables at once. Animating those vars makes
    // rapid theme switching heavy, so apply theme colors atomically and restore normal UI
    // transitions on the next frame. Other element animations continue outside this window.
    if (!root.classList.contains("dark-preload")) {
        root.classList.add("no-theme-transition");
        root.classList.remove("anim-suppress-filter");
        applyFn();
        requestAnimationFrame(() => {
            root.classList.remove("no-theme-transition");
            document.dispatchEvent(new CustomEvent("theme-colors-changed"));
        });
        return;
    }

    // ── Page-init guard ────────────────────────────────────────────────────────
    // During page initialization, preload.js adds "dark-preload" to <html> which
    // applies filter:invert immediately from the very first paint.
    // If we proceed with the normal _smoothThemeSwitch machinery here, it adds
    // "anim-suppress-filter" (filter:none !important) — this OVERRIDES dark-preload
    // and causes a light flash when LoadingScreen is hidden (one frame without filter).
    // Fix: while dark-preload is present (i.e., we are still in the init phase before
    // DOMContentLoaded removes it via double-rAF), just apply the theme directly.
    // dark-preload already guarantees the page looks dark — no animation is needed.
    if (root.classList.contains("dark-preload")) {
        applyFn();
        return;
    }

    const wasFilterDark = (_overrideWasFilterDark !== undefined)
        ? _overrideWasFilterDark
        : _isFilterDarkActive();

    // === Case A/B: not currently in filter-dark ===
    if (!wasFilterDark) {
        const preferredTheme = localStorage.getItem("preferredTheme") || "light";
        const systemIsDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        const modeIsDark = preferredTheme === "dark" || (preferredTheme === "system" && systemIsDark);

        if (modeIsDark) {
            // Dark mode: filter is currently OFF (custom/dual-dark).
            // We must preemptively suppress the filter BEFORE running applyFn, because
            // applyFn removes data-dual-theme / data-custom-theme from body, which
            // immediately activates the CSS :has(…) filter:invert rule.  At that instant
            // the CSS vars are still the OLD dark values → invert(dark) = BRIGHT FLASH.
            //
            // By adding anim-suppress-filter first, filter:invert is blocked for the
            // entire duration of applyFn (and the subsequent animation), so the browser
            // never gets a chance to render that intermediate light frame.
            //
            // After applyFn we check whether the filter ended up ON (Case B) or OFF (Case E)
            // and remove / keep anim-suppress-filter accordingly.

            // 1. Capture current dark vars (animation start)
            const cs = getComputedStyle(root);
            const startColors = {};
            _THEME_VARS.forEach(v => { startColors[v] = (cs.getPropertyValue(v) || "").trim(); });

            // 2. Preemptively suppress filter so applyFn cannot cause a flash frame
            root.classList.add("anim-suppress-filter");

            // 3. Apply new theme silently (transitions still off via no-theme-transition)
            root.classList.add("no-theme-transition");
            applyFn();

            // 4. Check: did applyFn turn the filter ON (→ predefined-dark) or leave it OFF (→ dual/custom-dark)?
            const isNowFilterDark = _isFilterDarkActive();

            // 5. Capture vars set by applyFn — always resolve through getComputedStyle
            // to get real hex values, not var() references (which CSS cannot interpolate).
            const endVars = {};
            _THEME_VARS.forEach(v => {
                endVars[v] = getComputedStyle(root).getPropertyValue(v).trim() ||
                             root.style.getPropertyValue(v).trim();
            });

            if (!isNowFilterDark) {
                // === Case E: dual/custom-dark → dual/custom-dark ===
                // Filter stays OFF. Remove the preemptive suppress before animating.
                // endVars are already the correct dark values.
                // Animate startColors → endVars directly — pure dark→dark. ✓
                _THEME_VARS.forEach(v => root.style.setProperty(v, startColors[v]));
                let _caseE_cancelled = false;
                _pendingAnimCancel = function() {
                    _caseE_cancelled = true;
                    root.classList.remove("anim-suppress-filter");
                    root.classList.remove("no-theme-transition");
                };
                requestAnimationFrame(() => {
                    if (_caseE_cancelled) return;
                    root.classList.remove("anim-suppress-filter"); // safe to remove — filter stays OFF
                    root.classList.remove("no-theme-transition");
                    requestAnimationFrame(() => {
                        if (_caseE_cancelled) return;
                        _THEME_VARS.forEach(v => root.style.setProperty(v, endVars[v]));
                    });
                });
            } else {
                // === Case B: custom/dual-dark → predefined-dark — SMOOTH ANIMATION ===
                //
                // Now that _filterInvertHueRotate uses the correct W3C CSS color matrix
                // (not HSL), it produces pixel-perfect equivalents for ALL colors including
                // saturated custom/dual themes. This enables a true dark→dark animation:
                //
                //   startLight = _filterInvertHueRotate(startColors)
                //     → under filter:invert+hue-rotate these light values look EXACTLY
                //       like the old dark theme. Zero visible difference. ✓
                //
                // ATOMIC sequence (no rAF between sync lines → ONE paint frame):
                //   1. [sync] setProperty(startLight)         ─┐ batched by browser
                //   2. [sync] remove(anim-suppress-filter)    ─┘ → filter ON, looks like old dark ✓
                //      no-theme-transition still ON → no premature CSS transitions
                //   3. rAF: remove(no-theme-transition)       → transitions live
                //   4. rAF: setProperty(endVars)              → CSS transitions: startLight → endVars
                //      Both values are light (under filter = dark). Smooth dark→dark. ✓
                //
                const startLight = {};
                _THEME_VARS.forEach(v => {
                    startLight[v] = _filterInvertHueRotate(startColors[v]);
                });

                // ATOMIC: both lines in same JS task → browser paints exactly once
                _THEME_VARS.forEach(v => root.style.setProperty(v, startLight[v]));
                root.classList.remove("anim-suppress-filter"); // filter ON → startLight = old dark ✓
                // no-theme-transition still ON → no premature transitions yet

                let _caseB_cancelled = false;
                _pendingAnimCancel = function() {
                    _caseB_cancelled = true;
                    root.classList.remove("no-theme-transition");
                };
                requestAnimationFrame(() => {
                    if (_caseB_cancelled) return;
                    root.classList.remove("no-theme-transition"); // transitions live
                    requestAnimationFrame(() => {
                        if (_caseB_cancelled) return;
                        // CSS transitions: startLight → endVars, both under filter = dark→dark ✓
                        _THEME_VARS.forEach(v => root.style.setProperty(v, endVars[v]));
                    });
                });
            }
        } else {
            // Case A: light mode — CSS transitions handle everything naturally
            applyFn();
        }
        return;
    }

    // === wasFilterDark = true: currently in predefined-dark (filter:invert active) ===

    // Capture current raw light var values (before applyFn touches anything)
    const cs = getComputedStyle(root);
    const startRawColors = {};
    _THEME_VARS.forEach(v => { startRawColors[v] = (cs.getPropertyValue(v) || "").trim(); });

    // Suppress filter BEFORE applyFn to prevent a flash frame where the browser renders
    // (data-dual-theme=active with old light CSS vars) between attribute change and var update.
    // anim-suppress-filter is safe here: _isFilterDarkActive() does not read it.
    root.classList.add("anim-suppress-filter");

    // Apply new theme with transitions off
    root.classList.add("no-theme-transition");
    applyFn();

    const isStillFilterDark = _isFilterDarkActive();

    if (isStillFilterDark) {
        // === Case C: predefined-dark → predefined-dark ===
        // Filter stays on throughout. Animate raw light vars old → new.
        // Since filter:invert+hueRotate is always applied: user sees dark→dark. ✓

        // IMPORTANT: always use getComputedStyle to resolve var() chain to real hex.
        // root.style may contain "var(--bg-color-red)" which CSS cannot interpolate.
        const endColors = {};
        _THEME_VARS.forEach(v => {
            endColors[v] = getComputedStyle(root).getPropertyValue(v).trim() ||
                           root.style.getPropertyValue(v).trim();
        });

        // Snap vars back to old raw values (invisible: filter stays on)
        _THEME_VARS.forEach(v => root.style.setProperty(v, startRawColors[v]));

        let _caseC_cancelled = false;
        _pendingAnimCancel = function() {
            _caseC_cancelled = true;
            root.classList.remove("anim-suppress-filter");
            root.classList.remove("no-theme-transition");
        };
        requestAnimationFrame(() => {
            if (_caseC_cancelled) return;
            // Case C: filter stays ON — remove the temporary suppress so filter is active again
            root.classList.remove("anim-suppress-filter");
            root.classList.remove("no-theme-transition");
            requestAnimationFrame(() => {
                if (_caseC_cancelled) return;
                _THEME_VARS.forEach(v => root.style.setProperty(v, endColors[v]));
            });
        });
    } else {
        // === Case D: predefined-dark → custom/dual-dark ===
        // Filter is now OFF. Animate from visual-dark-start → new dark vars. ✓

        const visualStartColors = {};
        _THEME_VARS.forEach(v => {
            visualStartColors[v] = _filterInvertHueRotate(startRawColors[v]);
        });

        const endColors = {};
        _THEME_VARS.forEach(v => {
            // getComputedStyle resolves var() chains to real hex — needed for CSS transition
            endColors[v] = getComputedStyle(root).getPropertyValue(v).trim() ||
                           root.style.getPropertyValue(v).trim();
        });

        _THEME_VARS.forEach(v => root.style.setProperty(v, visualStartColors[v]));

        // Case D: filter is now OFF (data-dual/custom active). anim-suppress-filter
        // was added before applyFn to prevent flash — keep it off for the animation
        // since we are now in custom/dual mode (filter should stay off permanently).
        let _caseD_cancelled = false;
        _pendingAnimCancel = function() {
            _caseD_cancelled = true;
            root.classList.remove("anim-suppress-filter");
            root.classList.remove("no-theme-transition");
        };
        requestAnimationFrame(() => {
            if (_caseD_cancelled) return;
            root.classList.remove("anim-suppress-filter");
            root.classList.remove("no-theme-transition");
            requestAnimationFrame(() => {
                if (_caseD_cancelled) return;
                _THEME_VARS.forEach(v => root.style.setProperty(v, endColors[v]));
            });
        });
    }
}

// Alias kept for dual-color.js compatibility
function _atomicThemeSwitch(applyFn, _overrideWasFilterDark) { _smoothThemeSwitch(applyFn, _overrideWasFilterDark); }
// Export filter-dark checker and smooth switch so other scripts can integrate
window._isFilterDarkActive = _isFilterDarkActive;
// ────────────────────────────────────────────────────────────────────────────

// MediaQuery for system theme detection
const systemTheme = window.matchMedia('(prefers-color-scheme: dark)');

const syncThemeChange = (MediaQuery) => {
    document.body.setAttribute("sysTheme", MediaQuery.matches ? "systemDark" : "systemLight");
}

function ensureThemeBackgroundMode() {
    if (!document.body.getAttribute("data-bg")) {
        document.body.setAttribute("data-bg", "color");
    }
}

// Initialize system theme attribute immediately
ensureThemeBackgroundMode();
syncThemeChange(systemTheme);

// ===== Segmented Control for Dark Mode =====
(function () {
    const preferredThemeKey = "preferredTheme";
    const segment = document.getElementById("themeSegment");
    const indicator = segment.querySelector(".themeIndicator");
    const buttons = segment.querySelectorAll(".themeSegBtn");

    // Move indicator to correct position
    function moveIndicator(theme) {
        const ltrIndex = theme === "light" ? 0 : theme === "dark" ? 1 : 2;
        const index = getComputedStyle(segment).direction === "rtl" ? 2 - ltrIndex : ltrIndex;
        indicator.style.transform = `translateX(${index * 100}%)`;
    }

    // Helper: is the black (dark) color plate selected?

    // Apply theme mode (light/dark/system)
    function applyThemeMode(theme) {
        // Capture the CURRENT filter-dark state BEFORE mutating localStorage/DOM.
        // applyThemeMode sets localStorage first, so _isFilterDarkActive() inside
        // _smoothThemeSwitch would read the NEW state — causing Cases B/D to fire
        // incorrectly and skip the light↔dark animation. Passing the pre-switch
        // value lets _smoothThemeSwitch determine the real transition direction.
        const _preSwitchWasFilterDark = _isFilterDarkActive();

        localStorage.setItem(preferredThemeKey, theme);
        segment.dataset.active = theme;
        ensureThemeBackgroundMode();
        // Mirror the segment's selected mode onto <html data-pref> so theme-aware CSS
        // can match via a cheap attribute selector instead of a global :has() lookup
        // (the old html:has(.themeSegment[data-active="..."]) selectors caused multi-second
        // style recalcs and non-deterministic first-run rendering). sysTheme stays on <body>.
        document.documentElement.setAttribute("data-pref", theme);
        moveIndicator(theme);

        // Black circle now uses CSS filter like all other colors — no special class needed
        if (theme === "system") {
            syncThemeChange(systemTheme);
        }

        // Re-apply theme immediately so mode change is instant
        // Use typeof guards to handle calls before const-hoisted functions are initialized
        const dualStored = localStorage.getItem("dualColorTheme");
        if (dualStored) {
            if (window.dualColorTheme) {
                // Wrap in _smoothThemeSwitch so no-theme-transition is active while
                // _applyDualGradientCore runs — enabling the double-rAF animation on
                // the large circle and trigger button halves. Without this wrapper,
                // _suppressedNow = false → colors snap instead of animating.
                _smoothThemeSwitch(function() {
                    window.dualColorTheme.loadStoredDualColor();
                }, _preSwitchWasFilterDark);
            } else {
                // dualColorTheme not ready yet — retry after DOM is loaded
                document.addEventListener("DOMContentLoaded", function _retryDual() {
                    if (window.dualColorTheme) window.dualColorTheme.loadStoredDualColor();
                    document.removeEventListener("DOMContentLoaded", _retryDual);
                }, { once: true });
            }
        } else {
            const safePresetTheme = localStorage.getItem(safePresetThemeStorageKey);
            if (safePresetTheme) {
                applySafePresetTheme(safePresetTheme, _preSwitchWasFilterDark);
                if (typeof renderSavedColors === "function") renderSavedColors();
                return;
            }

            const customColor = localStorage.getItem(customThemeStorageKey);
            if (customColor) {
                applyCustomTheme(customColor);
            } else {
                // Re-apply predefined theme so it responds to mode changes
                // Wrapped in _smoothThemeSwitch to prevent white flash when
                // switching Light/Dark/System then clicking a color plate.
                const predefinedTheme = localStorage.getItem(themeStorageKey);
                if (predefinedTheme) {
                    _smoothThemeSwitch(() => applySelectedTheme(predefinedTheme), _preSwitchWasFilterDark);
                } else {
                    // No theme stored yet (first install) — still animate Light ↔ Dark
                    // so filter:invert doesn't snap instantly.
                    const _checked = document.querySelector(".colorPlate:checked");
                    const _defaultTheme = (_checked && _checked.value) ? _checked.value : "blue";
                    if (isSafePresetTheme(_defaultTheme)) {
                        localStorage.setItem(safePresetThemeStorageKey, _defaultTheme);
                        localStorage.removeItem(themeStorageKey);
                        localStorage.removeItem("dualColorTheme");
                        localStorage.removeItem("dualColorSwapped");
                        applySafePresetTheme(_defaultTheme, _preSwitchWasFilterDark);
                        setCheckedThemePlate(_defaultTheme);
                    } else {
                        _smoothThemeSwitch(() => applySelectedTheme(_defaultTheme), _preSwitchWasFilterDark);
                    }
                }
            }
        }
        // Always re-render saved color dots so they reflect the new mode
        if (typeof renderSavedColors === "function") renderSavedColors();
    }

    // Button click handlers
    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            applyThemeMode(btn.dataset.theme);
        });
    });

    // System theme change listener
    systemTheme.addEventListener('change', (mq) => {
        syncThemeChange(mq);
        // Only re-apply colors if the user has chosen "system" mode
        const currentPref = localStorage.getItem("preferredTheme");
        if (currentPref === "system") {
            // Re-apply current theme with new OS mode so dual/custom colors update
            const dualStored = localStorage.getItem("dualColorTheme");
            if (dualStored && window.dualColorTheme) {
                window.dualColorTheme.loadStoredDualColor();
            } else {
                const safePresetTheme = localStorage.getItem(safePresetThemeStorageKey);
                if (safePresetTheme) {
                    applySafePresetTheme(safePresetTheme);
                    if (typeof renderSavedColors === "function") renderSavedColors();
                    return;
                }

                const customColor = localStorage.getItem(customThemeStorageKey);
                if (customColor) {
                    applyCustomTheme(customColor);
                } else {
                    const predefinedTheme = localStorage.getItem(themeStorageKey);
                    if (predefinedTheme) {
                        _smoothThemeSwitch(() => applySelectedTheme(predefinedTheme));
                    }
                }
            }
            if (typeof renderSavedColors === "function") renderSavedColors();
        }
    });

    function initializeThemeMode() {
        const darkModeCheckboxState = localStorage.getItem(darkModeCheckboxKey);
        const savedPreferredTheme = localStorage.getItem(preferredThemeKey);

        let initialTheme;

        if (darkModeCheckboxState === "checked") {
            // Migrate old checkbox users to "dark" mode
            initialTheme = "dark";
            localStorage.removeItem(darkModeCheckboxKey);
            localStorage.setItem(preferredThemeKey, "dark");
        } else if (savedPreferredTheme) {
            initialTheme = savedPreferredTheme; // Use saved preference
        } else {
            initialTheme = "light"; // First time user
        }

        applyThemeMode(initialTheme);
    }

    // Initialize
    initializeThemeMode();
    // NOTE: dark-preload and preload-theme-vars are cleaned up AFTER DOMContentLoaded
    // applies the real theme — see the DOMContentLoaded handler below.
    // Expose globally so other scripts can force a mode switch
    window.setThemeMode = applyThemeMode;
})();

document.addEventListener("DOMContentLoaded", () => {
    ensureThemeBackgroundMode();

    // ── Remove anim-suppress-filter BEFORE hiding the LoadingScreen ──────────────
    // During page init, initializeThemeMode() (called from the IIFE in theme.js as a
    // deferred script) invokes _smoothThemeSwitch which adds anim-suppress-filter
    // (filter:none !important) and schedules a rAF to remove it.
    // Problem: DOMContentLoaded hides the LoadingScreen in the SAME JS task, causing
    // the browser to render one frame where LoadingScreen is gone BUT anim-suppress-filter
    // is still active — filter:invert is suppressed, page flashes LIGHT for one frame.
    // Fix: remove both classes synchronously at the very start of DOMContentLoaded so
    // the real :has() dark-mode filter is already active when the loading screen hides.
    document.documentElement.classList.remove("anim-suppress-filter");
    document.documentElement.classList.remove("no-theme-transition");

    // Determine which theme takes priority:
    // predefined radio > custom single color > dual color (gradient)
    // (predefined/custom clear dualColorTheme in their handlers, so if both exist = stale dual)
    const storedTheme = localStorage.getItem(themeStorageKey);
    const storedCustomColor = localStorage.getItem(customThemeStorageKey);
    const currentSafePresetTheme = normalizeThemePlateValue(localStorage.getItem(safePresetThemeStorageKey));
    const storedDual = localStorage.getItem("dualColorTheme");

    if (currentSafePresetTheme) {
        localStorage.removeItem(themeStorageKey);
        applySafePresetTheme(currentSafePresetTheme);
        setCheckedThemePlate(currentSafePresetTheme);
    } else if (storedTheme) {
        // Predefined theme wins — clear any stale dual/custom
        applySelectedTheme(storedTheme);
        const selectedRadioButton = document.querySelector(`.colorPlate[value="${storedTheme}"]`);
        if (selectedRadioButton) selectedRadioButton.checked = true;
    } else if (storedCustomColor) {
        // Custom single-color theme — clear any stale dual theme from localStorage
        localStorage.removeItem("dualColorTheme");
        localStorage.removeItem("dualColorSwapped");
        applyCustomTheme(storedCustomColor);
        radioButtons.forEach(radio => { radio.checked = false; });
    } else if (storedDual) {
        // Dual gradient theme — dual-color.js handles it via loadStoredDualColor()
        radioButtons.forEach(radio => { radio.checked = false; });
    }

    // Custom swap button — toggle palette between light/dark for pick-color themes
    // ── RAF state for custom-swap animation ────────────────────────────────
    // Mirrors the dual-color swap mechanism: cancel any in-flight RAF before
    // No RAF state needed — CSS @property transitions handle the large circle animation.
    window._customSwapAnimRunning = false;

    const customSwapBtnEl = document.getElementById("customSwapBtn");
    if (customSwapBtnEl) {
        customSwapBtnEl.addEventListener("click", () => {
            const currentColor = localStorage.getItem(customThemeStorageKey);
            if (!currentColor) return;

            // Toggle swap state.
            const wasSwapped = localStorage.getItem(customSwapKey) === "1";
            localStorage.setItem(customSwapKey, wasSwapped ? "0" : "1");

            // If custom color picker is open in single mode, sync its view to show updated swapped theme colors
            if (window.customColorPickerModal && 
                typeof window.customColorPickerModal.isOpen === "function" && 
                window.customColorPickerModal.isOpen() && 
                typeof window.customColorPickerModal.getMode === "function" && 
                window.customColorPickerModal.getMode() === "single" &&
                typeof window.customColorPickerModal.syncSingleColor === "function") {
                window.customColorPickerModal.syncSingleColor();
            }

            // Call core directly — bypasses _atomicThemeSwitch/_smoothThemeSwitch which
            // adds no-theme-transition (transition:none!important), which would suppress
            // the CSS @property transition on --lc-left-color/--lc-right-color.
            // Without no-theme-transition, the large circle's two halves animate smoothly.
            // Theme color transitions are intentionally suppressed inside applyCustomTheme().
            _applyCustomThemeCore(currentColor);
            if (typeof renderSavedColors === "function") renderSavedColors();
        });
    }

    // Remove Loading Screen when the DOM and the theme has loaded
    document.getElementById("LoadingScreen").style.display = "none";

    // ── Remove FOUC-prevention preload now that the real theme is fully applied ──
    // Two rAFs: first commits the real theme vars to the renderer,
    // second removes the preload overrides so there is zero gap between
    // "real vars live" and "preload vars gone".
    requestAnimationFrame(function() {
        requestAnimationFrame(function() {
            document.documentElement.classList.remove("dark-preload");
            var preloadStyle = document.getElementById("preload-theme-vars");
            if (preloadStyle) preloadStyle.remove();
        });
    });

    // Stop blinking of some elements when the page is reloaded
    setTimeout(() => {
        document.documentElement.classList.add("theme-transition");
    }, 25);
});

// Function to load background color 
function ApplyLoadingColor() {
    // Save the raw computed background color.
    // For predefined dark themes, the filter:invert on <html> is a page-level CSS effect —
    // preload.js sets --Loading-Screen-Color to this raw value, then dark-preload applies
    // filter:invert on the whole page, making the loading screen appear dark automatically.
    // Do NOT pre-invert here: that would cause double-inversion (light flash) on next load.
    let LoadingScreenColor = getComputedStyle(document.body).getPropertyValue("background-color");
    localStorage.setItem("LoadingScreenColor", LoadingScreenColor);
}

function resetDarkTheme() {
    // Remove the dark theme class
    document.documentElement.classList.remove("black-theme");
    document.body.removeAttribute("data-dual-theme");
    document.body.removeAttribute("data-dual-theme");
    document.body.removeAttribute("data-custom-theme");

    // Reset inline styles that were applied specifically for dark mode
    const resetElements = ["searchQ", "searchIconDark", "darkFeelsLikeIcon", "menuButton", "menuCloseButton", "closeBtnX"];

    resetElements.forEach((id) => {
        const element = document.getElementById(id);
        if (element) {
            element.removeAttribute("style");
        }
    });

    // Reset fill color for elements with the class "accentColor"
    const accentElements = document.querySelectorAll(".accentColor");
    accentElements.forEach((element) => {
        element.style.fill = ""; // Reset fill color
    });

    // Reset the dual color button.
    // IMPORTANT: do NOT removeProperty — that would flash to @property initial-value.
    // Instead freeze the current COMPUTED colors so the next applyCustomTheme can
    // transition FROM them smoothly. getComputedStyle resolves var() chains to real hex.
    const _cs = getComputedStyle(document.documentElement);
    const _cur1 = _cs.getPropertyValue("--btn-half-1-color").trim() ||
                  _cs.getPropertyValue("--accentLightTint-blue").trim();
    const _cur2 = _cs.getPropertyValue("--btn-half-2-color").trim() ||
                  _cs.getPropertyValue("--darkColor-blue").trim();
    if (_cur1) document.documentElement.style.setProperty("--btn-half-1-color", _cur1);
    if (_cur2) document.documentElement.style.setProperty("--btn-half-2-color", _cur2);

    const trigBtn = document.getElementById("dualColorTriggerBtn");
    if (trigBtn) {
        trigBtn.classList.remove("dualActive");
    }
};

// Function to apply the selected theme

// Helper: resolve a CSS variable reference to its computed hex/rgb value.
// This is needed so @property typed vars receive real color values (not var()),
// enabling CSS to interpolate them as colors during theme transitions.
function _resolveColor(varRef, _depth) {
    if (!varRef || !varRef.trim().startsWith("var(")) return varRef;
    // Guard against circular / deeply-chained var() references (shouldn't happen in
    // practice but protects against infinite recursion if CSS is unusual).
    if ((_depth || 0) > 5) return varRef;
    const match = varRef.match(/var\((--[\w-]+)\)/);
    if (!match) return varRef;
    const resolved = getComputedStyle(document.documentElement)
        .getPropertyValue(match[1]).trim();
    // BUG FIX: the original code stopped here and could return an unresolved var()
    // string if `resolved` itself started with "var(". @property typed vars with
    // syntax:"<color>" silently revert to initial-value when given a var() string
    // they cannot parse — causing the Big Circle to show the wrong (stale) color.
    // We now recurse until we have a concrete hex/rgb value or exhaust the depth limit.
    if (!resolved) return varRef;
    return resolved.startsWith("var(")
        ? _resolveColor(resolved, (_depth || 0) + 1)
        : resolved;
}

function _setThemeVar(prop, value) {
    document.documentElement.style.setProperty(prop, _resolveColor(value));
}


// ── Persist computed theme vars for FOUC-free preload on next page open ──────
function _saveThemeVarsCache() {
    try {
        var root = document.documentElement;
        var get = function(v) { return root.style.getPropertyValue(v).trim(); };
        var cache = {
            bg:      get("--bg-color-blue"),
            tint:    get("--accentLightTint-blue"),
            dark:    get("--darkColor-blue"),
            darker:  get("--darkerColor-blue"),
            text:    get("--textColorDark-blue"),
            white:   get("--whitishColor-blue"),
        };
        localStorage.setItem("themeVarsCache", JSON.stringify(cache));
    } catch(e) {}
}

function applySelectedTheme(colorValue) {
    colorValue = normalizeThemePlateValue(colorValue);
    const isDarkMode = colorValue === "dark";

    // Reset dark theme if not in dark mode
    if (!isDarkMode) resetDarkTheme();

    // Reset color picker label border when switching to predefined theme
    colorPickerLabel.style.borderColor = "";

    // Set CSS variables based on the selected color theme
    if (colorValue === "blue") {
        document.documentElement.style.setProperty("--bg-color-blue", "#C2D8FB");
        document.documentElement.style.setProperty("--accentLightTint-blue", "#E6F0FF");
        document.documentElement.style.setProperty("--darkerColor-blue", "#1A5FC8");
        document.documentElement.style.setProperty("--darkColor-blue", "#2979E8");
        document.documentElement.style.removeProperty("--textColorDark-blue"); // let CSS dark-mode rule control this
        document.documentElement.style.setProperty("--whitishColor-blue", "#ffffff");
    } else if (colorValue === "teal") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-teal)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-teal)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-teal)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-teal)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-teal)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-teal)");
    } else if (colorValue === "rose") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-rose)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-rose)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-rose)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-rose)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-rose)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-rose)");
    } else if (colorValue === "indigo") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-indigo)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-indigo)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-indigo)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-indigo)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-indigo)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-indigo)");
    } else if (colorValue === "amber") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-amber)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-amber)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-amber)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-amber)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-amber)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-amber)");
    } else if (colorValue === "lime") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-lime)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-lime)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-lime)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-lime)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-lime)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-lime)");
    } else if (colorValue === "olive") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-olive)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-olive)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-olive)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-olive)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-olive)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-olive)");
    } else if (colorValue === "coral") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-coral)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-coral)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-coral)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-coral)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-coral)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-coral)");
    } else if (colorValue === "mint") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-mint)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-mint)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-mint)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-mint)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-mint)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-mint)");
    } else if (colorValue === "gold") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-gold)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-gold)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-gold)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-gold)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-gold)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-gold)");
    } else if (colorValue === "forest") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-forest)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-forest)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-forest)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-forest)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-forest)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-forest)");
    } else if (colorValue === "lavender") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-lavender)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-lavender)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-lavender)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-lavender)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-lavender)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-lavender)");
    } else if (colorValue === "sage") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-sage)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-sage)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-sage)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-sage)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-sage)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-sage)");
    } else if (colorValue === "slate") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-slate)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-slate)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-slate)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-slate)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-slate)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-slate)");
    } else if (colorValue === "copper") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-copper)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-copper)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-copper)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-copper)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-copper)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-copper)");
    } else if (colorValue === "sky") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-sky)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-sky)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-sky)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-sky)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-sky)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-sky)");
    } else if (colorValue === "magenta") {
        _setThemeVar("--bg-color-blue", "var(--bg-color-magenta)");
        _setThemeVar("--accentLightTint-blue", "var(--accentLightTint-magenta)");
        _setThemeVar("--darkerColor-blue", "var(--darkerColor-magenta)");
        _setThemeVar("--darkColor-blue", "var(--darkColor-magenta)");
        _setThemeVar("--textColorDark-blue", "var(--textColorDark-magenta)");
        _setThemeVar("--whitishColor-blue", "var(--whitishColor-magenta)");
    } else {
        const prefix = isDarkMode ? "dark" : colorValue;
        // These vars are registered via @property <color>. Setting them to a raw var(--x)
        // can yield inconsistent computed values during mode-switch animations (and may not
        // interpolate), causing the big half/half circle to lag by one theme. Always write
        // resolved color values.
        _setThemeVar("--bg-color-blue", `var(--bg-color-${prefix})`);
        _setThemeVar("--accentLightTint-blue", `var(--accentLightTint-${prefix})`);
        _setThemeVar("--darkerColor-blue", `var(--darkerColor-${prefix})`);
        _setThemeVar("--darkColor-blue", `var(--darkColor-${prefix})`);
        _setThemeVar("--textColorDark-blue", `var(--textColorDark-${prefix})`);

        if (!isDarkMode) {
            _setThemeVar("--whitishColor-blue", `var(--whitishColor-${colorValue})`);
        }
    }

    // Black circle now uses CSS filter for dark mode like all other colors — no special class
    document.body.removeAttribute("data-custom-theme");

    // Capture a monotonic token for this apply.  Any deferred rAF callbacks that were
    // scheduled by a PREVIOUS call (rapid theme switching, or leftover color-picker rAFs)
    // will no-op when they fire and find that _themeSeq has already advanced past their
    // captured _seq.  This counter is shared with _applyCustomThemeCore so that switching
    // FROM a custom-color theme TO a predefined theme cancels any still-pending custom rAFs.
    const _seq = ++_themeSeq;

    // Update --btn-half-1/2-color with the double-rAF pattern so the @property
    // transition fires AFTER no-theme-transition is removed (mode switch).
    // Set the trigger-button half colors IMMEDIATELY.
    // CSS now allows --btn-half-1/2-color transitions even during no-theme-transition
    // (see html.no-theme-transition exemption in style.css), so we do NOT need the
    // old double-rAF dance.  Setting immediately is simpler, reliable, and immune to
    // rAF-invalidation bugs (e.g. a pending rAF from a previous gradient-theme apply
    // overwriting the correct new predefined color).
    const _root = document.documentElement;
    const _resolvedCs = getComputedStyle(_root);

    // BUG FIX: The old code read --accentLightTint-blue and --darkColor-blue, which are
    // @property <color> animated aliases. During a _smoothThemeSwitch animation these vars
    // are actively INTERPOLATING between old and new values -- reading them now returns the
    // mid-transition color, not the target color. That mid-point value then gets locked
    // into --lc-left-color / --lc-right-color and the Big Circle appears stuck on the
    // previous (or blended) theme colors until the page is refreshed.
    //
    // FIX: read from the STATIC per-theme source variables (--accentLightTint-teal,
    // --darkColor-rose, etc.), which are defined as plain values on :root and never
    // transition. They always hold the exact final color for this theme, regardless
    // of what animation is currently in flight on the -blue aliases.
    //
    // Special case: "blue" stores its values directly into --*-blue via inline style
    // (see the if (colorValue === "blue") block above), so we read from element.style.
    // "dark" reads from --*-dark.
    const _themePrefix = (colorValue === "dark") ? "dark" : colorValue;
    let _newHalf1 = "";
    let _newHalf2 = "";

    if (colorValue === "blue") {
        // Blue theme writes inline styles directly on the element -- reading those bypasses
        // getComputedStyle which returns the currently-animating (mid-transition) value.
        _newHalf1 = _root.style.getPropertyValue("--accentLightTint-blue").trim();
        _newHalf2 = _root.style.getPropertyValue("--darkColor-blue").trim();
    } else {
        // All other predefined themes have static source vars --accentLightTint-{prefix}
        // defined on :root. These never participate in CSS transitions so they always
        // return the correct final target color immediately.
        _newHalf1 = _resolvedCs.getPropertyValue(`--accentLightTint-${_themePrefix}`).trim();
        _newHalf2 = _resolvedCs.getPropertyValue(`--darkColor-${_themePrefix}`).trim();
    }

    // Fallback: if the static source was not found (unknown/future theme name), read the
    // animated alias and force-resolve any var() ref to a concrete hex via _resolveColor.
    if (!_newHalf1) {
        _newHalf1 = _resolvedCs.getPropertyValue("--accentLightTint-blue").trim();
        if (_newHalf1.startsWith("var(")) _newHalf1 = (_resolveColor(_newHalf1) || _newHalf1);
    }
    if (!_newHalf2) {
        _newHalf2 = _resolvedCs.getPropertyValue("--darkColor-blue").trim();
        if (_newHalf2.startsWith("var(")) _newHalf2 = (_resolveColor(_newHalf2) || _newHalf2);
    }
    // Final safety: force-resolve any remaining var() reference.
    if (_newHalf1 && _newHalf1.startsWith("var(")) _newHalf1 = (_resolveColor(_newHalf1) || _newHalf1);
    if (_newHalf2 && _newHalf2.startsWith("var(")) _newHalf2 = (_resolveColor(_newHalf2) || _newHalf2);

    // FIX: store RESOLVED hex values (not var() references) for --dual-color-1/2.
    //
    // The previous approach stored "var(--accentLightTint-blue)" as a live reference.
    // That worked correctly when the CSS var was stable, but _smoothThemeSwitch (Case C:
    // predefined-dark → predefined-dark) temporarily SNAPS --accentLightTint-blue back
    // to the OLD theme's values for the duration of its rAF animation. During that brief
    // window the var() reference resolved to the PREVIOUS theme's color, making the
    // large circle and trigger-button halves flash / stay on the old color.
    //
    // Storing the already-resolved hex bypasses the snap-back entirely: --dual-color-1
    // holds the correct new-theme color as a literal value and is unaffected by later
    // changes to --accentLightTint-blue.
    if (_newHalf1) _root.style.setProperty("--dual-color-1", _newHalf1);
    else _root.style.setProperty("--dual-color-1", "var(--accentLightTint-blue)");
    if (_newHalf2) _root.style.setProperty("--dual-color-2", _newHalf2);
    else _root.style.setProperty("--dual-color-2", "var(--darkColor-blue)");

    // Predefined dark mode uses a page-level filter invert; it snaps instantly (by design),
    // which makes the dual-color trigger circle "flip" abruptly. To match the smooth
    // animation used by custom/dual themes, we:
    // 1) counter-invert the trigger circle in CSS (so it opts out of the page filter)
    // 2) drive its half colors here to the *visual* (filtered) equivalents, so they can
    //    transition smoothly via @property on --btn-half-1-color/--btn-half-2-color.
    let _targetHalf1 = _newHalf1;
    let _targetHalf2 = _newHalf2;
    if (_isFilterDarkActive()) {
        if (_newHalf1) _targetHalf1 = _filterInvertHueRotate(_newHalf1);
        if (_newHalf2) _targetHalf2 = _filterInvertHueRotate(_newHalf2);
    }
    // Always set immediately — CSS exemption ensures the transition fires even when
    // no-theme-transition is active (see html.no-theme-transition rule in style.css).
    if (_targetHalf1) _root.style.setProperty("--btn-half-1-color", _targetHalf1);
    if (_targetHalf2) _root.style.setProperty("--btn-half-2-color", _targetHalf2);

    // Keep the large dual-circle preview in sync even when leaving a 2-color theme.
    // CSS already exempts .dualColorLargeCircle from no-theme-transition suppression,
    // so setting immediately always produces the correct transition animation.
    const _largeCircle = document.getElementById("dualColorLargeCircle");
    if (_largeCircle) {
        _largeCircle.style.removeProperty("background");
        if (_newHalf1) _largeCircle.style.setProperty("--lc-left-color",  _newHalf1);
        if (_newHalf2) _largeCircle.style.setProperty("--lc-right-color", _newHalf2);
    }

    // FIX: Re-apply large circle + favicon AFTER _smoothThemeSwitch finishes its rAF chain.
    // When switching from a gradient (dual) theme to a solid theme, _smoothThemeSwitch uses
    // a double-rAF that can overwrite --lc-left/right-color with stale gradient values.
    // Scheduling our update in a second double-rAF ensures we always win and the circle +
    // favicon reflect the final selected theme color.
    // IMPORTANT: we guard with _themeSeq !== _seq so that if the user immediately picks a
    // gradient (or any other theme) AFTER this solid theme, our deferred rAF is a no-op and
    // does NOT overwrite the freshly applied gradient colors with the old solid colors.
    const _fixHalf1 = _newHalf1;
    const _fixHalf2 = _newHalf2;
    const _fixSeq = _seq;
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            if (_themeSeq !== _fixSeq) return; // cancelled — a newer theme was applied
            const _lc2 = document.getElementById("dualColorLargeCircle");
            if (_lc2) {
                _lc2.style.removeProperty("background");
                if (_fixHalf1) _lc2.style.setProperty("--lc-left-color",  _fixHalf1);
                if (_fixHalf2) _lc2.style.setProperty("--lc-right-color", _fixHalf2);
            }
            // Re-run favicon AFTER CSS vars are fully settled.
            // Pass _fixHalf2 directly — avoids reading the still-animating @property var.
            if (typeof changeFaviconColor === "function") changeFaviconColor(_fixHalf2);
        });
    });

    // Pass _newHalf2 directly so the favicon uses the final target color, not the
    // mid-transition getComputedStyle value of the animated @property --darkColor-blue.
    changeFaviconColor(_newHalf2);
    ApplyLoadingColor();
    // Cache vars for FOUC-free next-page preload
    _saveThemeVarsCache();

    // Notify other components that theme colors have changed
    // Small delay lets CSS vars propagate before saved-color dots re-render
    setTimeout(() => {
        if (typeof renderSavedColors === "function") renderSavedColors();
        document.dispatchEvent(new CustomEvent("theme-colors-changed"));
    }, 30);
};

function changeFaviconColor(color) {
    // FIX: Accept an explicit color to bypass getComputedStyle entirely.
    //
    // --darkColor-blue is an @property <color> variable, meaning the browser
    // ANIMATES it during theme transitions. Reading it via getComputedStyle
    // returns the mid-transition (interpolated) value, not the final target —
    // so the favicon was being painted with the PREVIOUS theme's color.
    //
    // Callers that know the final target color (applySelectedTheme,
    // _applyCustomThemeCore) now pass it directly. The getComputedStyle fallback
    // is kept for the initial page-load call where no animation is in flight.
    const darkColor = (color && color.trim())
        ? color.trim()
        : getComputedStyle(document.documentElement).getPropertyValue("--darkColor-blue").trim();

    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="${darkColor}" style="transform: scale(1.2); transform-origin: center;" d="M10 19v-5h4v5c0 .55.45 1 1 1h3c.55 0 1-.45 1-1v-7h1.7c.46 0 .68-.57.33-.87L12.67 3.6c-.38-.34-.96-.34-1.34 0l-8.36 7.53c-.34.3-.13.87.33.87H5v7c0 .55.45 1 1 1h3c.55 0 1-.45 1-1"/></svg>`;
    const encodedSvg = 'data:image/svg+xml,' + encodeURIComponent(svg);

    // FIX: Force Chrome to repaint the tab icon.
    // Browsers (especially Chromium) aggressively cache favicons and often ignore
    // a simple href reassignment. Removing the <link> element from <head> and
    // re-appending it is the reliable way to guarantee the tab icon updates
    // immediately without a page refresh.
    const favicon = document.getElementById("favicon");
    favicon.setAttribute('type', 'image/svg+xml');
    favicon.href = encodedSvg;
    const parent = favicon.parentNode;
    if (parent) {
        parent.removeChild(favicon);
        parent.appendChild(favicon);
    }
}
changeFaviconColor();

// --------------------- Color Picker ---------------------
function mixReadableHex(colorA, colorB, amount = 0.5) {
    const toRgb = (value) => {
        const safe = String(value || "#000000").replace("#", "").padEnd(6, "0").slice(0, 6);
        return {
            r: parseInt(safe.slice(0, 2), 16) || 0,
            g: parseInt(safe.slice(2, 4), 16) || 0,
            b: parseInt(safe.slice(4, 6), 16) || 0
        };
    };
    const toHex = (channel) => Math.max(0, Math.min(255, Math.round(channel))).toString(16).padStart(2, "0");
    const a = toRgb(colorA);
    const b = toRgb(colorB);
    const t = clamp01(amount);
    return `#${toHex(a.r + (b.r - a.r) * t)}${toHex(a.g + (b.g - a.g) * t)}${toHex(a.b + (b.b - a.b) * t)}`.toUpperCase();
}

function getReadableTextOnColor(hex, options = {}) {
    const lum = getSimpleLuminance(hex);
    const lightText = options.lightText || "#F4F6FA";
    const darkText = options.darkText || "#101318";
    const threshold = Number.isFinite(options.threshold) ? options.threshold : 0.42;
    const blendWidth = Number.isFinite(options.blendWidth) ? options.blendWidth : 0.18;
    const mix = smoothStep(threshold - blendWidth, threshold + blendWidth, lum);
    return mixReadableHex(lightText, darkText, mix);
}

function applyCustomTheme(color, _overrideWasFilterDark) {
    // Cancel any in-flight custom-swap animation so external callers
    // (mode switch, color picker, saved-colors) can fully update the large circle.
    if (typeof _cancelCustomSwapAnim === "function") _cancelCustomSwapAnim();
    else if (window._customSwapAnimRunning) window._customSwapAnimRunning = false;
    if (!window._colorPickerDragging || window._colorPickerCommitOnly) {
        clearPresetThemeIndicators();
    }

    // During color-picker drag: skip _smoothThemeSwitch's double-rAF dance entirely.
    // no-theme-transition is already active (added by the drag start handler),
    // so we can apply vars directly for an instant live preview without any lag.
    if (window._colorPickerDragging) {
        _applyCustomThemeCore(color);
        return;
    }

    _atomicThemeSwitch(() => _applyCustomThemeCore(color), _overrideWasFilterDark);
}

function _applyCustomThemeCore(color) {
    // Capture a monotonic token for this apply. Increments the SHARED _themeSeq counter
    // so that applySelectedTheme (and vice versa) can detect and skip stale deferred rAFs
    // from a previous apply (e.g. leftover rAFs from a color-picker drag after the user
    // has already switched to a predefined or dual theme).
    const _seq = ++_themeSeq;

    // Detect current mode first
    const preferredTheme = localStorage.getItem("preferredTheme") || "light";
    const systemIsDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const isDarkMode = preferredTheme === "dark" || (preferredTheme === "system" && systemIsDark);
    const _customSwapped = localStorage.getItem(customSwapKey) === "1";

    function getLuminance(hex) {
        hex = hex.replace("#", "");
        const r = parseInt(hex.substring(0,2), 16) / 255;
        const g = parseInt(hex.substring(2,4), 16) / 255;
        const b = parseInt(hex.substring(4,6), 16) / 255;
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }

    // Use the exact color the user picked — no barriers.
    // Surface/accent derivation handles all luminance ranges:
    //   very light colors (lum > 0.80) → DARKEN for visible depth (can't lighten white)
    //   dark colors (lum < 0.18)       → LIGHTEN heavily for light surfaces
    //   everything else                → proportional lightening
    let rawColor = color;
    const lum = getSimpleLuminance(rawColor);
    const hexLum = (hex) => getSimpleLuminance(hex);

    let bgColor, bgTintColor, accentColor, accentDarkColor, textDarkColor, whitishColor;

    if (isDarkMode) {
        const blackFactor = smoothStep(0.0, 0.12, lum);
        const bgTarget = mixNumber(0.0, mixNumber(0.028, 0.048, smoothStep(0.06, 0.96, lum)), blackFactor);
        bgColor = shiftHexToLuminance(rawColor, bgTarget);

        const bgLum = getSimpleLuminance(bgColor);
        const tintTarget = Math.min(
            0.19,
            bgLum + mixNumber(0.075, 0.045, smoothStep(0.08, 0.90, lum))
        );
        bgTintColor = shiftHexToLuminance(rawColor, tintTarget);

        const accentFloor = Math.min(
            0.86,
            bgLum + mixNumber(0.55, 0.22, smoothStep(0.08, 0.78, lum))
        );
        const accentTarget = Math.min(0.86, Math.max(lum, accentFloor));
        accentColor = shiftHexToLuminance(rawColor, accentTarget);

        const accentLum = getSimpleLuminance(accentColor);
        accentDarkColor = shiftHexToLuminance(
            accentColor,
            Math.max(bgLum + 0.15, accentLum * 0.70)
        );
        textDarkColor = getReadableTextOnColor(bgTintColor, {
            lightText: "#F4F6FA",
            darkText: "#101318",
            threshold: 0.40,
            blendWidth: 0.18
        });
        whitishColor = shiftHexToLuminance(
            bgColor,
            Math.min(0.22, bgLum + 0.055)
        );
    } else {
        const whiteFactor = smoothStep(0.85, 1.0, lum);
        const bgTarget = clamp01(
            0.84
            + 0.10 * (1 - smoothStep(0.00, 0.22, lum))
            - 0.18 * smoothStep(0.65, 0.99, lum)
        );
        const targetBgAdjusted = mixNumber(bgTarget, 1.0, whiteFactor);
        bgColor = shiftHexToLuminance(rawColor, targetBgAdjusted);

        const tintTarget = clamp01(
            Math.min(1.0, targetBgAdjusted + 0.05 * (1 - whiteFactor))
        );
        bgTintColor = shiftHexToLuminance(rawColor, tintTarget);

        const accentMax = mixNumber(0.74, 0.38, smoothStep(0.68, 1.00, lum));
        const accentTarget = Math.min(lum, accentMax);
        accentColor = shiftHexToLuminance(rawColor, accentTarget);

        const accentLum = getSimpleLuminance(accentColor);
        accentDarkColor = shiftHexToLuminance(
            accentColor,
            Math.max(0.10, accentLum * 0.72)
        );
        textDarkColor = shiftHexToLuminance(
            accentColor,
            Math.max(0.06, Math.min(0.20, accentLum * 0.34))
        );
        whitishColor = '#FFFFFF';
    }

    // ── Mode-consistent circle display colors ─────────────────────────────────
    // Do NOT use bgColor/accentColor directly for the circle display. In light mode
    // bgColor is LIGHT and accentColor is DARK; in dark mode bgColor is NEAR-BLACK
    // and accentColor is BRIGHT. The left/right sides visually invert on mode switch.
    //
    // Instead, derive both display colors from rawColor in a mode-agnostic way —
    // identical to the _deriveDisplayColor approach used by dual-color.js — so both
    // halves shift in the SAME direction (brighter in dark mode) with no side-swap:
    //   light mode: [tint = lightened(raw)] | [base = raw]
    //   dark  mode: [tint = more-lightened] | [base = lightened for visibility]
    // The lighter half stays on the same side in both modes → no visual inversion.
    const _circleDisplayBase = isDarkMode ? adjustHexColor(rawColor, 0.45, true) : rawColor;
    const _circleDisplayTint = isDarkMode ? adjustHexColor(rawColor, 0.80, true)
                                          : adjustHexColor(rawColor, 0.70, true);

    // SWAP: exchange bg↔accent positions (keeps same mode, just swaps color roles)
    if (_customSwapped) {
        if (isDarkMode) {
            // ── Dark mode swap: must re-derive both roles properly ──
            // accentColor may be bright (e.g. from near-white input) → CANNOT be used as bg.
            // bgColor is already near-black → can be lightened into the new accent.
            const swapAccentSeed = accentColor; // bright — becomes the seed for a new dark bg
            const swapBgSeed     = bgColor;     // dark — lighten into new accent

            // New bg: darken the accentSeed hue down to TARGET_BG_LUM
            const TARGET_SWAP_BG = 0.035;
            const swapAccLum = hexLum(swapAccentSeed);
            let newBg;
            if (swapAccLum <= TARGET_SWAP_BG) {
                newBg = swapAccentSeed;
            } else {
                const df = Math.min(0.97, 1 - TARGET_SWAP_BG / swapAccLum);
                newBg = adjustHexColor(swapAccentSeed, df, false);
            }

            // New bgTint: slightly lighter than newBg
            const newBgLum    = hexLum(newBg);
            const minNewTint  = newBgLum * 1.8 + 0.015;
            let newBgTint = adjustHexColor(newBg, 0.15, true);
            if (hexLum(newBgTint) < minNewTint) {
                for (let s = 5; s <= 90; s += 5) {
                    const tc = adjustHexColor(newBg, s / 100, true);
                    if (hexLum(tc) >= minNewTint) { newBgTint = tc; break; }
                }
            }

            // New accent: lighten the bgSeed hue until visible + cap at 0.78
            const minNewAccLum = newBgLum * 4.5 + mixNumber(0.45, 0.175, smoothStep(0.0, 0.25, newBgLum));
            let newAccent = swapBgSeed;
            if (hexLum(newAccent) < minNewAccLum) {
                for (let s = 5; s <= 95; s += 5) {
                    const c = adjustHexColor(swapBgSeed, s / 100, true);
                    if (hexLum(c) >= minNewAccLum) { newAccent = c; break; }
                }
            }
            if (hexLum(newAccent) > 0.78) {
                for (let s = 5; s <= 80; s += 5) {
                    const c = adjustHexColor(swapBgSeed, s / 100, false);
                    if (hexLum(c) <= 0.78) { newAccent = c; break; }
                }
            }

            bgColor         = newBg;
            bgTintColor     = newBgTint;
            accentColor     = newAccent;
            accentDarkColor = adjustHexColor(newAccent, 0.20, false);
            textDarkColor   = getReadableTextOnColor(newBgTint, {
                lightText: "#F4F6FA",
                darkText: "#101318",
                threshold: 0.40,
                blendWidth: 0.18
            });
            whitishColor    = adjustHexColor(newBg, 0.12, true);
        } else {
            // ── Light mode swap: accent is medium-dark → CANNOT be used directly as bg ──
            // Re-derive proper LIGHT surfaces from the accent hue seed.
            // This produces a more saturated/colorful light bg instead of going dark.
            const swapSeed    = accentColor;
            const swapSeedLum = getLuminance(swapSeed);

            // Bring swapSeed into usable base range (same guard as normal light mode)
            let swapBase = swapSeed;
            if (swapSeedLum < 0.12) swapBase = adjustHexColor(swapSeed, 0.30, true);

            // Lighten less than the default 0.72 → more saturated/colorful bg (the "swapped" look)
            const newBg   = adjustHexColor(swapBase, 0.55, true);
            const newTint = adjustHexColor(swapBase, 0.78, true);

            // Tint depth check: ensure enough separation between bg and tint
            const nbgLum  = getLuminance(newBg);
            const ntntLum = getLuminance(newTint);
            const checkedTint = (ntntLum - nbgLum < 0.04)
                ? adjustHexColor(newBg, 0.40, true)
                : newTint;

            // New accent: slightly darker than swapBase (visible on the new lighter bg)
            const newAccent     = adjustHexColor(swapBase, 0.12, false);
            const newAccentDark = adjustHexColor(newAccent, 0.28, false);
            const newText       = adjustHexColor(newAccent, 0.70, false);

            bgColor         = newBg;
            bgTintColor     = checkedTint;
            accentColor     = newAccent;
            accentDarkColor = newAccentDark;
            textDarkColor   = newText;
            whitishColor    = "#ffffff";
        }
    }

    // ── CRITICAL: set data-custom-theme BEFORE CSS vars ──
    // The CSS dark-mode rule uses filter:invert() only when data-custom-theme is NOT "active".
    // If we set CSS vars first (dark values) while filter:invert() is still on,
    // the browser renders one frame of: dark-vars + invert = light flash.
    // Setting the attribute first removes the filter immediately, then vars animate in correctly.
    document.body.setAttribute("data-custom-theme", "active");

    document.documentElement.style.setProperty("--bg-color-blue",        bgColor);
    document.documentElement.style.setProperty("--accentLightTint-blue",  bgTintColor);
    document.documentElement.style.setProperty("--darkColor-blue",        accentColor);
    document.documentElement.style.setProperty("--darkerColor-blue",      accentDarkColor);
    document.documentElement.style.setProperty("--textColorDark-blue",    textDarkColor);
    document.documentElement.style.setProperty("--whitishColor-blue",     whitishColor);

    // Dynamic contrast button text, disabled button bg, and input borders
    const accLumForBtn = getSimpleLuminance(accentColor);
    const btnTextFactor = smoothStep(0.45, 0.65, accLumForBtn);
    const btnTextColor = adjustHexColor("#FFFFFF", btnTextFactor, false);

    const bgLumForBtn = getSimpleLuminance(bgColor);
    const disabledBtnBgColor = bgLumForBtn < 0.08
        ? adjustHexColor("#1A1A1A", (0.08 - bgLumForBtn) / 0.08 * 0.45, true)
        : (bgLumForBtn > 0.45 ? "rgba(0, 0, 0, 0.08)" : "rgba(255, 255, 255, 0.14)");

    const inputBorderFactor = 1 - smoothStep(0.0, 0.18, bgLumForBtn);
    const inputBorderColor = `rgba(255, 255, 255, ${0.22 * inputBorderFactor})`;

    document.documentElement.style.setProperty("--savebtn-text-color", btnTextColor);
    document.documentElement.style.setProperty("--savebtn-disabled-bg-color", disabledBtnBgColor);
    document.documentElement.style.setProperty("--input-border-color", inputBorderColor);
    // Cache vars for FOUC-free next-page preload
    if (!window._colorPickerDragging || window._colorPickerCommitOnly) {
        _saveThemeVarsCache();
    }

    colorPickerLabel.style.borderColor = "";
    // Note: Radio buttons are unchecked by the caller (color picker handler or saved-colors)
    // to avoid duplication and timing issues
    // data-custom-theme is set BEFORE CSS vars above — see comment there.

    // Update trigger circle — swap is a pure positional flip of the pre-swap display colors.
    // _circleDisplayTint is always the lighter half; _circleDisplayBase the more vivid/mid half.
    // Swapping exchanges their positions without re-deriving new colors.
    const _display1 = _customSwapped ? _circleDisplayBase : _circleDisplayTint;
    const _display2 = _customSwapped ? _circleDisplayTint : _circleDisplayBase;
    // Keep _circleOrderFixed in a stable state for the color-picker drag logic.
    window._circleOrderFixed = true;
    document.documentElement.style.setProperty("--dual-color-1", _display1);
    document.documentElement.style.setProperty("--dual-color-2", _display2);

    // Set large circle and trigger-button halves IMMEDIATELY.
    // Both --lc-left/right-color and --btn-half-1/2-color are now exempt from
    // no-theme-transition suppression via CSS (see style.css exemption rules), so the
    // browser will always start the CSS transition right away without any rAF dance.
    // This eliminates the previous double-rAF timing bugs where a pending rAF from
    // one apply could fire after a newer apply had already set the correct colors.
    const _largeCircle = document.getElementById("dualColorLargeCircle");
    if (_largeCircle) {
        _largeCircle.style.removeProperty("background");
        _largeCircle.style.setProperty("--lc-left-color",  _display1);
        _largeCircle.style.setProperty("--lc-right-color", _display2);
    }

    // Always set immediately — CSS exemption ensures the transition fires.
    document.documentElement.style.setProperty("--btn-half-1-color", _display1);
    document.documentElement.style.setProperty("--btn-half-2-color", _display2);

    const trigBtn = document.getElementById("dualColorTriggerBtn");
    if (trigBtn) {
        trigBtn.classList.remove("dualActive");
    }

    // Show custom swap button; update active state to reflect current swap
    const customSwapBtn = document.getElementById("customSwapBtn");
    if (customSwapBtn) {
        customSwapBtn.style.display = "flex";
        customSwapBtn.classList.toggle("dualSwapActive", localStorage.getItem(customSwapKey) === "1");
    }
    // Hide dual swap btn (only for dual themes)
    const dualSwapBtn = document.getElementById("dualSwapBtn");
    if (dualSwapBtn) dualSwapBtn.style.display = "none";

    // Pass accentColor directly — it is already the resolved hex that was written
    // into --darkColor-blue above, so changeFaviconColor gets the correct final
    // color immediately without having to read the animating @property var.
    if (!window._colorPickerDragging || window._colorPickerCommitOnly) {
        changeFaviconColor(accentColor);
        ApplyLoadingColor();
    }
    // FIX: Deferred double-rAF favicon + circle refresh.
    // The immediate call above runs while _smoothThemeSwitch may still be mid-animation
    // (Case E snaps --darkColor-blue back to startColors right after applyFn returns).
    // The deferred call fires after all rAF chains settle, guaranteeing Chrome commits
    // the correct favicon colour. Guard with _themeSeq so rapid picks don't clobber newer themes.
    const _customFixSeq = _seq;
    const _customAccent = accentColor;
    const _customDisp1  = _display1;
    const _customDisp2  = _display2;
    if (!window._colorPickerDragging || window._colorPickerCommitOnly) {
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                if (_themeSeq !== _customFixSeq) return;
                const _lc = document.getElementById("dualColorLargeCircle");
                if (_lc) {
                    _lc.style.removeProperty("background");
                    if (_customDisp1) _lc.style.setProperty("--lc-left-color",  _customDisp1);
                    if (_customDisp2) _lc.style.setProperty("--lc-right-color", _customDisp2);
                }
                if (_customDisp1) document.documentElement.style.setProperty("--btn-half-1-color", _customDisp1);
                if (_customDisp2) document.documentElement.style.setProperty("--btn-half-2-color", _customDisp2);
                if (typeof changeFaviconColor === "function") changeFaviconColor(_customAccent);
            });
        });
    }

    // Notify components that theme changed — fire immediately for live preview
    // (shadow-control responds to this and needs it during color-picker drag)
    const livePickerPreview = !!(window._colorPickerDragging && !window._colorPickerCommitOnly);
    if (livePickerPreview) {
        if (typeof window.updateThemeShadowNow === "function") {
            window.updateThemeShadowNow();
        }
    } else {
        document.dispatchEvent(new CustomEvent("theme-colors-changed"));
    }

    // Also fire after 30ms so components that need settled CSS var values
    // (e.g. renderSavedColors) get the final correct result.
    if (!livePickerPreview) {
        setTimeout(() => {
            if (typeof renderSavedColors === "function") renderSavedColors();
            document.dispatchEvent(new CustomEvent("theme-colors-changed"));
        }, 30);
    }
}


// ── Force-update shortcut SVG circle fills ──────────────────────────────────
// Some browsers fail to repaint SVG circles inside shortcut icons when CSS
// custom properties change (e.g. YouTube, Discord in dark + custom/dual theme).
// Reading the variable directly and setting it as an inline style is a reliable
// workaround. Called after every custom / dual theme apply.
// ── Helper: apply a predefined theme immediately (used by click and right-click) ──
function applyPredefinedThemeNow(colorValue) {
    if (isSafePresetTheme(colorValue)) {
        const safeColor = getSafePresetThemeColor(colorValue);
        _smoothThemeSwitch(() => {
            localStorage.removeItem(themeStorageKey);
            localStorage.setItem(safePresetThemeStorageKey, colorValue);
            localStorage.setItem(customThemeStorageKey, safeColor);
            localStorage.removeItem("dualColorTheme");
            localStorage.removeItem("dualColorSwapped");
            localStorage.removeItem(customSwapKey);
            const csb = document.getElementById("customSwapBtn");
            if (csb) csb.style.display = "none";

            if (window.dualColorTheme) window.dualColorTheme.clearDualTheme();

            _applySafePresetThemeCore(colorValue);
            setCheckedThemePlate(colorValue);
            if (typeof renderSavedColors === "function") renderSavedColors();
        });
        return;
    }
    _smoothThemeSwitch(() => {
        clearSafePresetTheme();
        localStorage.setItem(themeStorageKey, colorValue);
        localStorage.removeItem(customThemeStorageKey);
        localStorage.removeItem("dualColorTheme");
        localStorage.removeItem("dualColorSwapped");
        localStorage.removeItem(customSwapKey);
        const csb = document.getElementById("customSwapBtn");
        if (csb) csb.style.display = "none";

        if (window.dualColorTheme) window.dualColorTheme.clearDualTheme();

        applySelectedTheme(colorValue);
        setCheckedThemePlate(colorValue);
        if (typeof renderSavedColors === "function") renderSavedColors();
    });
}
// Handle radio button changes — apply immediately
const handleThemeChange = function () {
    if (this.checked) {
        applyPredefinedThemeNow(this.value);
    }
};

// Remove any previously attached listeners and add only one
radioButtons.forEach(radioButton => {
    radioButton.removeEventListener("change", handleThemeChange);
    radioButton.addEventListener("change", handleThemeChange);
    // Play bounce animation on click for visual feedback
    radioButton.addEventListener("click", function() {
        document.querySelectorAll(".colorPlate, .colorPlate-grad, .sc-color-dot").forEach(el => {
            el.classList.remove("plate-select-anim");
        });
        // Force reflow so animation restarts even if clicking same plate again
        void this.offsetWidth;
        this.classList.add("plate-select-anim");
        this.addEventListener("animationend", () => {
            this.classList.remove("plate-select-anim");
        }, { once: true });
    });
});

// ── Right-click "Apply Theme" context menu for predefined (default) themes ──
let activePredefinedContextMenu = null;

function closePredefinedContextMenu() {
    if (activePredefinedContextMenu) {
        const menu = activePredefinedContextMenu;
        activePredefinedContextMenu = null;
        menu.classList.remove("sc-ctx-visible");
        menu.addEventListener("transitionend", function handler(e) {
            if (e.propertyName === "opacity") {
                menu.remove();
            }
        });
    }
}

function showPredefinedContextMenu(e, colorValue) {
    e.preventDefault();
    closePredefinedContextMenu();
    // Also close saved-colors context menu if open
    if (typeof closeContextMenu === "function") closeContextMenu();
    // Also close the dual-color context menu (avoids two menus at same position)
    if (typeof _closeContextMenuDual === "function") {
        try { _closeContextMenuDual(); } catch(err) {}
    }

    // Capture the radio dot that was right-clicked so we can animate it on Apply
    const sourceDot = e.target.closest ? e.target.closest("input[type=\"radio\"]") : null;

    const menu = document.createElement("div");
    menu.className = "sc-context-menu";

    const applyBtn = document.createElement("button");
    applyBtn.className = "sc-ctx-btn sc-ctx-apply";
    applyBtn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>
        </svg>
        <span>${typeof getT === "function" ? getT("savedColorApply") : "Apply Theme"}</span>`;
    applyBtn.addEventListener("click", () => {
        closePredefinedContextMenu();
        // Play bounce animation on the source dot then apply the theme
        if (sourceDot && sourceDot.isConnected) {
            document.querySelectorAll(".colorPlate, .colorPlate-grad, .sc-color-dot").forEach(el => {
                el.classList.remove("plate-select-anim");
            });
            void sourceDot.offsetWidth;
            sourceDot.classList.add("plate-select-anim");
            sourceDot.addEventListener("animationend", () => {
                sourceDot.classList.remove("plate-select-anim");
            }, { once: true });
        }
        applyPredefinedThemeNow(colorValue);
    });

    menu.appendChild(applyBtn);
    document.body.appendChild(menu);
    activePredefinedContextMenu = menu;

    const menuW = 160, menuH = 46;
    let x = e.clientX, y = e.clientY;
    if (x + menuW > window.innerWidth) x = window.innerWidth - menuW - 8;
    if (y + menuH > window.innerHeight) y = window.innerHeight - menuH - 8;
    menu.style.left = x + "px";
    menu.style.top = y + "px";

    // Force reflow to register starting styles for transition
    void menu.offsetWidth;

    menu.classList.add("sc-ctx-visible");
}


document.addEventListener("click", closePredefinedContextMenu);
document.addEventListener("keydown", e => { if (e.key === "Escape") closePredefinedContextMenu(); });

// Attach right-click via delegation on the container — avoids duplicate listeners on shared parent
(function() {
    const container = document.getElementById("colorsContainer");
    if (!container) return;
    container.addEventListener("contextmenu", function(e) {
        // Find the clicked .colorPlate radio input
        let target = e.target;
        let found = null;
        while (target && target !== container) {
            if (target.classList && target.classList.contains("colorPlate") && target.type === "radio") {
                found = target;
                break;
            }
            target = target.parentElement;
        }
        if (!found) return; // Not a predefined radio — ignore
        showPredefinedContextMenu(e, found.value);
    });
})();

// Handle color picker changes
const handleColorPickerChange = function (event, options = {}) {
    const selectedColor = event.target.value;
    const commit = !!options.commit || !window._colorPickerDragging;

    if (commit) {
        clearSafePresetTheme();
        localStorage.removeItem(customSwapKey); // New color = reset swap
        localStorage.setItem(customThemeStorageKey, selectedColor); // Save custom color
        localStorage.removeItem(themeStorageKey); // Clear predefined theme
    }

    if (commit || !_colorPickerPreviewPrepared) {
        clearPresetThemeIndicators();
        document.body.removeAttribute("data-dual-theme");
        const dualSwapBtn = document.getElementById("dualSwapBtn");
        if (dualSwapBtn) dualSwapBtn.style.display = "none";
        const dualTriggerBtn = document.getElementById("dualColorTriggerBtn");
        if (dualTriggerBtn) dualTriggerBtn.classList.remove("dualActive");
        _colorPickerPreviewPrepared = true;
    }

    // Clear dual theme BEFORE applyCustomTheme so --dual-color-1/2 are NOT
    // removed AFTER being set (clearDualTheme removes those vars, causing
    // the circle halves to flash back to fallback colors every frame during drag).
    if (commit) {
        localStorage.removeItem("dualColorTheme");
        if (window.dualColorTheme) window.dualColorTheme.clearDualTheme();
    }

    applyCustomTheme(selectedColor);
    
    // Re-render saved colors to update checkmarks
    if (commit && typeof renderSavedColors === "function") {
        renderSavedColors();
    }
};

// Throttle for performance optimization
const throttle = (func, limit) => {
    let lastFunc;
    let lastRan;
    const throttled = (...args) => {
        if (!lastRan) {
            func(...args);
            lastRan = Date.now();
        } else {
            clearTimeout(lastFunc);
            lastFunc = setTimeout(() => {
                if (Date.now() - lastRan >= limit) {
                    func(...args);
                    lastRan = Date.now();
                }
            }, limit - (Date.now() - lastRan));
        }
    };
    throttled.cancel = () => {
        clearTimeout(lastFunc);
        lastFunc = null;
        lastRan = 0;
    };
    return throttled;
};

// Add listeners for color picker
// During drag: suppress theme-var transitions so colors update instantly (no lag)
// On release ("change"): re-enable transitions for the final snap animation
colorPicker.removeEventListener("input", handleColorPickerChange); // Ensure no duplicate listeners

let _colorPickerDragging = false;
let _colorPickerPreviewPrepared = false;
// Expose globally so shadow-control.js can suppress updates during drag
// (prevents flickering from shadow re-renders racing with in-flight CSS var changes)
window._colorPickerDragging = false;
window._colorPickerCommitOnly = false;

const handleColorPickerInput = throttle(function(e) {
    if (!_colorPickerDragging) {
        _colorPickerDragging = true;
        window._colorPickerDragging = true;
        _colorPickerPreviewPrepared = false;
        document.documentElement.classList.add("no-theme-transition");
    }
    handleColorPickerChange(e, { commit: false });
}, 16); // ~60fps for smooth live preview

colorPicker.addEventListener("input", handleColorPickerInput);

colorPicker.addEventListener("change", function(e) {
    handleColorPickerInput.cancel();
    // User released — apply final color and re-enable transitions.
    // Keep _circleOrderFixed alive so the FINAL apply uses the same stable order
    // as the drag (prevents a one-frame flip on mouse-up). Reset it AFTER apply.
    _colorPickerDragging = false;
    window._colorPickerDragging = false;
    // Do NOT reset _circleOrderFixed yet — handleColorPickerChange reads it below
    window._colorPickerCommitOnly = true;
    handleColorPickerChange(e, { commit: true });
    window._colorPickerCommitOnly = false;
    _colorPickerPreviewPrepared = false;
    window._circleOrderFixed = null; // reset AFTER final apply so next drag recalculates
    // One clean shadow re-apply after CSS vars have settled.
    // Also explicitly re-run favicon here — this fires AFTER no-theme-transition is removed
    // and after _smoothThemeSwitch's rAF chain has settled, which is the safest point to
    // commit the favicon colour in Chrome (handles any Chrome-side debouncing of rapid updates).
    requestAnimationFrame(() => {
        document.documentElement.classList.remove("no-theme-transition");
        document.dispatchEvent(new CustomEvent("theme-colors-changed"));
        if (typeof changeFaviconColor === "function") {
            // Read --darkColor-blue now that CSS vars are settled (no animation in flight)
            changeFaviconColor();
        }
    });
});

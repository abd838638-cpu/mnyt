/* Small, finite animations give each action a clear visual response. */
(function () {
    "use strict";
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    const active = new Set();
    const duration = multiplier => Math.min(1200, (window.getPanelAnimDur?.() || 220) * multiplier);
    function animate(element, frames, options) {
        if (!element || reduced.matches || !element.animate) return;
        const animation = element.animate(frames, options);
        active.add(animation);
        animation.finished.catch(() => {}).finally(() => active.delete(animation));
        return animation;
    }
    reduced.addEventListener("change", () => {
        if (reduced.matches) {
            active.forEach(animation => animation.cancel());
            document.querySelectorAll(".ux-ripple-layer").forEach(layer => layer.remove());
        }
    });
    document.addEventListener("click", event => {
        if (reduced.matches) return;
        const target = event.target.closest("button,.shortcuts a,.search-engine,.ux-dock-button");
        if (!target || target.disabled || target.getAttribute("aria-disabled") === "true") return;
        // Let the existing action update its label before inserting the effect.
        queueMicrotask(() => {
            if (!target.isConnected || reduced.matches) return;
            if (getComputedStyle(target).position === "static") target.classList.add("ux-ripple-static");
            target.querySelector(":scope > .ux-ripple-layer")?.remove();
            const layer = document.createElement("span");
            layer.className = "ux-ripple-layer";
            layer.setAttribute("aria-hidden", "true");
            const wave = document.createElement("span");
            wave.className = "ux-ripple-wave";
            const rect = target.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height) * 2;
            const x = event.detail ? event.clientX - rect.left : rect.width / 2;
            const y = event.detail ? event.clientY - rect.top : rect.height / 2;
            wave.style.cssText = `width:${size}px;height:${size}px;left:${x - size / 2}px;top:${y - size / 2}px;`;
            layer.appendChild(wave);
            target.appendChild(layer);
            const animation = animate(wave, [{ transform: "scale(0)", opacity: .22 }, { transform: "scale(1)", opacity: 0 }], { duration: duration(2), easing: "cubic-bezier(.2,.7,.2,1)" });
            if (animation) animation.finished.catch(() => {}).finally(() => layer.remove());
            else layer.remove();
        });
    }, true);

    // A staggered entrance runs only once, after loading and onboarding finish.
    let entered = false;
    function reveal() {
        if (entered) return;
        const loader = document.getElementById("LoadingScreen");
        const onboarding = document.getElementById("onboardingOverlay");
        if ((loader && getComputedStyle(loader).display !== "none") || (onboarding && getComputedStyle(onboarding).display !== "none")) return;
        entered = true;
        document.querySelectorAll(".leftDiv > *, .rightDiv > *, .shortcutsContainer .shortcuts").forEach((element, index) => {
            animate(element, [{ opacity: 0, translate: "0 16px" }, { opacity: 1, translate: "0 0" }], { duration: duration(2.2), delay: Math.min(index * 45, 300), easing: "cubic-bezier(.16,1,.3,1)", fill: "backwards" });
        });
        observer.disconnect();
    }
    const observer = new MutationObserver(reveal);
    ["LoadingScreen", "onboardingOverlay"].forEach(id => {
        const element = document.getElementById(id);
        if (element) observer.observe(element, { attributes: true, attributeFilter: ["style", "class"] });
    });
    window.addEventListener("load", reveal, { once: true });
    reveal();

    // The sidebar keeps its native slide; its cards settle in afterwards.
    const sidebar = document.getElementById("bookmarkSidebar");
    let sidebarOpen = false;
    new MutationObserver(() => {
        const open = sidebar.classList.contains("open");
        if (open && !sidebarOpen) {
            [".bookmark-sidebar-header", ".bookmark-search-container", ".bookmark-controls-container", ".bm-discovery-bar"].forEach((selector, index) => {
                animate(sidebar.querySelector(selector), [{ opacity: 0, translate: "0 10px" }, { opacity: 1, translate: "0 0" }], { duration: duration(1.6), delay: index * 35, easing: "ease-out" });
            });
        }
        sidebarOpen = open;
    }).observe(sidebar, { attributes: true, attributeFilter: ["class"] });
})();

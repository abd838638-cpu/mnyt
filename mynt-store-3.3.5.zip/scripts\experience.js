/*
 * Material You New Tab
 * Copyright (c) 2024-2026 Prem, 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 */
(function () {
    "use strict";
    const core = window.MyntProductivityCore;
    if (!core) return;
    const $ = id => document.getElementById(id);
    const copy = {
        en: {
            quick: "Quick actions", focus: "Focus session", searchActions: "Search actions, settings or shortcuts…",
            actionsTitle: "A shortcut to everything", actionsSub: "Your tools, one search away.", close: "Close",
            navigate: "Navigate", select: "Open", dismiss: "Close", actionsEmpty: "No matching actions",
            actionsEmptySub: "Try weather, theme, focus, or a shortcut name.", tools: "Tools", settings: "Settings", links: "Your shortcuts",
            focusTitle: "Make room for focus", focusSub: "One intention. A little uninterrupted time.",
            intention: "What are you working on?", intentionPlaceholder: "Choose one thing to move forward…",
            focus25: "Focus · 25 min", focus50: "Deep work · 50 min", break5: "Break · 5 min", break15: "Rest · 15 min",
            start: "Start session", pause: "Pause", resume: "Resume", again: "Start again", reset: "Reset",
            ready: "Ready when you are", running: "One thing at a time", paused: "Take your time", complete: "Session complete. Nicely done.",
            quiet: "Quiet view", quietSub: "Keep the clock and search. Hide distractions.", today: "Today", sessions: "Focus sessions", minutes: "Minutes focused",
            sessionDone: "Focus session complete. Time for a break!", breakDone: "Break complete. Ready for your next session?",
            quietOn: "Quiet view enabled", quietOff: "Full view restored", resetDone: "Timer reset",
            settingsTitle: "Make it yours", settingsSub: "A new tab that works your way.", settingsSearch: "Find a setting…",
            clear: "Clear search", settingsEmpty: "No settings found", settingsEmptySub: "Try clock, wallpaper, or language.",
            results: "Matching sections", webSearch: "Search the web", editShortcuts: "Edit shortcuts", appearance: "Colors & appearance",
            weather: "Weather & location", clock: "Clock & greeting", personalization: "Widgets & tools", search: "Search preferences",
            shortcuts: "Shortcuts", general: "Language & backup", light: "Use light theme", dark: "Use dark theme", system: "Follow system theme",
            quietCommand: "Toggle quiet view", name: "Your name", mic: "Voice search", bookmarkSearch: "Search bookmarks",
            editText: "Edit your custom text", addTask: "Add task", taskInput: "New task", saved: "Preference saved",
            settingJump: "Go to section", shortcutHint: "Ctrl K", switchHelp: "Choose a session length before starting. Reset to change an active session.",
            fromTask: "Or choose from your pending tasks…", tasks: "Task list",
            themeToggle: "Toggle theme", themeDark: "Dark theme enabled 🌙", themeLight: "Light theme enabled ☀️",
            ambientTitle: "Ambient Sanctuary", ambientSub: "Background sounds to help you focus",
            ambientRain: "Gentle Rain 🌧️", ambientWaves: "Ocean Waves 🌊", ambientNoise: "Deep Focus 🎧",
            ambientPlay: "Play sound", ambientStop: "Mute sound",
            hishamAgent: "Hisham Agent ✦", clockSwitch: "Switch clock style (Analog / Digital)",
        },
        ar_SA: {
            quick: "الأوامر السريعة", focus: "جلسة تركيز", searchActions: "ابحث عن أمر أو إعداد أو اختصار…",
            actionsTitle: "كل شيء أقرب إليك", actionsSub: "أدواتك وإعداداتك، ببحث واحد.", close: "إغلاق",
            navigate: "تنقّل", select: "فتح", dismiss: "إغلاق", actionsEmpty: "لا توجد أوامر مطابقة",
            actionsEmptySub: "جرّب الطقس أو المظهر أو التركيز أو اسم اختصار.", tools: "الأدوات", settings: "الإعدادات", links: "اختصاراتك",
            focusTitle: "مساحة للتركيز", focusSub: "هدف واحد، ووقت هادئ لإنجازه.",
            intention: "ما الذي تعمل عليه؟", intentionPlaceholder: "اختر شيئاً واحداً لتنجزه…",
            focus25: "تركيز · ٢٥ دقيقة", focus50: "عمل عميق · ٥٠ دقيقة", break5: "استراحة · ٥ دقائق", break15: "راحة · ١٥ دقيقة",
            start: "ابدأ الجلسة", pause: "إيقاف مؤقت", resume: "متابعة", again: "جلسة جديدة", reset: "إعادة الضبط",
            ready: "ابدأ عندما تكون مستعداً", running: "خطوة واحدة في كل مرة", paused: "خذ وقتك", complete: "اكتملت الجلسة، أحسنت!",
            quiet: "واجهة هادئة", quietSub: "أبقِ الساعة والبحث وأخفِ المشتتات.", today: "اليوم", sessions: "جلسات التركيز", minutes: "دقائق التركيز",
            sessionDone: "اكتملت جلسة التركيز. حان وقت الاستراحة!", breakDone: "انتهت الاستراحة. جاهز لجلسة جديدة؟",
            quietOn: "تم تفعيل الواجهة الهادئة", quietOff: "تمت استعادة الواجهة الكاملة", resetDone: "تمت إعادة ضبط المؤقّت",
            settingsTitle: "على ذوقك", settingsSub: "تبويب جديد يناسب أسلوبك.", settingsSearch: "ابحث عن إعداد…",
            clear: "مسح البحث", settingsEmpty: "لا توجد إعدادات مطابقة", settingsEmptySub: "جرّب الساعة أو الخلفية أو اللغة.",
            results: "الأقسام المطابقة", webSearch: "البحث في الويب", editShortcuts: "تعديل الاختصارات", appearance: "الألوان والمظهر",
            weather: "الطقس والموقع", clock: "الساعة والتحية", personalization: "العناصر والأدوات", search: "تفضيلات البحث",
            shortcuts: "الاختصارات", general: "اللغة والنسخ الاحتياطي", light: "استخدام المظهر الفاتح", dark: "استخدام المظهر الداكن", system: "اتباع مظهر النظام",
            quietCommand: "تبديل الواجهة الهادئة", name: "اسمك", mic: "البحث الصوتي", bookmarkSearch: "البحث في الإشارات المرجعية",
            editText: "تعديل النص الشخصي", addTask: "إضافة مهمة", taskInput: "مهمة جديدة", saved: "تم حفظ التفضيل",
            settingJump: "الانتقال إلى القسم", shortcutHint: "Ctrl K", switchHelp: "اختر المدة قبل البدء. أعد ضبط الجلسة الحالية لتغيير مدتها.",
            fromTask: "أو اختر من مهامك المتبقية…", tasks: "قائمة المهام",
            themeToggle: "تبديل المظهر", themeDark: "تم تفعيل المظهر الداكن 🌙", themeLight: "تم تفعيل المظهر الفاتح ☀️",
            ambientTitle: "أجواء السكينة والتركيز", ambientSub: "أصوات خلفية هادئة تعزل المشتتات",
            ambientRain: "أمطار هادئة 🌧️", ambientWaves: "أمواج البحر 🌊", ambientNoise: "تركيز عميق 🎧",
            ambientPlay: "تشغيل الصوت", ambientStop: "كتم الصوت",
            hishamAgent: "Hisham Agent ✦", clockSwitch: "تبديل شكل الساعة (عقارب / رقمية)",
        },
    };
    const t = key => (copy[window.currentLanguage] || copy.en)[key] || copy.en[key] || key;
    const paths = {
        command: '<path d="M9 7V5a2 2 0 1 0-2 2h10a2 2 0 1 0-2-2v14a2 2 0 1 0 2-2H7a2 2 0 1 0 2 2V7"/>',
        timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M9 2h6M12 2v3M18 5l2 2"/>',
        search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
        close: '<path d="m6 6 12 12M6 18 18 6"/>',
        arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
        settings: '<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="2"/><circle cx="15" cy="17" r="2"/>',
        moon: '<path d="M20 15a8 8 0 0 1-11-11 8 8 0 1 0 11 11Z"/>',
        sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
        sparkle: '<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"/>',
        volume: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14"/>',
        volumeMute: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>',
        link: '<path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2"/>',
        check: '<path d="m5 12 4 4L19 6"/>',
    };
    const icon = name => `<svg class="keep-color" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.settings}</svg>`;
    function read(key, fallback) {
        try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
    }
    function write(key, value) {
        try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* The timer remains usable if storage is full. */ }
    }
    const host = document.createElement("div");
    host.id = "experienceRoot";
    host.innerHTML = `
        <nav class="ux-dock" aria-label="Quick tools">
            <button id="quickActionsButton" class="ux-dock-button" type="button" aria-haspopup="dialog" aria-controls="commandPalette">${icon("command")}<span data-ux-text="quick"></span><kbd id="commandKeyHint">Ctrl K</kbd></button>
            <span class="ux-dock-divider" aria-hidden="true"></span>
            <button id="focusSessionButton" class="ux-dock-button" type="button" aria-haspopup="dialog" aria-controls="focusDialog">${icon("timer")}<span id="focusDockLabel"></span><span id="focusDockTime" class="ux-dock-time" hidden></span></button>
            <span class="ux-dock-divider" aria-hidden="true"></span>
            <button id="themeQuickToggle" class="ux-dock-button ux-theme-toggle" type="button" aria-label="Toggle theme" title="Toggle theme"><span id="themeQuickIcon">${icon("moon")}</span></button>
        </nav>
        <dialog id="commandPalette" class="ux-dialog ux-command-dialog" aria-labelledby="commandTitle">
            <header class="ux-dialog-header"><div><h2 id="commandTitle" data-ux-text="actionsTitle"></h2><p data-ux-text="actionsSub"></p></div><button type="button" class="ux-icon-button" data-ux-close="commandPalette" data-ux-label="close">${icon("close")}</button></header>
            <div class="ux-command-search">${icon("search")}<input id="commandSearch" type="search" autocomplete="off" spellcheck="false" data-ux-placeholder="searchActions" data-ux-label="searchActions" role="combobox" aria-autocomplete="list" aria-expanded="true" aria-controls="commandResults"><kbd>Esc</kbd></div>
            <div id="commandResults" class="ux-command-results" role="listbox" aria-label="Actions"></div>
            <div id="commandEmpty" class="ux-empty" hidden>${icon("search")}<strong data-ux-text="actionsEmpty"></strong><p data-ux-text="actionsEmptySub"></p></div>
            <footer class="ux-command-footer"><span><kbd>↑ ↓</kbd> <span data-ux-text="navigate"></span></span><span><kbd>↵</kbd> <span data-ux-text="select"></span></span><span><kbd>Esc</kbd> <span data-ux-text="dismiss"></span></span></footer>
        </dialog>
        <dialog id="focusDialog" class="ux-dialog ux-focus-dialog" aria-labelledby="focusTitle">
            <header class="ux-dialog-header"><div><span class="ux-eyebrow" data-ux-text="focus"></span><h2 id="focusTitle" data-ux-text="focusTitle"></h2><p data-ux-text="focusSub"></p></div><button type="button" class="ux-icon-button" data-ux-close="focusDialog" data-ux-label="close">${icon("close")}</button></header>
            <label class="ux-field-label" for="focusIntention" data-ux-text="intention"></label>
            <input id="focusIntention" class="ux-text-input" type="text" maxlength="120" autocomplete="off" dir="auto" data-ux-placeholder="intentionPlaceholder">
            <select id="focusTaskSelect" class="ux-text-input ux-task-select" data-ux-label="fromTask" hidden></select>
            <div class="ux-session-presets" role="group" aria-label="Session length" aria-describedby="focusPresetHelp">
                <button type="button" data-focus-minutes="25" data-ux-text="focus25"></button><button type="button" data-focus-minutes="50" data-ux-text="focus50"></button><button type="button" data-focus-minutes="5" data-ux-text="break5"></button><button type="button" data-focus-minutes="15" data-ux-text="break15"></button>
            </div>
            <p id="focusPresetHelp" class="ux-sr-only" data-ux-text="switchHelp"></p>
            <div class="ux-timer-face"><svg class="ux-timer-ring keep-color" viewBox="0 0 220 220" aria-hidden="true"><circle class="ux-ring-track" cx="110" cy="110" r="98"/><circle id="focusRing" class="ux-ring-progress" cx="110" cy="110" r="98" pathLength="100"/></svg><div class="ux-timer-center"><span id="focusTime" role="timer" aria-live="off" dir="ltr">25:00</span><span id="focusState"></span></div></div>
            <div class="ux-timer-controls"><button id="focusToggle" class="ux-primary" type="button"></button><button id="focusReset" class="ux-secondary" type="button" data-ux-text="reset"></button></div>
            <div class="ux-ambient-block" role="region" aria-label="Ambient focus sounds">
                <div class="ux-ambient-header">
                    <div>
                        <strong data-ux-text="ambientTitle"></strong>
                        <p data-ux-text="ambientSub"></p>
                    </div>
                    <button type="button" id="ambientToggle" class="ux-ambient-toggle" aria-pressed="false">${icon("volumeMute")}<span data-ux-text="ambientPlay"></span></button>
                </div>
                <div class="ux-ambient-controls">
                    <div class="ux-ambient-presets" role="group" aria-label="Sound preset">
                        <button type="button" class="ux-ambient-preset" data-preset="rain" data-ux-text="ambientRain"></button>
                        <button type="button" class="ux-ambient-preset" data-preset="waves" data-ux-text="ambientWaves"></button>
                        <button type="button" class="ux-ambient-preset" data-preset="focus" data-ux-text="ambientNoise"></button>
                    </div>
                    <div class="ux-ambient-slider-wrap">
                        <input type="range" id="ambientVolume" min="0.05" max="1" step="0.05" value="0.35" aria-label="Volume">
                    </div>
                </div>
            </div>
            <label class="ux-quiet-option"><div><strong data-ux-text="quiet"></strong><p data-ux-text="quietSub"></p></div><input id="quietViewCheckbox" type="checkbox" role="switch"></label>
            <div class="ux-focus-summary"><span class="ux-eyebrow" data-ux-text="today"></span><div><strong id="focusTodaySessions">0</strong><span data-ux-text="sessions"></span></div><div><strong id="focusTodayMinutes">0</strong><span data-ux-text="minutes"></span></div></div>
        </dialog>
        <div id="experienceToast" class="ux-toast" role="status" aria-live="polite" aria-atomic="true" hidden>${icon("check")}<span></span></div>`;
    document.body.appendChild(host);

    let toastTimer;
    function toast(message) {
        clearTimeout(toastTimer);
        $("experienceToast").querySelector("span").textContent = message;
        $("experienceToast").hidden = false;
        toastTimer = setTimeout(() => { $("experienceToast").hidden = true; }, 4000);
    }
    // Shared with other scripts (quotes copy, voice search, ai-tools save…)
    window.uxToast = toast;
    document.querySelectorAll("[data-ux-close]").forEach(button => {
        button.addEventListener("click", () => $(button.dataset.uxClose).close());
    });
    for (const dialog of [$("commandPalette"), $("focusDialog")]) {
        // Close only genuine backdrop clicks; content clicks and drags remain intact.
        let downOnBackdrop = false;
        dialog.addEventListener("pointerdown", event => {
            const r = dialog.getBoundingClientRect();
            downOnBackdrop = event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom;
        });
        dialog.addEventListener("click", event => {
            const r = dialog.getBoundingClientRect();
            if (downOnBackdrop && (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom)) dialog.close();
            downOnBackdrop = false;
        });
    }

    // Settings discovery: search existing controls without changing their values.
    const menu = $("menuCont");
    const menuHeader = menu.querySelector(":scope > .topDiv");
    const settingsTools = document.createElement("div");
    settingsTools.className = "ux-settings-tools";
    settingsTools.innerHTML = `<div class="ux-settings-caption"><span class="ux-eyebrow" data-ux-text="settingsTitle"></span><p data-ux-text="settingsSub"></p></div><div class="ux-settings-search">${icon("search")}<input id="settingsSearch" type="search" autocomplete="off" data-ux-placeholder="settingsSearch" data-ux-label="settingsSearch"><button id="settingsSearchClear" class="ux-icon-button" type="button" data-ux-label="clear" hidden>${icon("close")}</button></div><nav id="settingsNavigation" class="ux-settings-nav" aria-label="Settings sections"></nav><div id="settingsResultsStatus" class="ux-settings-status" role="status" hidden></div>`;
    menuHeader.appendChild(settingsTools);
    $("menuCloseButton").innerHTML = icon("close");
    menuHeader.appendChild($("menuCloseButton"));
    const emptySettings = document.createElement("div");
    emptySettings.id = "settingsEmpty";
    emptySettings.className = "ux-empty";
    emptySettings.hidden = true;
    emptySettings.innerHTML = `${icon("search")}<strong data-ux-text="settingsEmpty"></strong><p data-ux-text="settingsEmptySub"></p>`;
    $("overviewPage").appendChild(emptySettings);

    const sectionKeys = {
        shortcutsSectionTitle: ["shortcuts", "shortcuts links bookmarks اختصارات"],
        personalizationSectionTitle: ["personalization", "widgets tools todo bookmarks layout تخصيص مهام اشارات ادوات تخطيط"],
        clockSectionTitle: ["clock", "clock time greeting ساعة وقت تحية"],
        searchSectionTitle: ["search", "search microphone suggestions بحث ميكروفون اقتراحات"],
        weatherSectionTitle: ["weather", "weather location temperature طقس موقع حرارة"],
        appearanceSectionTitle: ["appearance", "appearance color theme wallpaper background gradient مظهر الوان لون خلفية سمة تدرج"],
        settingsSectionTitle: ["general", "settings language backup restore لغة اعدادات نسخة احتياطي استعادة"],
    };
    const sections = [...$("overviewPage").querySelectorAll(".section")];
    const previousExpanded = new Map();
    let filtering = false;
    sections.forEach((section, index) => {
        const header = section.querySelector(".sectionHeader");
        const inner = section.querySelector(".sectionInner");
        section.id = `settings-section-${index}`;
        header.tabIndex = 0;
        if (inner) {
            inner.id = `settings-section-body-${index}`;
            header.setAttribute("aria-controls", inner.id);
        }
        const syncSection = () => {
            const expanded = section.classList.contains("expanded");
            header.setAttribute("aria-expanded", String(expanded));
            if (inner) inner.inert = !expanded;
        };
        syncSection();
        new MutationObserver(syncSection).observe(section, { attributes: true, attributeFilter: ["class"] });
        header.addEventListener("keydown", event => {
            if (event.key === "Enter" || event.key === " ") { event.preventDefault(); header.click(); }
        });
        const button = document.createElement("button");
        button.type = "button";
        button.dataset.section = header.querySelector(".sectionTitle").id;
        button.addEventListener("click", () => jumpToSection(button.dataset.section));
        $("settingsNavigation").appendChild(button);
    });
    function sectionTitle(section) { return section.querySelector(".sectionTitle"); }
    function filterSettings() {
        const query = $("settingsSearch").value.trim();
        $("overviewPage").classList.toggle("ux-searching", Boolean(query));
        if (query && !filtering) {
            sections.forEach(section => previousExpanded.set(section, section.classList.contains("expanded")));
            filtering = true;
        }
        let count = 0;
        for (const section of sections) {
            const title = sectionTitle(section);
            const aliases = sectionKeys[title.id]?.[1] || "";
            const sectionMatch = core.matchesQuery(`${title.textContent} ${aliases}`, query);
            const contentMatch = core.matchesQuery(section.textContent, query);
            section.classList.toggle("ux-filter-hidden", Boolean(query) && !sectionMatch && !contentMatch);
            if (!section.classList.contains("ux-filter-hidden")) count++;
            if (query && (sectionMatch || contentMatch)) section.classList.add("expanded");
            if (!query && filtering) section.classList.toggle("expanded", previousExpanded.get(section));
            section.querySelectorAll(".ttcont").forEach(row => {
                const inputText = [...row.querySelectorAll("input")].map(input => `${input.placeholder} ${input.getAttribute("aria-label") || ""}`).join(" ");
                row.classList.toggle("ux-filter-hidden", Boolean(query) && !sectionMatch && !core.matchesQuery(`${row.textContent} ${inputText}`, query));
            });
        }
        if (!query) { filtering = false; previousExpanded.clear(); }
        $("settingsSearchClear").hidden = !query;
        $("settingsEmpty").hidden = !query || count > 0;
        $("settingsResultsStatus").hidden = !query;
        $("settingsResultsStatus").textContent = `${t("results")}: ${count}`;
        $("optCont").scrollTop = 0;
    }
    $("settingsSearch").addEventListener("input", filterSettings);
    $("settingsSearchClear").addEventListener("click", () => {
        $("settingsSearch").value = ""; filterSettings(); $("settingsSearch").focus();
    });
    $("settingsSearch").addEventListener("keydown", event => {
        if (event.key === "Escape" && $("settingsSearch").value) {
            event.stopPropagation(); event.preventDefault(); $("settingsSearchClear").click();
        }
    });
    function jumpToSection(id) {
        $("settingsSearch").value = "";
        filterSettings();
        if (typeof pageReset === "function") pageReset();
        const section = $(id)?.closest(".section");
        if (!section) return;
        section.classList.add("expanded");
        section.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth", block: "start" });
        section.querySelector(".sectionHeader").focus({ preventScroll: true });
        $("settingsNavigation").querySelectorAll("button").forEach(button => button.setAttribute("aria-current", String(button.dataset.section === id)));
    }
    new MutationObserver(() => {
        const editing = $("shortcutEditPage").style.display === "block";
        settingsTools.hidden = editing;
    }).observe($("shortcutEditPage"), { attributes: true, attributeFilter: ["style"] });

    // Command palette. Arrow keys keep focus in the combobox; native dialog traps Tab.
    let results = [];
    let activeIndex = 0;
    function commandItems() {
        const items = [
            { label: t("focus"), keywords: "focus timer pomodoro session تركيز مؤقت جلسة", group: "tools", glyph: "timer", action: openFocus },
            { label: t("hishamAgent"), keywords: "hisham agent ai assistant ذكاء اصطناعي مساعد هشام بوت شات", group: "tools", glyph: "sparkle", action: () => { const tile = $("hishamAgentTile"); if (tile) tile.click(); } },
            { label: t("themeToggle"), keywords: "theme toggle light dark مظهر فاتح داكن تبديل سمة", group: "tools", glyph: "moon", action: () => { $("themeQuickToggle")?.click(); } },
            { label: t("clockSwitch"), keywords: "clock digital analog switch ساعة رقمية عقارب تبديل", group: "tools", glyph: "timer", action: () => { $("digitalCheckbox")?.click(); toast(t("saved")); } },
            { label: t("webSearch"), keywords: "search web بحث ويب", group: "tools", glyph: "search", action: () => { $("searchQ").focus(); } },
            { label: t("quietCommand"), keywords: "quiet calm distraction هدوء هادئة مشتتات", group: "tools", glyph: "moon", action: () => setQuiet(!$("quietViewCheckbox").checked, true) },
            { label: t("tasks"), keywords: "todo task list مهام مهمة قائمة", group: "tools", glyph: "check", action: () => {
                if (!$("todoListCheckbox").checked) $("todoListCheckbox").click();
                if ($("todoContainer").style.display === "none" || !$("todoContainer").style.display) $("todoListCont").click();
            } },
        ];
        for (const [id, [key, keywords]] of Object.entries(sectionKeys)) {
            items.push({ label: t(key), keywords, group: "settings", glyph: "settings", action: () => {
                openMenuBar(); jumpToSection(id);
            } });
        }
        items.push({ label: t("editShortcuts"), keywords: "edit shortcut link تعديل اختصار رابط", group: "settings", glyph: "link", action: () => {
            openMenuBar(); $("shortcutEditButton").click();
        } });
        for (const [mode, key] of [["light", "light"], ["dark", "dark"], ["system", "system"]]) {
            const modeKeyword = { light: "فاتح", dark: "داكن", system: "نظام" }[mode];
            items.push({ label: t(key), keywords: `theme ${mode} مظهر سمة ${modeKeyword}`, group: "settings", glyph: "moon", action: () => {
                document.querySelector(`.themeSegBtn[data-theme="${mode}"]`)?.click();
                toast(t("saved"));
            } });
        }
        document.querySelectorAll(".shortcutsContainer .shortcuts a").forEach(link => {
            const name = link.querySelector(".shortcut-name")?.textContent || link.textContent.trim() || link.title;
            if (!name || !/^https?:$/.test(new URL(link.href, location.href).protocol)) return;
            items.push({ label: name, keywords: link.href, group: "links", glyph: "link", action: () => link.click() });
        });
        return items;
    }
    function highlightResult() {
        const rows = [...$("commandResults").querySelectorAll("[role=option]")];
        rows.forEach((row, index) => row.setAttribute("aria-selected", String(index === activeIndex)));
        const row = rows[activeIndex];
        if (row) {
            $("commandSearch").setAttribute("aria-activedescendant", row.id);
            row.scrollIntoView({ block: "nearest" });
        } else $("commandSearch").removeAttribute("aria-activedescendant");
    }
    function runCommand(index) {
        const item = results[index];
        if (!item) return;
        $("commandPalette").close();
        item.action();
    }
    function renderCommands() {
        const query = $("commandSearch").value;
        results = commandItems().filter(item => core.matchesQuery(`${item.label} ${item.keywords}`, query));
        activeIndex = 0;
        $("commandResults").replaceChildren();
        let lastGroup;
        results.forEach((item, index) => {
            if (item.group !== lastGroup) {
                const heading = document.createElement("div");
                heading.className = "ux-command-group"; heading.setAttribute("role", "presentation"); heading.textContent = t(item.group);
                $("commandResults").appendChild(heading); lastGroup = item.group;
            }
            const row = document.createElement("div");
            row.id = `ux-command-${index}`; row.className = "ux-command-item";
            row.setAttribute("role", "option");
            row.innerHTML = `${icon(item.glyph)}<span></span>${icon("arrow")}`;
            row.querySelector("span").textContent = item.label;
            row.addEventListener("click", () => runCommand(index));
            row.addEventListener("pointermove", () => { if (activeIndex !== index) { activeIndex = index; highlightResult(); } });
            $("commandResults").appendChild(row);
        });
        $("commandEmpty").hidden = results.length > 0;
        highlightResult();
    }
    function openCommands() {
        if ($("commandPalette").open) { $("commandSearch").focus(); return; }
        if ($("focusDialog").open) $("focusDialog").close();
        $("commandSearch").value = "";
        $("commandPalette").showModal(); renderCommands(); $("commandSearch").focus();
    }
    $("quickActionsButton").addEventListener("click", openCommands);
    $("commandSearch").addEventListener("input", renderCommands);
    $("commandSearch").addEventListener("keydown", event => {
        if (event.isComposing) return;
        if (event.key === "ArrowDown" || event.key === "ArrowUp") {
            event.preventDefault();
            if (results.length) activeIndex = (activeIndex + (event.key === "ArrowDown" ? 1 : -1) + results.length) % results.length;
            highlightResult();
        } else if (event.key === "Enter") { event.preventDefault(); runCommand(activeIndex); }
    });

    // A deadline-based timer survives reloading, tab suspension and multiple tabs.
    const sessionKey = "myntFocusSessionV1";
    const historyKey = "myntFocusHistoryV1";
    let session = core.normalizeSession(read(sessionKey, {}));
    let ticker;
    const originalTitle = document.title;
    function saveSession() { write(sessionKey, session); }
    function stats() {
        const history = read(historyKey, []);
        const records = Array.isArray(history) ? history.filter(item => item && Number.isFinite(item.at) && Number.isFinite(item.minutes)) : [];
        const today = records.filter(item => core.localDay(item.at) === core.localDay());
        $("focusTodaySessions").textContent = today.length;
        $("focusTodayMinutes").textContent = today.reduce((sum, item) => sum + item.minutes, 0);
    }
    function finishSession() {
        // Read again to avoid recording the same session in another new-tab window.
        const saved = core.normalizeSession(read(sessionKey, session));
        if (saved.id === session.id && saved.status === "complete") { session = saved; return; }
        session.status = "complete"; session.remaining = 0; session.endsAt = 0;
        saveSession();
        if (session.minutes >= 25) {
            write(historyKey, core.recordCompletion(read(historyKey, []), session));
        }
        toast(t(session.minutes >= 25 ? "sessionDone" : "breakDone"));
        if (typeof ambientAudio !== "undefined" && ambientAudio.playChime) ambientAudio.playChime();
        stats();
    }
    function updateTimer() {
        let remaining = core.remainingSeconds(session);
        if (session.status === "running" && remaining === 0) { finishSession(); remaining = 0; }
        $("focusTime").textContent = core.formatTime(remaining);
        $("focusRing").style.strokeDashoffset = String(100 - remaining / (session.minutes * 60) * 100);
        const stateText = t({ idle: "ready", running: "running", paused: "paused", complete: "complete" }[session.status]);
        if ($("focusState").textContent !== stateText) $("focusState").textContent = stateText;
        $("focusToggle").textContent = t({ idle: "start", running: "pause", paused: "resume", complete: "again" }[session.status]);
        $("focusDockLabel").textContent = t("focus");
        $("focusDockTime").hidden = !["running", "paused"].includes(session.status);
        $("focusDockTime").textContent = core.formatTime(remaining);
        $("focusSessionButton").classList.toggle("ux-session-active", session.status === "running");
        $("focusSessionButton").setAttribute("aria-label", `${t("focus")}${$("focusDockTime").hidden ? "" : ` ${core.formatTime(remaining)}`}`);
        document.title = session.status === "running" ? `${core.formatTime(remaining)} · ${t("focus")} — MYNT` : originalTitle;
        $("focusIntention").disabled = session.status === "running";
        $("focusTaskSelect").disabled = session.status === "running";
        $("focusReset").disabled = session.status === "idle";
        document.querySelectorAll("[data-focus-minutes]").forEach(button => {
            button.setAttribute("aria-pressed", String(Number(button.dataset.focusMinutes) === session.minutes));
            button.disabled = ["running", "paused"].includes(session.status);
        });
        if (session.status !== "running" && ticker) { clearInterval(ticker); ticker = null; }
        if (session.status === "running" && !ticker) ticker = setInterval(updateTimer, 1000);
    }
    function openFocus() {
        if ($("commandPalette").open) $("commandPalette").close();
        $("focusIntention").value = session.intention;
        const tasks = read("todoList", {});
        $("focusTaskSelect").replaceChildren(new Option(t("fromTask"), ""));
        if (tasks && typeof tasks === "object") {
            Object.entries(tasks).filter(([, task]) => task && task.status !== "completed" && typeof task.title === "string").forEach(([id, task]) => {
                $("focusTaskSelect").add(new Option(task.title, id));
            });
        }
        $("focusTaskSelect").hidden = $("focusTaskSelect").options.length <= 1;
        stats(); updateTimer();
        if (!$("focusDialog").open) $("focusDialog").showModal();
    }
    $("focusSessionButton").addEventListener("click", openFocus);
    $("focusToggle").addEventListener("click", () => {
        if (session.status === "running") {
            session.remaining = core.remainingSeconds(session); session.status = "paused"; session.endsAt = 0;
        } else {
            if (session.status === "complete") session.remaining = session.minutes * 60;
            if (session.status !== "paused" || !session.id) session.id = crypto.randomUUID();
            session.intention = $("focusIntention").value.trim();
            session.endsAt = Date.now() + session.remaining * 1000; session.status = "running";
        }
        saveSession(); updateTimer();
    });
    $("focusReset").addEventListener("click", () => {
        session.status = "idle"; session.endsAt = 0; session.remaining = session.minutes * 60; session.id = "";
        saveSession(); updateTimer(); toast(t("resetDone"));
    });
    $("focusIntention").addEventListener("input", () => { session.intention = $("focusIntention").value; saveSession(); });
    $("focusTaskSelect").addEventListener("change", () => {
        if (!$("focusTaskSelect").value) return;
        session.intention = $("focusTaskSelect").selectedOptions[0].textContent.slice(0, 120);
        $("focusIntention").value = session.intention; saveSession();
    });
    document.querySelectorAll("[data-focus-minutes]").forEach(button => button.addEventListener("click", () => {
        session.minutes = Number(button.dataset.focusMinutes); session.remaining = session.minutes * 60; session.status = "idle"; session.id = "";
        saveSession(); updateTimer();
    }));
    function setQuiet(enabled, announce = false) {
        $("quietViewCheckbox").checked = enabled;
        document.body.classList.toggle("ux-quiet-view", enabled);
        write("myntQuietView", enabled);
        if (announce) toast(t(enabled ? "quietOn" : "quietOff"));
    }
    $("quietViewCheckbox").addEventListener("change", () => setQuiet($("quietViewCheckbox").checked, true));
    setQuiet(read("myntQuietView", false) === true);
    window.addEventListener("storage", event => {
        if (event.key === sessionKey || event.key === null) {
            session = core.normalizeSession(read(sessionKey, {})); $("focusIntention").value = session.intention; updateTimer(); stats();
        }
        if (event.key === historyKey) stats();
        if (event.key === "myntQuietView" || event.key === null) setQuiet(read("myntQuietView", false) === true);
    });
    document.addEventListener("visibilitychange", () => { if (!document.hidden) { updateTimer(); stats(); } });
    window.addEventListener("pageshow", updateTimer);

    // ── Luxury Ambient Sanctuary Audio (Native Web Audio API) ─────────────
    const ambientAudio = {
        ctx: null,
        currentPreset: "rain",
        isPlaying: false,
        nodes: [],
        gainNode: null,
        volume: Number(read("myntAmbientVol", 0.35)),

        init() {
            if (!this.ctx) {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                if (!AudioCtx) return false;
                this.ctx = new AudioCtx();
            }
            if (this.ctx.state === "suspended") {
                this.ctx.resume();
            }
            return true;
        },

        createNoiseBuffer(type) {
            const bufferSize = this.ctx.sampleRate * 3;
            const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
            const data = buffer.getChannelData(0);
            let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
            let lastOut = 0;
            for (let i = 0; i < bufferSize; i++) {
                const white = Math.random() * 2 - 1;
                if (type === "brown") {
                    data[i] = (lastOut + (0.02 * white)) / 1.02;
                    lastOut = data[i];
                    data[i] *= 3.5;
                } else if (type === "pink") {
                    b0 = 0.99886 * b0 + white * 0.0555179;
                    b1 = 0.99332 * b1 + white * 0.0750759;
                    b2 = 0.96900 * b2 + white * 0.1538520;
                    b3 = 0.86650 * b3 + white * 0.3104856;
                    b4 = 0.55000 * b4 + white * 0.5329522;
                    b5 = -0.7616 * b5 - white * 0.0168980;
                    data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
                    b6 = white * 0.115926;
                } else {
                    data[i] = white * 0.25;
                }
            }
            return buffer;
        },

        play(preset) {
            if (!this.init()) return;
            const chosen = preset || this.currentPreset || "rain";
            this.stop(false);

            this.gainNode = this.ctx.createGain();
            this.gainNode.gain.setValueAtTime(0.001, this.ctx.currentTime);
            this.gainNode.gain.exponentialRampToValueAtTime(Math.max(0.001, this.volume), this.ctx.currentTime + 0.5);
            this.gainNode.connect(this.ctx.destination);

            if (chosen === "rain") {
                const src = this.ctx.createBufferSource();
                src.buffer = this.createNoiseBuffer("pink");
                src.loop = true;
                const lp = this.ctx.createBiquadFilter();
                lp.type = "lowpass";
                lp.frequency.value = 1200;
                src.connect(lp);
                lp.connect(this.gainNode);
                src.start();
                this.nodes.push(src, lp);
            } else if (chosen === "waves") {
                const src = this.ctx.createBufferSource();
                src.buffer = this.createNoiseBuffer("brown");
                src.loop = true;
                const filter = this.ctx.createBiquadFilter();
                filter.type = "lowpass";
                filter.frequency.value = 380;
                filter.Q.value = 2.5;

                const lfo = this.ctx.createOscillator();
                lfo.frequency.value = 0.14;
                const lfoGain = this.ctx.createGain();
                lfoGain.gain.value = 280;
                lfo.connect(lfoGain);
                lfoGain.connect(filter.frequency);

                src.connect(filter);
                filter.connect(this.gainNode);
                src.start();
                lfo.start();
                this.nodes.push(src, filter, lfo, lfoGain);
            } else {
                const src = this.ctx.createBufferSource();
                src.buffer = this.createNoiseBuffer("brown");
                src.loop = true;
                const lp = this.ctx.createBiquadFilter();
                lp.type = "lowpass";
                lp.frequency.value = 600;
                src.connect(lp);
                lp.connect(this.gainNode);
                src.start();
                this.nodes.push(src, lp);
            }

            this.currentPreset = chosen;
            this.isPlaying = true;
            write("myntAmbientPreset", chosen);
            this.updateUI();
        },

        stop(fade = true) {
            if (!this.isPlaying || !this.gainNode) return;
            const nodesToStop = [...this.nodes];
            const currentGain = this.gainNode;
            this.nodes = [];
            this.gainNode = null;
            this.isPlaying = false;

            if (fade && this.ctx) {
                try {
                    currentGain.gain.setValueAtTime(currentGain.gain.value, this.ctx.currentTime);
                    currentGain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.3);
                    setTimeout(() => {
                        nodesToStop.forEach(n => { try { n.stop?.(); n.disconnect?.(); } catch(_) {} });
                    }, 350);
                } catch(_) {
                    nodesToStop.forEach(n => { try { n.stop?.(); n.disconnect?.(); } catch(_) {} });
                }
            } else {
                nodesToStop.forEach(n => { try { n.stop?.(); n.disconnect?.(); } catch(_) {} });
            }
            this.updateUI();
        },

        setVolume(val) {
            this.volume = Math.max(0.01, Math.min(1, val));
            write("myntAmbientVol", this.volume);
            if (this.gainNode && this.ctx) {
                this.gainNode.gain.setValueAtTime(this.volume, this.ctx.currentTime);
            }
        },

        updateUI() {
            const toggle = $("ambientToggle");
            if (toggle) {
                toggle.setAttribute("aria-pressed", String(this.isPlaying));
                toggle.classList.toggle("ux-active", this.isPlaying);
                toggle.innerHTML = `${icon(this.isPlaying ? "volume" : "volumeMute")}<span>${t(this.isPlaying ? "ambientStop" : "ambientPlay")}</span>`;
            }
            document.querySelectorAll(".ux-ambient-preset").forEach(btn => {
                btn.classList.toggle("ux-active", btn.dataset.preset === this.currentPreset);
                btn.setAttribute("aria-pressed", String(btn.dataset.preset === this.currentPreset));
            });
        },

        playChime() {
            if (!this.init()) return;
            try {
                const now = this.ctx.currentTime;
                const freqs = [528, 1056, 1584];
                freqs.forEach((freq, idx) => {
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = "sine";
                    osc.frequency.setValueAtTime(freq, now);
                    const initialGain = 0.12 / (idx + 1);
                    gain.gain.setValueAtTime(initialGain, now);
                    gain.gain.exponentialRampToValueAtTime(0.00001, now + 2.8);
                    osc.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc.start(now);
                    osc.stop(now + 2.8);
                });
            } catch { /* AudioContext might be unavailable or blocked */ }
        },

        playTap() {
            if (!this.init()) return;
            try {
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = "sine";
                osc.frequency.setValueAtTime(800, now);
                osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);
                gain.gain.setValueAtTime(0.035, now);
                gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now);
                osc.stop(now + 0.04);
            } catch { /* AudioContext might be unavailable */ }
        }
    };
    window.MyntAmbientAudio = ambientAudio;

    // Ambient UI wiring
    $("ambientToggle")?.addEventListener("click", () => {
        if (ambientAudio.isPlaying) ambientAudio.stop();
        else ambientAudio.play(read("myntAmbientPreset", "rain"));
    });
    document.querySelectorAll(".ux-ambient-preset").forEach(btn => {
        btn.addEventListener("click", () => {
            ambientAudio.play(btn.dataset.preset);
        });
    });
    $("ambientVolume")?.addEventListener("input", e => ambientAudio.setVolume(Number(e.target.value)));

    // ── Quick Theme Switcher in Dock ─────────────────────────────────────
    const themeBtn = $("themeQuickToggle");
    function updateThemeIcon() {
        if (!themeBtn) return;
        const isDark = document.documentElement.getAttribute("data-pref") === "dark" || 
                       (document.documentElement.getAttribute("data-pref") === "system" && document.body.getAttribute("sysTheme") === "systemDark");
        themeBtn.innerHTML = icon(isDark ? "sun" : "moon");
        themeBtn.title = t(isDark ? "light" : "dark");
        themeBtn.setAttribute("aria-label", t(isDark ? "light" : "dark"));
    }
    themeBtn?.addEventListener("click", () => {
        const isDark = document.documentElement.getAttribute("data-pref") === "dark" || 
                       (document.documentElement.getAttribute("data-pref") === "system" && document.body.getAttribute("sysTheme") === "systemDark");
        const target = isDark ? "light" : "dark";
        const segBtn = document.querySelector(`.themeSegBtn[data-theme="${target}"]`);
        if (segBtn) segBtn.click();
        else if (typeof setSavedThemeMode === "function") setSavedThemeMode(target);
        
        ambientAudio.playTap();
        themeBtn.style.transform = "rotate(360deg)";
        setTimeout(() => { themeBtn.style.transform = ""; }, 400);
        updateThemeIcon();
        toast(t(target === "dark" ? "themeDark" : "themeLight"));
    });
    new MutationObserver(updateThemeIcon).observe(document.documentElement, { attributes: true, attributeFilter: ["data-pref"] });
    new MutationObserver(updateThemeIcon).observe(document.body, { attributes: true, attributeFilter: ["sysTheme"] });
    updateThemeIcon();

    // ── Mouse Ambient Spotlight on Glass Cards ───────────────────────────
    if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
        let lastMove = 0;
        document.addEventListener("pointermove", event => {
            const now = performance.now();
            if (now - lastMove < 25) return;
            lastMove = now;
            const target = event.target.closest?.(".ux-dock, .ux-dialog, .searchbar, .lrectangle, .quotesContainer, #userText, #date, .shortcutsContainer .shortcuts a");
            if (!target) return;
            const rect = target.getBoundingClientRect();
            target.style.setProperty("--mouse-x", `${Math.round(event.clientX - rect.left)}px`);
            target.style.setProperty("--mouse-y", `${Math.round(event.clientY - rect.top)}px`);
        }, { passive: true });
    }

    // ── Interactive Weather Refresh ──────────────────────────────────────
    const weatherDial = document.querySelector(".rAndakar") || document.getElementById("temp");
    if (weatherDial) {
        weatherDial.style.cursor = "pointer";
        weatherDial.setAttribute("title", (window.currentLanguage === "ar_SA" || localStorage.getItem("selectedLanguage") === "ar_SA") ? "انقر لتحديث بيانات الطقس 🌤️" : "Click to refresh weather 🌤️");
        weatherDial.addEventListener("click", () => {
            const fetchFn = window.getWeatherData || window.getweather;
            if (typeof fetchFn === "function") {
                fetchFn();
                weatherDial.style.transform = "scale(0.96)";
                setTimeout(() => { weatherDial.style.transform = ""; }, 180);
                ambientAudio.playTap();
                toast((window.currentLanguage === "ar_SA" || localStorage.getItem("selectedLanguage") === "ar_SA") ? "جارٍ تحديث الطقس… ⛅" : "Refreshing weather… ⛅");
            }
        });
    }

    // ── Interactive Clock Style Toggle (Digital / Analog) ────────────────
    const clockElements = [document.getElementById("digitalClock"), document.getElementById("analogClock")].filter(Boolean);
    clockElements.forEach(clock => {
        clock.style.cursor = "pointer";
        clock.setAttribute("role", "button");
        clock.setAttribute("tabindex", "0");
        const getTitle = () => (window.currentLanguage === "ar_SA" || localStorage.getItem("selectedLanguage") === "ar_SA")
            ? "انقر لتبديل شكل الساعة (رقمية / عقارب)"
            : "Click to switch clock style (Digital / Analog)";
        clock.title = getTitle();
        clock.setAttribute("aria-label", getTitle());
        const toggleClock = () => {
            const digitalCb = $("digitalCheckbox");
            if (digitalCb) {
                digitalCb.click();
                clock.style.transform = "scale(0.97)";
                setTimeout(() => { clock.style.transform = ""; }, 180);
                ambientAudio.playTap();
                toast((window.currentLanguage === "ar_SA" || localStorage.getItem("selectedLanguage") === "ar_SA") ? "تم تبديل شكل الساعة ⌚" : "Clock style switched ⌚");
            }
        };
        clock.addEventListener("click", toggleClock);
        clock.addEventListener("keydown", e => {
            if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggleClock(); }
        });
    });

    // Make existing launchers and switches accessible without replacing their handlers.
    function buttonSemantics(element, label) {
        if (!element) return;
        element.setAttribute("aria-label", label);
        if (!element.matches("button,a,input")) {
            element.setAttribute("role", "button"); element.tabIndex = 0;
            element.addEventListener("keydown", event => {
                if (event.key === "Enter" || event.key === " ") { event.preventDefault(); element.click(); }
            });
        }
    }
    const launcherLabels = { menuButton: "settings", menuCloseButton: "close", micIcon: "mic", todoListCont: "tasks", bookmarkButton: "bookmarkSearch", searchWithHint: "search", aiToolsIcon: "tools", googleAppsCont: "tools", toastClose: "close" };
    function labels() {
        document.querySelectorAll("[data-ux-text]").forEach(el => { el.textContent = t(el.dataset.uxText); });
        document.querySelectorAll("[data-ux-label]").forEach(el => el.setAttribute("aria-label", t(el.dataset.uxLabel)));
        document.querySelectorAll("[data-ux-placeholder]").forEach(el => { el.placeholder = t(el.dataset.uxPlaceholder); });
        $("settingsNavigation").querySelectorAll("button").forEach(button => {
            button.textContent = $(button.dataset.section)?.textContent || t(sectionKeys[button.dataset.section]?.[0]);
            button.title = `${t("settingJump")}: ${button.textContent}`;
        });
        for (const [id, key] of Object.entries(launcherLabels)) $(id)?.setAttribute("aria-label", t(key));
        $("commandResults").setAttribute("aria-label", t("quick"));
        host.querySelector(".ux-dock").setAttribute("aria-label", t("tools"));
        $("settingsNavigation").setAttribute("aria-label", t("settings"));
        host.querySelector(".ux-session-presets").setAttribute("aria-label", t("focus"));
        $("onbNameInput").setAttribute("aria-label", t("name"));
        $("searchQ").setAttribute("aria-label", t("webSearch"));
        $("bookmarkSearch").setAttribute("aria-label", t("bookmarkSearch"));
        $("todoInput").setAttribute("aria-label", t("taskInput"));
        $("todoAdd").setAttribute("aria-label", t("addTask"));
        $("backButton").setAttribute("aria-label", t("settings"));
        $("userText").setAttribute("aria-label", t("editText"));
        $("commandKeyHint").textContent = /Mac/.test(navigator.platform) ? "⌘ K" : "Ctrl K";
        document.querySelectorAll(".switch input").forEach(input => {
            const row = input.closest(".ttcont");
            const title = row?.querySelector(".bigText");
            const description = row?.querySelector(".infoText");
            if (title?.id) input.setAttribute("aria-labelledby", title.id);
            else if (title) input.setAttribute("aria-label", title.textContent);
            if (description?.id) input.setAttribute("aria-describedby", description.id);
            input.setAttribute("role", "switch");
        });
        updateTimer();
        updateThemeIcon();
        ambientAudio.updateUI();
    }
    for (const [id, key] of Object.entries(launcherLabels)) buttonSemantics($(id), t(key));
    $("userText").setAttribute("role", "textbox");
    $("userText").setAttribute("aria-multiline", "true");
    $("userText").addEventListener("focus", () => {
        if ($("userText").textContent === $("userText").dataset.placeholder) $("userText").textContent = "";
    });
    $("LoadingScreen").alt = "";
    $("focusState").setAttribute("role", "status");
    $("LoadingScreen").setAttribute("aria-hidden", "true");
    document.querySelectorAll(".search-engine").forEach((engine, index) => {
        const radio = engine.querySelector('input[type="radio"]');
        const name = engine.querySelector(".engine-name");
        if (!radio || !name) return;
        if (!name.id) name.id = `search-engine-label-${index}`;
        radio.setAttribute("aria-labelledby", name.id);
        radio.addEventListener("keydown", event => {
            const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[event.key];
            if (!step) return;
            const group = [...engine.parentElement.querySelectorAll('.search-engine input[type="radio"]')].filter(input => input.getClientRects().length);
            if (!group.length) return;
            event.preventDefault();
            const next = group[(group.indexOf(radio) + step + group.length) % group.length];
            next.click(); next.focus();
        });
    });
    const sidebar = $("bookmarkSidebar");
    const syncBookmarks = () => { sidebar.inert = !sidebar.classList.contains("open"); };
    syncBookmarks();
    new MutationObserver(syncBookmarks).observe(sidebar, { attributes: true, attributeFilter: ["class"] });

    // Settings trap focus while open and restore focus to the invoking control.
    let menuOpener;
    let menuWasOpen = false;
    $("menuCont").setAttribute("role", "dialog");
    $("menuCont").setAttribute("aria-modal", "true");
    menuHeader.querySelector("h1").id = "settingsDialogTitle";
    $("menuCont").setAttribute("aria-labelledby", "settingsDialogTitle");
    $("menuButton").setAttribute("aria-controls", "menuBar");
    $("menuButton").setAttribute("aria-haspopup", "dialog");
    function syncMenu() {
        const open = $("menuBar").style.display === "block";
        $("menuButton").setAttribute("aria-expanded", String(open));
        if (open === menuWasOpen) return;
        menuWasOpen = open;
        document.querySelector(".centerDiv").inert = open;
        if (open) {
            menuOpener = document.activeElement;
            $("settingsSearch").focus({ preventScroll: true });
        } else {
            $("settingsSearch").value = ""; filterSettings();
            if (menuOpener?.isConnected && !document.querySelector("dialog[open]")) menuOpener.focus({ preventScroll: true });
        }
    }
    new MutationObserver(syncMenu).observe($("menuBar"), { attributes: true, attributeFilter: ["style"] });
    // Native dialogs live in the top layer, outside the parent's visual filter.
    // Apply the same filter to them only for predefined themes that invert body.
    function syncDialogTheme() {
        const filtered = getComputedStyle(document.body).filter.includes("invert(1)");
        for (const dialog of [$("commandPalette"), $("focusDialog")]) dialog.classList.toggle("ux-filter-dark", filtered);
    }
    new MutationObserver(syncDialogTheme).observe(document.documentElement, { attributes: true, attributeFilter: ["data-pref", "class", "style"] });
    new MutationObserver(syncDialogTheme).observe(document.body, { attributes: true, attributeFilter: ["data-bg", "data-custom-theme", "data-dual-theme", "sysTheme", "class", "style"] });
    syncDialogTheme();
    document.addEventListener("keydown", event => {
        const onboarding = $("onboardingOverlay");
        if (onboarding && getComputedStyle(onboarding).display !== "none") return;
        if (event.isComposing) return;
        // Let existing editors and child overlays handle their own keyboard events.
        const childOverlay = [...document.querySelectorAll("#galleryModal,#aiToolsSettingsModal,#customColorPickerPopover,#shadowFloatingPanel,#dualColorPanel,#shortcutIconPopover,#lePanel,#prompt-modal-container,#editBookmarkModal")]
            .some(element => element.getClientRects().length && getComputedStyle(element).display !== "none" && getComputedStyle(element).visibility !== "hidden");
        if (childOverlay) return;
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
            event.preventDefault(); openCommands(); return;
        }
        const dialogOpen = document.querySelector("dialog[open]");
        if (dialogOpen) return;
        if (menuWasOpen) {
            if (event.key === "Escape" && document.activeElement === $("settingsSearch") && $("settingsSearch").value) return;
            if (event.key === "Escape") { event.preventDefault(); closeMenuBar(); }
            if (event.key === "Tab") {
                const focusable = [...menu.querySelectorAll("button,input,select,a[href],[tabindex='0']")].filter(el => !el.disabled && !el.closest("[inert]") && el.getClientRects().length && getComputedStyle(el).visibility !== "hidden");
                const first = focusable[0]; const last = focusable[focusable.length - 1];
                if (event.shiftKey && (document.activeElement === first || !menu.contains(document.activeElement))) { event.preventDefault(); last?.focus(); }
                else if (!event.shiftKey && (document.activeElement === last || !menu.contains(document.activeElement))) { event.preventDefault(); first?.focus(); }
            }
            return;
        }
        const editing = document.activeElement?.matches("input,textarea,select,[contenteditable=true]");
        if (event.key === "/" && !event.ctrlKey && !event.metaKey && !event.altKey && !editing) { event.preventDefault(); $("searchQ").focus(); }
    }, true);
    window.addEventListener("material-you-language-change", labels);
    labels(); stats(); updateTimer();
})();

(function() {
    "use strict";

    function openPanel() {
        var panel = document.getElementById("iconContainer");
        var icon = document.getElementById("googleAppsCont");
        if (!panel) return;
        if (window.resetFloatingPanelPosition) {
            window.resetFloatingPanelPosition(panel);
        }
        if (window.panelOpenAnim) {
            window.panelOpenAnim(panel, "grid");
        } else {
            panel.style.display = "grid";
        }
        if (icon) icon.classList.add("menu-open");
    }

    function closePanel() {
        var panel = document.getElementById("iconContainer");
        var icon = document.getElementById("googleAppsCont");
        if (!panel || panel.style.display === "none") return;
        if (icon) icon.classList.remove("menu-open");
        if (window.closeWithAnim) {
            window.closeWithAnim(panel, function() {
                panel.style.display = "none";
            }, "down");
        } else {
            panel.style.display = "none";
        }
    }

    function togglePanel(event) {
        if (event) event.stopPropagation();
        var panel = document.getElementById("iconContainer");
        if (!panel || panel.style.display === "none" || !panel.style.display) {
            openPanel();
        } else {
            closePanel();
        }
    }

    function syncVisibility() {
        var checkbox = document.getElementById("googleAppsCheckbox");
        var icon = document.getElementById("googleAppsCont");
        if (checkbox && icon) {
            icon.style.display = checkbox.checked ? "flex" : "none";
        }
        if (checkbox) {
            localStorage.setItem("googleAppsCheckboxState", checkbox.checked ? "checked" : "unchecked");
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        var icon = document.getElementById("googleAppsCont");
        var checkbox = document.getElementById("googleAppsCheckbox");
        var panel = document.getElementById("iconContainer");

        if (checkbox) {
            var saved = localStorage.getItem("googleAppsCheckboxState");
            if (saved === "checked") checkbox.checked = true;
            else if (saved === "unchecked") checkbox.checked = false;
        }

        if (icon) icon.addEventListener("click", togglePanel);
        if (checkbox) {
            checkbox.addEventListener("change", syncVisibility);
            syncVisibility();
        }
        if (panel) {
            panel.addEventListener("click", function(event) {
                event.stopPropagation();
            });
        }
        document.addEventListener("click", function(event) {
            var launcher = document.getElementById("googleAppsCont");
            var currentPanel = document.getElementById("iconContainer");
            if (!launcher || !currentPanel) return;
            if (!launcher.contains(event.target) && !currentPanel.contains(event.target)) {
                closePanel();
            }
        });
    });
})();

/**
 * layout-editor.js  v3
 * ─────────────────────────────────────────────────────────────────────────────
 * FIXES:
 *  1. Viewport boundary clamp — elements cannot escape the screen
 *  2. Minimum gap guard — keeps MIN_GAP px between any two elements (pure math)
 *  3. Clock highlight ring — box-shadow (follows circular border-radius exactly)
 *  4. Long-press acceleration on −/+ buttons (gets faster the longer you hold)
 *  5. Panel is draggable via its drag bar
 * ─────────────────────────────────────────────────────────────────────────────
 */
(function () {
    "use strict";

    const STORAGE_KEY         = "layoutEditorV1";
    const PRESETS_STORAGE_KEY = "layoutEditorPresetsV1";
    const ACTIVE_PRESET_KEY   = "layoutEditorActivePresetV1";
    const SCALE_STEP  = 0.05;
    const MIN_GAP     = 16;  // px gap enforced between any two elements
    const MARGIN      = 8;   // px minimum gap from viewport edge

    /* ─────────────────────────────────────────────────────────────────────────
       Translation helper — resolves a key from the active language, falls back to English
    ───────────────────────────────────────────────────────────────────────── */
    function _t(key) {
        const lang = (typeof currentLanguage !== "undefined") ? currentLanguage : "en";
        if (typeof translations === "undefined") return key;
        return (translations[lang] && translations[lang][key])
            || (translations["en"] && translations["en"][key])
            || key;
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Built-in layout presets
    ───────────────────────────────────────────────────────────────────────── */
    const BUILT_IN_PRESETS = [
        {
            id: "default",
            labelKey: "lePresetDefaultLabel",
            icon: "M3 3h8v8H3zm0 10h8v8H3zm10-10h8v8h-8zm0 10h8v8h-8z",
            descKey: "lePresetDefaultDesc",
            state: {
                clock:   { tx: 0,    ty: 0,   scale: 1    },
                text:    { tx: 0,    ty: 0,   scale: 1    },
                weather: { tx: 0,    ty: 0,   scale: 1    },
                search:  { tx: 0,    ty: 0,   scale: 1    },
                quotes:  { tx: 0,    ty: 0,    scale: 1    },
            }
        },
        {
            id: "big-clock",
            labelKey: "lePresetBigClockLabel",
            icon: "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2M12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8m.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z",
            descKey: "lePresetBigClockDesc",
            state: {
                // Clock: large, pushed far left so it never overlaps weather
                clock:   { tx: -18,  ty: -28, scale: 1.45 },
                // Text: pushed down well below the enlarged clock
                text:    { tx: -12,  ty: 55,  scale: 0.72 },
                // Weather: pushed noticeably right and up, scaled down to stay clear
                weather: { tx: 28,   ty: -18, scale: 0.76 },
                // Search: centre lane, slight down
                search:  { tx: 0,    ty: 12,  scale: 0.88 },
                // Quotes: right-of-centre, well below search
                quotes:  { tx: 18,   ty: 28,  scale: 0.68 },
            }
        },
        {
            id: "compact",
            labelKey: "lePresetCompactLabel",
            icon: "M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z",
            descKey: "lePresetCompactDesc",
            state: {
                // Stay inside natural columns — only scale down, tiny nudges toward centre
                clock:   { tx: 12,   ty: 8,   scale: 0.76 },
                text:    { tx: 10,   ty: -8,  scale: 0.67 },
                weather: { tx: -12,  ty: 8,   scale: 0.76 },
                search:  { tx: 0,    ty: -10, scale: 0.82 },
                quotes:  { tx: 0,    ty: -14, scale: 0.62 },
            }
        },
        {
            id: "focus",
            labelKey: "lePresetFocusLabel",
            icon: "M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
            descKey: "lePresetFocusDesc",
            state: {
                // Clock: moderately enlarged, shifted left so it stays clear of weather
                clock:   { tx: -18,  ty: -22, scale: 1.28 },
                // Text: small, pushed down and away from clock
                text:    { tx: -8,   ty: 38,  scale: 0.60 },
                // Weather: small, right side, pushed up
                weather: { tx: 22,   ty: -16, scale: 0.68 },
                // Search: slightly bigger — second hero element, nudged up
                search:  { tx: 0,    ty: -10, scale: 1.18 },
                // Quotes: very small, pushed down out of the way
                quotes:  { tx: 0,    ty: 22,  scale: 0.55 },
            }
        },
        {
            id: "weather-hero",
            labelKey: "lePresetWeatherHeroLabel",
            icon: "M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z",
            descKey: "lePresetWeatherHeroDesc",
            state: {
                // Clock: smaller, pushed left so weather has ample room
                clock:   { tx: -32,  ty: 0,   scale: 0.78 },
                // Text: small, beneath clock on the left
                text:    { tx: -22,  ty: -10, scale: 0.65 },
                // Weather: hero element — pushed right and higher to clear the search bar below
                weather: { tx: 30,   ty: -50, scale: 1.22 },
                // Search: centre, pushed down to give weather room above
                search:  { tx: 0,    ty: 20,  scale: 0.88 },
                // Quotes: slight right, below search
                quotes:  { tx: 14,   ty: 34,  scale: 0.68 },
            }
        },
        {
            id: "minimal",
            labelKey: "lePresetMinimalLabel",
            icon: "M4 6h16v2H4zm4 5h12v2H8zm4 5h8v2h-8z",
            descKey: "lePresetMinimalDesc",
            state: {
                clock:   { tx: 0,    ty: -10, scale: 1.05 },
                text:    { tx: 0,    ty: 0,   scale: 0.6  },
                weather: { tx: 0,    ty: -10, scale: 0.65 },
                search:  { tx: 0,    ty: 0,   scale: 1.0  },
                quotes:  { tx: 0,    ty: 0,   scale: 0.55 },
            }
        },
        {
            id: "spread",
            labelKey: "lePresetSpreadLabel",
            icon: "M20 9H4v2h16V9zM4 15h16v-2H4v2z",
            descKey: "lePresetSpreadDesc",
            state: {
                clock:   { tx: -60,  ty: -30, scale: 1.0  },
                text:    { tx: -60,  ty: 15,  scale: 0.9  },
                weather: { tx: 60,   ty: -30, scale: 1.0  },
                search:  { tx: 0,    ty: 20,  scale: 1.0  },
                quotes:  { tx: 60,   ty: 15,  scale: 0.9  },
            }
        },
        {
            id: "cozy",
            labelKey: "lePresetCozyLabel",
            icon: "M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z",
            descKey: "lePresetCozyDesc",
            state: {
                // Clock: slight left push, bit bigger
                clock:   { tx: -38,  ty: -12, scale: 1.08 },
                // Text: same left column but well below clock
                text:    { tx: -28,  ty: 22,  scale: 0.80 },
                // Weather: right side, mirroring clock position
                weather: { tx: 38,   ty: -12, scale: 1.05 },
                // Search: centred, slight upward nudge for breathing room
                search:  { tx: 0,    ty: -6,  scale: 0.93 },
                // Quotes: right of centre, below search
                quotes:  { tx: 22,   ty: 20,  scale: 0.80 },
            }
        },
    ];

    /* ─────────────────────────────────────────────────────────────────────────
       Element catalogue
    ───────────────────────────────────────────────────────────────────────── */
    // Use translated labels if translations are available
    const _leT = (typeof translations !== "undefined" && typeof currentLanguage !== "undefined" && translations[currentLanguage])
        ? translations[currentLanguage]
        : (typeof translations !== "undefined" ? (translations["en"] || {}) : {});

    const ELEMENTS = [
        {
            key: "clock",
            label: _leT.leLabelClock || "Clock",
            icon: "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2M12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8m.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z",
            selectors: ["#analogClock", "#digitalClock"],
            minScale: 0.4, maxScale: 1.8,
        },
        {
            key: "text",
            label: _leT.leLabelText || "Custom Text",
            icon: "M2.5 4v3h5v12h3V7h5V4h-13zm19 5h-9v3h3v7h3v-7h3V9z",
            selectors: [".ttteexxtt"],
            minScale: 0.5, maxScale: 1.8,
        },
        {
            key: "weather",
            label: _leT.leLabelWeather || "Weather",
            icon: "M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z",
            selectors: ["#hideWeather"],
            minScale: 0.5, maxScale: 1.5,
        },
        {
            key: "search",
            label: _leT.leLabelSearch || "Search Bar",
            icon: "M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
            selectors: ["#searchWrapper"],
            minScale: 0.7, maxScale: 1.3,
        },
        {
            key: "quotes",
            label: _leT.leLabelQuotes || "Quotes",
            icon: "M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z",
            selectors: ["#motivationalQuotesCont"],
            minScale: 0.5, maxScale: 1.5,
        },
    ];

    /* ─────────────────────────────────────────────────────────────────────────
       State
    ───────────────────────────────────────────────────────────────────────── */
    let state      = {};
    let editMode   = false;
    let activeDrag = null;
    let panelDrag  = null;
    let activeKey  = null;
    let activePresetId = "default";   // tracks which preset is currently active
    let activePresetSnapshot = null;   // post-clamp state snapshot of the last applied preset

    function loadState() {
        try {
            const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
            // Clean up removed elements (shortcuts, ai) from old saved state
            delete saved["shortcuts"];
            delete saved["ai"];
            ELEMENTS.forEach(def => {
                const s = saved[def.key] || {};
                state[def.key] = {
                    tx:    typeof s.tx    === "number" ? s.tx    : 0,
                    ty:    typeof s.ty    === "number" ? s.ty    : 0,
                    scale: typeof s.scale === "number" ? s.scale : 1,
                };
            });
        } catch (_) {
            ELEMENTS.forEach(def => { state[def.key] = { tx: 0, ty: 0, scale: 1 }; });
        }
    }

    function saveState() {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) {}
        // Persist the active preset context so the blue-dot check survives page reloads
        saveActivePresetContext();
    }

    function saveActivePresetContext() {
        try {
            localStorage.setItem(ACTIVE_PRESET_KEY, JSON.stringify({
                id: activePresetId,
                snapshot: activePresetSnapshot,
            }));
        } catch (_) {}
    }

    function loadActivePresetContext() {
        try {
            const saved = JSON.parse(localStorage.getItem(ACTIVE_PRESET_KEY) || "null");
            if (saved && saved.id) {
                activePresetId = saved.id;
                activePresetSnapshot = saved.snapshot || null;
            }
        } catch (_) {}
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Custom Presets (saved by user)
    ───────────────────────────────────────────────────────────────────────── */
    let customPresets = [];

    function loadCustomPresets() {
        try {
            const saved = JSON.parse(localStorage.getItem(PRESETS_STORAGE_KEY) || "[]");
            customPresets = Array.isArray(saved) ? saved : [];
        } catch (_) { customPresets = []; }
    }

    function saveCustomPresets() {
        try { localStorage.setItem(PRESETS_STORAGE_KEY, JSON.stringify(customPresets)); } catch (_) {}
    }

    /* Compare two layout states — returns true if every element's tx/ty/scale match */
    function statesEqual(a, b) {
        return ELEMENTS.every(def => {
            const sa = a[def.key], sb = b[def.key];
            if (!sa || !sb) return false;
            return Math.abs((sa.tx    || 0) - (sb.tx    || 0)) < 3.0 &&
                   Math.abs((sa.ty    || 0) - (sb.ty    || 0)) < 3.0 &&
                   Math.abs((sa.scale || 1) - (sb.scale || 1)) < 0.01;
        });
    }

    /* Returns the label of the first existing preset (built-in or custom)
       whose state is identical to the current layout, or null if unique.
       Also compares against activePresetSnapshot (post-clamp values) so that
       a preset applied at runtime still matches even if clampToViewport shifted it. */
    function findDuplicatePreset() {
        // Compare against post-clamp snapshot first — fastest & most accurate
        if (activePresetSnapshot && statesEqual(state, activePresetSnapshot)) {
            // Identify the label of the active preset
            const bp = BUILT_IN_PRESETS.find(p => p.id === activePresetId);
            if (bp) return _t(bp.labelKey) || bp.id;
            const cp = customPresets.find(p => p.id === activePresetId);
            if (cp) return cp.label;
        }
        // Fallback: compare against raw preset definitions (handles edge cases)
        for (const bp of BUILT_IN_PRESETS) {
            if (statesEqual(state, bp.state)) return _t(bp.labelKey) || bp.id;
        }
        for (const cp of customPresets) {
            if (statesEqual(state, cp.state)) return cp.label;
        }
        return null;
    }

    function saveCurrentAsPreset(name) {
        const preset = {
            id:    "custom_" + Date.now(),
            label: name.trim(),
            state: JSON.parse(JSON.stringify(state)),
        };
        customPresets.push(preset);
        saveCustomPresets();
        return preset;
    }

    function deleteCustomPreset(id) {
        customPresets = customPresets.filter(p => p.id !== id);
        saveCustomPresets();
    }

    /* Set which preset is visually active — updates built-in cards and custom rows */
    function setActivePreset(id) {
        activePresetId = id;
        document.querySelectorAll(".le-preset-card").forEach(c =>
            c.classList.toggle("le-preset-active", c.dataset.presetId === id));
        document.querySelectorAll(".le-custom-preset-row").forEach(r =>
            r.classList.toggle("le-custom-row-active", r.dataset.presetId === id));
    }

    function autoDetectAndSetActivePreset() {
        let matchedId = null;
        let matchedSnapshot = null;

        // Check built-in presets using their post-clamped states
        for (const bp of BUILT_IN_PRESETS) {
            const clampedPresetState = getClampedPresetState(bp.state, bp.id);
            if (statesEqual(state, clampedPresetState)) {
                matchedId = bp.id;
                matchedSnapshot = JSON.parse(JSON.stringify(clampedPresetState));
                break;
            }
        }

        if (!matchedId) {
            // Check custom presets
            for (const cp of customPresets) {
                const clampedPresetState = getClampedPresetState(cp.state, cp.id);
                if (statesEqual(state, clampedPresetState)) {
                    matchedId = cp.id;
                    matchedSnapshot = JSON.parse(JSON.stringify(clampedPresetState));
                    break;
                }
            }
        }

        activePresetId = matchedId;
        activePresetSnapshot = matchedSnapshot;

        document.querySelectorAll(".le-preset-card").forEach(c =>
            c.classList.toggle("le-preset-active", c.dataset.presetId === activePresetId));
        document.querySelectorAll(".le-custom-preset-row").forEach(r =>
            r.classList.toggle("le-custom-row-active", r.dataset.presetId === activePresetId));

        saveActivePresetContext();
    }

    function getClampedPresetState(presetState, presetId) {
        const clamped = {};
        ELEMENTS.forEach(def => {
            const ps = presetState[def.key];
            clamped[def.key] = {
                tx:    ps && typeof ps.tx    === "number" ? ps.tx    : 0,
                ty:    ps && typeof ps.ty    === "number" ? ps.ty    : 0,
                scale: ps && typeof ps.scale === "number" ? ps.scale : 1,
            };
        });
        
        ELEMENTS.forEach(def => {
            const s = clamped[def.key];
            if (presetId === "default" || (s.tx === 0 && s.ty === 0)) {
                return;
            }
            const c = clampToViewport(def.key, s.tx, s.ty, state, s.scale);
            s.tx = c.tx;
            s.ty = c.ty;
        });
        return clamped;
    }

    function applyPreset(presetState, presetId) {
        const oldState = JSON.parse(JSON.stringify(state));
        ELEMENTS.forEach(def => {
            const ps = presetState[def.key];
            if (ps) {
                state[def.key] = {
                    tx:    typeof ps.tx    === "number" ? ps.tx    : 0,
                    ty:    typeof ps.ty    === "number" ? ps.ty    : 0,
                    scale: typeof ps.scale === "number" ? ps.scale : 1,
                };
            }
        });
        // Clamp every element to viewport after applying to prevent out-of-bounds
        ELEMENTS.forEach(def => {
            const s = state[def.key];
            if (presetId === "default" || (s.tx === 0 && s.ty === 0)) {
                return; // Keep natural CSS defaults intact without clamping shift
            }
            const clamped = clampToViewport(def.key, s.tx, s.ty, oldState, s.scale);
            s.tx = clamped.tx;
            s.ty = clamped.ty;
        });
        applyAll(); saveState(); applyTargetClasses();
        autoDetectAndSetActivePreset();
        refreshAllRows();
    }

    function isModified(key) {
        const s = state[key];
        return Math.abs(s.tx) > 0.25 || Math.abs(s.ty) > 0.25 || Math.abs(s.scale - 1) > 0.01;
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Responsive breakpoint: below this width the CSS @media layout takes over,
       so layout-editor position offsets (tx/ty) are suppressed.
       Scale is always kept so the user's size preference is preserved.
    ───────────────────────────────────────────────────────────────────────── */
    // At ≤ 1200px the CSS switches to single-column layout (grid-template-columns:auto),
    // so layout-editor position offsets are meaningless below this threshold.
    const RESPONSIVE_BREAKPOINT = 1201; // px — matches the @media (max-width:1200px) breakpoint

    function isMobileViewport() {
        return window.innerWidth < RESPONSIVE_BREAKPOINT;
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Apply CSS vars to <html>
       On mobile viewports tx/ty are forced to 0 so the responsive CSS layout
       is not disturbed. Scale is always applied. State is NEVER mutated here.
    ───────────────────────────────────────────────────────────────────────── */
    function applyAll() {
        const root   = document.documentElement;
        const mobile = isMobileViewport();

        // Clear any stale vars from previously removed elements
        ["shortcuts", "ai"].forEach(k => {
            root.style.removeProperty(`--le-tx-${k}`);
            root.style.removeProperty(`--le-ty-${k}`);
            root.style.removeProperty(`--le-scale-${k}`);
        });
        ELEMENTS.forEach(def => {
            const s = state[def.key];
            // On small screens suppress position offsets — let CSS handle layout
            root.style.setProperty(`--le-tx-${def.key}`,    (mobile ? 0 : s.tx) + "px");
            root.style.setProperty(`--le-ty-${def.key}`,    (mobile ? 0 : s.ty) + "px");
            root.style.setProperty(`--le-scale-${def.key}`, s.scale);
        });
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Target helpers
    ───────────────────────────────────────────────────────────────────────── */
    function resolveTarget(def) {
        for (const sel of def.selectors) {
            const el = document.querySelector(sel);
            if (el && isVisible(el)) return el;
        }
        // Fallback: any selector even if invisible
        for (const sel of def.selectors) {
            const el = document.querySelector(sel);
            if (el) return el;
        }
        return null;
    }

    function isVisible(el) {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
    }

    /**
     * Get the CURRENT bounding rect of an element projected at a specific
     * tx/ty offset — WITHOUT touching the DOM.
     *
     * Since our CSS applies:  transform: translate(tx, ty) scale(s)
     * The element's current rect already includes the current tx/ty.
     * So projecting to a NEW tx/ty is just:
     *   newRect = currentRect shifted by (newTx - currentTx, newTy - currentTy)
     */
    function projectRect(el, key, newTx, newTy, oldStateContext = null, targetScale = null) {
        const r   = el.getBoundingClientRect();
        const cur = (oldStateContext && oldStateContext[key]) ? oldStateContext[key] : state[key];
        const dx  = newTx - cur.tx;
        const dy  = newTy - cur.ty;

        const curScale = (cur && typeof cur.scale === "number") ? cur.scale : 1;
        const tScale   = typeof targetScale === "number" ? targetScale : curScale;

        const f = curScale !== 0 ? (tScale / curScale) : 1;
        const wNew = r.width * f;
        const hNew = r.height * f;

        let left = r.left + dx;
        let top = r.top + dy;
        let right = r.right + dx;
        let bottom = r.bottom + dy;

        if (key === "clock") {
            const cx = left + r.width / 2;
            const cy = top + r.height / 2;
            left = cx - wNew / 2;
            right = cx + wNew / 2;
            top = cy - hNew / 2;
            bottom = cy + hNew / 2;
        } else if (key === "text") {
            right = left + wNew;
            bottom = top + hNew;
        } else if (key === "weather") {
            left = right - wNew;
            bottom = top + hNew;
        } else if (key === "search") {
            const cx = left + r.width / 2;
            left = cx - wNew / 2;
            right = cx + wNew / 2;
            bottom = top + hNew;
        } else if (key === "quotes") {
            const cx = left + r.width / 2;
            left = cx - wNew / 2;
            right = cx + wNew / 2;
            top = bottom - hNew;
        } else {
            const cx = left + r.width / 2;
            const cy = top + r.height / 2;
            left = cx - wNew / 2;
            right = cx + wNew / 2;
            top = cy - hNew / 2;
            bottom = cy + hNew / 2;
        }

        return {
            left,
            top,
            right,
            bottom,
            width:  wNew,
            height: hNew,
        };
    }

    /* ─────────────────────────────────────────────────────────────────────────
       1. Viewport boundary clamp  (pure math — no DOM writes for measurement)
          Top edge: simple MARGIN (elements CAN go near top buttons — enforceGap
          handles per-pixel collision with the actual button rects instead).
          Bottom edge accounts for the fixed shortcuts bar.
    ───────────────────────────────────────────────────────────────────────── */
    function getBottomMargin() {
        const sc = document.getElementById("shortcuts-section");
        if (sc) {
            const r = sc.getBoundingClientRect();
            const barH = window.innerHeight - r.top;
            if (barH > 0) return MARGIN + barH;
        }
        return MARGIN;
    }

    function clampToViewport(key, proposedTx, proposedTy, oldStateContext = null, targetScale = null) {
        const def = ELEMENTS.find(d => d.key === key);
        if (!def) return { tx: proposedTx, ty: proposedTy };

        const el = resolveTarget(def);
        if (!el || !isVisible(el)) return { tx: proposedTx, ty: proposedTy };

        const r  = projectRect(el, key, proposedTx, proposedTy, oldStateContext, targetScale);
        const vw = window.innerWidth;
        const vh = window.innerHeight;

        let tx = proposedTx;
        let ty = proposedTy;

        const topMargin    = MARGIN;
        const bottomMargin = getBottomMargin();

        if (r.left   < MARGIN)              tx += (MARGIN        - r.left);
        if (r.right  > vw - MARGIN)         tx -= (r.right       - (vw - MARGIN));
        if (r.top    < topMargin)           ty += (topMargin     - r.top);
        if (r.bottom > vh - bottomMargin)   ty -= (r.bottom      - (vh - bottomMargin));

        return { tx, ty };
    }

    /* ─────────────────────────────────────────────────────────────────────────
       2. Gap guard between elements  (pure math — no DOM writes)
    ───────────────────────────────────────────────────────────────────────── */
    function enforceGap(movingKey, proposedTx, proposedTy) {
        const movingDef = ELEMENTS.find(d => d.key === movingKey);
        if (!movingDef) return { tx: proposedTx, ty: proposedTy };

        const movingEl = resolveTarget(movingDef);
        if (!movingEl || !isVisible(movingEl)) return { tx: proposedTx, ty: proposedTy };

        const prevTx = state[movingKey].tx;
        const prevTy = state[movingKey].ty;

        /**
         * Helper: does the moving element at (testTx, testTy) overlap
         * the 'other' element (with MIN_GAP padding)?
         */
        function overlaps(testTx, testTy, or) {
            const mr = projectRect(movingEl, movingKey, testTx, testTy);
            return !(mr.right  + MIN_GAP <= or.left   ||
                     mr.left   - MIN_GAP >= or.right  ||
                     mr.bottom + MIN_GAP <= or.top    ||
                     mr.top    - MIN_GAP >= or.bottom);
        }

        let finalTx = proposedTx;
        let finalTy  = proposedTy;

        // ── Static obstacles: fixed UI buttons that are always on screen ──
        const STATIC_OBSTACLES = [
            "#bookmarkButton",
            ".bookmark-button",
            ".googleAppsCont",
            "#todoListCont",
            ".todoListCont",
        ];
        const staticRects = [];
        STATIC_OBSTACLES.forEach(sel => {
            const el = document.querySelector(sel);
            if (el) {
                const r = el.getBoundingClientRect();
                // Only add if element has real size and is visible
                if (r.width > 0 && r.height > 0) staticRects.push(r);
            }
        });
        // Deduplicate (bookmark-button and #bookmarkButton may resolve to same el)
        const dedupedStatic = staticRects.filter((r, i) =>
            staticRects.findIndex(s => s.left === r.left && s.top === r.top) === i
        );

        for (const or of ELEMENTS.map(other => {
            if (other.key === movingKey) return null;
            const el = resolveTarget(other);
            return (el && isVisible(el)) ? el.getBoundingClientRect() : null;
        }).concat(dedupedStatic).filter(Boolean)) {

            // No overlap with both proposed values → nothing to do
            if (!overlaps(finalTx, finalTy, or)) continue;

            // There IS overlap. Try resolving per-axis:
            const canMoveX = !overlaps(finalTx, prevTy,  or);   // X alone is OK?
            const canMoveY = !overlaps(prevTx,  finalTy, or);   // Y alone is OK?

            if (canMoveX && canMoveY) {
                // Both axes are independently fine — combined movement causes issue.
                // Allow the one that moves us further from the other element's center.
                const mr = projectRect(movingEl, movingKey, finalTx, finalTy);
                const movingCX = (mr.left + mr.right)   / 2;
                const movingCY = (mr.top  + mr.bottom)  / 2;
                const otherCX  = (or.left  + or.right)  / 2;
                const otherCY  = (or.top   + or.bottom) / 2;
                const distX = Math.abs(movingCX - otherCX);
                const distY = Math.abs(movingCY - otherCY);
                // Keep the axis that separates them more
                if (distX >= distY) finalTy = prevTy;
                else                finalTx = prevTx;
            } else if (canMoveX) {
                finalTy = prevTy;   // block Y
            } else if (canMoveY) {
                finalTx = prevTx;   // block X
            } else {
                // Neither axis is safe — block both
                finalTx = prevTx;
                finalTy  = prevTy;
            }
        }

        return { tx: finalTx, ty: finalTy };
    }

    /* ─────────────────────────────────────────────────────────────────────────
       CSS injection
    ───────────────────────────────────────────────────────────────────────── */
    function injectCSS() {
        if (document.getElementById("le-style")) return;
        const s = document.createElement("style");
        s.id = "le-style";
        s.textContent = `
/* ── Layout Editor: dynamic rules only (transforms are in static style.css) ── */

/* Edit mode */

/* ── Element highlight ring (dashed outline approach — layout-safe) ───────── */

/* All non-clock targets: outline follows the element shape */
body.le-edit-mode .le-target:not(#analogClock):not(#digitalClock) {
    outline: 2.5px dashed color-mix(in srgb, var(--darkColor-blue) 55%, transparent) !important;
    outline-offset: 5px !important;
    cursor: grab !important;
    transition: outline-color var(--dur-2,0.18s) !important;
}
body.le-edit-mode .le-target.le-focused:not(#analogClock):not(#digitalClock) {
    outline: 2.5px solid var(--darkColor-blue) !important;
    outline-offset: 5px !important;
}
body.le-edit-mode .le-target.le-dragging:not(#analogClock):not(#digitalClock) {
    cursor: grabbing !important;
    outline: 2.5px solid var(--darkerColor-blue) !important;
    outline-offset: 5px !important;
}

/* ── Clock ring: shape-aware bounds ─────────────────────────────────────── */
body.le-edit-mode #analogClock.le-target {
    --le-clock-ring-top: 50%;
    --le-clock-ring-left: 50%;
    --le-clock-ring-width: 104%;
    --le-clock-ring-height: 107%;
    --le-clock-ring-radius: 50%;
}
body.le-edit-mode[data-clock-shape="circle"] #analogClock.le-target {
    --le-clock-ring-width: 105%;
    --le-clock-ring-height: 105%;
}
body.le-edit-mode[data-clock-shape="squircle"] #analogClock.le-target {
    --le-clock-ring-width: 101%;
    --le-clock-ring-height: 101%;
    --le-clock-ring-radius: 38%;
}
body.le-edit-mode #analogClock.le-target::before,
body.le-edit-mode #digitalClock.le-target::before {
    content: '';
    position: absolute;
    top: var(--le-clock-ring-top, 50%);
    left: var(--le-clock-ring-left, 50%);
    width: var(--le-clock-ring-width, 102%);
    height: var(--le-clock-ring-height, 105%);
    transform: translate(-50%, -50%);
    border: 2.5px dashed color-mix(in srgb, var(--darkColor-blue) 55%, transparent);
    border-radius: var(--le-clock-ring-radius, 50%);
    pointer-events: none;
    z-index: 999;
    box-sizing: border-box;
    transition: border-color var(--dur-2, 0.18s);
}
body.le-edit-mode #digitalClock.le-target {
    --le-clock-ring-top: 48%;
    --le-clock-ring-left: 50%;
    --le-clock-ring-width: 105%;
    --le-clock-ring-height: 82%;
    --le-clock-ring-radius: 999px;
}
body.le-edit-mode #analogClock.le-focused::before,
body.le-edit-mode #digitalClock.le-focused::before,
body.le-edit-mode #analogClock.le-target.le-focused::before,
body.le-edit-mode #digitalClock.le-target.le-focused::before {
    border-style: solid;
    border-color: var(--darkColor-blue);
}
body.le-edit-mode #analogClock.le-target.le-dragging::before,
body.le-edit-mode #digitalClock.le-target.le-dragging::before {
    border-style: solid;
    border-color: var(--darkerColor-blue);
}
/* grab cursor */
body.le-edit-mode #analogClock.le-target,
body.le-edit-mode #digitalClock.le-target { cursor: grab !important; }
body.le-edit-mode #analogClock.le-target.le-dragging,
body.le-edit-mode #digitalClock.le-target.le-dragging { cursor: grabbing !important; }

/* ── Editor Panel ────────────────────────────────────────────────────────── */
#lePanel {
    position: fixed;
    top: auto;
    left: auto;
    bottom: 24px; right: 24px;
    z-index: 99999;
    width: 316px;
    background: var(--accentLightTint-blue);
    border: 1.5px solid var(--ui-sep);
    border-radius: 22px;
    box-shadow: var(--theme-shadow-xl, 0 28px 80px rgba(0,0,0,0.38));
    display: none;
    flex-direction: column;
    font-family: var(--main-font-family, sans-serif);
    pointer-events: all;
    height: auto;
    max-height: calc(100vh - 48px);
    overflow: hidden;
    transition: box-shadow var(--sc-live-dur, var(--sc-dur, var(--dur-4))) ease;
}
#lePanel.le-open {
    display: flex;
    animation: lePanelIn var(--dur-5, calc(0.4s * var(--ui-anim-mult, 1))) cubic-bezier(0.34,1.56,0.64,1) both;
}
#lePanel.le-closing {
    display: flex;
    animation: lePanelOut var(--dur-4, calc(0.32s * var(--ui-anim-mult, 1))) cubic-bezier(0.4,0,0.6,1) both;
    pointer-events: none;
}
@keyframes lePanelIn {
    from { opacity:0; transform:scale(0.85) translateY(16px); }
    to   { opacity:1; transform:scale(1)    translateY(0); }
}
@keyframes lePanelOut {
    from { opacity:1; transform:scale(1)    translateY(0); }
    to   { opacity:0; transform:scale(0.88) translateY(12px); }
}
.bookmark-ctx-menu.ctx-menu-closing {
    animation: ctxMenuOut calc(0.26s * var(--ui-anim-mult, 1)) var(--md-motion-ease, ease) both;
    pointer-events: none;
}

/* Drag bar */
#leDragBar {
    display: flex; flex-direction: column; align-items: center; gap: 3px;
    padding: 10px 12px 6px;
    cursor: grab; user-select: none; flex-shrink: 0;
    border-radius: 22px 22px 0 0;
    transition: background var(--dur-1,0.12s);
    touch-action: none;
}
#leDragBar:hover { background: color-mix(in srgb, var(--darkColor-blue) 8%, transparent); }
#leDragBar:active { cursor: grabbing; }
#leDragBar .le-drag-line {
    width: 36px; height: 3.5px; border-radius: 2px;
    background: var(--darkColor-blue); opacity: 0.28;
    transition: opacity var(--dur-2,0.18s);
}
#leDragBar:hover .le-drag-line { opacity: 0.65; }
#leDragBar .le-drag-label {
    font-size: 0.58rem; font-weight: 600; letter-spacing: 0.05em;
    color: var(--darkColor-blue); opacity: 0;
    transition: opacity var(--dur-2,0.18s);
}
#leDragBar:hover .le-drag-label { opacity: 0.45; }

/* Panel header */
#lePanelHeader {
    display: flex; align-items: center; gap: 9px;
    padding: 4px 16px 12px;
    border-bottom: 1.5px solid color-mix(in srgb, var(--darkColor-blue) 15%, transparent);
    flex-shrink: 0;
}
#lePanelHeaderIcon {
    width: 30px; height: 30px; border-radius: 50%;
    background: var(--darkColor-blue);
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
#lePanelTitle { font-size: 0.88rem; font-weight: 700; color: var(--darkerColor-blue); flex: 1; }
#lePanelHint {
    font-size: 0.7rem; color: var(--textColorDark-blue); opacity: 0.58;
    line-height: 1.55; padding: 8px 16px 2px; flex-shrink: 0;
}

/* Scrollable rows */
#lePanelBody { overflow-y: auto; overflow-x: hidden; flex: 1; scrollbar-width: none; padding: 8px 12px; }
#lePanelBody::-webkit-scrollbar { display: none; }
#leRows { display: flex; flex-direction: column; gap: 5px; }

.le-row {
    display: grid;
    grid-template-columns: 28px minmax(0,1fr) auto auto;
    align-items: center; gap: 8px;
    padding: 9px 10px; border-radius: 14px;
    background: color-mix(in srgb, var(--darkColor-blue) 7%, transparent);
    cursor: pointer;
    transition: background var(--dur-2,0.18s);
    border: 1.5px solid transparent;
}
.le-row:hover { background: color-mix(in srgb, var(--darkColor-blue) 13%, transparent); }
.le-row.le-row-active {
    background: color-mix(in srgb, var(--darkColor-blue) 14%, transparent);
    border-color: color-mix(in srgb, var(--darkColor-blue) 28%, transparent);
}
.le-row-icon {
    width: 28px; height: 28px; border-radius: 50%;
    background: color-mix(in srgb, var(--darkColor-blue) 16%, transparent);
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; position: relative;
}
.le-row-icon::after {
    content:''; position:absolute; top:-1px; right:-1px;
    width:7px; height:7px; border-radius:50%;
    background: var(--darkColor-blue);
    border: 1.5px solid var(--accentLightTint-blue);
    opacity:0; transition:opacity 0.15s;
}
.le-row.le-modified .le-row-icon::after { opacity: 1; }
.le-row-label {
    font-size: 0.8rem; font-weight: 600; color: var(--textColorDark-blue);
    white-space: nowrap; overflow: hidden; text-overflow: clip;
}
.le-scale-wrap { display: flex; align-items: center; gap: 5px; }

/* Scale buttons */
.le-btn {
    width: 26px; height: 26px; border-radius: 50%; border: none; cursor: pointer;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    transition: background var(--dur-1,0.12s), transform var(--dur-1,0.12s),
                box-shadow var(--dur-1,0.12s);
    font-size: 1.1rem; line-height: 1; font-weight: 700; padding: 0;
    font-family: var(--main-font-family, sans-serif);
    touch-action: none;
}
.le-btn-scale {
    background: color-mix(in srgb, var(--darkColor-blue) 14%, transparent);
    color: var(--darkerColor-blue);
}
.le-btn-scale:hover { background: var(--darkColor-blue); color: #fff; transform: scale(1.12); }
/* Visual feedback when holding */
.le-btn-scale.le-holding {
    background: var(--darkerColor-blue); color: #fff; transform: scale(0.93);
    box-shadow: 0 0 0 4px color-mix(in srgb, var(--darkColor-blue) 30%, transparent);
}
.le-scale-pct {
    font-size: 0.72rem; font-weight: 700; color: var(--darkerColor-blue);
    min-width: 38px; text-align: center;
}

/* Reset button */
.le-btn-reset {
    width: 26px; height: 26px; border-radius: 50%;
    border: 1.5px solid color-mix(in srgb, var(--darkColor-blue) 32%, transparent);
    background: transparent; color: var(--darkColor-blue); cursor: pointer;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    transition: background var(--dur-1,0.12s), border-color var(--dur-1,0.12s),
                transform var(--dur-1,0.12s), opacity var(--dur-1,0.12s);
    opacity: 0.35;
}
.le-row.le-modified .le-btn-reset { opacity: 1; }
.le-btn-reset:hover {
    background: color-mix(in srgb, var(--darkColor-blue) 12%, transparent);
    border-color: var(--darkColor-blue);
    transform: rotate(-35deg) scale(1.1);
}

/* Footer */
#lePanelFooter {
    display: flex; gap: 8px; padding: 10px 12px 14px;
    border-top: 1.5px solid color-mix(in srgb, var(--darkColor-blue) 15%, transparent);
    flex-shrink: 0;
}
.le-footer-btn {
    flex: 1; padding: 9px 8px; border-radius: 12px; border: none; cursor: pointer;
    font-size: 0.79rem; font-weight: 700;
    font-family: var(--main-font-family, sans-serif);
    transition: background var(--dur-2,0.18s), transform var(--dur-1,0.12s);
}
.le-footer-btn:active { transform: scale(0.95); }
#leResetAllBtn {
    background: color-mix(in srgb, var(--darkColor-blue) 13%, transparent);
    color: var(--darkerColor-blue);
}
#leResetAllBtn:hover { background: color-mix(in srgb, var(--darkColor-blue) 22%, transparent); }
#leDoneBtn { background: var(--darkColor-blue); color: #fff; }
#leDoneBtn:hover { background: var(--darkerColor-blue); }

/* ── Trigger button in sidebar ───────────────────────────────────────────── */
#layoutEditorBtn {
    display: flex; align-items: center; justify-content: center;
    width: 38px; height: 38px; padding: 0; box-sizing: border-box;
    border-radius: 50%; border: none; cursor: pointer; flex-shrink: 0;
    appearance: none; -webkit-appearance: none; pointer-events: auto;
    background: color-mix(in srgb, var(--darkColor-blue) 14%, transparent);
    color: var(--darkerColor-blue);
    transition: background var(--dur-2,0.18s), transform var(--dur-1,0.12s);
}
#layoutEditorBtn:hover { background: var(--darkColor-blue); color: #fff; transform: scale(1.08); }
#layoutEditorBtn.le-btn-active {
    background: var(--darkColor-blue); color: #fff;
    animation: leBtnPulse 1.8s ease-in-out infinite;
}
@keyframes leBtnPulse {
    0%,100% { box-shadow: 0 0 0 0   color-mix(in srgb, var(--darkColor-blue) 40%, transparent); }
    50%      { box-shadow: 0 0 0 8px transparent; }
}

/* ── Tabs ─────────────────────────────────────────────────────────────────── */
#leTabs {
    position: relative;
    display: flex; gap: 4px; padding: 6px 12px 0;
    border-bottom: 1.5px solid color-mix(in srgb, var(--darkColor-blue) 15%, transparent);
    flex-shrink: 0;
}
/* Sliding blue indicator bar */
#leTabIndicator {
    position: absolute;
    bottom: -1.5px; height: 2px;
    background: var(--darkColor-blue);
    border-radius: 2px 2px 0 0;
    transition: left calc(0.28s * var(--ui-anim-mult, 1)) cubic-bezier(0.4, 0, 0.2, 1),
                width calc(0.28s * var(--ui-anim-mult, 1)) cubic-bezier(0.4, 0, 0.2, 1);
    pointer-events: none;
}
.le-tab {
    flex: 1; padding: 7px 4px; border: none; border-radius: 10px 10px 0 0;
    background: transparent; cursor: pointer;
    font-size: 0.73rem; font-weight: 700; letter-spacing: 0.01em;
    color: var(--textColorDark-blue); opacity: 0.5;
    font-family: var(--main-font-family, sans-serif);
    transition: opacity calc(var(--dur-2, 0.18s) * var(--ui-anim-mult, 1)),
                color calc(var(--dur-2, 0.18s) * var(--ui-anim-mult, 1));
    border-bottom: none; margin-bottom: 0;
}
.le-tab:hover { opacity: 0.75; }
.le-tab.le-tab-active {
    opacity: 1;
    color: var(--darkerColor-blue);
}

/* ── Tab content panels — animated fade+slide ─────────────────────────────── */
#lePanelBody, #lePresetsBody {
    overflow-y: auto; overflow-x: hidden; flex: 1; scrollbar-width: none; padding: 10px 12px;
    /* shared animation properties */
    transition: opacity calc(0.2s * var(--ui-anim-mult, 1)) ease,
                transform calc(0.2s * var(--ui-anim-mult, 1)) ease;
}
#lePanelBody { padding: 8px 12px; }
#lePanelBody::-webkit-scrollbar, #lePresetsBody::-webkit-scrollbar { display: none; }

/* Hidden state — used during tab switch */
#lePanelBody.le-tab-hidden, #lePresetsBody.le-tab-hidden {
    opacity: 0;
    transform: translateX(6px);
    pointer-events: none;
}
/* Visible state */
#lePanelBody.le-tab-visible-anim, #lePresetsBody.le-tab-visible-anim {
    opacity: 1;
    transform: translateX(0);
    pointer-events: auto;
}
/* Presets panel hidden by default (no display:none — we animate instead) */
#lePresetsBody { display: none; }
#lePresetsBody.le-tab-visible { display: block; }

.le-preset-section-label {
    font-size: 0.65rem; font-weight: 700; letter-spacing: 0.07em; text-transform: uppercase;
    color: var(--darkColor-blue); opacity: 0.5; padding: 4px 2px 6px;
}
.le-preset-grid {
    display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 12px;
}
.le-preset-card {
    padding: 10px 8px 8px; border-radius: 13px;
    background: color-mix(in srgb, var(--darkColor-blue) 8%, transparent);
    border: 1.5px solid transparent; cursor: pointer;
    transition: background var(--dur-2,0.18s), border-color var(--dur-2,0.18s), transform var(--dur-1,0.12s);
    display: flex; flex-direction: column; align-items: center; gap: 5px;
    text-align: center;
}
.le-preset-card:hover {
    background: color-mix(in srgb, var(--darkColor-blue) 15%, transparent);
    transform: translateY(-1px);
}
.le-preset-card.le-preset-active {
    border-color: var(--darkColor-blue);
    background: color-mix(in srgb, var(--darkColor-blue) 14%, transparent);
}
.le-preset-card-icon {
    width: 30px; height: 30px; border-radius: 50%;
    background: color-mix(in srgb, var(--darkColor-blue) 18%, transparent);
    display: flex; align-items: center; justify-content: center;
}
.le-preset-card-name {
    font-size: 0.73rem; font-weight: 700; color: var(--darkerColor-blue);
}
.le-preset-card-desc {
    font-size: 0.62rem; color: var(--textColorDark-blue); opacity: 0.6; line-height: 1.35;
}
/* Custom presets list */
#leCustomPresetsList {
    max-height: 160px;
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: thin;
    scrollbar-color: color-mix(in srgb, var(--darkColor-blue) 25%, transparent) transparent;
    margin-bottom: 4px;
}
#leCustomPresetsList::-webkit-scrollbar { width: 4px; }
#leCustomPresetsList::-webkit-scrollbar-thumb {
    background: color-mix(in srgb, var(--darkColor-blue) 25%, transparent);
    border-radius: 4px;
}
.le-custom-preset-row {
    display: flex; align-items: center; gap: 7px;
    padding: 8px 10px; border-radius: 11px; margin-bottom: 5px;
    background: color-mix(in srgb, var(--darkColor-blue) 7%, transparent);
    border: 1.5px solid transparent;
    transition: background var(--dur-2,0.18s), border-color var(--dur-2,0.18s);
}
.le-custom-preset-row:hover { background: color-mix(in srgb, var(--darkColor-blue) 13%, transparent); }
.le-custom-preset-row.le-custom-row-active {
    border-color: var(--darkColor-blue);
    background: color-mix(in srgb, var(--darkColor-blue) 14%, transparent);
}
.le-custom-preset-name {
    flex: 1; font-size: 0.78rem; font-weight: 600; color: var(--darkerColor-blue);
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.le-custom-preset-apply {
    padding: 4px 10px; border-radius: 8px; border: none; cursor: pointer;
    background: var(--darkColor-blue); color: #fff;
    font-size: 0.68rem; font-weight: 700; font-family: var(--main-font-family, sans-serif);
    transition: background var(--dur-1,0.12s);
    flex-shrink: 0;
}
.le-custom-preset-apply:hover { background: var(--darkerColor-blue); }
.le-custom-preset-del {
    width: 22px; height: 22px; border-radius: 50%; border: none; cursor: pointer;
    background: transparent; color: var(--darkColor-blue); opacity: 0.4;
    display: flex; align-items: center; justify-content: center;
    font-size: 1rem; line-height: 1; transition: opacity var(--dur-1,0.12s), background var(--dur-1,0.12s);
    flex-shrink: 0; padding: 0;
}
.le-custom-preset-del:hover { opacity: 1; background: color-mix(in srgb, red 15%, transparent); color: red; }
/* Save form */
#leSavePresetForm {
    display: flex; gap: 6px; margin-top: 8px; padding-top: 10px;
    border-top: 1.5px solid color-mix(in srgb, var(--darkColor-blue) 12%, transparent);
}
#leSavePresetInput {
    flex: 1; padding: 7px 10px; border-radius: 10px;
    border: 1.5px solid color-mix(in srgb, var(--darkColor-blue) 25%, transparent);
    background: color-mix(in srgb, var(--darkColor-blue) 6%, transparent);
    font-size: 0.75rem; font-weight: 600; color: var(--darkerColor-blue);
    font-family: var(--main-font-family, sans-serif); outline: none;
    transition: border-color var(--dur-2,0.18s);
}
#leSavePresetInput:focus { border-color: var(--darkColor-blue); }
#leSavePresetInput::placeholder { opacity: 0.45; }
#leSavePresetBtn {
    padding: 7px 12px; border-radius: 10px; border: none; cursor: pointer;
    background: var(--darkColor-blue); color: #fff;
    font-size: 0.73rem; font-weight: 700; font-family: var(--main-font-family, sans-serif);
    transition: background var(--dur-1,0.12s), transform var(--dur-1,0.12s);
    flex-shrink: 0;
}
#leSavePresetBtn:hover { background: var(--darkerColor-blue); }
#leSavePresetBtn:active { transform: scale(0.94); }
#leNoCustomPresets {
    font-size: 0.72rem; color: var(--textColorDark-blue); opacity: 0.45;
    text-align: center; padding: 10px 0 4px; font-style: italic;
}

#leToast {
    z-index: 999999 !important;
}
`;
        document.head.appendChild(s);
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Toast notification
    ───────────────────────────────────────────────────────────────────────── */
    let toastTimer = null;
    let toastProgressTimer = null;
    function getAnimMult() {
        return parseFloat(
            getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")
        ) || 1;
    }
    function showToast(msg, iconType = "edit") {
        const DURATION = 3000;
        let toast = document.getElementById("leToast");
        if (!toast) {
            toast = document.createElement("div");
            toast.id = "leToast";
            toast.className = "bm-action-toast";
            toast.innerHTML = `
                <div class="bm-toast-progress"></div>
                <div class="bm-toast-inner">
                    <div class="bm-toast-icon-wrap" id="leToastIconWrap"></div>
                    <span class="bm-toast-text" id="leToastText"></span>
                </div>`;
            document.body.appendChild(toast);
        }

        const iconWrap = toast.querySelector("#leToastIconWrap");
        const textEl   = toast.querySelector("#leToastText");
        const progress = toast.querySelector(".bm-toast-progress");

        const icons = {
            copy:    `<svg viewBox="0 0 24 24"><path d="M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z"/></svg>`,
            edit:    `<svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>`,
            delete:  `<svg viewBox="0 0 24 24"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>`,
            add:     `<svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>`,
            move:    `<svg viewBox="0 0 24 24"><path d="M20 9V7H4v2l8 8 8-8z"/></svg>`,
            undo:    `<svg viewBox="0 0 24 24"><path d="M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z"/></svg>`,
            redo:    `<svg viewBox="0 0 24 24"><path d="M18.4 10.6C16.55 8.99 14.15 8 11.5 8c-4.65 0-8.58 3.03-9.96 7.22L3.9 16c1.05-3.19 4.05-5.5 7.6-5.5 1.95 0 3.73.72 5.12 1.88L13 16h9V7l-3.6 3.6z"/></svg>`,
            pin:     `<svg viewBox="0 0 24 24"><path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2z"/></svg>`,
            unpin:   `<svg viewBox="0 0 24 24"><path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2zm-4 5.17V16h-1v1.17L9.83 16H8v-.17L10 14V4h4v10l2 1.83V16h-1.17L12 17.17z"/></svg>`,
        };

        iconWrap.innerHTML = icons[iconType] || icons["edit"];
        textEl.textContent = msg;

        // Reset + start progress
        progress.style.transition = "none";
        progress.style.width = "100%";
        toast.classList.remove("bm-toast-show", "bm-toast-out");
        void toast.offsetWidth;
        toast.classList.add("bm-toast-show");

        clearTimeout(toastTimer);
        clearTimeout(toastProgressTimer);
        cancelAnimationFrame(toastProgressTimer);

        const mult = getAnimMult();
        const displayMs = Math.round(DURATION * Math.max(0.3, Math.min(mult, 2)));

        toastProgressTimer = requestAnimationFrame(() => {
            progress.style.transition = `width ${displayMs}ms linear`;
            progress.style.width = "0%";
        });

        toastTimer = setTimeout(() => {
            toast.classList.remove("bm-toast-show");
            void toast.offsetWidth;
            toast.classList.add("bm-toast-out");
            const hideDuration = 180;
            setTimeout(() => toast.classList.remove("bm-toast-show", "bm-toast-out"), hideDuration + 20);
        }, displayMs);
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Check if resetting a key to (tx=0, ty=0) would overlap another element.
       Returns the label of the blocking element, or null if the position is clear.
    ───────────────────────────────────────────────────────────────────────── */
    function checkResetOverlap(key) {
        const movingDef = ELEMENTS.find(d => d.key === key);
        if (!movingDef) return null;
        const movingEl = resolveTarget(movingDef);
        if (!movingEl) return null;

        for (const other of ELEMENTS) {
            if (other.key === key) continue;
            const otherEl = resolveTarget(other);
            if (!otherEl || !isVisible(otherEl)) continue;

            // Use 0 gap: only block reset if there is actual pixel overlap at origin
            const mr = projectRect(movingEl, key, 0, 0);
            const or = otherEl.getBoundingClientRect();

            const overlaps = !(mr.right  <= or.left  ||
                               mr.left   >= or.right ||
                               mr.bottom <= or.top   ||
                               mr.top    >= or.bottom);
            if (overlaps) return other.label;
        }
        return null;
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Build panel DOM
    ───────────────────────────────────────────────────────────────────────── */
    function _leConfirm(message) {
        if (typeof window.confirmPrompt === "function") return window.confirmPrompt(message);
        return Promise.resolve(window.confirm(message));
    }

    function _leIsArabic() {
        return (window.currentLanguage || localStorage.getItem("selectedLanguage") || "en").startsWith("ar");
    }

    function buildPanel() {
        if (document.getElementById("lePanel")) return;

        const panel = document.createElement("div");
        panel.id = "lePanel";
        panel.className = "shadow-floating-panel";
        panel.innerHTML = `
<div id="leDragBar" aria-hidden="true">
    <div class="le-drag-line"></div>
    <span class="le-drag-label" id="leDragLabel">drag</span>
</div>
<div id="lePanelHeader">
    <div id="lePanelHeaderIcon">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="white">
            <path d="M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z"/>
        </svg>
    </div>
    <span id="lePanelTitle">Layout Editor</span>
</div>
<div id="leTabs">
    <button class="le-tab le-tab-active" data-le-tab="elements">🎛 Elements</button>
    <button class="le-tab" data-le-tab="presets">🗂 Presets</button>
    <div id="leTabIndicator"></div>
</div>
<p id="lePanelHint">Drag elements on the page to move them. Hold −/+ to resize faster.</p>
<div id="lePanelBody"><div id="leRows"></div></div>
<div id="lePresetsBody">
    <div class="le-preset-section-label" id="leBuiltInPresetsLabel">Built-in Presets</div>
    <div class="le-preset-grid" id="leBuiltInGrid"></div>
    <div class="le-preset-section-label" id="leMyPresetsLabel">My Presets</div>
    <div id="leCustomPresetsList"></div>
    <div id="leSavePresetForm">
        <input id="leSavePresetInput" type="text" placeholder="Name this layout…" maxlength="30" />
        <button id="leSavePresetBtn">Save</button>
    </div>
</div>
<div id="lePanelFooter">
    <button class="le-footer-btn" id="leResetAllBtn">Reset All</button>
    <button class="le-footer-btn" id="leDoneBtn">✓ Done</button>
</div>`;

        // Apply translations to panel text
        const _lang = (typeof currentLanguage !== "undefined" ? currentLanguage : "en");
        const _tP = (key) => {
            if (typeof translations === "undefined") return key;
            return (translations[_lang] && translations[_lang][key])
                || (translations["en"] && translations["en"][key])
                || key;
        };
        function applyPanelTranslations() {
            const els = {
                lePanelTitle:         "lePanelTitle",
                lePanelHint:          "lePanelHint",
                leResetAllBtn:        "leResetAll",
                leDoneBtn:            "leDone",
                leDragLabel:          "leDragLabel",
                leBuiltInPresetsLabel:"leBuiltInPresetsLabel",
                leMyPresetsLabel:     "leMyPresetsLabel",
                leSavePresetBtn:      "leSaveBtnText",
            };
            Object.entries(els).forEach(([id, key]) => {
                const el = document.getElementById(id);
                if (el) el.textContent = _tP(key);
            });
            // Tabs
            document.querySelectorAll(".le-tab").forEach(tab => {
                const which = tab.dataset.leTab;
                if (which === "elements") tab.textContent = _tP("leTabElements");
                else if (which === "presets") tab.textContent = _tP("leTabPresets");
            });
            // Save input placeholder
            const inp = document.getElementById("leSavePresetInput");
            if (inp) inp.placeholder = _tP("leNameLayoutPlaceholder");
        }
        applyPanelTranslations();

        document.body.appendChild(panel);

        // Re-apply translations after window.onload (languages.js runs then)
        window.addEventListener("load", () => {
            applyPanelTranslations();
            buildBuiltInGrid(); // rebuild with translated labels
        }, { once: true });

        const rowsEl = panel.querySelector("#leRows");
        ELEMENTS.forEach(def => rowsEl.appendChild(createRow(def)));

        panel.querySelector("#leResetAllBtn").addEventListener("click", () => {
            const msg = _leIsArabic()
                ? "إعادة ضبط مواضع وأحجام كل العناصر؟"
                : "Reset position and size for all elements?";
            _leConfirm(msg).then((ok) => {
                if (!ok) return;
                ELEMENTS.forEach(def => { state[def.key] = { tx: 0, ty: 0, scale: 1 }; });
                applyAll(); saveState(); refreshAllRows(); applyTargetClasses();
                autoDetectAndSetActivePreset();
                showToast(_t("leToastResetAll"), "undo");
            });
        });
        panel.querySelector("#leDoneBtn").addEventListener("click", exitEditMode);

        // ── Tab switching with animated indicator + content fade ──
        let _currentTab = "elements";

        function moveTabIndicator(targetTab) {
            const indicator = document.getElementById("leTabIndicator");
            if (!indicator) return;
            const rect = targetTab.getBoundingClientRect();
            const tabsRect = document.getElementById("leTabs").getBoundingClientRect();
            indicator.style.left  = (rect.left - tabsRect.left) + "px";
            indicator.style.width = rect.width + "px";
        }

        function switchTab(which) {
            if (which === _currentTab) return;
            const mult = getAnimMult();
            const dur  = Math.round(200 * mult);

            panel.querySelectorAll(".le-tab").forEach(t =>
                t.classList.toggle("le-tab-active", t.dataset.leTab === which));

            // Move indicator to the active tab
            const activeTabEl = panel.querySelector(`.le-tab[data-le-tab="${which}"]`);
            if (activeTabEl) moveTabIndicator(activeTabEl);

            const hint       = document.getElementById("lePanelHint");
            const body       = document.getElementById("lePanelBody");
            const presetsBody= document.getElementById("lePresetsBody");

            const outPanel = which === "presets" ? body       : presetsBody;

            // If switching to presets, populate first (while still hidden)
            if (which === "presets") refreshPresetsUI();

            // Fade OUT current panel
            if (outPanel) {
                outPanel.classList.add("le-tab-hidden");
                outPanel.classList.remove("le-tab-visible-anim");
            }
            if (hint) hint.style.transition = `opacity calc(0.18s * var(--ui-anim-mult,1))`;
            if (hint) hint.style.opacity = which === "presets" ? "0" : "1";

            setTimeout(() => {
                // Measure panel height before switching contents
                const startHeight = panel.getBoundingClientRect().height;

                // Hide outgoing, show incoming
                if (which === "presets") {
                    if (body) body.style.display = "none";
                    if (hint) hint.style.display = "none";
                    if (presetsBody) {
                        presetsBody.classList.add("le-tab-visible", "le-tab-hidden");
                        presetsBody.classList.remove("le-tab-visible-anim");
                        // Force reflow then animate in
                        void presetsBody.offsetWidth;
                        presetsBody.classList.remove("le-tab-hidden");
                        presetsBody.classList.add("le-tab-visible-anim");
                    }
                } else {
                    if (presetsBody) {
                        presetsBody.classList.remove("le-tab-visible", "le-tab-visible-anim");
                    }
                    if (body) {
                        body.style.display = "";
                        body.classList.add("le-tab-hidden");
                        void body.offsetWidth;
                        body.classList.remove("le-tab-hidden");
                        body.classList.add("le-tab-visible-anim");
                    }
                    if (hint) {
                        hint.style.display = "";
                        hint.style.opacity = "1";
                    }
                }

                // Measure panel height after switching contents
                const targetHeight = panel.getBoundingClientRect().height;

                // Apply height transition with premium spring/bounce timing
                panel.style.height = startHeight + "px";
                void panel.offsetHeight; // Force reflow
                
                panel.style.transition = `height ${dur}ms cubic-bezier(0.34, 1.56, 0.64, 1)`;
                panel.style.height = targetHeight + "px";

                const onTransitionEnd = (e) => {
                    if (e.propertyName === "height") {
                        panel.style.height = "";
                        panel.style.transition = "";
                        panel.removeEventListener("transitionend", onTransitionEnd);
                    }
                };
                panel.addEventListener("transitionend", onTransitionEnd);

                _currentTab = which;
            }, dur);
        }

        // Initialise indicator position on first render
        requestAnimationFrame(() => {
            const firstTab = panel.querySelector(".le-tab.le-tab-active");
            if (firstTab) moveTabIndicator(firstTab);
            // Set initial visible state on elements panel
            const body = document.getElementById("lePanelBody");
            if (body) body.classList.add("le-tab-visible-anim");
        });

        panel.querySelectorAll(".le-tab").forEach(tab => {
            tab.addEventListener("click", () => switchTab(tab.dataset.leTab));
        });

        // ── Built-in presets grid ──
        buildBuiltInGrid();

        // ── Save preset button ──
        panel.querySelector("#leSavePresetBtn").addEventListener("click", () => {
            const input = document.getElementById("leSavePresetInput");
            const name = (input ? input.value : "").trim();
            if (!name) { showToast(_t("leToastEnterName"), "edit"); return; }

            // Block saving if a custom preset with the exact same name already exists
            const nameExists = customPresets.some(p => p.label.toLowerCase() === name.toLowerCase());
            if (nameExists) {
                showToast(`"${name}" ${_t("leToastNameExists") || "already exists"}`, "edit");
                return;
            }

            // Block saving if current layout is identical to an existing preset
            const dupLabel = findDuplicatePreset();
            if (dupLabel) {
                showToast(`"${dupLabel}" ${_t("leToastDuplicate") || "already exists"}`, "edit");
                return;
            }
            const newPreset = saveCurrentAsPreset(name);
            if (input) input.value = "";

            // Automatically select the newly created layout preset
            setActivePreset(newPreset.id);
            activePresetSnapshot = JSON.parse(JSON.stringify(state));
            saveActivePresetContext();

            refreshPresetsUI();
            showToast(`"${name}" ${_t("leToastSaved")}`, "add");
        });
        document.getElementById("leSavePresetInput")?.addEventListener("keydown", e => {
            if (e.key === "Enter") document.getElementById("leSavePresetBtn")?.click();
        });

        initPanelDrag(panel, panel.querySelector("#leDragBar"));
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Build built-in presets grid (called once at panel creation)
    ───────────────────────────────────────────────────────────────────────── */
    function buildBuiltInGrid() {
        const grid = document.getElementById("leBuiltInGrid");
        if (!grid) return;
        grid.innerHTML = "";
        BUILT_IN_PRESETS.forEach(preset => {
            const label = _t(preset.labelKey);
            const desc  = _t(preset.descKey);
            const card = document.createElement("div");
            card.className = "le-preset-card" + (preset.id === activePresetId ? " le-preset-active" : "");
            card.dataset.presetId = preset.id;
            card.innerHTML = `
<div class="le-preset-card-icon">
    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" style="color:var(--darkerColor-blue)">
        <path d="${preset.icon}"/>
    </svg>
</div>
<div class="le-preset-card-name">${label}</div>
<div class="le-preset-card-desc">${desc}</div>`;
            card.addEventListener("click", () => {
                if (activePresetId === preset.id && activePresetSnapshot !== null) return;
                applyPreset(preset.state, preset.id);
                showToast(`"${label}" ${_t("leToastApplied")}`, "move");
            });
            grid.appendChild(card);
        });
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Refresh custom presets list (called when switching to presets tab or after save/delete)
    ───────────────────────────────────────────────────────────────────────── */
    function refreshPresetsUI() {
        const list = document.getElementById("leCustomPresetsList");
        if (!list) return;
        list.innerHTML = "";

        if (customPresets.length === 0) {
            const empty = document.createElement("div");
            empty.id = "leNoCustomPresets";
            empty.textContent = _t("leNoCustomPresets");
            list.appendChild(empty);
            return;
        }

        customPresets.forEach(preset => {
            const row = document.createElement("div");
            row.className = "le-custom-preset-row" + (preset.id === activePresetId ? " le-custom-row-active" : "");
            row.dataset.presetId = preset.id;
            row.innerHTML = `
<span class="le-custom-preset-name">${preset.label}</span>
<button class="le-custom-preset-apply">${_t("leApplyBtnText")}</button>
<button class="le-custom-preset-del" title="${_t("leDeleteBtnTitle")}">×</button>`;
            row.querySelector(".le-custom-preset-apply").addEventListener("click", () => {
                if (activePresetId === preset.id && activePresetSnapshot !== null) return;
                applyPreset(preset.state, preset.id);
                showToast(`"${preset.label}" ${_t("leToastApplied")}`, "move");
            });
            row.querySelector(".le-custom-preset-del").addEventListener("click", () => {
                const msg = _leIsArabic()
                    ? `حذف "${preset.label}"؟`
                    : `Delete "${preset.label}"?`;
                _leConfirm(msg).then((ok) => {
                    if (!ok) return;
                    const wasActive = (activePresetId === preset.id);
                    deleteCustomPreset(preset.id);
                    refreshPresetsUI();
                    // If the deleted preset was the active one, actually apply Default layout
                    if (wasActive) {
                        const defaultPreset = BUILT_IN_PRESETS.find(p => p.id === "default");
                        if (defaultPreset) applyPreset(defaultPreset.state, "default");
                        showToast(_t("leToastDeletedActive"), "delete");
                    } else {
                        showToast(_t("leToastDeleted"), "delete");
                    }
                });
            });
            list.appendChild(row);
        });
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Panel drag via pointer capture on drag bar
    ───────────────────────────────────────────────────────────────────────── */
    function initPanelDrag(panel, handle) {
        handle.addEventListener("pointerdown", e => {
            if (e.button !== 0) return;
            e.preventDefault(); e.stopPropagation();

            const r = panel.getBoundingClientRect();
            panel.style.bottom = "auto";
            panel.style.right  = "auto";
            panel.style.left   = r.left + "px";
            panel.style.top    = r.top  + "px";

            panelDrag = {
                pointerId: e.pointerId,
                startPX: e.clientX, startPY: e.clientY,
                startLeft: r.left,  startTop: r.top,
            };
            handle.setPointerCapture(e.pointerId);
        });

        handle.addEventListener("pointermove", e => {
            if (!panelDrag || e.pointerId !== panelDrag.pointerId) return;
            const vw = window.innerWidth, vh = window.innerHeight;
            const pw = panel.offsetWidth,  ph = panel.offsetHeight;
            panel.style.left = Math.max(0, Math.min(vw - pw, panelDrag.startLeft + e.clientX - panelDrag.startPX)) + "px";
            panel.style.top  = Math.max(0, Math.min(vh - ph, panelDrag.startTop  + e.clientY - panelDrag.startPY)) + "px";
        });

        const endPD = () => { panelDrag = null; };
        handle.addEventListener("pointerup",     endPD);
        handle.addEventListener("pointercancel", endPD);
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Long-press acceleration on −/+ scale buttons
       • Single tap  → one step immediately
       • Hold 400ms+ → starts repeating, interval decreases (gets faster)
       • Max speed caps at MIN_INTERVAL ms
    ───────────────────────────────────────────────────────────────────────── */
    function setupScaleHold(btn, def, delta) {
        const MIN_INTERVAL = 40;    // fastest allowed repeat (ms)
        const INIT_DELAY   = 400;   // wait before starting repeats (ms)
        const ACCEL        = 0.68;  // multiply interval by this each step

        let holdTimer   = null;
        let repeatTimer = null;
        let interval    = 280;
        let isHolding   = false;

        function step() {
            adjustScale(def, delta);
        }

        function repeat() {
            step();
            interval = Math.max(MIN_INTERVAL, interval * ACCEL);
            repeatTimer = setTimeout(repeat, interval);
        }

        function startHold() {
            interval = 280;
            holdTimer = setTimeout(() => {
                isHolding = true;
                btn.classList.add("le-holding");
                repeat();
            }, INIT_DELAY);
        }

        function stopHold() {
            clearTimeout(holdTimer);
            clearTimeout(repeatTimer);
            holdTimer = repeatTimer = null;
            isHolding = false;
            btn.classList.remove("le-holding");
        }

        btn.addEventListener("pointerdown", e => {
            if (e.button > 0) return;
            e.preventDefault(); e.stopPropagation();
            startHold();
        });
        ["pointerup", "pointercancel", "pointerleave"].forEach(ev =>
            btn.addEventListener(ev, stopHold)
        );

        // click fires once on tap; for held presses we already fired via repeat()
        btn.addEventListener("click", e => {
            e.stopPropagation();
            if (!isHolding) step();
        });
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Row helpers
    ───────────────────────────────────────────────────────────────────────── */
    function pct(key) { return Math.round(state[key].scale * 100) + "%"; }

    function adjustScale(def, delta) {
        const s = state[def.key];
        s.scale = +(Math.max(def.minScale, Math.min(def.maxScale, s.scale + delta)).toFixed(2));
        applyAll(); saveState(); refreshRow(def.key);
        autoDetectAndSetActivePreset();
    }

    function createRow(def) {
        const row = document.createElement("div");
        row.className = "le-row" + (isModified(def.key) ? " le-modified" : "");
        row.dataset.leKey = def.key;
        row.innerHTML = `
<div class="le-row-icon">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"
         style="color:var(--darkerColor-blue)"><path d="${def.icon}"/></svg>
</div>
<span class="le-row-label">${def.label}</span>
<div class="le-scale-wrap">
    <button class="le-btn le-btn-scale" data-action="minus" title="Shrink (hold to speed up)">−</button>
    <span class="le-scale-pct" data-scale-pct="${def.key}">${pct(def.key)}</span>
    <button class="le-btn le-btn-scale" data-action="plus"  title="Grow (hold to speed up)">+</button>
</div>
<button class="le-btn-reset" title="Reset position &amp; size">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
    </svg>
</button>`;

        setupScaleHold(row.querySelector("[data-action='minus']"), def, -SCALE_STEP);
        setupScaleHold(row.querySelector("[data-action='plus']"),  def, +SCALE_STEP);

        row.querySelector(".le-btn-reset").addEventListener("click", e => {
            e.stopPropagation();
            state[def.key] = { tx: 0, ty: 0, scale: 1 };
            applyAll(); saveState(); refreshRow(def.key); applyTargetClasses();
            autoDetectAndSetActivePreset();
        });
        row.addEventListener("click", e => {
            if (e.target.closest(".le-btn-scale,.le-btn-reset")) return;
            setFocus(def.key);
        });
        return row;
    }

    function refreshRow(key) {
        const row = document.querySelector(`.le-row[data-le-key="${key}"]`);
        if (!row) return;
        row.classList.toggle("le-modified", isModified(key));
        const p = row.querySelector(`[data-scale-pct="${key}"]`);
        if (p) p.textContent = pct(key);
    }
    function refreshAllRows() { ELEMENTS.forEach(d => refreshRow(d.key)); }

    /* ─────────────────────────────────────────────────────────────────────────
       Focus
    ───────────────────────────────────────────────────────────────────────── */
    function setFocus(key) {
        activeKey = key;
        document.querySelectorAll(".le-row").forEach(r =>
            r.classList.toggle("le-row-active", r.dataset.leKey === key));
        document.querySelectorAll(".le-target").forEach(el =>
            el.classList.toggle("le-focused", el.dataset.leKey === key));
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Target classes
    ───────────────────────────────────────────────────────────────────────── */
    function applyTargetClasses() {
        if (!editMode) return;
        ELEMENTS.forEach(def => {
            def.selectors.forEach(sel => {
                document.querySelectorAll(sel).forEach(el => {
                    el.classList.add("le-target");
                    el.dataset.leKey  = def.key;
                    el.style.touchAction = "none";
                });
            });
        });
    }

    function removeTargetClasses() {
        document.querySelectorAll(".le-target").forEach(el => {
            el.classList.remove("le-target", "le-focused", "le-dragging");
            delete el.dataset.leKey;
            el.style.touchAction = "";
        });
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Deselect all — shared helper used by pointer + click handlers
    ───────────────────────────────────────────────────────────────────────── */
    function deselectAll() {
        activeKey = null;
        document.querySelectorAll(".le-row").forEach(r => r.classList.remove("le-row-active"));
        document.querySelectorAll(".le-target").forEach(el => el.classList.remove("le-focused"));
    }

    /* Fallback bubbling-phase click handler — catches clicks that land outside
       every .le-target and the panel (safety net for the capture path above) */
    function onBgClick(e) {
        if (!editMode) return;
        const panel = document.getElementById("lePanel");
        if (panel && panel.contains(e.target)) return;
        if (e.target.closest(".le-target")) return;
        deselectAll();
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Element drag (capture phase — intercepts any child's pointer events)
    ───────────────────────────────────────────────────────────────────────── */
    function onPointerDown(e) {
        if (!editMode || e.button > 0) return;
        const panel = document.getElementById("lePanel");
        if (panel && panel.contains(e.target)) return;

        const target = e.target.closest(".le-target");
        if (!target) {
            // Clicked on empty area — deselect but do NOT stopPropagation so
            // the menuBar backdrop-click handler can still fire and close the sidebar.
            deselectAll();
            return;
        }

        e.preventDefault(); e.stopPropagation();

        const key = target.dataset.leKey;
        if (!key) return;

        setFocus(key);
        target.classList.add("le-dragging");
        try { target.setPointerCapture(e.pointerId); } catch (_) {}

        activeDrag = {
            key, target,
            pointerId: e.pointerId,
            startPX: e.clientX, startPY: e.clientY,
            startTX: state[key].tx,
            startTY: state[key].ty,
        };
    }

    function onPointerMove(e) {
        if (!activeDrag || e.pointerId !== activeDrag.pointerId) return;

        // If viewport became small while dragging, cancel the drag
        if (isMobileViewport()) {
            onPointerUp(e);
            return;
        }

        const rawTx = activeDrag.startTX + (e.clientX - activeDrag.startPX);
        const rawTy = activeDrag.startTY + (e.clientY - activeDrag.startPY);

        // Step 1: clamp to viewport edges
        const clamped = clampToViewport(activeDrag.key, rawTx, rawTy, null, state[activeDrag.key].scale);

        // Step 2: enforce minimum gap from other elements
        const final = enforceGap(activeDrag.key, clamped.tx, clamped.ty);

        state[activeDrag.key].tx = final.tx;
        state[activeDrag.key].ty = final.ty;

        applyAll();
        refreshRow(activeDrag.key);
    }

    function onPointerUp(e) {
        if (!activeDrag || e.pointerId !== activeDrag.pointerId) return;
        activeDrag.target.classList.remove("le-dragging");
        saveState();
        autoDetectAndSetActivePreset();
        activeDrag = null;
    }

    /* ─────────────────────────────────────────────────────────────────────────
       Edit mode lifecycle
    ───────────────────────────────────────────────────────────────────────── */
    function enterEditMode() {
        // Layout editor is not useful on small viewports where the responsive
        // CSS controls the layout — silently bail out.
        if (isMobileViewport()) return;

        editMode = true;
        document.body.classList.add("le-edit-mode");

        document.addEventListener("pointerdown",   onPointerDown, { capture: true });
        document.addEventListener("pointermove",   onPointerMove, { capture: true, passive: true });
        document.addEventListener("pointerup",     onPointerUp,   { capture: true });
        document.addEventListener("pointercancel", onPointerUp,   { capture: true });
        document.addEventListener("click",         onBgClick);

        applyTargetClasses();

        const panel = document.getElementById("lePanel");
        if (panel) {
            panel.style.bottom = "24px";
            panel.style.right  = "24px";
            panel.style.left   = "auto";
            panel.style.top    = "auto";
            panel.classList.add("le-open");
        }
        refreshAllRows();
        document.getElementById("layoutEditorBtn")?.classList.add("le-btn-active");
        document.addEventListener("keydown", _esc);
        // Ensure the currently active preset card is visually highlighted
        setActivePreset(activePresetId);
    }

    function exitEditMode() {
        if (findDuplicatePreset() === null) {
            showToast(_t("leToastSaveFirst"), "edit");
            return;
        }
        editMode = false;
        document.body.classList.remove("le-edit-mode");

        document.removeEventListener("pointerdown",   onPointerDown, { capture: true });
        document.removeEventListener("pointermove",   onPointerMove, { capture: true });
        document.removeEventListener("pointerup",     onPointerUp,   { capture: true });
        document.removeEventListener("pointercancel", onPointerUp,   { capture: true });
        document.removeEventListener("click",         onBgClick);

        removeTargetClasses();
        activeDrag = null;

        const panel = document.getElementById("lePanel");
        if (panel) {
            panel.classList.remove("le-open");
            panel.classList.add("le-closing");
            const panelStyles = getComputedStyle(panel);
            const parseTimingMs = (value = "") => Math.max(...value.split(",").map((part) => {
                const trimmed = part.trim();
                if (!trimmed) return 0;
                if (trimmed.endsWith("ms")) return parseFloat(trimmed) || 0;
                if (trimmed.endsWith("s")) return (parseFloat(trimmed) || 0) * 1000;
                return parseFloat(trimmed) || 0;
            }));
            const hideDelay = Math.max(
                parseTimingMs(panelStyles.animationDuration) + parseTimingMs(panelStyles.animationDelay),
                180
            );
            setTimeout(() => {
                panel.classList.remove("le-closing");
            }, hideDelay + 24);
        }

        document.getElementById("layoutEditorBtn")?.classList.remove("le-btn-active");
        document.removeEventListener("keydown", _esc);
        activeKey = null;
    }

    function _esc(e) { if (e.key === "Escape") exitEditMode(); }

    /* ─────────────────────────────────────────────────────────────────────────
       Init
    ───────────────────────────────────────────────────────────────────────── */
    document.addEventListener("DOMContentLoaded", () => {
        loadState();
        loadCustomPresets();

        // Restore the active preset context (ID + snapshot) from localStorage
        // so the blue-dot modified check works correctly after page reloads.
        loadActivePresetContext();
        autoDetectAndSetActivePreset();

        injectCSS();
        applyAll();
        buildPanel();
        document.getElementById("layoutEditorBtn")?.addEventListener("click", () => {
            editMode ? exitEditMode() : enterEditMode();
        });

        // Expose a re-translate hook so languages.js can call it after a language change
        window.reTranslateLayoutEditor = function () {
            if (!document.getElementById("lePanel")) return;
            const lang2 = (typeof currentLanguage !== "undefined" ? currentLanguage : "en");
            const tFn = (key) => {
                if (typeof translations === "undefined") return key;
                return (translations[lang2] && translations[lang2][key])
                    || (translations["en"] && translations["en"][key])
                    || key;
            };
            const ids = {
                lePanelTitle:          "lePanelTitle",
                lePanelHint:           "lePanelHint",
                leResetAllBtn:         "leResetAll",
                leDoneBtn:             "leDone",
                leDragLabel:           "leDragLabel",
                leBuiltInPresetsLabel: "leBuiltInPresetsLabel",
                leMyPresetsLabel:      "leMyPresetsLabel",
                leSavePresetBtn:       "leSaveBtnText",
            };
            Object.entries(ids).forEach(([id, key]) => {
                const el = document.getElementById(id);
                if (el) el.textContent = tFn(key);
            });
            document.querySelectorAll(".le-tab").forEach(tab => {
                const which = tab.dataset.leTab;
                if (which === "elements") tab.textContent = tFn("leTabElements");
                else if (which === "presets") tab.textContent = tFn("leTabPresets");
            });
            const inp = document.getElementById("leSavePresetInput");
            if (inp) inp.placeholder = tFn("leNameLayoutPlaceholder");
            buildBuiltInGrid();
            refreshPresetsUI();
        };

        // Re-apply transforms when viewport changes (resize / browser zoom).
        // IMPORTANT: state is NEVER mutated here and we NEVER call saveState()
        // while transitioning to a small viewport.
        // Doing so would overwrite the user's desktop positions with mobile-
        // clamped values, making them impossible to restore on resize back.
        // applyAll() already suppresses tx/ty on small viewports automatically.
        // On return to a large viewport we do a single gentle clamp+save so that
        // positions that genuinely exceed the current desktop size are corrected.
        let _resizeTimer = null;
        function onViewportChange() {
            clearTimeout(_resizeTimer);
            _resizeTimer = setTimeout(() => {
                // Auto-close the editor panel if we cross into responsive territory
                if (editMode && isMobileViewport()) {
                    exitEditMode();
                }

                // First apply without mutating state (handles mobile → tx/ty = 0)
                applyAll();

                // Only clamp+save when back on a desktop-sized viewport
                if (!isMobileViewport()) {
                    let changed = false;
                    for (const def of ELEMENTS) {
                        const s = state[def.key];
                        if (s.tx === 0 && s.ty === 0) {
                            continue; // Skip clamping natural defaults
                        }
                        const clamped = clampToViewport(def.key, s.tx, s.ty, null, s.scale);
                        if (clamped.tx !== s.tx || clamped.ty !== s.ty) {
                            s.tx = clamped.tx;
                            s.ty = clamped.ty;
                            changed = true;
                        }
                    }
                    if (changed) {
                        applyAll();
                        saveState();
                        autoDetectAndSetActivePreset();
                    }
                }
            }, 150);
        }

        window.addEventListener("resize", onViewportChange);
        // visualViewport handles pinch-zoom and browser zoom changes
        if (window.visualViewport) {
            window.visualViewport.addEventListener("resize", onViewportChange);
        }
    });

})();

/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

// Global variables to track intervals and last date strings
let analogIntervalId = null;
let digitalIntervalId = null;
let lastDateString = null;
let lastDigitalDateString = null;
let lastGreetingString = null;
let clockLanguageListenerBound = false;

const CLOCK_LOCALE_ALIASES = Object.freeze({
    ar_SA: "ar-SA",
    az: "az-AZ",
    bn: "bn-BD",
    cs: "cs-CZ",
    de: "de-DE",
    el: "el-GR",
    es: "es-ES",
    fa: "fa-IR",
    fr: "fr-FR",
    hi: "hi-IN",
    hu: "hu-HU",
    हु: "hu-HU",
    idn: "id-ID",
    it: "it-IT",
    ja: "ja-JP",
    ko: "ko-KR",
    mr: "mr-IN",
    np: "ne-NP",
    pl: "pl-PL",
    pt: "pt-BR",
    ru: "ru-RU",
    sl: "sl-SI",
    ta: "ta-IN",
    th: "th-TH",
    tr: "tr-TR",
    uk: "uk-UA",
    ur: "ur-PK",
    uz: "uz-UZ",
    vi: "vi-VN",
    zh: "zh-CN",
    zh_TW: "zh-TW",
});

const CLOCK_RTL_LANGUAGES = new Set(["ar_SA", "fa", "ur"]);

function resolveClockLanguage() {
    const docLang = document.documentElement?.lang;
    if (docLang && typeof translations !== "undefined" && translations[docLang]) {
        return docLang;
    }

    const savedLang = localStorage.getItem("selectedLanguage");
    if (savedLang && typeof translations !== "undefined" && translations[savedLang]) {
        return savedLang;
    }

    return "en";
}

function getClockLocale(language) {
    return CLOCK_LOCALE_ALIASES[language] || language || "en-US";
}

function syncClockDateLanguage(language) {
    const dir = CLOCK_RTL_LANGUAGES.has(language) ? "rtl" : "ltr";
    const locale = getClockLocale(language);

    ["date", "digidate"].forEach((id) => {
        const el = document.getElementById(id);
        if (!el) return;
        el.setAttribute("lang", locale);
        el.setAttribute("dir", dir);
    });
}

function getLocalizedDateParts(date, language, options = {}) {
    const {
        weekday = "long",
        month = "long",
    } = options;

    const fallbackDayName =
        translations[language]?.days?.[date.getDay()] ?? translations["en"].days[date.getDay()];
    const fallbackMonthName =
        translations[language]?.months?.[date.getMonth()] ?? translations["en"].months[date.getMonth()];
    const fallbackDayOfMonth = localizeNumbers(String(date.getDate()), language);

    try {
        const formatter = new Intl.DateTimeFormat(getClockLocale(language), {
            weekday,
            month,
            day: "numeric",
        });
        const parts = formatter.formatToParts(date);
        const dayName = parts.find((part) => part.type === "weekday")?.value || fallbackDayName;
        const monthName = parts.find((part) => part.type === "month")?.value || fallbackMonthName;
        const dayOfMonthText = parts.find((part) => part.type === "day")?.value || fallbackDayOfMonth;

        return { dayName, monthName, dayOfMonthText };
    } catch (error) {
        return {
            dayName: fallbackDayName,
            monthName: fallbackMonthName,
            dayOfMonthText: fallbackDayOfMonth,
        };
    }
}

// ---------------------- Hiding clock func ----------------------
// Select elements
const leftDiv = document.getElementById("leftDiv");
const rightDiv = document.getElementById("rightDiv");
const hideClockCheckbox = document.getElementById("hideClock");
const analogClockElement = document.getElementById("analogClock");
const digitalClockElement = document.getElementById("digitalClock");
const clockTextElement = document.querySelector(".ttteexxtt");
const clockShapeField = document.getElementById("clockShapeField");
const clockShapePicker = document.getElementById("clockShapePicker");
const elementsToHide = document.querySelectorAll(".clockRegion");
let hideClockListenerBound = false;

function updateClockShapeControlState() {
    const isClockHidden = localStorage.getItem("hideClockVisible") === "true";
    const isDigitalClock = localStorage.getItem("clocktype") === "digital";
    const shouldDisable = !isClockHidden && isDigitalClock;

    if (clockShapeField) {
        clockShapeField.classList.toggle("inactive", shouldDisable);
    }

    if (clockShapePicker) {
        clockShapePicker.classList.toggle("inactive", shouldDisable);
        clockShapePicker.setAttribute("aria-hidden", isClockHidden ? "true" : "false");
    }
}

function toggleHideState(isHidden) {
    document.getElementById("clockHidden").style.borderBottom =
        isHidden ? "none" : "";

    elementsToHide.forEach(element => {
        if (isHidden) {
            element.style.transform = "translateY(-20px)";
            setTimeout(() => {
                element.style.display = "none";
            }, 250);
        } else {
            element.style.display = "flex";
            setTimeout(() => {
                element.style.transform = "translateY(0)";
            }, 50);
        }
    });

    updateClockShapeControlState();
}

function applyClockState(isHidden) {
    leftDiv.classList.toggle("clock-hidden-left", isHidden);
    rightDiv.classList.toggle("clock-shifted-right", isHidden);
    rightDiv.classList.toggle("clock-shifted-right-wide", !isHidden);
    rightDiv.classList.toggle("clock-padding-adjusted", isHidden);
    leftDiv.style.display = isHidden ? "none" : "";
    leftDiv.setAttribute("aria-hidden", isHidden ? "true" : "false");

    if (isHidden) {
        analogClockElement.style.display = "none";
        digitalClockElement.style.display = "none";
        if (clockTextElement) clockTextElement.style.display = "none";
    } else if (clockTextElement) {
        clockTextElement.style.display = "";
    }
}

function handleClockVisibility() {
    const isClockHidden = localStorage.getItem("hideClockVisible") === "true";
    hideClockCheckbox.checked = isClockHidden;

    applyClockState(isClockHidden);
    toggleHideState(isClockHidden);
    updateClockShapeControlState();

    if (window.matchMedia("(max-width: 500px)").matches) {
        rightDiv.classList.remove("clock-padding-adjusted");
    }

    if (!isClockHidden) {
        initializeClock();
    }

    if (!hideClockListenerBound) {
        hideClockCheckbox.addEventListener("change", function () {
            const isChecked = hideClockCheckbox.checked;
            localStorage.setItem("hideClockVisible", isChecked);
            applyClockState(isChecked);
            toggleHideState(isChecked);
            updateClockShapeControlState();

            if (!isChecked) {
                initializeClock();
            }
        });
        hideClockListenerBound = true;
    }
}

handleClockVisibility();
// Update on window resize
window.addEventListener("resize", handleClockVisibility);

// ---------------------- Clock func ----------------------
async function initializeClock() {
    // Clear any existing intervals first
    if (analogIntervalId) {
        clearInterval(analogIntervalId);
        analogIntervalId = null;
    }
    if (digitalIntervalId) {
        clearInterval(digitalIntervalId);
        digitalIntervalId = null;
    }

    let clocktype;

    // Track cumulative rotations
    let cumulativeSecondRotation = 0;
    let cumulativeMinuteRotation = 0;
    let cumulativeHourRotation = 0;

    // Initialize on first load
    let isFirstLoad = true;

    // Retrieve current time and calculate initial angles
    var currentTime = new Date();
    var initialSeconds = currentTime.getSeconds();
    var initialMinutes = currentTime.getMinutes();
    var initialHours = currentTime.getHours();

    // Initialize cumulative rotations
    cumulativeSecondRotation = initialSeconds * 6;
    cumulativeMinuteRotation = initialMinutes * 6 + (initialSeconds / 10);
    cumulativeHourRotation = (30 * initialHours + initialMinutes / 2);

    // Apply initial rotations (no need to wait 1s now)
    document.getElementById("second").style.transform = `rotate(${cumulativeSecondRotation}deg)`;
    document.getElementById("minute").style.transform = `rotate(${cumulativeMinuteRotation}deg)`;
    document.getElementById("hour").style.transform = `rotate(${cumulativeHourRotation}deg)`;

    let secondMarkerTimer = null;
    let secondMarkerCatchupTimer = null;
    let roundedMarkerStep = 0;

    function clearSecondMarkerMotion() {
        if (secondMarkerTimer) {
            clearTimeout(secondMarkerTimer);
            secondMarkerTimer = null;
        }

        if (secondMarkerCatchupTimer) {
            clearTimeout(secondMarkerCatchupTimer);
            secondMarkerCatchupTimer = null;
        }
    }

    function snapSecondMarker(step) {
        const marker = document.getElementById("secondMarker");
        if (!marker) return;

        marker.classList.add("second-marker-snap");
        marker.classList.add("second-marker-ready");
        updateSecondMarkerPosition(step);
        void marker.offsetWidth;

        requestAnimationFrame(() => {
            marker.classList.remove("second-marker-snap");
        });
    }

    function runSecondMarkerCatchup(targetSecond) {
        const marker = document.getElementById("secondMarker");
        if (!marker) {
            return;
        }

        marker.classList.add("second-marker-ready");
        marker.classList.add("second-marker-catchup");

        if (targetSecond <= 0) {
            marker.classList.remove("second-marker-catchup");
            scheduleRoundedMarkerLiveTicks();
            return;
        }

        const stepDelay = Math.max(14, Math.min(60, Math.round(900 / Math.max(targetSecond, 1))));

        const tickCatchup = () => {
            if (roundedMarkerStep >= targetSecond) {
                marker.classList.remove("second-marker-catchup");
                roundedMarkerStep = new Date().getSeconds();
                snapSecondMarker(roundedMarkerStep);
                scheduleRoundedMarkerLiveTicks();
                secondMarkerCatchupTimer = null;
                return;
            }

            roundedMarkerStep += 1;
            updateSecondMarkerPosition(roundedMarkerStep);
            secondMarkerCatchupTimer = setTimeout(tickCatchup, stepDelay);
        };

        secondMarkerCatchupTimer = setTimeout(tickCatchup, stepDelay);
    }

    function scheduleRoundedMarkerLiveTicks() {
        const now = new Date();
        const delayMs = Math.max(40, 1000 - now.getMilliseconds());

        secondMarkerTimer = setTimeout(function tickSecondMarker() {
            roundedMarkerStep = (roundedMarkerStep + 1) % 60;
            updateSecondMarkerPosition(roundedMarkerStep);
            scheduleRoundedMarkerLiveTicks();
        }, delayMs);
    }

    function updateSecondMarkerPosition(stepInput = roundedMarkerStep) {
        const marker = document.getElementById("secondMarker");
        const analogClock = document.getElementById("analogClock");
        const shape = document.body?.dataset?.clockShape || "scallop";
        if (!marker || !analogClock) return;

        if (shape !== "rounded") {
            marker.style.setProperty("--second-marker-x", "0px");
            marker.style.setProperty("--second-marker-y", "0px");
            return;
        }

        const rect = analogClock.getBoundingClientRect();
        const size = Math.min(rect.width, rect.height);
        if (!size) return;

        const markerSize = marker.getBoundingClientRect().width || 20;
        const inset = Math.max(size * 0.045, markerSize * 0.52);
        const half = size / 2 - inset;
        const step = ((stepInput % 60) + 60) % 60;
        let x;
        let y;

        if (step <= 8) {
            const progress = step / 8;
            x = half * progress;
            y = -half;
        } else if (step <= 23) {
            const progress = (step - 8) / 15;
            x = half;
            y = -half + (progress * half * 2);
        } else if (step <= 38) {
            const progress = (step - 23) / 15;
            x = half - (progress * half * 2);
            y = half;
        } else if (step <= 53) {
            const progress = (step - 38) / 15;
            x = -half;
            y = half - (progress * half * 2);
        } else {
            const progress = (step - 53) / 7;
            x = -half + (progress * half);
            y = -half;
        }

        marker.style.setProperty("--second-marker-x", `${x.toFixed(2)}px`);
        marker.style.setProperty("--second-marker-y", `${y.toFixed(2)}px`);
    }

    function syncSecondMarkerAnimation(resetToTop = false) {
        const shape = document.body?.dataset?.clockShape || "scallop";
        const marker = document.getElementById("secondMarker");
        clearSecondMarkerMotion();

        if (!marker) return;

        if (shape !== "rounded") {
            marker.classList.remove("second-marker-catchup");
            marker.classList.remove("second-marker-ready");
            return;
        }

        const now = new Date();
        const liveSecond = now.getSeconds();

        if (resetToTop) {
            roundedMarkerStep = 0;
            snapSecondMarker(roundedMarkerStep);
            runSecondMarkerCatchup(liveSecond);
            return;
        }

        roundedMarkerStep = liveSecond;
        snapSecondMarker(roundedMarkerStep);
        scheduleRoundedMarkerLiveTicks();
    }

    window.updateClockSecondMarker = updateSecondMarkerPosition;
    window.syncClockSecondMarkerAnimation = syncSecondMarkerAnimation;
    syncSecondMarkerAnimation();
    window.addEventListener("resize", () => syncSecondMarkerAnimation());

    function initializeClockType() {
        const savedClockType = localStorage.getItem("clocktype");
        clocktype = savedClockType ? savedClockType : "analog"; // Default to "analog" if nothing is saved
        localStorage.setItem("clocktype", clocktype); // Ensure it's set in local storage
    }

    // Call this function to initialize the clock type
    initializeClockType();

    function updateDate() {
        if (clocktype === "analog") {
            var currentTime = new Date();
            var dayOfWeek = currentTime.getDay();
            var dayOfMonth = currentTime.getDate();
            var month = currentTime.getMonth();

            // Define the current language
            const currentLanguage = resolveClockLanguage();
            syncClockDateLanguage(currentLanguage);
            const { dayName, monthName, dayOfMonthText } = getLocalizedDateParts(currentTime, currentLanguage, {
                weekday: "long",
                month: "long",
            });

            // Keep the original variable name so the format table below stays intact.
            var localizedDayOfMonth = dayOfMonthText;

            // DATE DISPLAY FOR ANALOG CLOCK
            const dateDisplay = {
                bn: `${dayName}, ${localizedDayOfMonth} ${monthName}`,
                mr: `${dayName}, ${localizedDayOfMonth} ${monthName}`,
                np: `${dayName}, ${localizedDayOfMonth} ${monthName}`,
                zh: `${month + 1}月${dayOfMonth}日，${dayName}`,
                zh_TW: `${month + 1}月${dayOfMonth}日，${dayName}`,
                cs: `${dayName}, ${dayOfMonth}. ${monthName}`,
                hi: `${dayName}, ${dayOfMonth} ${monthName}`,
                it: `${dayName.substring(0, 3)} ${dayOfMonth} ${monthName.substring(0, 3)}`,
                ja: `${monthName} ${dayOfMonth}日(${dayName.substring(0, 1)})`,
                ko: `${monthName} ${dayOfMonth}일(${dayName.substring(0, 1)})`,
                pl: `${dayName}, ${dayOfMonth}. ${monthName}`,
                pt: `${dayName.substring(0, 3)}, ${dayOfMonth} ${monthName.substring(0, 3)}`,
                ru: `${dayName}, ${dayOfMonth} ${monthName}`,
                es: `${dayName.substring(0, 3)}, ${dayOfMonth} ${monthName.substring(0, 3)}`,
                tr: `${dayName.substring(0, 3)}, ${dayOfMonth} ${monthName}`,
                uz: `${dayName.substring(0, 3)}, ${dayOfMonth}-${monthName}`,
                vi: `${dayName}, ngày ${dayOfMonth} ${monthName}`,
                idn: `${dayName}, ${dayOfMonth} ${monthName}`,
                fr: `${dayName.substring(0, 3)}, ${dayOfMonth} ${monthName.substring(0, 3)}`,
                az: `${dayName.substring(0, 3)}, ${dayOfMonth} ${monthName.substring(0, 3)}`,
                sl: `${dayName}, ${dayOfMonth}. ${monthName.substring(0, 3)}.`,
                hu: `${monthName.substring(0, 3)} ${dayOfMonth}, ${dayName}`,
                ta: `${monthName} ${localizedDayOfMonth}, ${dayName}`,
                ur: `${dayName}، ${dayOfMonth} ${monthName}`,
                de: `${dayName}, ${dayOfMonth}. ${monthName}`,
                fa: `${dayName}، ${localizedDayOfMonth} ${monthName}`,
                ar_SA: `${dayName}, ${localizedDayOfMonth} ${monthName}`,
                el: `${dayName.substring(0, 3)} ${dayOfMonth} ${monthName}`,
                th: `วัน${dayName}ที่ ${dayOfMonth} ${monthName}`,
                uk: `${dayName}, ${dayOfMonth} ${monthName.substring(0, 4)}`,
                default: `${dayName.substring(0, 3)}, ${monthName.substring(0, 3)} ${dayOfMonth}`
            };

            const newDateString = dateDisplay[currentLanguage] || dateDisplay.default;
            // Update date if date actually changed or if it's the first time
            if (newDateString !== lastDateString) {
                document.getElementById("date").innerText = newDateString;
                lastDateString = newDateString;
            }
        }
    }

    // Helper function to update hand rotation smoothly
    function updateHandRotation(handId, newRotation, currentTotal, isResetCondition) {
        let newTotal;

        // Always calculate the shortest path for smooth transitions
        const diff = newRotation - (currentTotal % 360);

        if (isFirstLoad) {
            // On first load, just set the initial position
            newTotal = newRotation;
        } else if (isResetCondition && Math.abs(diff + 360) < Math.abs(diff)) {
            // When resetting (like 59s→0s), choose the forward path if it's shorter
            newTotal = newRotation + (Math.floor(currentTotal / 360) + 1) * 360;
        } else {
            // Normal case - maintain current rotation count
            newTotal = newRotation + Math.floor(currentTotal / 360) * 360;
        }

        // Apply the smooth transition
        document.getElementById(handId).style.transition = "transform 1s ease";
        document.getElementById(handId).style.transform = `rotate(${newTotal}deg)`;

        return newTotal;
    }

    function updateanalogclock() {
        var currentTime = new Date();
        var currentSeconds = currentTime.getSeconds();
        var currentMinutes = currentTime.getMinutes();
        var currentHours = currentTime.getHours();

        // Calculate the new rotation values
        let newSecondRotation = currentSeconds * 6; // 6° per second
        let newMinuteRotation = currentMinutes * 6 + (currentSeconds / 10); // 6° per minute + adjustment for seconds
        let newHourRotation = (30 * (currentHours % 12) + currentMinutes / 2); // 30° per hour + adjustment for minutes, 12-hour cycle

        // Define reset conditions
        const secondReset = currentSeconds === 0;
        const minuteReset = currentMinutes === 0 && currentSeconds === 0;
        const hourReset = currentHours % 12 === 0 && currentMinutes === 0 && currentSeconds === 0;

        // Update each hand using the helper function
        cumulativeSecondRotation = updateHandRotation("second", newSecondRotation, cumulativeSecondRotation, secondReset);
        cumulativeMinuteRotation = updateHandRotation("minute", newMinuteRotation, cumulativeMinuteRotation, minuteReset);
        cumulativeHourRotation = updateHandRotation("hour", newHourRotation, cumulativeHourRotation, hourReset);
        if ((document.body?.dataset?.clockShape || "scallop") !== "rounded") {
            updateSecondMarkerPosition(currentSeconds);
        }

        // Mark that we're no longer on first load
        isFirstLoad = false;

        // Update date immediately
        updateDate();
    }

    function getGreeting() {
        const currentHour = new Date().getHours();
        let greetingKey;

        // Determine the greeting key based on the current hour
        if (currentHour < 12) {
            greetingKey = "morning";
        } else if (currentHour < 17) {
            greetingKey = "afternoon";
        } else {
            greetingKey = "evening";
        }

        // Get the user's language setting
        const currentLanguage = resolveClockLanguage();

        // Get translated greeting
        let greeting = translations[currentLanguage]?.greeting?.[greetingKey] ?? translations["en"]?.greeting?.[greetingKey] ?? "Hello";

        // Append user's name if available
        const userName = localStorage.getItem("userName");
        if (userName) {
            greeting = greeting.replace(/(!?)$/, ", " + userName + "$1");
        }

        return greeting;
    }

    function updatedigiClock() {
        const hourformatstored = localStorage.getItem("hourformat");
        let hourformat = hourformatstored === "true"; // Default to false if null
        const greetingCheckbox = document.getElementById("greetingcheckbox");
        const isGreetingEnabled = localStorage.getItem("greetingEnabled") === "true";
        greetingCheckbox.checked = isGreetingEnabled;

        const now = new Date();
        const dayOfWeek = now.getDay(); // Get day of the week (0-6)
        const dayOfMonth = now.getDate(); // Get current day of the month (1-31)

        const currentLanguage = resolveClockLanguage();
        syncClockDateLanguage(currentLanguage);
        const { dayName, dayOfMonthText } = getLocalizedDateParts(now, currentLanguage, {
            weekday: "long",
            month: "long",
        });

        // Keep the original variable name so the format table below stays intact.
        const localizedDayOfMonth = dayOfMonthText;

        // DATE DISPLAY FOR DIGITAL CLOCK
        const dateFormats = {
            az: `${dayName} ${dayOfMonth}`,
            bn: `${dayName}, ${localizedDayOfMonth}`,
            mr: `${dayName}, ${localizedDayOfMonth}`,
            np: `${dayName}, ${localizedDayOfMonth}`,
            zh: `${dayOfMonth}日${dayName}`,
            zh_TW: `${dayOfMonth}日${dayName}`,
            cs: `${dayName}, ${dayOfMonth}.`,
            hi: `${dayName}, ${dayOfMonth}`,
            ja: `${dayOfMonth}日 (${dayName[0]})`,
            ko: `${dayOfMonth}일 (${dayName[0]})`,
            pl: `${dayName}, ${dayOfMonth}`,
            pt: `${dayName}, ${dayOfMonth}`,
            ru: `${dayOfMonth} ${dayName}`,
            ta: `${localizedDayOfMonth} ${dayName.substring(0, 2)}`,
            vi: `${dayOfMonth} ${dayName}`,
            idn: `${dayOfMonth} ${dayName}`,
            fr: `${dayName} ${dayOfMonth}`,
            hu: `${dayName} ${dayOfMonth}`,
            ur: `${dayName}، ${dayOfMonth}`,
            de: `${dayOfMonth}. ${dayName}`,
            fa: `${dayName} ${localizedDayOfMonth}`,
            ar_SA: `${dayName}, ${localizedDayOfMonth}`,
            el: `${dayName.substring(0, 3)} ${dayOfMonth}`,
            th: `${dayName}ที่ ${dayOfMonth}`,
            uk: `${dayOfMonth} ${dayName}`,
            default: `${dayOfMonth} ${dayName.substring(0, 3)}`,
        };

        const newDigitalDateString = dateFormats[currentLanguage] || dateFormats.default;
        // Update date if date actually changed or if it's the first time
        if (newDigitalDateString !== lastDigitalDateString) {
            document.getElementById("digidate").textContent = newDigitalDateString;
            lastDigitalDateString = newDigitalDateString;
        }

        // Handle time formatting based on the selected language
        let timeString;
        let period = ""; // For storing AM/PM equivalent

        // Array of languages to use "en-US" format
        const specialLanguages = ["tr", "zh", "zh_TW", "ja", "ko", "hu", "ar_SA"]; // Languages that need a safe fallback locale
        const localizedLanguages = Object.keys(numberMappings);
        // Force the "en-US" format for numeral-localized languages, otherwise, it will be localized twice, resulting in NaN

        // Set time options and determine locale based on the current language
        const timeOptions = { hour: "2-digit", minute: "2-digit", hour12: hourformat };
        const localeAliases = {
            ar_SA: "ar-SA",
            zh_TW: "zh-TW",
        };
        const requestedLocale = localeAliases[currentLanguage] || currentLanguage;
        const locale = specialLanguages.includes(currentLanguage) || localizedLanguages.includes(currentLanguage) ? "en-US" : requestedLocale;

        try {
            timeString = now.toLocaleTimeString(locale, timeOptions);
        } catch (error) {
            timeString = now.toLocaleTimeString("en-US", timeOptions);
        }

        // Split the time and period (AM/PM) if in 12-hour format
        if (hourformat) {
            [timeString, period] = timeString.split(" "); // Split AM/PM if present
        }

        // Split the hours and minutes from the localized time string
        let [hours, minutes] = timeString.split(":");

        // Remove leading zero from hours in 12-hour format
        if (hourformat) {
            hours = parseInt(hours, 10).toString(); // Remove leading zero
        }

        // Localize hours and minutes for the selected language
        const localizedHours = localizeNumbers(hours, currentLanguage);
        const localizedMinutes = localizeNumbers(minutes, currentLanguage);

        // Update the hour, colon, and minute text elements
        document.getElementById("digihours").textContent = localizedHours;
        document.getElementById("digicolon").textContent = ":";
        document.getElementById("digiminutes").textContent = localizedMinutes;

        if (isFirefoxAll)
            document.getElementById("digicolon").classList.add("no-blink");

        // Manually set the period for special languages if 12-hour format is enabled
        if (hourformat && (specialLanguages.includes(currentLanguage) || localizedLanguages.includes(currentLanguage))) {
            let realHours = new Date().getHours();

            // lANGUAGE-SPECIFIC AM/PM 
            if (currentLanguage === "fa") {
                period = realHours < 12 ? "ق.ظ" : "ب.ظ";
            } else if (currentLanguage === "ar_SA") {
                period = realHours < 12 ? "ص" : "م";
            } else if (currentLanguage === "ta") {
                if (realHours < 2) {
                    period = "யாமம்"
                } else if (realHours < 6) {
                    period = "வைகறை"
                } else if (realHours < 10) {
                    period = "காலை"
                } else if (realHours < 14) {
                    period = "நண்பகல்"
                } else if (realHours < 18) {
                    period = "எற்பாடு"
                } else if (realHours < 22) {
                    period = "மாலை"
                } else {
                    period = "யாமம்"
                }
            } else {
                period = realHours < 12 ? "AM" : "PM";
            }
        }

        // Display AM/PM if in 12-hour format
        if (hourformat) {
            document.getElementById("amPm").textContent = period; // Show AM/PM based on calculated period
        } else {
            document.getElementById("amPm").textContent = ""; // Clear AM/PM for 24-hour format
        }

        const clocktype1 = localStorage.getItem("clocktype");
        const dateElement = document.getElementById("date");
        if (clocktype1 === "digital" && isGreetingEnabled) {
            const newGreeting = getGreeting();
            if (newGreeting !== lastGreetingString) {
                dateElement.style.display = "block";
                dateElement.innerText = newGreeting;
                lastGreetingString = newGreeting;
            }
        } else if (clocktype1 === "digital") {
            dateElement.style.display = "none";  // Hide the greeting
            lastGreetingString = null;
        }
    }

    // Function to start the analog clock
    function startAnalogClock() {
        if (!analogIntervalId) { // Only set interval if not already set
            analogIntervalId = setInterval(updateanalogclock, 500);
        }
    }

    // Function to stop the analog clock
    function stopAnalogClock() {
        if (analogIntervalId) {
            clearInterval(analogIntervalId);
            analogIntervalId = null; // Reset intervalId
        }
    }

    // Function to start the digital clock
    function startDigitalClock() {
        if (!digitalIntervalId) {
            digitalIntervalId = setInterval(updatedigiClock, 1000);
        }
    }

    // Function to stop the digital clock
    function stopDigitalClock() {
        if (digitalIntervalId) {
            clearInterval(digitalIntervalId);
            digitalIntervalId = null;
        }
    }

    // Initial clock display
    displayClock();
    updateanalogclock();

    // Start appropriate clock based on type
    if (clocktype === "digital") {
        updatedigiClock();
        startDigitalClock();
        stopAnalogClock();
    } else if (clocktype === "analog") {
        if (document.visibilityState === "visible") {
            startAnalogClock();
            updateDate(); // Immediately update date when clock is analog
        }
        stopDigitalClock();
    }

    // Event listener for visibility change
    document.addEventListener("visibilitychange", function () {
        if (document.visibilityState === "visible") {
            if (clocktype === "analog") {
                startAnalogClock(); // Start the analog clock if the tab is focused
                updateDate(); // Update date when the tab becomes visible
            } else if (clocktype === "digital") {
                startDigitalClock(); // Start the digital clock if the tab is focused
            }
        } else {
            stopAnalogClock(); // Stop the analog clock if the tab is not focused
            stopDigitalClock(); // Stop the digital clock if the tab is not focused
        }
    });

    function displayClock() {
        const analogClock = document.getElementById("analogClock");
        const digitalClock = document.getElementById("digitalClock");
        const isClockHidden = localStorage.getItem("hideClockVisible") === "true";

        if (isClockHidden) {
            leftDiv.style.display = "none";
            leftDiv.setAttribute("aria-hidden", "true");
            analogClock.style.display = "none";
            digitalClock.style.display = "none";
            if (clockTextElement) clockTextElement.style.display = "none";
            return;
        }

        leftDiv.style.display = "";
        leftDiv.setAttribute("aria-hidden", "false");
        if (clockTextElement) clockTextElement.style.display = "";

        if (clocktype === "analog") {
            analogClock.style.display = "block";  // Show the analog clock
            digitalClock.style.display = "none";  // Hide the digital clock
        } else if (clocktype === "digital") {
            digitalClock.style.display = "block";  // Show the digital clock
            analogClock.style.display = "none";    // Hide the analog clock
        }
    }

    // ----------------------- End of clock display -------------------------
    function resetDateDisplay() {
        const dateElement = document.getElementById("date");
        dateElement.style.display = "block";
        dateElement.innerText = "";
        lastGreetingString = null;
        lastDateString = null;
        updateDate();
    }

    if (!clockLanguageListenerBound) {
        window.addEventListener("material-you-language-change", () => {
            lastDateString = null;
            lastDigitalDateString = null;
            lastGreetingString = null;

            if (localStorage.getItem("clocktype") === "digital") {
                updatedigiClock();
            } else {
                resetDateDisplay();
            }
        });
        clockLanguageListenerBound = true;
    }

    // Save and load toggle state
    document.addEventListener("DOMContentLoaded", function () {
        const timeformatField = document.getElementById("timeformatField");
        const hourcheckbox = document.getElementById("12hourcheckbox");
        const digitalCheckbox = document.getElementById("digitalCheckbox");
        const greetingCheckbox = document.getElementById("greetingcheckbox");
        const greetingField = document.getElementById("greetingField");

        function syncClockModeUI(isDigitalMode) {
            digitalCheckbox.checked = isDigitalMode;
            localStorage.setItem("clocktype", isDigitalMode ? "digital" : "analog");
            clocktype = localStorage.getItem("clocktype");

            timeformatField.classList.toggle("inactive", !isDigitalMode);
            greetingField.classList.toggle("inactive", !isDigitalMode);
            greetingCheckbox.disabled = !isDigitalMode;

            saveActiveStatus("timeformatField", isDigitalMode ? "active" : "inactive");
            saveActiveStatus("greetingField", isDigitalMode ? "active" : "inactive");

            if (isDigitalMode) {
                stopAnalogClock();
                startDigitalClock();
                updatedigiClock();
            } else {
                stopDigitalClock();
                startAnalogClock();
                updateanalogclock();
                resetDateDisplay();
            }

            displayClock();
            updateClockShapeControlState();
        }

        if (localStorage.getItem("greetingEnabled") === null) {
            localStorage.setItem("greetingEnabled", "true");
        }

        greetingCheckbox.checked = localStorage.getItem("greetingEnabled") === "true";
        greetingCheckbox.disabled = localStorage.getItem("clocktype") !== "digital";

        digitalCheckbox.addEventListener("change", function () {
            saveCheckboxState("digitalCheckboxState", digitalCheckbox);
            syncClockModeUI(digitalCheckbox.checked);
        });

        hourcheckbox.addEventListener("change", function () {
            saveCheckboxState("hourcheckboxState", hourcheckbox);
            if (hourcheckbox.checked) {
                localStorage.setItem("hourformat", "true");
            } else {
                localStorage.setItem("hourformat", "false");
            }
        });

        greetingCheckbox.addEventListener("change", () => {
            localStorage.setItem("greetingEnabled", greetingCheckbox.checked);
            updatedigiClock();
        });

        loadCheckboxState("digitalCheckboxState", digitalCheckbox);
        loadCheckboxState("hourcheckboxState", hourcheckbox);
        loadActiveStatus("timeformatField", timeformatField);
        loadActiveStatus("greetingField", greetingField);
        syncClockModeUI(digitalCheckbox.checked);
    });
}


// ── Clock Shape Picker ──────────────────────────────────────────────
(function () {
    const SHAPE_KEY = "clockShape";
    const SHAPES = ["scallop", "circle"];
    const saved = localStorage.getItem(SHAPE_KEY) || "scallop";
    const clockShapeToggle = document.getElementById("clockShapeToggle");

    function normalizeShape(shape) {
        return SHAPES.includes(shape) ? shape : "scallop";
    }

    function getNextShape(shape) {
        return shape === "circle" ? "scallop" : "circle";
    }

    function applyShape(shape) {
        shape = normalizeShape(shape);
        if (clockShapePicker?.classList.contains("inactive")) return;
        document.body.dataset.clockShape = shape;
        localStorage.setItem(SHAPE_KEY, shape);
        document.querySelectorAll(".shape-toggle-icon[data-shape-preview]").forEach(option => {
            option.classList.toggle("active", option.dataset.shapePreview === shape);
        });
        const nextShape = getNextShape(shape);
        clockShapeToggle?.setAttribute("data-current-shape", shape);
        clockShapeToggle?.setAttribute("data-next-shape", nextShape);
        window.syncClockSecondMarkerAnimation?.(false);
    }

    // Apply on load
    document.addEventListener("DOMContentLoaded", () => {
        applyShape(saved);
        clockShapeToggle?.addEventListener("click", () => {
            const currentShape = normalizeShape(localStorage.getItem(SHAPE_KEY) || document.body.dataset.clockShape);
            applyShape(getNextShape(currentShape));
        });
    });
})();

﻿/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */


// Get the current language from localStorage
const currentLanguage = localStorage.getItem("selectedLanguage") || "en";

// ------------Showing & Hiding Menu-bar ---------------
const menuButton = document.getElementById("menuButton");
const menuBar = document.getElementById("menuBar");
const menuCont = document.getElementById("menuCont");
const optCont = document.getElementById("optCont");
const overviewPage = document.getElementById("overviewPage");
const shortcutEditPage = document.getElementById("shortcutEditPage");
const shortcutEditButton = document.getElementById("shortcutEditButton");
const backButton = document.getElementById("backButton");
let menuHideTimer = null;
let menuState = "closed";
let menuTransitionToken = 0;
let queuedMenuState = null;

function menuExitTransform() {
    return `translateX(${document.documentElement.dir === "rtl" ? "-" : ""}100%) translateZ(0)`;
}

function getMenuTransitionMs() {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return 0;
    const style = getComputedStyle(document.body);
    const multRaw = style.getPropertyValue("--ui-anim-mult").trim();
    const mult = parseFloat(multRaw) || 1;
    return Math.round(400 * mult);
}

function finalizeMenuClose(token) {
    if (token !== menuTransitionToken) {
        return;
    }
    menuCont.style.scrollBehavior = "auto";
    menuCont.scrollTop = 0;
    requestAnimationFrame(() => { menuCont.style.scrollBehavior = "smooth"; });
    menuBar.style.opacity = "0";
    menuCont.style.transform = menuExitTransform();
    optCont.style.opacity = "0";
    optCont.style.transform = "translateX(15%)";
    menuBar.style.display = "none";
    menuState = "closed";
    if (queuedMenuState === "open") {
        queuedMenuState = null;
        requestAnimationFrame(() => openMenuBar());
    }
}

function pageReset() {
    optCont.scrollTop = 0;
    overviewPage.style.transform = "translateX(0)";
    overviewPage.style.opacity = "1";
    overviewPage.style.display = "block";
    shortcutEditPage.style.transform = "translateX(120%)";
    shortcutEditPage.style.opacity = "0";
    shortcutEditPage.style.display = "none";
}

const closeMenuBar = () => {
    if (menuState === "closed") {
        return;
    }
    if (menuState === "closing") {
        return;
    }
    if (menuState === "opening") {
        queuedMenuState = "closed";
        return;
    }

    const transitionToken = ++menuTransitionToken;
    queuedMenuState = null;
    menuState = "closing";
    if (menuHideTimer) {
        clearTimeout(menuHideTimer);
        menuHideTimer = null;
    }
    if (typeof window.closeAIToolsSettings === "function") {
        window.closeAIToolsSettings();
    }

    const transDur = getMenuTransitionMs();
    const fallback = transDur + 140;

    requestAnimationFrame(() => {
        optCont.style.opacity = "0";
        optCont.style.transform = "translateX(15%)";
        menuBar.style.opacity = "0";
        menuCont.style.transform = menuExitTransform();
    });

    const onMenuContCloseEnd = (event) => {
        if (transitionToken !== menuTransitionToken) return;
        if (event.target !== menuCont) return;
        if (event.propertyName !== "transform") return;
        menuCont.removeEventListener("transitionend", onMenuContCloseEnd);
        finalizeMenuClose(transitionToken);
        menuHideTimer = null;
    };
    menuCont.addEventListener("transitionend", onMenuContCloseEnd);

    menuHideTimer = setTimeout(() => {
        menuCont.removeEventListener("transitionend", onMenuContCloseEnd);
        finalizeMenuClose(transitionToken);
        menuHideTimer = null;
    }, fallback);
}

const openMenuBar = () => {
    if (menuState === "open") {
        return;
    }
    if (menuState === "opening") {
        return;
    }
    if (menuState === "closing") {
        queuedMenuState = "open";
        return;
    }

    const transitionToken = ++menuTransitionToken;
    queuedMenuState = null;
    menuState = "opening";
    if (menuHideTimer) {
        clearTimeout(menuHideTimer);
        menuHideTimer = null;
    }

    menuBar.style.display = "block";
    pageReset();
    menuBar.style.opacity = "0";
    menuCont.style.transform = menuExitTransform();
    optCont.style.opacity = "0";
    optCont.style.transform = "translateX(15%)";

    // Force the browser to commit the hidden start state before animating in.
    void menuCont.offsetWidth;

    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            if (transitionToken !== menuTransitionToken) return;
            menuBar.style.opacity = "1";
            menuCont.style.transform = "translateX(0) translateZ(0)";
            optCont.style.opacity = "1";
            optCont.style.transform = "translateX(0)";
        });
    });

    const openDur = getMenuTransitionMs() + 80;
    menuHideTimer = setTimeout(() => {
        if (transitionToken !== menuTransitionToken) return;
        menuState = "open";
        menuHideTimer = null;
        if (queuedMenuState === "closed") {
            queuedMenuState = null;
            closeMenuBar();
        }
    }, openDur);
}

menuButton.addEventListener("click", () => {
    if (menuState === "closed" || menuBar.style.display === "none" || menuBar.style.display === "") {
        openMenuBar();
    } else {
        closeMenuBar();
    }
});

//   ----------Hiding Menu Bar--------
// Track pointer position on mousedown so we can distinguish a real click
// (no movement) from a scroll gesture that ends with a spurious click event.
let _menuPointerDownX = 0;
let _menuPointerDownY = 0;
menuBar.addEventListener("pointerdown", (event) => {
    _menuPointerDownX = event.clientX;
    _menuPointerDownY = event.clientY;
});
menuBar.addEventListener("click", (event) => {
    if (window._customColorPickerOpen) {
        const pickerPopover = document.getElementById("customColorPickerPopover");
        const pickerTrigger = document.getElementById("rangColor");
        if ((pickerPopover && pickerPopover.contains(event.target)) || (pickerTrigger && pickerTrigger.contains(event.target))) {
            return;
        }
    }
    if (event.target !== menuBar) return;
    // Ignore if the pointer moved more than 6px — that was a scroll/drag, not a tap
    const dx = event.clientX - _menuPointerDownX;
    const dy = event.clientY - _menuPointerDownY;
    if (Math.sqrt(dx * dx + dy * dy) > 6) return;
    closeMenuBar();
});

// Hiding Menu Bar when user click on close button
document.getElementById("menuCloseButton").onclick = () => {
    closeMenuBar()
}


// Toggle expand/collapse sections
document.querySelectorAll(".sectionHeader").forEach(header => {
    header.addEventListener("click", () => {
        header.closest(".section").classList.toggle("expanded");
    });
});


/* ------ Shortcut Page Transitions & Animations ------ */

// When clicked, open new page by sliding it in from the right (or left in RTL).
shortcutEditButton.onclick = () => {
    setTimeout(() => {
        shortcutEditPage.style.display = "block"
    });
    requestAnimationFrame(() => {
        overviewPage.style.transform = "translateX(-120%)"
        overviewPage.style.opacity = "0"
    });
    setTimeout(() => {
        requestAnimationFrame(() => {
            shortcutEditPage.style.transform = "translateX(0)"
            shortcutEditPage.style.opacity = "1"
        });
    }, 50);
    setTimeout(() => {
        overviewPage.style.display = "none";
    }, 650);
}

// Close page by sliding it away to the right (or left in RTL).
backButton.onclick = () => {
    setTimeout(() => {
        overviewPage.style.display = "block"
    });
    requestAnimationFrame(() => {
    shortcutEditPage.style.transform = "translateX(120%)";
        shortcutEditPage.style.opacity = "0";
    });
    setTimeout(() => {
        requestAnimationFrame(() => {
            overviewPage.style.transform = "translateX(0)";
            overviewPage.style.opacity = "1";
        });
    }, 50);
    setTimeout(() => {
        shortcutEditPage.style.display = "none";
    }, 650);
}

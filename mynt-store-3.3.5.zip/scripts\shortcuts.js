/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 */

document.addEventListener("DOMContentLoaded", function () {
    // Constants
    const MAX_SHORTCUTS = 50;
    const ICON_SCALE_CONFIG = Object.freeze({
        min: 70,
        max: 130,
        step: 2,
        default: 100,
        snapZone: 4,
        visualBoost: 16
    });
    const STORAGE_KEYS = Object.freeze({
        iconScale: "shortcutIconScale",
        iconScaleSnapEnabled: "shortcutIconScaleSnapEnabled"
    });
    const PLACEHOLDER = {
        name: "New shortcut",
        url: "",
        inputName: "Shortcut Name",
        inputUrl: "Shortcut URL"
    };

    // DOM Elements
    const dom = {
        shortcuts: document.getElementById("shortcuts-section"),
        shortcutsCheckbox: document.getElementById("shortcutsCheckbox"),
        shortcutEditField: document.getElementById("shortcutEditField"),
        adaptiveIconField: document.getElementById("adaptiveIconField"),
        adaptiveIconToggle: document.getElementById("adaptiveIconToggle"),
        shortcutSettingsContainer: document.getElementById("shortcutList"),
        shortcutsContainer: document.getElementById("shortcutsContainer"),
        newShortcutButton: document.getElementById("newShortcutButton"),
        resetShortcutsButton: document.getElementById("resetButton"),
        shortcutIconControlBar: document.getElementById("shortcutIconControlBar"),
        shortcutIconPopoverButton: document.getElementById("shortcutIconPopoverButton"),
        shortcutIconPopover: document.getElementById("shortcutIconPopover"),
        shortcutIconPopoverClose: document.getElementById("shortcutIconPopoverClose"),
        shortcutIconScaleRow: document.getElementById("shortcutIconScaleRow"),
        shortcutIconScaleSlider: document.getElementById("shortcutIconScaleSlider"),
        shortcutIconScaleValue: document.getElementById("shortcutIconScaleValue"),
    };

    // Preset Data
    const presets = [
        {
            name: "YouTube",
            url: "youtube.com",
            domains: ["youtube.com", "m.youtube.com", "youtu.be"],
            svg: `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path class="bgLightTint" fill-rule="evenodd"
                    d="M14.9 6.2a1.8 1.8 0 0 0-1.27-1.27C12.52 4.6 10 4.6 10 4.6s-2.52 0-3.63.33A1.8 1.8 0 0 0 5.1 6.2C4.77 7.3 4.77 10 4.77 10s0 2.7.33 3.8a1.8 1.8 0 0 0 1.27 1.27c1.11.33 3.63.33 3.63.33s2.52 0 3.63-.33a1.8 1.8 0 0 0 1.27-1.27c.33-1.1.33-3.8.33-3.8s0-2.7-.33-3.8ZM8.9 12.9V7.1l4.3 2.9z"/></svg>`
        },
        {
            name: "Gmail",
            url: "mail.google.com",
            domains: ["gmail.com", "mail.google.com"],
            svg: `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><g style="transform: scale(0.58); transform-origin: center;"><path class="bgLightTint" id="darkLightTint" 
                    d="m8.606 13.6 3.396 2.323 3.274-2.259 7.338 7.24q-.29.095-.614.096H2c-.264 0-.516-.052-.747-.144zM24 7.652V19a2 2 0 0 1-.18.83l-7.193-7.097zM0 7.715l7.25 4.958-7.123 7.03A2.04 2.04 0 0 1 0 19ZM22 3a2 2 0 0 1 2 2v.704l-12.002 8.274L0 5.772V5a2 2 0 0 1 2-2Z"/></g></svg>`
        },
        {
            name: "Telegram",
            url: "web.telegram.org",
            domains: ["telegram.org", "t.me", "web.telegram.org"],
            svg: `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path class="bgLightTint" d="M14.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38Z"/></svg>`
        },
        {
            name: "WhatsApp",
            url: "web.whatsapp.com",
            domains: ["whatsapp.com", "web.whatsapp.com", "api.whatsapp.com"],
            svg: `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path class="bgLightTint" d="M6.592 5.3l-.2.008a.961.961 0 0 0-.372.1 1.293 1.293 0 0 0-.294.228c-.12.113-.188.211-.261.306a2.73 2.73 0 0 0-.566 1.678c.002.49.13.967.33 1.413.409.902 1.082 1.857 1.97 2.742.214.213.424.427.65.626a9.448 9.448 0 0 0 3.84 2.046l.568.087c.185.01.37-.004.556-.013a1.99 1.99 0 0 0 .833-.231c.131-.067.259-.14.383-.22 0 0 .043-.028.125-.09.135-.1.218-.171.33-.288.083-.086.155-.187.21-.302.078-.163.156-.474.188-.733.024-.198.017-.306.014-.373-.004-.107-.093-.218-.19-.265l-.582-.261s-.87-.379-1.402-.621a.497.497 0 0 0-.176-.041.482.482 0 0 0-.378.127c-.005-.002-.072.055-.795.931a.35.35 0 0 1-.368.13 1.432 1.432 0 0 1-.191-.066c-.124-.052-.167-.072-.252-.108a6.028 6.028 0 0 1-1.575-1.003c-.126-.11-.243-.23-.363-.346a6.298 6.298 0 0 1-1.02-1.268l-.059-.095a.923.923 0 0 1-.102-.205c-.038-.147.061-.265.061-.265s.243-.266.356-.41c.11-.14.203-.276.263-.373.118-.19.155-.385.093-.536-.28-.684-.57-1.365-.868-2.041-.059-.134-.234-.23-.393-.249a4.439 4.439 0 0 0-.162-.016 3.385 3.385 0 0 0-.403.004l.201-.008.001.001Z"/></svg>`
        },
        {
            name: "Twitter",
            url: "x.com",
            domains: ["twitter.com", "x.com"],
            svg: `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path class="bgLightTint" d="M8.171 15.271c4.429 0 6.858-3.671 6.858-6.857V8.1a4.783 4.783 0 0 0 1.2-1.257c-.429.186-.9.314-1.386.386.5-.3.886-.772 1.057-1.329a5.215 5.215 0 0 1-1.529.586 2.405 2.405 0 0 0-1.757-.757A2.42 2.42 0 0 0 10.2 8.143c0 .186.014.371.071.543-2-.1-3.785-1.057-4.971-2.515-.2.358-.329.772-.329 1.215 0 .828.429 1.571 1.072 2-.4 0-.772-.115-1.086-.3v.028c0 1.172.829 2.143 1.929 2.372a2.3 2.3 0 0 1-.629.085c-.157 0-.3-.014-.457-.042.3.957 1.2 1.657 2.243 1.671a4.883 4.883 0 0 1-3 1.029c-.2 0-.386 0-.572-.029a6.765 6.765 0 0 0 3.686 1.086"/></svg>`
        },
        {
            name: "Discord",
            url: "discord.com/app",
            domains: ["discord.com", "discord.gg", "discordapp.com"],
            svg: `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path class="bgLightTint"
                    d="M14.84 6.11a8.7 8.7 0 0 0-2.2-.68c-.1.17-.2.4-.28.57a8.4 8.4 0 0 0-2.72 0c-.07-.17-.18-.4-.28-.57a8.63 8.63 0 0 0-2.2.68A9.1 9.1 0 0 0 5.6 13.3a8.97 8.97 0 0 0 2.7 1.35c.22-.3.42-.62.58-.95-.3-.12-.58-.27-.85-.44.07-.05.14-.11.2-.16 1.76.8 3.78.8 5.54 0 .07.06.13.11.2.16-.27.17-.55.32-.85.44.16.33.36.65.58.95a8.95 8.95 0 0 0 2.7-1.35 9.15 9.15 0 0 0-1.56-7.19ZM8.67 11.98c-.52 0-.95-.47-.95-1.05s.42-1.05.95-1.05.96.47.95 1.05c0 .58-.43 1.05-.95 1.05Zm2.66 0c-.52 0-.95-.47-.95-1.05s.42-1.05.95-1.05.96.47.95 1.05c0 .58-.42 1.05-.95 1.05Z"/></svg>`
        }
    ];

    // Cache for shortcuts data
    let shortcutsCache = [];
    let _scUndoStack = []; // undo stack for drag-and-drop reorder
    let shortcutPopoverOpen = false;
    let shortcutPopoverMounted = false;
    let shortcutPopoverDragged = false;
    let shortcutPopoverCloseTimer = null;

    // Initialization
    loadSettings();
    setupEventListeners();
    loadShortcuts();
    setupNameMarquee();
    setupThemeRefresh();
    window.addEventListener("material-you-language-change", refreshShortcutEntryActionLabels);

    // Loads all settings from localStorage and applies them
    function loadSettings() {
        loadCheckboxState("shortcutsCheckboxState", dom.shortcutsCheckbox);
        loadCheckboxState("adaptiveIconToggle", dom.adaptiveIconToggle);
        loadActiveStatus("shortcutEditField", dom.shortcutEditField);
        loadActiveStatus("adaptiveIconField", dom.adaptiveIconField);
        loadDisplayStatus("shortcutsDisplayStatus", dom.shortcuts);
        applyShortcutIconScale(getSavedShortcutIconScale());

        // Apply adaptive icon style if enabled
        if (dom.adaptiveIconToggle.checked) {
            dom.shortcutsContainer.classList.add("adaptive-icons");
        } else {
            dom.shortcutsContainer.classList.remove("adaptive-icons");
        }
    }

    // Sets up all event listeners
    function setupEventListeners() {
        // Checkbox events
        dom.shortcutsCheckbox.addEventListener("change", handleShortcutsToggle);
        dom.adaptiveIconToggle.addEventListener("change", handleAdaptiveIconToggle);

        // Button events
        dom.newShortcutButton.addEventListener("click", handleNewShortcutClick);
        dom.resetShortcutsButton.addEventListener("click", resetShortcuts);

        setupShortcutIconPopover();
        setupShortcutIconScaleControl();
    }

    // Handles the new shortcut button click with animation and focus
    let focusTimeoutId;
    function handleNewShortcutClick() {
        if (this.classList.contains("inactive")) return;

        const currentAmount = parseInt(localStorage.getItem("shortcutAmount")) || shortcutsCache.length;
        if (currentAmount >= MAX_SHORTCUTS) return;

        addNewShortcut();

        // Scroll to the new shortcut and focus on the URL input
        const allEntries = document.querySelectorAll(".shortcutSettingsEntry");
        const lastEntry = allEntries[allEntries.length - 1];
        const urlInput = lastEntry.querySelector("input.URL");

        urlInput.scrollIntoView({ behavior: "smooth", block: "center" });

        clearTimeout(focusTimeoutId);
        focusTimeoutId = setTimeout(() => {
            // alert-modal.js toggles classes and creates the dialog lazily,
            // so re-query it now and treat presence as "dialog is open".
            if (!document.getElementById("prompt-modal-container"))
                urlInput.focus();
        }, 800);
    }

    // Loads shortcuts from localStorage or uses presets if none exist
    function loadShortcuts() {
        const amount = localStorage.getItem("shortcutAmount") || presets.length;
        const deleteInactive = amount <= 1;

        shortcutsCache = [];

        for (let i = 0; i < amount; i++) {
            const shortcutRecord = getStoredShortcut(i, presets[i]);

            shortcutsCache.push(shortcutRecord);

            const entry = createShortcutEntry(
                shortcutRecord.name,
                shortcutRecord.url,
                deleteInactive,
                i,
                shortcutRecord.uploadedIcon
            );
            dom.shortcutSettingsContainer.appendChild(entry);
            renderShortcut(shortcutRecord.name, shortcutRecord.url, i, shortcutRecord.uploadedIcon);
        }

        // Disable new shortcut button if max reached
        if (amount >= MAX_SHORTCUTS) {
            dom.newShortcutButton.classList.add("inactive");
        }

        setupDragAndDrop();
        refreshShortcutEntryActionLabels();

    }

    function getShortcutUiText(key, fallback) {
        const lang = document.documentElement.lang || localStorage.getItem("selectedLanguage") || "en";
        const translationStore = window.materialYouTranslations || {};
        return translationStore[lang]?.[key] || translationStore.en?.[key] || fallback;
    }

    function refreshShortcutEntryActionLabels() {
        if (!dom.shortcutSettingsContainer) return;
        dom.shortcutSettingsContainer.querySelectorAll(".shortcutSettingsEntry").forEach(entry => {
            setEntryUploadedIcon(entry, entry.dataset.uploadedIcon || "");
        });
    }

    // Creates a shortcut entry element for the settings panel
    function createShortcutEntry(name, url, deleteInactive, index, uploadedIcon = "") {
        const uploadTitle = uploadedIcon
            ? getShortcutUiText("shortcutReplaceUploadedIcon", "Replace uploaded icon")
            : getShortcutUiText("shortcutUploadIcon", "Upload icon");
        const restoreTitle = getShortcutUiText("shortcutRestoreOriginalIcon", "Restore original icon");
        const entry = document.createElement("div");
        entry.className = "shortcutSettingsEntry";
        entry.draggable = true;
        entry._index = index;
        entry.dataset.uploadedIcon = uploadedIcon || "";

        entry.innerHTML = `
            <div class="grip-container" draggable="true">
                <svg stroke="currentColor" width="18" height="18" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5">
                    <circle cy="2.5" cx="5.5" r=".75"/>
                    <circle cy="8" cx="5.5" r=".75"/>
                    <circle cy="13.5" cx="5.5" r=".75"/>
                    <circle cy="2.5" cx="10.5" r=".75"/>
                    <circle cy="8" cx="10.5" r=".75"/>
                    <circle cy="13.5" cx="10.5" r=".75"/>
                </svg>
            </div>
            <div>
                <input class="shortcutName" placeholder="${PLACEHOLDER.inputName}" value="${escapeHtml(name)}">
                <input class="URL" placeholder="${PLACEHOLDER.inputUrl}" value="${escapeHtml(url)}">
            </div>
            <div class="shortcutEntryActions">
                <label class="shortcutUploadButton ${uploadedIcon ? "has-uploaded-icon" : ""}" title="${uploadTitle}" aria-label="${uploadTitle}">
                    <input class="shortcutIconUpload" type="file" accept=".svg,image/svg+xml">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" d="M11 19h2v-6.175l1.6 1.6L16 13l-4-4-4 4 1.4 1.425 1.6-1.6zm-5 3q-.825 0-1.412-.587Q4 20.825 4 20V4q0-.825.588-1.412Q5.175 2 6 2h12q.825 0 1.413.588Q20 3.175 20 4v16q0 .825-.587 1.413Q18.825 22 18 22z"/>
                    </svg>
                </label>
                <button class="shortcutRestoreButton" type="button" title="${restoreTitle}" aria-label="${restoreTitle}" ${uploadedIcon ? "" : "disabled"}>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" d="M12 5V2L8 6l4 4V7c2.76 0 5 2.24 5 5a4.98 4.98 0 0 1-.81 2.74l1.46 1.46A6.96 6.96 0 0 0 19 12c0-3.87-3.13-7-7-7zm-5 .8L5.54 7.26A6.96 6.96 0 0 0 5 12c0 3.87 3.13 7 7 7v3l4-4-4-4v3c-2.76 0-5-2.24-5-5 0-1.01.3-1.95.81-2.74z"/>
                    </svg>
                </button>
                <div class="delete">
                    <button class="${deleteInactive ? 'inactive' : ''}">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24">
                            <path d="M7.8 20.4q-.742 0-1.271-.529Q6 19.343 6 18.6v-12h-.3q-.383 0-.641-.257-.259-.258-.259-.638t.259-.643Q5.317 4.8 5.7 4.8h3.9v-.3q0-.383.259-.641.258-.259.641-.259h3q.383 0 .641.259.259.258.259.641v.3h3.9q.383 0 .641.257.259.257.259.638 0 .38-.259.643-.258.262-.641.262H18v11.99q0 .76-.529 1.285-.529.525-1.271.525Zm8.4-13.8H7.8v12h8.4zm-5.705 10.2q.38 0 .643-.259.262-.259.262-.641V9.3q0-.383-.257-.641-.258-.259-.638-.259t-.643.259Q9.6 8.917 9.6 9.3v6.6q0 .383.257.641.258.259.638.259Zm3 0q.38 0 .643-.259.262-.259.262-.641V9.3q0-.383-.257-.641-.258-.259-.638-.259t-.643.259q-.262.258-.262.641v6.6q0 .383.257.641.258.259.638.259ZM7.8 6.6v12z"/>
                        </svg>
                    </button>
                </div>
            </div>
        `;

        const inputs = entry.querySelectorAll("input");
        attachInputListeners(entry.querySelectorAll("input.shortcutName, input.URL"), entry);

        const uploadInput = entry.querySelector(".shortcutIconUpload");
        uploadInput.addEventListener("change", async (event) => {
            const file = event.target.files?.[0];
            if (!file) return;

            const isSvg = file.type === "image/svg+xml" || /\.svg$/i.test(file.name || "");
            if (!isSvg) {
                if (typeof alertPrompt === "function") {
                    alertPrompt(getShortcutUiText("shortcutSvgOnlyWarning", "Only SVG icons are supported."));
                }
                event.target.value = "";
                return;
            }

            try {
                const uploadedDataUrl = await createStoredIconDataUrl(file);
                setEntryUploadedIcon(entry, uploadedDataUrl);
                saveShortcut(entry);
                renderShortcut(
                    entry.querySelector(".shortcutName").value,
                    entry.querySelector(".URL").value,
                    entry._index,
                    uploadedDataUrl
                );
                scShowToast(getShortcutToastMsg("icon_uploaded"), "icon");
            } catch (error) {
                if (typeof alertPrompt === "function") {
                    alertPrompt(getShortcutUiText("shortcutSvgOnlyWarning", "Only SVG icons are supported."));
                }
                console.warn("Failed to process uploaded SVG icon.", error);
            }
            event.target.value = "";
        });

        const restoreButton = entry.querySelector(".shortcutRestoreButton");
        restoreButton.addEventListener("click", () => {
            if (!entry.dataset.uploadedIcon) return;
            setEntryUploadedIcon(entry, "");
            saveShortcut(entry);
            renderShortcut(
                entry.querySelector(".shortcutName").value,
                entry.querySelector(".URL").value,
                entry._index,
                ""
            );
            scShowToast(getShortcutToastMsg("icon_restored"), "edit");
        });

        const deleteBtn = entry.querySelector(".delete button");
        deleteBtn.addEventListener("click", () => deleteShortcut(entry));
        setEntryUploadedIcon(entry, uploadedIcon);

        return entry;
    }

    // Renders a shortcut in the main view
    function renderShortcut(name, url, index, uploadedIcon = "") {
        const shortcut = buildShortcutElement({ name, url, uploadedIcon }, index);
        if (index < dom.shortcutsContainer.children.length) {
            dom.shortcutsContainer.replaceChild(shortcut, dom.shortcutsContainer.children[index]);
        } else {
            dom.shortcutsContainer.appendChild(shortcut);
        }
    }

    // Escapes HTML to prevent XSS
    function escapeHtml(unsafe) {
        return String(unsafe ?? "").replace(/[&<>"']/g, match => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[match]));
    }

    // Normalizes URLs to ensure they're valid
    function normalizeUrl(url) {
        url = String(url ?? "").trim();
        if (!url) return "";

        return window.MyntNavigationCore.normalizeUrl(url);
    }

    function getHostnameFromUrl(url) {
        const normalizedUrl = normalizeUrl(url);
        if (!normalizedUrl) return "";

        try {
            return new URL(normalizedUrl).hostname.replace("www.", "");
        } catch {
            return "";
        }
    }

    function getSpecialShortcutSvg(hostname) {
        if (!hostname) return null;
        if (["youtube.com", "m.youtube.com", "youtu.be"].some(domain => hostname === domain || hostname.endsWith(`.${domain}`))) {
            return "./svgs/youtube-shortcut.svg";
        }
        if (["discord.com", "discord.gg", "discordapp.com"].some(domain => hostname === domain || hostname.endsWith(`.${domain}`))) {
            return "./svgs/discord-shortcut.svg";
        }
        return null;
    }

    function buildShortcutFaviconImg(pageUrl, hostname) {
        return `<img class="shortcut-icon-asset shortcut-icon-favicon" alt="">`;
    }

    // Gets the appropriate logo HTML for a given URL
    function getLogoHtml(url, uploadedIcon = "") {
        if (uploadedIcon) {
            return `<img class="shortcut-icon-asset shortcut-icon-uploaded" src="${uploadedIcon}" alt="">`;
        }

        const normalizedUrl = normalizeUrl(url);
        const hostname = getHostnameFromUrl(url);

        if (!hostname) {
            return `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path class="bgLightTint" d="M6.1 4.35A1.75 1.75 0 0 0 4.35 6.1v2.15A1.75 1.75 0 0 0 6.1 10h2.15A1.75 1.75 0 0 0 10 8.25V6.1a1.75 1.75 0 0 0-1.75-1.75Zm5.65 0A1.75 1.75 0 0 0 10 6.1v2.15A1.75 1.75 0 0 0 11.75 10h2.15a1.75 1.75 0 0 0 1.75-1.75V6.1a1.75 1.75 0 0 0-1.75-1.75ZM6.1 10.9a1.75 1.75 0 0 0-1.75 1.75v1.25A1.75 1.75 0 0 0 6.1 15.65h1.25A1.75 1.75 0 0 0 9.1 13.9v-1.25A1.75 1.75 0 0 0 7.35 10.9Zm5.65 0A1.75 1.75 0 0 0 10 12.65v1.25a1.75 1.75 0 0 0 1.75 1.75h2.15a1.75 1.75 0 0 0 1.75-1.75v-1.25a1.75 1.75 0 0 0-1.75-1.75Z"/>
            </svg>`;
        }

        if (hostname === "github.com") {
            return `<img class="shortcut-icon-asset shortcut-icon-special" src="./svgs/github-shortcut.svg" alt="">`;
        }

        const specialIcon = getSpecialShortcutSvg(hostname);
        if (specialIcon) {
            return `<img class="shortcut-icon-asset shortcut-icon-special" src="${specialIcon}" alt="">`;
        }

        // Check presets for matching domain
        const preset = presets.find(p => p.domains.includes(hostname));
        if (preset) {
            return preset.svg;
        }

        return buildShortcutFaviconImg(normalizedUrl, hostname);
    }

    function buildShortcutElement(shortcutItem, index) {
        const normalizedUrl = normalizeUrl(shortcutItem.url);
        const shortcut = document.createElement("div");
        shortcut.className = "shortcuts";
        shortcut._index = index;

        shortcut.innerHTML = `
            <a href="${escapeHtml(normalizedUrl || "#")}" aria-label="${escapeHtml(shortcutItem.name)}" title="${escapeHtml(shortcutItem.name)}">
                <div class="shortcutLogoContainer">
                    ${getLogoHtml(shortcutItem.url, shortcutItem.uploadedIcon)}
                </div>
                <span class="shortcut-name"><span class="sc-inner">${escapeHtml(shortcutItem.name)}</span></span>
            </a>
        `;

        if (!normalizedUrl) {
            const link = shortcut.querySelector("a");
            link.setAttribute("aria-disabled", "true");
            link.addEventListener("click", (event) => event.preventDefault());
        }

        shortcut.querySelectorAll("img").forEach(image => {
            window.MyntSiteIcons.set(image, normalizedUrl, {
                label: shortcutItem.name,
                size: 128,
                src: image.classList.contains("shortcut-icon-favicon") ? "" : image.getAttribute("src"),
                onResolved: () => applyShortcutGlyphTone(shortcut)
            });
        });
        applyShortcutGlyphTone(shortcut);
        return shortcut;
    }

    function isFilterDarkActiveNow() {
        try {
            return typeof window._isFilterDarkActive === "function" && window._isFilterDarkActive();
        } catch {
            return false;
        }
    }

    function areAdaptiveIconsEnabled() {
        return Boolean(dom.shortcutsContainer?.classList.contains("adaptive-icons"));
    }

    // Make shortcut glyphs look white in all themes.
    // In filter-based dark mode we pre-blacken so html invert renders them white.
    function applyShortcutGlyphTone(scope) {
        if (!scope) return;

        const preColor = isFilterDarkActiveNow() ? "#000000" : "#FFFFFF";
        const imgFilter = isFilterDarkActiveNow()
            ? "brightness(0)"
            : "brightness(0) saturate(100%) invert(1)";
        const adaptiveIconsEnabled = areAdaptiveIconsEnabled();

        scope.querySelectorAll(".shortcutLogoContainer img").forEach(img => {
            if (img.classList.contains("site-icon-fallback")) {
                img.style.setProperty("filter", "none", "important");
                img.style.setProperty("mix-blend-mode", "normal", "important");
                return;
            }
            if (img.classList.contains("shortcut-icon-uploaded")) {
                img.style.setProperty("filter", "none", "important");
                img.style.setProperty("mix-blend-mode", "normal", "important");
                return;
            }

            if (img.classList.contains("shortcut-icon-favicon") && !adaptiveIconsEnabled) {
                img.style.setProperty("filter", "none", "important");
                img.style.setProperty("mix-blend-mode", "normal", "important");
                return;
            }

            img.style.setProperty("filter", imgFilter, "important");
            img.style.setProperty("mix-blend-mode", "normal", "important");
        });

        scope.querySelectorAll(".shortcutLogoContainer svg").forEach(svg => {
            svg.style.setProperty("filter", "none", "important");

            svg.querySelectorAll("path, rect, polygon, use, ellipse, line, polyline, circle").forEach(el => {
                if (el.classList.contains("accentColor") || el.classList.contains("shorcutDarkColor")) return;
                el.style.setProperty("fill", preColor, "important");
                el.style.setProperty("color", preColor, "important");
                el.style.removeProperty("stroke");
            });
        });

    }

    function getUploadedIconKey(index) {
        return `shortcutUploadedIcon${index}`;
    }

    function getStoredShortcut(index, preset) {
        const storedName = localStorage.getItem(`shortcutName${index}`);
        const storedUrl = localStorage.getItem(`shortcutURL${index}`);

        return {
            name: storedName !== null ? storedName : (preset ? preset.name : PLACEHOLDER.name),
            url: storedUrl !== null ? storedUrl : (preset ? preset.url : PLACEHOLDER.url),
            uploadedIcon: localStorage.getItem(getUploadedIconKey(index)) || ""
        };
    }

    function setEntryUploadedIcon(entry, uploadedIcon = "") {
        const uploadButton = entry.querySelector(".shortcutUploadButton");
        const restoreButton = entry.querySelector(".shortcutRestoreButton");
        entry.dataset.uploadedIcon = uploadedIcon || "";

        if (uploadButton) {
            uploadButton.classList.toggle("has-uploaded-icon", Boolean(uploadedIcon));
            const uploadLabel = uploadedIcon
                ? getShortcutUiText("shortcutReplaceUploadedIcon", "Replace uploaded icon")
                : getShortcutUiText("shortcutUploadIcon", "Upload icon");
            uploadButton.title = uploadLabel;
            uploadButton.setAttribute("aria-label", uploadLabel);
        }

        if (restoreButton) {
            const restoreLabel = getShortcutUiText("shortcutRestoreOriginalIcon", "Restore original icon");
            restoreButton.disabled = !uploadedIcon;
            restoreButton.title = restoreLabel;
            restoreButton.setAttribute("aria-label", restoreLabel);
        }
    }

    function readShortcutEntry(entry) {
        return {
            name: entry.querySelector(".shortcutName").value,
            url: entry.querySelector(".URL").value,
            uploadedIcon: entry.dataset.uploadedIcon || ""
        };
    }

    function persistShortcutRecord(index, shortcutRecord) {
        localStorage.setItem(`shortcutName${index}`, shortcutRecord.name);
        localStorage.setItem(`shortcutURL${index}`, shortcutRecord.url);

        if (shortcutRecord.uploadedIcon) {
            localStorage.setItem(getUploadedIconKey(index), shortcutRecord.uploadedIcon);
        } else {
            localStorage.removeItem(getUploadedIconKey(index));
        }
    }

    function persistShortcutCollection(shortcuts) {
        const previousAmount = parseInt(localStorage.getItem("shortcutAmount"), 10) || 0;
        const cleanLength = Math.max(previousAmount, shortcuts.length);

        for (let i = 0; i < cleanLength; i++) {
            localStorage.removeItem(`shortcutName${i}`);
            localStorage.removeItem(`shortcutURL${i}`);
            localStorage.removeItem(getUploadedIconKey(i));
        }

        localStorage.setItem("shortcutAmount", shortcuts.length.toString());
        shortcuts.forEach((shortcutRecord, index) => persistShortcutRecord(index, shortcutRecord));
    }

    function readFileAsText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result || ""));
            reader.onerror = () => reject(reader.error || new Error("Unable to read SVG icon."));
            reader.readAsText(file);
        });
    }

    function normalizeSvgToWhite(svgSource) {
        const parser = new DOMParser();
        const parsed = parser.parseFromString(svgSource, "image/svg+xml");
        const svg = parsed.documentElement;

        if (parsed.querySelector("parsererror") || !svg || svg.nodeName.toLowerCase() !== "svg") {
            throw new Error("Invalid SVG icon.");
        }

        svg.removeAttribute("width");
        svg.removeAttribute("height");
        svg.setAttribute("fill", "#FFFFFF");
        svg.setAttribute("color", "#FFFFFF");

        svg.querySelectorAll("*").forEach((node) => {
            if (!(node instanceof Element)) return;

            if (node.hasAttribute("style")) {
                const styleText = node.getAttribute("style") || "";
                const cleaned = styleText
                    .replace(/fill\s*:\s*[^;]+;?/gi, "")
                    .replace(/stroke\s*:\s*[^;]+;?/gi, "")
                    .trim();
                if (cleaned) node.setAttribute("style", cleaned);
                else node.removeAttribute("style");
            }

            if (node.hasAttribute("fill") && node.getAttribute("fill") !== "none") {
                node.setAttribute("fill", "#FFFFFF");
            } else if (["path", "rect", "circle", "ellipse", "polygon", "polyline", "use"].includes(node.tagName.toLowerCase())) {
                node.setAttribute("fill", "#FFFFFF");
            }

            if (node.hasAttribute("stroke") && node.getAttribute("stroke") !== "none") {
                node.setAttribute("stroke", "#FFFFFF");
            }
        });

        const serialized = new XMLSerializer().serializeToString(svg);
        return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(serialized)}`;
    }

    async function createStoredIconDataUrl(file) {
        const svgText = await readFileAsText(file);
        return normalizeSvgToWhite(svgText);
    }

    function clampIconScaleValue(value) {
        const parsed = parseInt(value, 10);
        if (!Number.isFinite(parsed)) return ICON_SCALE_CONFIG.default;
        return Math.min(ICON_SCALE_CONFIG.max, Math.max(ICON_SCALE_CONFIG.min, parsed));
    }

    function mountShortcutIconPopover() {
        if (!dom.shortcutIconPopover || shortcutPopoverMounted) return;
        document.body.appendChild(dom.shortcutIconPopover);
        shortcutPopoverMounted = true;
    }

    function setShortcutIconPopoverOpen(isOpen) {
        if (!dom.shortcutIconPopover || !dom.shortcutIconPopoverButton) return;

        mountShortcutIconPopover();
        const nextOpenState = Boolean(isOpen);
        const popover = dom.shortcutIconPopover;
        const openDur = Math.max(180, Number(window.getPanelAnimDur?.()) || 220);
        const closeDur = Math.max(160, Number(window.getPanelCloseDur?.()) || Math.round(openDur * 0.9));
        popover.style.setProperty("--shortcut-popover-open-ms", `${openDur}ms`);
        popover.style.setProperty("--shortcut-popover-close-ms", `${closeDur}ms`);
        shortcutPopoverOpen = nextOpenState;

        if (shortcutPopoverCloseTimer) {
            clearTimeout(shortcutPopoverCloseTimer);
            shortcutPopoverCloseTimer = null;
        }

        if (nextOpenState) {
            shortcutPopoverDragged = false;
            popover.classList.remove("is-closing");
            popover.classList.remove("panel-closing-down");
            popover.classList.remove("is-open");
            popover.style.animation = "none";
            popover.setAttribute("aria-hidden", "false");
            void popover.offsetWidth;
            positionShortcutIconPopover(true);
            dom.shortcutIconPopoverButton.setAttribute("aria-expanded", "true");
            requestAnimationFrame(() => {
                if (!shortcutPopoverOpen) return;
                popover.style.animation = "";
                popover.classList.add("is-open");
                positionShortcutIconPopover(true);
                requestAnimationFrame(() => {
                    if (shortcutPopoverOpen) positionShortcutIconPopover(true);
                });
            });
        } else {
            shortcutPopoverDragged = false;
            popover.style.animation = "";
            void popover.offsetWidth;
            popover.classList.remove("panel-closing-down");
            popover.classList.add("is-closing");
            dom.shortcutIconPopoverButton.setAttribute("aria-expanded", "false");
            shortcutPopoverCloseTimer = setTimeout(() => {
                popover.classList.remove("is-closing");
                popover.classList.remove("panel-closing-down");
                popover.classList.remove("is-open");
                popover.style.animation = "";
                popover.setAttribute("aria-hidden", "true");
                shortcutPopoverCloseTimer = null;
            }, closeDur + 36);
        }
    }

function positionShortcutIconPopover(force = false) {
    if ((!shortcutPopoverOpen && !force) || !dom.shortcutIconPopover || !dom.shortcutIconPopoverButton) return;

    const popover = dom.shortcutIconPopover;
    const buttonRect = dom.shortcutIconPopoverButton.getBoundingClientRect();

    // Close the popover if its anchor button becomes hidden or goes off-screen
    const isButtonHidden = buttonRect.width === 0 && buttonRect.height === 0;
    const isButtonOffscreen = buttonRect.left >= window.innerWidth || buttonRect.right <= 0 ||
                              buttonRect.top >= window.innerHeight || buttonRect.bottom <= 0;
    if (isButtonHidden || isButtonOffscreen) {
        setShortcutIconPopoverOpen(false);
        return;
    }

    if (shortcutPopoverDragged && !force) {
        // If the panel has been dragged by the user, preserve its position but clamp to viewport borders with 0px padding
        const popoverRect = popover.getBoundingClientRect();
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        const pw = popoverRect.width || popover.offsetWidth;
        const ph = popoverRect.height || popover.offsetHeight;

        const currentLeft = parseFloat(popover.style.left) || popoverRect.left;
        const currentTop = parseFloat(popover.style.top) || popoverRect.top;

        const nextLeft = Math.max(0, Math.min(vw - pw, currentLeft));
        const nextTop = Math.max(0, Math.min(vh - ph, currentTop));

        popover.style.left = `${nextLeft}px`;
        popover.style.top = `${nextTop}px`;
        return;
    }

    const viewportPadding = 18;
    const popoverRect = popover.getBoundingClientRect();
    const popoverWidth = popoverRect.width || Math.min(330, window.innerWidth - 72);
    const popoverHeight = popoverRect.height || 140;

    let left = buttonRect.right - popoverWidth - 10;
    left = Math.min(left, window.innerWidth - popoverWidth - viewportPadding);
    left = Math.max(viewportPadding, left);

    const anchorGap = 12;
    let top = buttonRect.bottom + anchorGap;

    top = Math.min(top, window.innerHeight - popoverHeight - viewportPadding);
    top = Math.max(viewportPadding, top);

    popover.style.left = `${left}px`;
    popover.style.top = `${top}px`;
}

    function setupShortcutIconPopover() {
        if (!dom.shortcutIconPopoverButton || !dom.shortcutIconPopover) return;

        mountShortcutIconPopover();
        makeShortcutPopoverDraggable(dom.shortcutIconPopover, dom.shortcutIconPopover.querySelector(".shortcut-icon-popover-drag"));

        dom.shortcutIconPopoverButton.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            setShortcutIconPopoverOpen(!shortcutPopoverOpen);
        });

        dom.shortcutIconPopoverClose?.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            setShortcutIconPopoverOpen(false);
        });

        dom.shortcutIconPopover.addEventListener("click", (event) => {
            event.stopPropagation();
        });

        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape" && shortcutPopoverOpen) {
                setShortcutIconPopoverOpen(false);
            }
        });

        window.addEventListener("resize", () => {
            if (shortcutPopoverOpen) positionShortcutIconPopover();
        });

        window.addEventListener("scroll", () => {
            if (shortcutPopoverOpen) positionShortcutIconPopover();
        }, true);
    }

    function makeShortcutPopoverDraggable(panel, handle) {
        if (!panel || !handle) return;

        let startX = 0;
        let startY = 0;
        let startLeft = 0;
        let startTop = 0;
        let dragging = false;

        handle.addEventListener("mousedown", (event) => {
            if (event.button !== 0) return;
            event.preventDefault();
            dragging = true;
            shortcutPopoverDragged = true;
            startX = event.clientX;
            startY = event.clientY;
            const rect = panel.getBoundingClientRect();
            startLeft = rect.left;
            startTop = rect.top;
            handle.style.cursor = "grabbing";
        });

        document.addEventListener("mousemove", (event) => {
            if (!dragging) return;
            const panelWidth = panel.offsetWidth;
            const panelHeight = panel.offsetHeight;
            // Allow the panel to reach 0px boundaries (touching page borders)
            const nextLeft = Math.max(0, Math.min(window.innerWidth - panelWidth, startLeft + event.clientX - startX));
            const nextTop = Math.max(0, Math.min(window.innerHeight - panelHeight, startTop + event.clientY - startY));
            panel.style.left = `${nextLeft}px`;
            panel.style.top = `${nextTop}px`;
        });

        document.addEventListener("mouseup", () => {
            if (!dragging) return;
            dragging = false;
            handle.style.cursor = "grab";
        });
    }

    function getSavedShortcutIconScale() {
        const savedValue = localStorage.getItem(STORAGE_KEYS.iconScale);
        if (savedValue === null) {
            localStorage.setItem(STORAGE_KEYS.iconScale, ICON_SCALE_CONFIG.default);
            return ICON_SCALE_CONFIG.default;
        }
        return clampIconScaleValue(savedValue);
    }

    function updateShortcutIconScaleFill(value) {
        if (!dom.shortcutIconScaleSlider) return;
        const slider = dom.shortcutIconScaleSlider;
        const percent = ((value - ICON_SCALE_CONFIG.min) / (ICON_SCALE_CONFIG.max - ICON_SCALE_CONFIG.min)) * 100;
        slider.style.setProperty("--slider-fill", `${percent}%`);
    }

    function updateShortcutIconScaleLabel(value) {
        if (dom.shortcutIconScaleValue) {
            dom.shortcutIconScaleValue.textContent = `${(value / 100).toFixed(2)}x`;
        }
    }

    function applyShortcutIconScale(value) {
        const clampedValue = clampIconScaleValue(value);
        const visualScale = (clampedValue + ICON_SCALE_CONFIG.visualBoost) / 100;
        document.documentElement.style.setProperty("--shortcut-icon-scale", visualScale.toFixed(2));
        updateShortcutIconScaleFill(clampedValue);
        updateShortcutIconScaleLabel(clampedValue);
        if (dom.shortcutIconScaleSlider) {
            dom.shortcutIconScaleSlider.value = clampedValue;
        }
    }

    function sliderValueToX(slider, value) {
        const thumbSize = 15;
        const min = parseFloat(slider.min || ICON_SCALE_CONFIG.min);
        const max = parseFloat(slider.max || ICON_SCALE_CONFIG.max);
        const ratio = (value - min) / (max - min || 1);
        const travel = Math.max(0, slider.offsetWidth - thumbSize);
        return slider.offsetLeft + (thumbSize / 2) + (travel * ratio);
    }

    function updateShortcutDefaultMarkerPosition() {
        if (!dom.shortcutIconScaleSlider || !dom.shortcutIconScaleRow) return;
        dom.shortcutIconScaleRow.style.setProperty("--shortcut-default-marker-x", `${sliderValueToX(dom.shortcutIconScaleSlider, ICON_SCALE_CONFIG.default)}px`);
        dom.shortcutIconScaleRow.style.setProperty("--shortcut-default-marker-y", `${dom.shortcutIconScaleSlider.offsetTop + (dom.shortcutIconScaleSlider.offsetHeight / 2)}px`);
    }

    function isShortcutScaleSnapEnabled() {
        return localStorage.getItem(STORAGE_KEYS.iconScaleSnapEnabled) !== "0";
    }

    function syncShortcutScaleSnapState() {
        if (!dom.shortcutIconScaleRow || !dom.shortcutIconScaleSlider) return;
        const markerBtn = ensureShortcutScaleSnapToggle();
        const snapEnabled = isShortcutScaleSnapEnabled();
        const isAtDefault = parseInt(dom.shortcutIconScaleSlider.value, 10) === ICON_SCALE_CONFIG.default;
        const shouldGlow = snapEnabled && isAtDefault;

        dom.shortcutIconScaleRow.dataset.defaultSnapEnabled = snapEnabled ? "1" : "0";
        dom.shortcutIconScaleRow.dataset.defaultSnapActive = shouldGlow ? "1" : "0";

        if (markerBtn) {
            markerBtn.setAttribute("aria-pressed", snapEnabled ? "true" : "false");
            markerBtn.title = snapEnabled
                ? "Default snap on. Click to turn it off."
                : "Default snap off. Click to turn it on.";
        }

        if (shouldGlow) {
            dom.shortcutIconScaleSlider.dataset.snapped = "1";
        } else {
            delete dom.shortcutIconScaleSlider.dataset.snapped;
        }
    }

    function ensureShortcutScaleSnapToggle() {
        if (!dom.shortcutIconScaleRow) return null;

        let markerBtn = dom.shortcutIconScaleRow.querySelector(".default-marker-toggle");
        if (!markerBtn) {
            markerBtn = document.createElement("button");
            markerBtn.type = "button";
            markerBtn.className = "default-marker-toggle";
            markerBtn.setAttribute("aria-label", "Toggle default icon size snap");
            dom.shortcutIconScaleRow.appendChild(markerBtn);

            markerBtn.addEventListener("click", (event) => {
                event.preventDefault();
                event.stopPropagation();

                const nextState = isShortcutScaleSnapEnabled() ? "0" : "1";
                localStorage.setItem(STORAGE_KEYS.iconScaleSnapEnabled, nextState);
                syncShortcutScaleSnapState();
            });
        }

        return markerBtn;
    }

    function setupShortcutIconScaleControl() {
        if (!dom.shortcutIconScaleSlider || !dom.shortcutIconScaleRow) return;

        const slider = dom.shortcutIconScaleSlider;
        const applyScaleValue = (value) => {
            const clampedValue = clampIconScaleValue(value);
            slider.value = clampedValue;
            localStorage.setItem(STORAGE_KEYS.iconScale, clampedValue);
            applyShortcutIconScale(clampedValue);
            syncShortcutScaleSnapState();
        };
        const applySnapBehavior = () => {
            const SNAP_ZONE_PX = 8;
            const SNAP_RELEASE_ZONE_PX = 18;
            let snapLocked = false;

            slider.addEventListener("input", () => {
                if (!isShortcutScaleSnapEnabled()) {
                    snapLocked = false;
                    syncShortcutScaleSnapState();
                    return;
                }

                const currentValue = clampIconScaleValue(slider.value);
                const snapX = sliderValueToX(slider, ICON_SCALE_CONFIG.default);
                const currentX = sliderValueToX(slider, currentValue);
                const distance = Math.abs(currentX - snapX);

                if (snapLocked) {
                    if (distance < SNAP_RELEASE_ZONE_PX) {
                        applyScaleValue(ICON_SCALE_CONFIG.default);
                        return;
                    }

                    snapLocked = false;
                    syncShortcutScaleSnapState();
                    return;
                }

                if (distance < SNAP_ZONE_PX) {
                    snapLocked = true;
                    applyScaleValue(ICON_SCALE_CONFIG.default);
                    return;
                }

                syncShortcutScaleSnapState();
            });
        };

        ensureShortcutScaleSnapToggle();
        updateShortcutDefaultMarkerPosition();
        applyScaleValue(getSavedShortcutIconScale());
        window.addEventListener("resize", updateShortcutDefaultMarkerPosition);
        window.addEventListener("load", updateShortcutDefaultMarkerPosition);
        requestAnimationFrame(updateShortcutDefaultMarkerPosition);
        setTimeout(updateShortcutDefaultMarkerPosition, 80);
        applySnapBehavior();

        slider.addEventListener("input", () => {
            applyScaleValue(slider.value);
            updateShortcutDefaultMarkerPosition();
        });
    }

    // Attaches event listeners to shortcut input fields
    function attachInputListeners(inputs, entry) {
        inputs.forEach(input => {
            let oldValue = input.value;
            input.addEventListener("focus", e => {
                oldValue = e.target.value;
                e.target.select();
            });
            input.addEventListener("blur", () => {
                const newValue = input.value;
                saveShortcut(entry);
                renderShortcut(
                    entry.querySelector(".shortcutName").value,
                    entry.querySelector(".URL").value,
                    entry._index,
                    entry.dataset.uploadedIcon || ""
                );
                if (newValue !== oldValue) {
                    scShowToast(getShortcutToastMsg("edit"), "edit");
                }
            });
        });

        inputs[0].addEventListener("keydown", e => e.key === "Enter" && inputs[1].focus());
        inputs[1].addEventListener("keydown", e => e.key === "Enter" && e.target.blur());
    }

    // Drag and drop functionality for reordering shortcuts
    function setupDragAndDrop() {
        let draggedElement = null;
        let autoScrollInterval = null;
        let dragOffset = { x: 0, y: 0 };
        let isReordering = false;
        let pendingReorder = false;
        let isDragging = false;

        // Cache element positions for smooth gliding animation
        function cachePositions() {
            const map = new Map();
            const entries = dom.shortcutSettingsContainer.querySelectorAll('.shortcutSettingsEntry');
            for (const el of entries) {
                map.set(el, el.getBoundingClientRect().top);
            }
            return map;
        }

        // Animate smooth gliding effect for sibling elements
        function animateGlide(oldPositions) {
            const entries = [...dom.shortcutSettingsContainer.children];
            const newPositions = new Map();

            // Batch read
            entries.forEach(el => {
                if (el !== draggedElement) {
                    newPositions.set(el, el.getBoundingClientRect().top);
                }
            });

            // Batch write
            entries.forEach(el => {
                if (el === draggedElement) return;
                const oldTop = oldPositions.get(el);
                const newTop = newPositions.get(el);
                if (oldTop !== undefined && newTop !== undefined) {
                    const delta = oldTop - newTop;
                    if (delta !== 0) {
                        el.style.transition = 'none';
                        el.style.transform = `translateY(${delta}px)`;
                        requestAnimationFrame(() => {
                            el.style.transition = 'transform 300ms cubic-bezier(0.4, 0, 0.2, 1)';
                            el.style.transform = 'none';
                        });
                    }
                }
            });
        }

        // Auto-scroll functionality
        function handleAutoScroll(clientY) {
            const container = dom.shortcutSettingsContainer;
            const containerRect = container.getBoundingClientRect();
            const scrollThreshold = 50; // pixels from edge to trigger scroll
            const scrollSpeed = 5; // pixels per frame

            // Clear existing interval
            if (autoScrollInterval) {
                clearInterval(autoScrollInterval);
                autoScrollInterval = null;
            }

            // Check if we need to scroll up
            if (clientY - containerRect.top < scrollThreshold && container.scrollTop > 0) {
                autoScrollInterval = setInterval(() => {
                    container.scrollTop = Math.max(0, container.scrollTop - scrollSpeed);
                }, 16); // ~60fps
            }
            // Check if we need to scroll down
            else if (containerRect.bottom - clientY < scrollThreshold &&
                container.scrollTop < container.scrollHeight - container.clientHeight) {
                autoScrollInterval = setInterval(() => {
                    const maxScroll = container.scrollHeight - container.clientHeight;
                    container.scrollTop = Math.min(maxScroll, container.scrollTop + scrollSpeed);
                }, 16); // ~60fps
            }
        }

        // Stop auto-scroll
        function stopAutoScroll() {
            if (autoScrollInterval) {
                clearInterval(autoScrollInterval);
                autoScrollInterval = null;
            }
        }

        // Helper function for drag and drop with cached rect
        let dragElementsCache = [];
        let cacheTimestamp = 0;

        function getSortedElements() {
            const now = Date.now();
            // Cache for 16ms (one frame) to avoid repeated getBoundingClientRect calls
            if (now - cacheTimestamp < 16) {
                return dragElementsCache;
            }

            dragElementsCache = [...dom.shortcutSettingsContainer.querySelectorAll(".shortcutSettingsEntry:not(.dragging)")]
                .map(el => ({
                    element: el,
                    rect: el.getBoundingClientRect()
                }));
            cacheTimestamp = now;
            return dragElementsCache;
        }

        function getDragAfterElement(y) {
            const elements = getSortedElements();
            let low = 0, high = elements.length - 1;

            while (low <= high) {
                const mid = (low + high) >>> 1;
                const middleY = elements[mid].rect.top + elements[mid].rect.height / 2;
                y < middleY ? high = mid - 1 : low = mid + 1;
            }

            return elements[low]?.element || null;
        }

        // Insert element with smooth animation
        function insertElementWithAnimation(element, targetElement, insertBefore = true) {
            const oldPositions = cachePositions();
            const container = dom.shortcutSettingsContainer;

            // Perform DOM insertion
            if (targetElement) {
                if (insertBefore) {
                    // Insert before target element
                    container.insertBefore(element, targetElement);
                } else {
                    // Insert after target element
                    container.insertBefore(element, targetElement.nextSibling);
                }
            } else {
                // Append to end if no target element
                container.appendChild(element);
            }

            animateGlide(oldPositions);
            pendingReorder = true;
        }

        // Common drag logic for both mouse and touch
        function handleDragMove(clientX, clientY) {
            if (!isReordering || !draggedElement) return;

            // Handle auto-scroll
            handleAutoScroll(clientY);

            const afterElement = getDragAfterElement(clientY);

            // Add null/undefined check
            if (afterElement === null || afterElement === undefined) {
                // Move to end
                insertElementWithAnimation(draggedElement, null, false);
                return;
            }

            // Check if we need to reorder
            if (afterElement && afterElement !== draggedElement) {
                // Only move if it's actually a different position
                if (afterElement.previousSibling !== draggedElement) {
                    insertElementWithAnimation(draggedElement, afterElement, true);
                }
            } else if (!afterElement) {
                // Move to end if no after element
                const lastElement = dom.shortcutSettingsContainer.lastElementChild;
                if (lastElement && lastElement !== draggedElement) {
                    insertElementWithAnimation(draggedElement, null, false);
                }
            }
        }

        // Common cleanup logic
        function cleanup() {
            stopAutoScroll();

            // Remove CSS classes
            if (draggedElement) {
                draggedElement.classList.remove("dragging");
            }

            // Only update if we actually made changes
            if (pendingReorder) {
                updateShortcutIndices();
                saveShortcutOrder();
                pendingReorder = false;
                const lang = document.documentElement.lang || localStorage.getItem("selectedLanguage") || "en";
                const msg = lang === "ar" || lang.startsWith("ar_SA") ? "\u062a\u0645 \u062a\u062d\u062f\u064a\u062b \u0627\u0644\u062a\u0631\u062a\u064a\u0628" : "Order updated";
                scShowToast(msg, "edit");
            }

            // Reset state
            dom.shortcutSettingsContainer.classList.remove("dragging-ongoing");
            isReordering = false;
            isDragging = false;
            draggedElement = null;
        }

        // ==== MOUSE EVENTS ====
        dom.shortcutSettingsContainer.addEventListener("dragstart", e => {
            const item = e.target.closest(".shortcutSettingsEntry");
            if (item) {
                isReordering = true;
                draggedElement = item;

                // Calculate drag offset
                const rect = item.getBoundingClientRect();
                dragOffset.x = e.clientX - rect.left;
                dragOffset.y = e.clientY - rect.top;

                dom.shortcutSettingsContainer.classList.add("dragging-ongoing");

                // Add CSS classes for styling
                setTimeout(() => {
                    item.classList.add("dragging");
                }, 0);

                e.dataTransfer.effectAllowed = "move";
            }
        });

        dom.shortcutSettingsContainer.addEventListener("dragover", e => {
            e.preventDefault();
            handleDragMove(e.clientX, e.clientY);
        });

        dom.shortcutSettingsContainer.addEventListener("dragend", e => {
            if (!isReordering || !draggedElement) return;
            cleanup();
        });

        // Global event listeners for cleanup
        document.addEventListener("dragend", () => {
            if (isReordering) {
                cleanup();
            }
        });

        // Handle window blur for cleanup
        window.addEventListener("blur", () => {
            if (isReordering || isDragging) {
                cleanup();
            }
        });
    }

    // Updates indices of all shortcut entries after reordering
    function updateShortcutIndices() {
        document.querySelectorAll(".shortcutSettingsEntry").forEach((entry, index) => {
            entry._index = index;
        });
    }

    // Saves the new shortcut order to localStorage
    function saveShortcutOrder() {
        const entries = dom.shortcutSettingsContainer.querySelectorAll(".shortcutSettingsEntry");
        const newOrder = Array.from(entries).map(entry => ({
            name: entry.querySelector(".shortcutName").value,
            url: entry.querySelector(".URL").value,
            uploadedIcon: entry.dataset.uploadedIcon || ""
        }));

        // Only save if order has changed
        if (hasOrderChanged(newOrder)) {
            // Push current state to undo stack before overwriting
            _scUndoStack.push([...shortcutsCache]);

            persistShortcutCollection(newOrder);
            shortcutsCache = newOrder;
            renderAllShortcuts(newOrder);
        }
    }

    // Checks if the shortcut order has changed
    function hasOrderChanged(newOrder) {
        if (newOrder.length !== shortcutsCache.length) return true;

        return newOrder.some((item, index) => {
            const cached = shortcutsCache[index];
            return item.name !== cached.name || item.url !== cached.url || item.uploadedIcon !== cached.uploadedIcon;
        });
    }

    // Renders all shortcuts in the main view
    function renderAllShortcuts(order) {
        const fragment = document.createDocumentFragment();

        order.forEach((item, index) => {
            fragment.appendChild(buildShortcutElement(item, index));
        });

        dom.shortcutsContainer.innerHTML = "";
        dom.shortcutsContainer.appendChild(fragment);

    }

    function refreshShortcutIcons() {
        if (!shortcutsCache.length || !dom.shortcutsContainer) return;
        renderAllShortcuts(shortcutsCache);
        applyShortcutGlyphTone(dom.shortcutsContainer);
    }

    function setupThemeRefresh() {
        let refreshQueued = false;

        document.addEventListener("theme-colors-changed", () => {
            if (refreshQueued) return;
            refreshQueued = true;

            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    refreshShortcutIcons();
                    refreshQueued = false;
                });
            });
        });
    }

    // Handles the shortcuts toggle checkbox change
    function handleShortcutsToggle() {
        const isChecked = this.checked;
        saveCheckboxState("shortcutsCheckboxState", this);

        // Animate using sc-hidden class (position:fixed so layout is never affected)
        dom.shortcuts.classList.toggle("sc-hidden", !isChecked);
        saveDisplayStatus("shortcutsDisplayStatus", isChecked ? "flex" : "none");

        dom.shortcutEditField.classList.toggle("inactive", !isChecked);
        saveActiveStatus("shortcutEditField", isChecked ? "active" : "inactive");

        dom.adaptiveIconField.classList.toggle("inactive", !isChecked);
        saveActiveStatus("adaptiveIconField", isChecked ? "active" : "inactive");
    }

    // Handles the adaptive icon toggle checkbox change
    function handleAdaptiveIconToggle() {
        saveCheckboxState("adaptiveIconToggle", this);
        dom.shortcutsContainer.classList.toggle("adaptive-icons", this.checked);
        refreshShortcutIcons();
    }

    // Adds a new shortcut
    function addNewShortcut() {
        const currentAmount = parseInt(localStorage.getItem("shortcutAmount")) || shortcutsCache.length;
        if (currentAmount >= MAX_SHORTCUTS) return;

        const newAmount = currentAmount + 1;
        localStorage.setItem("shortcutAmount", newAmount.toString());

        if (currentAmount >= 1) {
            document.querySelectorAll(".delete button.inactive").forEach(b => {
                b.classList.remove("inactive");
            });
        }

        if (newAmount === MAX_SHORTCUTS) {
            dom.newShortcutButton.classList.add("inactive");
        }

        const entry = createShortcutEntry(PLACEHOLDER.name, PLACEHOLDER.url, false, currentAmount, "");
        dom.shortcutSettingsContainer.appendChild(entry);

        saveShortcut(entry);
        renderShortcut(PLACEHOLDER.name, PLACEHOLDER.url, currentAmount, "");
        scShowToast(getShortcutToastMsg("add"), "add");
    }

    // Deletes a shortcut
    function deleteShortcut(entry) {
        const currentAmount = parseInt(localStorage.getItem("shortcutAmount")) || shortcutsCache.length;
        if (currentAmount <= 1) return;

        entry.remove();
        updateShortcutIndices();

        const remainingEntries = [...dom.shortcutSettingsContainer.querySelectorAll(".shortcutSettingsEntry")];
        const newOrder = remainingEntries.map(readShortcutEntry);
        persistShortcutCollection(newOrder);
        shortcutsCache = newOrder;
        renderAllShortcuts(newOrder);

        if (newOrder.length === 1) {
            document.querySelectorAll(".delete button").forEach(b => {
                b.classList.add("inactive");
            });
        }

        dom.newShortcutButton.classList.remove("inactive");
        scShowToast(getShortcutToastMsg("delete"), "delete");
    }

    // Resets all shortcuts to default
    async function resetShortcuts() {
        if (!(await confirmPrompt(translations[currentLanguage]?.resetShortcutsPrompt || translations["en"].resetShortcutsPrompt)))
            return;

        // Animation for shortcut elements
        const shortcutEntries = [...dom.shortcutSettingsContainer.querySelectorAll('.shortcutSettingsEntry')];
        shortcutEntries.forEach(el => el.classList.add("reset-shift-animation"));

        // Animation for reset button
        const svg = dom.resetShortcutsButton.querySelector("svg");
        svg.classList.add("rotate-animation");

        // Clear storage
        for (let i = 0; i < (localStorage.getItem("shortcutAmount") || 0); i++) {
            localStorage.removeItem(`shortcutName${i}`);
            localStorage.removeItem(`shortcutURL${i}`);
            localStorage.removeItem(getUploadedIconKey(i));
        }
        localStorage.removeItem("shortcutAmount");

        // Wait for animations of shortcut elements to complete
        await new Promise(resolve => setTimeout(resolve, 300));

        // Reset UI
        dom.shortcutSettingsContainer.innerHTML = "";
        dom.shortcutsContainer.innerHTML = "";
        dom.newShortcutButton.classList.remove("inactive");
        setTimeout(() => svg.classList.remove("rotate-animation"), 500);

        // Reload
        loadShortcuts();
        scShowToast(getShortcutToastMsg("reset"), "reset");
    }

    // Saves a single shortcut to localStorage
    function saveShortcut(entry) {
        const previousShortcut = shortcutsCache[entry._index] || { name: "", url: "", uploadedIcon: "" };
        const nextShortcut = readShortcutEntry(entry);

        if (previousShortcut.url?.trim() && !nextShortcut.url.trim()) {
            nextShortcut.uploadedIcon = "";
            setEntryUploadedIcon(entry, "");
        }

        persistShortcutRecord(entry._index, nextShortcut);
        shortcutsCache[entry._index] = nextShortcut;
    }

    // Seamless infinite marquee for shortcut names on hover
    function setupNameMarquee() {
        dom.shortcutsContainer.addEventListener("mouseenter", (e) => {
            const shortcut = e.target.closest(".shortcuts");
            if (!shortcut) return;
            const nameEl = shortcut.querySelector(".shortcut-name");
            const inner  = nameEl?.querySelector(".sc-inner");
            if (!inner) return;

            const outerW = nameEl.offsetWidth;        // visible container width (120px)
            const textW  = inner.scrollWidth;         // natural text width

            // No overflow → nothing to scroll, keep centered
            if (textW <= outerW) return;

            // Build duplicate content once: [text] [gap=outerW] [text]
            // The gap equals the container width so the second copy
            // enters from the RIGHT edge at the same moment the first exits LEFT
            if (!inner.dataset.dup) {
                const rawText = inner.textContent;
                inner.dataset.dup = "1";
                inner.dataset.rawText = rawText;
                const gap = `<span style="display:inline-block;width:${outerW}px"></span>`;
                inner.innerHTML = escapeHtml(rawText) + gap + escapeHtml(rawText);
                nameEl.classList.add("sc-overflow");
            }

            // --sc-shift: the exact pixel distance to travel = textW + outerW (one full cycle)
            const cycleW = textW + outerW;
            inner.style.setProperty("--sc-shift", `-${cycleW}px`);

            // Speed ~80px/s
            const dur = cycleW / 80;
            inner.style.setProperty("--sc-dur", `${dur.toFixed(2)}s`);

            inner.classList.add("sc-running");
        }, true);

        dom.shortcutsContainer.addEventListener("mouseleave", (e) => {
            const shortcut = e.target.closest(".shortcuts");
            if (!shortcut) return;
            const inner = shortcut.querySelector(".sc-inner");
            if (!inner) return;
            // Stop immediately — the label fades out (opacity→0) so snap-back is invisible
            inner.classList.remove("sc-running");
        }, true);
    }

    // Apply a given order array to localStorage, cache, and UI
    function _scApplyOrder(order) {
        persistShortcutCollection(order);
        shortcutsCache = [...order];
        dom.shortcutSettingsContainer.innerHTML = "";
        const deleteInactive = order.length <= 1;
        order.forEach((item, index) => {
            const entry = createShortcutEntry(item.name, item.url, deleteInactive, index, item.uploadedIcon || "");
            dom.shortcutSettingsContainer.appendChild(entry);
        });
        renderAllShortcuts(order);
    }

    // Undo last drag-and-drop reorder
    function _scPerformUndo() {
        if (!_scUndoStack.length) return;
        const prev = _scUndoStack.pop();
        _scApplyOrder(prev);
    }

    // ── Set a STABLE bottom-padding reserve for .centerDiv so the page never shifts ──
    // --shortcuts-max-height is set once to the rendered height and never updated.
    // Hiding/showing shortcuts (sc-hidden class) only changes opacity+transform,
    // so the reserved space stays constant and the page never jumps.
    function initShortcutsMaxHeight() {
        const section = dom.shortcuts;
        if (!section) return;
        // Temporarily ensure element is visible to measure real height
        const wasHidden = section.classList.contains("sc-hidden");
        if (wasHidden) {
            section.classList.add("sc-no-transition");
            section.classList.remove("sc-hidden");
        }
        const h = section.getBoundingClientRect().height;
        if (wasHidden) {
            section.classList.add("sc-hidden");
            requestAnimationFrame(() => section.classList.remove("sc-no-transition"));
        }
        if (h > 0) {
            document.documentElement.style.setProperty("--shortcuts-max-height", h + "px");
        }
    }

    if (dom.shortcuts) {
        // Measure once after shortcuts are rendered
        if (document.readyState === "complete") {
            initShortcutsMaxHeight();
        } else {
            window.addEventListener("load", initShortcutsMaxHeight, { once: true });
        }
        // Re-measure only if shortcut count changes (new row added), not on toggle
        let _lastShortcutCount = 0;
        const ro = new ResizeObserver(() => {
            const current = dom.shortcutsContainer
                ? dom.shortcutsContainer.querySelectorAll(".shortcuts").length : 0;
            if (current !== _lastShortcutCount) {
                _lastShortcutCount = current;
                initShortcutsMaxHeight();
            }
        });
        ro.observe(dom.shortcuts);
    }


    let _scToastTimer = null;
    let _scToastProgressTimer = null;

    function getShortcutToastMsg(type) {
        const lang = document.documentElement.lang || localStorage.getItem("selectedLanguage") || "en";
        const isAr = lang === "ar" || lang.startsWith("ar_SA");
        if (type === "add") {
            return isAr ? "\u062a\u0645 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0627\u062e\u062a\u0635\u0627\u0631" : "Shortcut added";
        } else if (type === "delete") {
            return isAr ? "\u062a\u0645 \u062d\u0630\u0641 \u0627\u0644\u0627\u062e\u062a\u0635\u0627\u0631" : "Shortcut deleted";
        } else if (type === "edit") {
            return isAr ? "\u062a\u0645 \u062a\u062d\u062f\u064a\u062b \u0627\u0644\u0627\u062e\u062a\u0635\u0627\u0631" : "Shortcut updated";
        } else if (type === "icon_uploaded") {
            return isAr ? "\u062a\u0645 \u062a\u062d\u062f\u064a\u062b \u0627\u0644\u0623\u064a\u0642\u0648\u0646\u0629" : "Icon updated";
        } else if (type === "icon_restored") {
            return isAr ? "\u062a\u0645 \u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u0627\u0644\u0623\u064a\u0642\u0648\u0646\u0629 \u0627\u0644\u0623\u0635\u0644\u064a\u0629" : "Original icon restored";
        } else if (type === "reset") {
            return isAr ? "\u062a\u0645 \u0625\u0639\u0627\u062f\u0629 \u062a\u0639\u064a\u064a\u0646 \u0627\u0644\u0627\u062e\u062a\u0635\u0627\u0631\u0627\u062a" : "Shortcuts reset to default";
        }
        return isAr ? "\u062a\u0645 \u0627\u0644\u062d\u0641\u0638" : "Saved";
    }

    function _scParseCssTimeToMs(timeStr) {
        if (!timeStr) return 0;
        const val = parseFloat(timeStr);
        return timeStr.indexOf("ms") !== -1 ? val : val * 1000;
    }

    function _scGetTransitionTotalMs(el) {
        if (!el) return 0;
        const styles = window.getComputedStyle(el);
        const durations = styles.transitionDuration.split(",");
        const delays = styles.transitionDelay.split(",");
        const transitionTotal = Math.max(durations.length, delays.length, 1);
        let maxMs = 0;

        for (let i = 0; i < transitionTotal; i++) {
            const duration = _scParseCssTimeToMs(durations[i] ?? durations[durations.length - 1]);
            const delay = _scParseCssTimeToMs(delays[i] ?? delays[delays.length - 1]);
            maxMs = Math.max(maxMs, duration + delay);
        }

        const animationDurations = styles.animationDuration.split(",");
        const animationDelays = styles.animationDelay.split(",");
        const animationTotal = Math.max(animationDurations.length, animationDelays.length, 1);

        for (let i = 0; i < animationTotal; i++) {
            const duration = _scParseCssTimeToMs(animationDurations[i] ?? animationDurations[animationDurations.length - 1]);
            const delay = _scParseCssTimeToMs(animationDelays[i] ?? animationDelays[animationDelays.length - 1]);
            maxMs = Math.max(maxMs, duration + delay);
        }

        return Math.round(maxMs);
    }

    function scShowToast(message, iconType) {
        const DURATION = 3000;
        let toast = document.getElementById("scActionToast");
        if (!toast) {
            toast = document.createElement("div");
            toast.id = "scActionToast";
            toast.className = "bm-action-toast";
            toast.innerHTML = `
                <div class="bm-toast-progress"></div>
                <div class="bm-toast-inner">
                    <div class="bm-toast-icon-wrap" id="scToastIconWrap"></div>
                    <span class="bm-toast-text" id="scToastText"></span>
                </div>`;
            document.body.appendChild(toast);
        }

        const iconWrap = document.getElementById("scToastIconWrap");
        const textEl   = document.getElementById("scToastText");
        const progress = toast.querySelector(".bm-toast-progress");

        const icons = {
            edit:    `<svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>`,
            delete:  `<svg viewBox="0 0 24 24"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>`,
            add:     `<svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>`,
            reset:   `<svg viewBox="0 0 24 24"><path d="M12 5V2L8 6l4 4V7c2.76 0 5 2.24 5 5a4.98 4.98 0 0 1-.81 2.74l1.46 1.46A6.96 6.96 0 0 0 19 12c0-3.87-3.13-7-7-7zm-5 .8L5.54 7.26A6.96 6.96 0 0 0 5 12c0 3.87 3.13 7 7 7v3l4-4-4-4v3c-2.76 0-5-2.24-5-5 0-1.01.3-1.95.81-2.74z"/></svg>`,
            icon:    `<svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 16H6c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1h12c.55 0 1 .45 1 1v12c0 .55-.45 1-1 1zm-4.44-6.19l-2.35 3.02-1.56-1.88c-.2-.25-.58-.24-.78.01l-2.14 2.72c-.26.33-.02.82.4.82h11.75c.4 0 .65-.47.4-.81l-3.95-5.01c-.2-.26-.6-.26-.79 0z"/></svg>`,
        };

        iconWrap.innerHTML = icons[iconType] || icons["edit"];
        textEl.textContent = message;

        progress.style.transition = "none";
        progress.style.width = "100%";
        toast.classList.remove("bm-toast-show", "bm-toast-out");
        void toast.offsetWidth;

        toast.classList.add("bm-toast-show");

        clearTimeout(_scToastTimer);
        clearTimeout(_scToastProgressTimer);
        cancelAnimationFrame(_scToastProgressTimer);

        _scToastProgressTimer = requestAnimationFrame(() => {
            progress.style.transition = `width ${DURATION}ms linear`;
            progress.style.width = "0%";
        });

        _scToastTimer = setTimeout(() => {
            toast.classList.remove("bm-toast-show");
            void toast.offsetWidth;
            toast.classList.add("bm-toast-out");
            const hideDuration = Math.max(_scGetTransitionTotalMs(toast), 180);
            setTimeout(() => toast.classList.remove("bm-toast-show", "bm-toast-out"), hideDuration + 20);
        }, DURATION);
    }

    // Ctrl+Z for shortcuts reorder (settings panel open check optional)
    document.addEventListener("keydown", (e) => {
        const isZ = e.code === "KeyZ";
        const mod = e.ctrlKey || e.metaKey;
        if (!mod || !isZ || e.shiftKey) return;

        // Only trigger when shortcut settings panel is visible
        if (dom.shortcutSettingsContainer.closest(".inactive")) return;
        if (dom.shortcutSettingsContainer.offsetParent === null) return;

        e.preventDefault();
        e.stopPropagation();
        _scPerformUndo();
    });
});

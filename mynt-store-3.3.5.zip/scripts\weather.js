/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

document.addEventListener("DOMContentLoaded", function () {
    const hideWeather = document.getElementById("hideWeather");
    const hideWeatherCheckbox = document.getElementById("hideWeatherCheckbox");

    // Select all elements that need to be disabled
    const elementsToDisable = document.querySelectorAll(".weather");

    // Retrieve saved state from localStorage (default: false if null)
    const savedState = localStorage.getItem("hideWeatherVisible") === "true";
    hideWeatherCheckbox.checked = savedState;

    function applyVisibilityState(isHidden) {
        hideWeather.classList.toggle("weather-hidden", isHidden);
        if (!isHidden) {
            document.documentElement.classList.remove("pre-hide-weather");
        }
    }

    // Function to toggle the 'inactive' class
    function toggleInactiveState(isInactive) {
        elementsToDisable.forEach(element => {
            element.classList.toggle("inactive", isInactive);
        });
    }

    // Apply initial state
    toggleInactiveState(savedState);
    applyVisibilityState(savedState);

    // Run immediately since script tags are deferred and execute before DOMContentLoaded
    if (!savedState) {
        getWeatherData();
    }

    hideWeatherCheckbox.addEventListener("change", () => {
        const isChecked = hideWeatherCheckbox.checked;
        applyVisibilityState(isChecked);
        localStorage.setItem("hideWeatherVisible", isChecked);

        // Apply inactive class to disable elements visually
        toggleInactiveState(isChecked);

        if (!isChecked) {
            getWeatherData();
        }
    });
});

async function getWeatherData() {
    // Display texts 
    document.getElementById("conditionText").textContent = translations[currentLanguage]?.conditionText || translations["en"].conditionText;
    document.getElementById("humidityLevel").textContent = translations[currentLanguage]?.humidityLevel || translations["en"].humidityLevel;
    document.getElementById("location").textContent = translations[currentLanguage]?.location || translations["en"].location;

    const isRTL = rtlLanguages.includes(currentLanguage);

    // Cache DOM elements
    const userAPIInput = document.getElementById("userAPI");
    const userLocInput = document.getElementById("userLoc");
    const saveAPIButton = document.getElementById("saveAPI");
    const saveLocButton = document.getElementById("saveLoc");
    const gpsToggle = document.getElementById("useGPScheckbox");
    const locationCont = document.getElementById("locationCont");
    const locationSuggestions = document.getElementById("locationSuggestions");

    function setLocationSuggestionsVisible(isVisible) {
        const visible = !!isVisible && locationSuggestions.childElementCount > 0;
        locationSuggestions.classList.toggle("show", visible);
        locationSuggestions.setAttribute("aria-hidden", visible ? "false" : "true");
    }

    // Load saved data from localStorage
    const savedApiKey = localStorage.getItem("weatherApiKey");
    const savedLocation = localStorage.getItem("weatherLocation");

    // Pre-fill input fields with saved data
    if (savedLocation) userLocInput.value = savedLocation;
    if (savedApiKey) userAPIInput.value = savedApiKey;

    const minMaxTempCheckbox = document.getElementById("minMaxTempCheckbox");
    const isMinMaxEnabled = localStorage.getItem("minMaxTempEnabled") === "true";
    minMaxTempCheckbox.checked = isMinMaxEnabled;

    document.getElementById("feelsLike").textContent = isMinMaxEnabled
        ? translations[currentLanguage]?.minMaxTemp || translations["en"].minMaxTemp
        : translations[currentLanguage]?.feelsLike || translations["en"].feelsLike;

    // Function to simulate button click on Enter key press
    function handleEnterPress(event, buttonId) {
        if (event.key === "Enter") {
            document.getElementById(buttonId).click();
        }
    }

    // Add event listeners for handling Enter key presses
    userAPIInput.addEventListener("keydown", (event) => handleEnterPress(event, "saveAPI"));
    userLocInput.addEventListener("keydown", (event) => handleEnterPress(event, "saveLoc"));

    // Save API key to localStorage
    saveAPIButton.addEventListener("click", () => {
        const apiKey = userAPIInput.value.trim();
        localStorage.setItem("weatherApiKey", apiKey);
        userAPIInput.value = "";
        location.reload();
    });

    // Handle GPS toggle change
    gpsToggle.addEventListener("change", async () => {
        if (gpsToggle.checked) {
            const message = translations[currentLanguage]?.GPSDisclaimer || translations["en"].GPSDisclaimer;
            const yesLabel = translations[currentLanguage]?.yesText || translations["en"].yesText || "Yes";
            const noLabel = translations[currentLanguage]?.noText || translations["en"].noText || "No";
            const confirmGPS = await confirmPrompt(message, yesLabel, noLabel);

            if (!confirmGPS) {
                gpsToggle.checked = false; // Revert toggle if user cancels
                return;
            }
            localStorage.setItem("useGPS", true);
            locationCont.classList.add("inactive");
        } else {
            localStorage.setItem("useGPS", false);
            locationCont.classList.remove("inactive");
        }
        location.reload();
    });

    // Handle manual location input
    saveLocButton.addEventListener("click", () => {
        const userLocation = userLocInput.value.trim();
        localStorage.setItem("weatherLocation", userLocation);
        localStorage.setItem("useGPS", false);
        userLocInput.value = "";
        fetchWeather();
        location.reload();
    });

    // Default Weather API key
    const weatherApiKeys = [
        "d36ce712613d4f21a6083436240910",
        "db0392b338114f208ee135134240312",
        "de5f7396db034fa2bf3140033240312",
        "c64591e716064800992140217240312",
        "9b3204c5201b4b4d8a2140330240312",
        "eb8a315c15214422b60140503240312",
        "cd148ebb1b784212b74140622240312",
        "7ae67e219af54df2840140801240312",
        "0a6bc8a404224c8d89953341241912",
        "f59e58d7735d4739ae953115241912",
        "17859d22a346495c988115334252703",
        "97cc2ef3bc4f45b3b0d120816252703",
        "51348f046e3f47ee99d120933252703",
        "ddbba7cc66044f96b43121046252703",
        "ab1b595515084775be2121201252703"
    ];
    const defaultApiKey = weatherApiKeys[Math.floor(Math.random() * weatherApiKeys.length)];

    // Determine which API key to use
    const apiKey = savedApiKey || defaultApiKey;

    let activeIndex = -1; // Track keyboard navigation index
    let suggestions = []; // Store fetched location suggestions
    let latestLocationSuggestionRequestId = 0;

    function debounce(fn, delay) {
        let timeoutId = null;
        return function (...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => fn.apply(this, args), delay);
        };
    }

    // Hide/show browser autocomplete based on suggestion state
    function toggleAutocomplete() {
        if (suggestions.length > 0) {
            userLocInput.setAttribute("autocomplete", "off");
        } else {
            userLocInput.removeAttribute("autocomplete");
        }
    }

    // Fetch location suggestions from weatherAPI
    async function fetchLocationSuggestions(query) {
        if (!savedApiKey || query.length < 3) {
            suggestions = [];
            setLocationSuggestionsVisible(false);
            toggleAutocomplete();
            return;
        }

        const requestId = ++latestLocationSuggestionRequestId;

        try {
            const response = await fetch(`https://api.weatherapi.com/v1/search.json?key=${savedApiKey}&q=${query}`);
            const nextSuggestions = await response.json();
            if (requestId !== latestLocationSuggestionRequestId || userLocInput.value !== query) return;
            suggestions = nextSuggestions;

            if (suggestions.length > 0) {
                displaySuggestions(suggestions);
                toggleAutocomplete();
            } else {
                setLocationSuggestionsVisible(false);
                toggleAutocomplete();
            }
        } catch (error) {
            console.error("Error fetching location suggestions:", error);
            suggestions = [];
            setLocationSuggestionsVisible(false);
            toggleAutocomplete();
        }
    }

    // Display location suggestions in the dropdown
    function displaySuggestions(locations) {
        locationSuggestions.textContent = "";
        const fragment = document.createDocumentFragment();

        locations.forEach((location, index) => {
            const div = document.createElement("div");
            div.classList.add("location-suggestion-item");

            // Format text without extra comma if region is empty
            const locationText = location.region
                ? `${location.name}, ${location.region}, ${location.country}`
                : `${location.name}, ${location.country}`;
            div.textContent = locationText;

            div.dataset.index = index;

            // Mouse click selects location and saves
            div.addEventListener("click", () => {
                selectLocation(index);
                setLocationSuggestionsVisible(false);
                suggestions = [];
                toggleAutocomplete();
            });

            // Mouse hover highlights
            div.addEventListener("mouseenter", () => {
                activeIndex = index;
                updateActiveSuggestion();
            });

            fragment.appendChild(div);
        });

        locationSuggestions.appendChild(fragment);

        setLocationSuggestionsVisible(true);
        activeIndex = -1; // Reset selection
    }

    // Update active suggestion highlight
    function updateActiveSuggestion() {
        const items = locationSuggestions.querySelectorAll(".location-suggestion-item");

        items.forEach((item, i) => {
            item.classList.toggle("active", i === activeIndex);
            if (i === activeIndex) {
                item.scrollIntoView({ block: "nearest" });
            }
        });
    }

    // Select location from suggestions
    function selectLocation(index) {
        const selectedLocation = suggestions[index];

        const locationText = selectedLocation.region
            ? `${selectedLocation.name}, ${selectedLocation.region}, ${selectedLocation.country}`
            : `${selectedLocation.name}, ${selectedLocation.country}`;
        userLocInput.value = locationText;

        setLocationSuggestionsVisible(false);
        localStorage.setItem("weatherLocation", JSON.stringify(selectedLocation));
        saveLocButton.click();
        suggestions = [];
        toggleAutocomplete();
    }

    // Handle user input (fetch locations on change)
    const debouncedFetchLocationSuggestions = debounce((query) => {
        fetchLocationSuggestions(query);
    }, 150);

    userLocInput.addEventListener("input", () => {
        debouncedFetchLocationSuggestions(userLocInput.value);
    });

    // Display suggestions when input is focused
    userLocInput.addEventListener("focus", () => {
        if (userLocInput.value.length >= 3) {
            fetchLocationSuggestions(userLocInput.value);
        }
    });

    // Handle keyboard navigation for suggestions
    userLocInput.addEventListener("keydown", (e) => {
        const items = locationSuggestions.querySelectorAll(".location-suggestion-item");

        if (items.length === 0) return;

        if (e.key === "ArrowDown") {
            e.preventDefault();
            activeIndex = (activeIndex + 1) % items.length;
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            activeIndex = (activeIndex - 1 + items.length) % items.length;
        } else if (e.key === "Enter" && activeIndex >= 0) {
            e.preventDefault();
            selectLocation(activeIndex);
            setLocationSuggestionsVisible(false);
            return;
        }

        updateActiveSuggestion();
    });

    // Hide suggestions when clicking outside
    document.addEventListener("click", (e) => {
        if (!locationSuggestions.contains(e.target) && !userLocInput.contains(e.target)) {
            setLocationSuggestionsVisible(false);
            suggestions = [];
            toggleAutocomplete();
        }
    });

    // Determine the location to use
    let currentUserLocation = savedLocation;

    // Load the saved GPS state from localStorage
    let useGPS = false;
    try { useGPS = JSON.parse(localStorage.getItem("useGPS")) || false; } catch (_) {}
    gpsToggle.checked = useGPS;
    if (useGPS) locationCont.classList.add("inactive");


    // Function to fetch GPS-based location
    async function fetchGPSLocation() {
        const getLocationFromGPS = () => {
            return new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        resolve({
                            latitude: position.coords.latitude,
                            longitude: position.coords.longitude,
                        });
                    },
                    (error) => reject(error),
                    { timeout: 6000 }
                );
            });
        };

        try {
            const { latitude, longitude } = await getLocationFromGPS();
            return `${latitude},${longitude}`;
        } catch (error) {
            console.error("Failed to retrieve GPS Location:", error);
        }
    }

    // Fetch location based on user preference
    await (async function initializeLocation() {
        try {
            if (useGPS) currentUserLocation = await fetchGPSLocation();

            if (!currentUserLocation) {
                // Fallback to IP-based location if no manual input
                const ipInfo = "https://ipinfo.io/json/";
                const locationData = await fetch(ipInfo);
                const ipLocation = await locationData.json();
                currentUserLocation = ipLocation.loc;
            }

            // Fetch weather data
            fetchWeather();
        } catch (error) {
            console.error("Failed to retrieve IP-based location:", error);
            currentUserLocation = "auto:ip";
            fetchWeather();
        }
    })();

    // Fetch weather data based on a location
    async function fetchWeather() {
        try {
            let parsedData = JSON.parse(localStorage.getItem("weatherParsedData"));
            const weatherParsedTime = parseInt(localStorage.getItem("weatherParsedTime"));
            const weatherParsedLocation = localStorage.getItem("weatherParsedLocation");
            const weatherParsedLang = localStorage.getItem("weatherParsedLang");

            const retentionTime = savedApiKey ? 300000 : 600000; // 5 min for user key, 10 min otherwise

            if (!parsedData ||
                ((Date.now() - weatherParsedTime) > retentionTime) ||
                (weatherParsedLocation !== currentUserLocation) ||
                (weatherParsedLang !== currentLanguage)) {

                // Language code for Weather API
                let lang = currentLanguage === "zh_TW" ? currentLanguage : currentLanguage.split("_")[0];

                // Fetch weather data using Weather API
                let weatherApi = `https://api.weatherapi.com/v1/forecast.json?key=${apiKey}&q=${currentUserLocation}&days=1&aqi=no&alerts=no&lang=${lang}`;

                let data = await fetch(weatherApi);
                parsedData = await data.json();
                if (!parsedData.error) {
                    // Extract only the necessary fields before saving
                    const filteredData = {
                        location: {
                            name: parsedData.location.name,
                            lat: parsedData.location.lat,
                            lon: parsedData.location.lon,
                        },
                        current: {
                            condition: {
                                text: parsedData.current.condition.text,
                                icon: parsedData.current.condition.icon,
                            },
                            temp_c: parsedData.current.temp_c,
                            temp_f: parsedData.current.temp_f,
                            humidity: parsedData.current.humidity,
                            feelslike_c: parsedData.current.feelslike_c,
                            feelslike_f: parsedData.current.feelslike_f,
                        },
                        forecast: {
                            forecastday: [
                                {
                                    day: {
                                        mintemp_c: parsedData.forecast.forecastday[0].day.mintemp_c,
                                        maxtemp_c: parsedData.forecast.forecastday[0].day.maxtemp_c,
                                        mintemp_f: parsedData.forecast.forecastday[0].day.mintemp_f,
                                        maxtemp_f: parsedData.forecast.forecastday[0].day.maxtemp_f
                                    }
                                }
                            ]
                        }
                    };

                    // Save filtered weather data to localStorage
                    localStorage.setItem("weatherParsedData", JSON.stringify(filteredData));
                    localStorage.setItem("weatherParsedTime", Date.now()); // Save time of last fetching
                    localStorage.setItem("weatherParsedLocation", currentUserLocation); // Save user location
                    localStorage.setItem("weatherParsedLang", currentLanguage); // Save language preference
                }
            }

            // Update weather data
            UpdateWeather();

            function UpdateWeather() {
                // Weather data
                const conditionText = parsedData.current.condition.text;
                const tempCelsius = Math.round(parsedData.current.temp_c);
                const tempFahrenheit = Math.round(parsedData.current.temp_f);
                const humidity = parsedData.current.humidity;
                const feelsLikeCelsius = parsedData.current.feelslike_c;
                const feelsLikeFahrenheit = parsedData.current.feelslike_f;

                // Update DOM elements with the weather data
                document.getElementById("conditionText").textContent = conditionText;

                // Localize and display temperature and humidity
                const localizedHumidity = localizeNumbers(humidity.toString(), currentLanguage);
                const localizedTempCelsius = localizeNumbers(tempCelsius.toString(), currentLanguage);
                const localizedFeelsLikeCelsius = localizeNumbers(feelsLikeCelsius.toString(), currentLanguage);
                const localizedTempFahrenheit = localizeNumbers(tempFahrenheit.toString(), currentLanguage);
                const localizedFeelsLikeFahrenheit = localizeNumbers(feelsLikeFahrenheit.toString(), currentLanguage);

                const minTempC = parsedData.forecast.forecastday[0].day.mintemp_c;
                const maxTempC = parsedData.forecast.forecastday[0].day.maxtemp_c;
                const minTempF = parsedData.forecast.forecastday[0].day.mintemp_f;
                const maxTempF = parsedData.forecast.forecastday[0].day.maxtemp_f;
                const localizedMinTempC = localizeNumbers(minTempC.toString(), currentLanguage);
                const localizedMaxTempC = localizeNumbers(maxTempC.toString(), currentLanguage);
                const localizedMinTempF = localizeNumbers(minTempF.toString(), currentLanguage);
                const localizedMaxTempF = localizeNumbers(maxTempF.toString(), currentLanguage);

                // Set humidity level
                const humidityLabel = translations[currentLanguage]?.humidityLevel || translations["en"].humidityLevel;
                document.getElementById("humidityLevel").textContent = isRTL
                    ? `${humidityLabel} %${localizedHumidity}` // RTL: "76% ytidimuH"
                    : `${humidityLabel} ${localizedHumidity}%`;

                // Event Listener for the Fahrenheit toggle
                const fahrenheitCheckbox = document.getElementById("fahrenheitCheckbox");
                const feelsLikeElement = document.getElementById("feelsLike");
                const updateTemperatureDisplay = () => {
                    const tempElement = document.getElementById("temp");
                    const feelsLikeLabel = translations[currentLanguage]?.feelsLike || translations["en"].feelsLike;

                    // Localized degree symbols
                    const cSymbol = translations[currentLanguage]?.celsiusSymbol || "°C";
                    const fSymbol = translations[currentLanguage]?.fahrenheitSymbol || "°F";

                    // List of languages where a space before °F or °C is required
                    const langWithSpaceBeforeDegree = ["cs"];

                    // Range separator for min-max temperature
                    const rangeSeparator = {
                        cs: "až",
                        // Add more languages as needed
                        default: "~"
                    };
                    const separator = rangeSeparator[currentLanguage] || rangeSeparator.default;

                    if (fahrenheitCheckbox.checked) {
                        // Update temperature
                        tempElement.textContent = localizedTempFahrenheit;
                        const tempUnitF = document.createElement("span");
                        tempUnitF.className = "tempUnit";
                        tempUnitF.textContent = fSymbol;
                        tempElement.appendChild(tempUnitF);

                        // Update feels like or Min-Max temp
                        const feelsLikeFUnit = langWithSpaceBeforeDegree.includes(currentLanguage) ? ` ${fSymbol}` : fSymbol;
                        if (isMinMaxEnabled) {
                            const fullTextF = `${localizedMinTempF} ${separator} ${localizedMaxTempF}${feelsLikeFUnit}`;
                            feelsLikeElement.textContent = fullTextF;
                            feelsLikeElement.dataset.tooltip = fullTextF;
                        }
                        else {
                            const fullTextF = isRTL
                                ? `${localizedFeelsLikeFahrenheit}${feelsLikeFUnit} ${feelsLikeLabel}`
                                : `${feelsLikeLabel} ${localizedFeelsLikeFahrenheit}${feelsLikeFUnit}`;
                            feelsLikeElement.textContent = fullTextF;
                            feelsLikeElement.dataset.tooltip = fullTextF;
                        }
                    } else {
                        // Update temperature
                        tempElement.textContent = localizedTempCelsius;
                        const tempUnitC = document.createElement("span");
                        tempUnitC.className = "tempUnit";
                        tempUnitC.textContent = cSymbol;
                        tempElement.appendChild(tempUnitC);

                        // Update feels like or Min-Max temp
                        const feelsLikeCUnit = langWithSpaceBeforeDegree.includes(currentLanguage) ? ` ${cSymbol}` : cSymbol;
                        if (isMinMaxEnabled) {
                            const fullTextC = `${localizedMinTempC} ${separator} ${localizedMaxTempC}${feelsLikeCUnit}`;
                            feelsLikeElement.textContent = fullTextC;
                            feelsLikeElement.dataset.tooltip = fullTextC;
                        }
                        else {
                            const fullTextC = isRTL
                                ? `${localizedFeelsLikeCelsius}${feelsLikeCUnit} ${feelsLikeLabel}`
                                : `${feelsLikeLabel} ${localizedFeelsLikeCelsius}${feelsLikeCUnit}`;
                            feelsLikeElement.textContent = fullTextC;
                            feelsLikeElement.dataset.tooltip = fullTextC;
                        }
                    }
                };
                updateTemperatureDisplay();

                function positionWeatherTooltip(tooltipEl, anchorEl) {
                    if (!tooltipEl || !anchorEl) return;
                    const anchorCard = anchorEl.closest(".tiles") || anchorEl;
                    const rect = anchorCard.getBoundingClientRect();
                    const viewportWidth = window.innerWidth || document.documentElement.clientWidth;
                    const tooltipWidth = tooltipEl.offsetWidth || 0;
                    const sidePadding = 12;
                    const maxLeft = Math.max(sidePadding, viewportWidth - tooltipWidth - sidePadding);
                    const centeredLeft = rect.left + ((rect.width - tooltipWidth) / 2);
                    const left = Math.min(Math.max(centeredLeft, sidePadding), maxLeft);

                    tooltipEl.style.top = (rect.top - 40) + "px";
                    tooltipEl.style.left = left + "px";
                }

                // ── feelsLike tooltip on hover ──────────────────────────
                const feelsLikeTooltip = document.getElementById("feelsLikeTooltip");
                if (feelsLikeTooltip && feelsLikeElement) {
                    if (feelsLikeTooltip.parentElement !== document.body) {
                        document.body.appendChild(feelsLikeTooltip);
                    }
                    feelsLikeElement.addEventListener("mouseenter", () => {
                        const text = feelsLikeElement.dataset.tooltip;
                        if (!text) return;
                        feelsLikeTooltip.textContent = text;
                        positionWeatherTooltip(feelsLikeTooltip, feelsLikeElement);
                        feelsLikeTooltip.style.opacity = "1";
                        feelsLikeTooltip.style.transform = "translateY(0)";
                    });
                    feelsLikeElement.addEventListener("mouseleave", () => {
                        feelsLikeTooltip.style.opacity = "0";
                        feelsLikeTooltip.style.transform = "translateY(4px)";
                    });
                }
                // ──────────────────────────────────────────────────────────

                // Setting weather Icon
                const newWIcon = parsedData.current.condition.icon;
                const weatherIcon = newWIcon.replace("//cdn.weatherapi.com/weather/64x64/", "https://cdn.weatherapi.com/weather/128x128/");
                const wIcon = document.getElementById("wIcon");
                wIcon.onerror = () => {
                    wIcon.src = './svgs/defaultWeather.svg';
                };
                wIcon.src = weatherIcon;

                // Define minimum width for the slider based on the language
                const humidityMinWidth = {
                    idn: "47%",
                    hu: "48%",
                    de: "51%",
                    ta: "46%",
                    en: "42%" // Default for English and others
                };
                const slider = document.getElementById("slider");
                slider.style.minWidth = humidityMinWidth[currentLanguage] || humidityMinWidth["en"];

                // Set slider width based on humidity (clamped to avoid negative or overflow)
                const humidityPercent = Math.max(0, Math.min(100, humidity));
                if (humidityPercent > 40) {
                    slider.style.width = `calc(${humidityPercent}% - 60px)`;
                } else {
                    slider.style.width = `calc(${humidityPercent}% - 20px)`;
                }

                // Update location
                let city = parsedData.location.name;
                let maxLength = 10;
                let isLocationHidden = localStorage.getItem("locationHidden") === "true";

                const locationTile = document.querySelector(".tiles.location");
                const locationIcon = locationTile.querySelector(".location-icon");
                const locationText = document.getElementById("location");
                const locationTooltip = document.getElementById("locationTooltip");

                // Fetch localized city name via Nominatim for non-Latin languages
                const nonLatinLangs = ["ar_SA", "ur", "fa", "hi", "bn", "mr", "np", "ta", "th", "zh", "zh_TW", "ja", "ko", "el", "ru", "uk"];
                if (nonLatinLangs.includes(currentLanguage) && parsedData.location.lat && parsedData.location.lon) {
                    const nominatimLang = currentLanguage === "ar_SA" ? "ar"
                        : currentLanguage === "zh_TW" ? "zh-TW"
                        : currentLanguage.split("_")[0];
                    const cacheKey = `localizedCity_${parsedData.location.lat}_${parsedData.location.lon}_${nominatimLang}`;
                    const cachedCity = localStorage.getItem(cacheKey);
                    if (cachedCity) {
                        city = cachedCity;
                    } else {
                        fetch(`https://nominatim.openstreetmap.org/reverse?lat=${parsedData.location.lat}&lon=${parsedData.location.lon}&format=json&accept-language=${nominatimLang}`)
                            .then(r => r.json())
                            .then(geo => {
                                const localName = geo?.address?.city || geo?.address?.town || geo?.address?.village || geo?.address?.county || geo?.name;
                                if (localName) {
                                    city = localName;
                                    localStorage.setItem(cacheKey, localName);
                                    updateLocationText();
                                }
                            })
                            .catch(() => {});
                    }
                }

                // Apply initial content
                function updateLocationText() {
                    if (isLocationHidden) {
                        locationText.textContent = translations[currentLanguage]?.location || translations.en.location;
                        locationIcon.src = "./svgs/location-hidden.svg";
                        locationText.removeAttribute("data-city");
                    } else {
                        const limitedText = city.length > maxLength ? city.slice(0, maxLength) + "..." : city;
                        locationText.textContent = limitedText;
                        locationIcon.src = "./svgs/location.svg";
                        if (city.length > maxLength) {
                            locationText.dataset.city = city;
                        } else {
                            locationText.removeAttribute("data-city");
                        }
                    }
                }

                // Initialize content on load
                updateLocationText();

                // Return the toggle icon (hint shown on hover)
                function getToggleIcon() {
                    return isLocationHidden ? "./svgs/location.svg" : "./svgs/location-hidden.svg";
                }

                // ── Location tooltip (shows full name when truncated) ──
                if (locationTooltip) {
                    if (locationTooltip.parentElement !== document.body) {
                        document.body.appendChild(locationTooltip);
                    }
                    locationText.addEventListener("mouseenter", () => {
                        const fullCity = locationText.dataset.city;
                        if (!fullCity) return;
                        locationTooltip.textContent = fullCity;
                        positionWeatherTooltip(locationTooltip, locationText);
                        locationTooltip.style.opacity = "1";
                        locationTooltip.style.transform = "translateY(0)";
                    });
                    locationText.addEventListener("mouseleave", () => {
                        locationTooltip.style.opacity = "0";
                        locationTooltip.style.transform = "translateY(4px)";
                    });
                }

                // ── Location toggle — guard against duplicate listeners ──
                if (!locationTile.dataset.listenersAdded) {
                    locationTile.dataset.listenersAdded = "true";

                    // Hint icon on hover
                    let hoverTimeout;
                    locationIcon.addEventListener("mouseenter", () => {
                        hoverTimeout = setTimeout(() => {
                            locationIcon.src = getToggleIcon();
                        }, 120);
                    });

                    locationIcon.addEventListener("mouseleave", () => {
                        clearTimeout(hoverTimeout);
                        // Restore correct permanent icon
                        locationIcon.src = isLocationHidden ? "./svgs/location-hidden.svg" : "./svgs/location.svg";
                    });

                    // Toggle on click
                    locationIcon.addEventListener("click", (e) => {
                        e.stopPropagation();
                        isLocationHidden = !isLocationHidden;
                        localStorage.setItem("locationHidden", isLocationHidden);
                        updateLocationText();
                        if (locationIcon.matches(":hover")) {
                            locationIcon.src = getToggleIcon();
                        }
                    });
                }
            }
        } catch (error) {
            console.error("Error fetching weather data:", error);
            // Surface the failure instead of leaving a permanent "?" placeholder
            const isAr = (window.currentLanguage || localStorage.getItem("selectedLanguage") || "en").startsWith("ar");
            const tempEl = document.getElementById("temp");
            const conditionEl = document.getElementById("conditionText");
            const hasData = tempEl && tempEl.textContent && tempEl.textContent !== "?";
            if (!hasData) {
                if (tempEl) tempEl.textContent = "–";
                if (conditionEl) conditionEl.textContent = isAr ? "تعذّر تحديث الطقس" : "Couldn't update weather";
            }
            if (typeof window.uxToast === "function") {
                window.uxToast(isAr ? "تعذّر جلب بيانات الطقس. تحقق من الاتصال أو مفتاح API." : "Couldn't fetch weather. Check your connection or API key.");
            }
        }
    }
}

// Save and load toggle state
const hideWeatherCard = document.getElementById("hideWeatherCard");
const fahrenheitCheckbox = document.getElementById("fahrenheitCheckbox");

hideWeatherCard.addEventListener("change", function () {
    saveCheckboxState("hideWeatherCardState", hideWeatherCard);
});

fahrenheitCheckbox.addEventListener("change", function () {
    saveCheckboxState("fahrenheitCheckboxState", fahrenheitCheckbox);
    location.reload();
});

loadCheckboxState("hideWeatherCardState", hideWeatherCard);
loadCheckboxState("fahrenheitCheckboxState", fahrenheitCheckbox);

// Handle min-max temp checkbox state change
minMaxTempCheckbox.addEventListener("change", () => {
    const isChecked = minMaxTempCheckbox.checked;
    localStorage.setItem("minMaxTempEnabled", isChecked);
    location.reload();
});

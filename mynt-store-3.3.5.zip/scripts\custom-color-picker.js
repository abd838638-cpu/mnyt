/*
 * Shared custom color picker UI using iro.js
 * Supports single-color themes and dual-color themes in the same floating window.
 */

document.addEventListener("DOMContentLoaded", () => {
    const colorInput = document.getElementById("colorPicker");
    const trigger = document.getElementById("rangColor");
    const popover = document.getElementById("customColorPickerPopover");
    const pickerMount = document.getElementById("iroColorPicker");
    const dualAccentMount = document.getElementById("iroDualAccentPicker");
    const dualSurfaceMount = document.getElementById("iroDualSurfacePicker");
    const closeBtn = document.getElementById("closeCustomColorPicker");
    const cancelBtn = document.getElementById("cancelCustomColorPicker");
    const applyBtn = document.getElementById("applyCustomColorPicker");
    const actionBtn = document.getElementById("pickColorEyedropper");
    const accentActionBtn = document.getElementById("accentEyedropperBtn");
    const surfaceActionBtn = document.getElementById("surfaceEyedropperBtn");
    const titleLabel = document.getElementById("customColorPickerTitle");
    const valueLabel = document.getElementById("customColorPickerValue");
    const dragBar = document.getElementById("customColorPickerDragBar");
    const dragBarLabel = dragBar ? dragBar.querySelector(".drag-label") : null;
    const singleBody = document.getElementById("customColorPickerSingleBody");
    const dualBody = document.getElementById("customColorPickerDualBody");
    const accentTitle = document.getElementById("customColorPickerAccentTitle");
    const accentValue = document.getElementById("customColorPickerAccentValue");
    const surfaceTitle = document.getElementById("customColorPickerSurfaceTitle");
    const surfaceValue = document.getElementById("customColorPickerSurfaceValue");

    if (
        !colorInput ||
        !trigger ||
        !popover ||
        !pickerMount ||
        !closeBtn ||
        !cancelBtn ||
        !applyBtn ||
        !actionBtn ||
        !accentActionBtn ||
        !surfaceActionBtn ||
        !titleLabel ||
        !valueLabel ||
        !dragBar ||
        !singleBody ||
        !dualBody ||
        !dualAccentMount ||
        !dualSurfaceMount ||
        !accentTitle ||
        !accentValue ||
        !surfaceTitle ||
        !surfaceValue
    ) {
        return;
    }

    const pickerCard = popover.querySelector(".customColorPickerCard");
    const keepColorObservers = new WeakMap();
    const keepColorButtons = [
        closeBtn,
        cancelBtn,
        applyBtn,
        actionBtn,
        accentActionBtn,
        surfaceActionBtn
    ];
    const PICKER_POSITION_KEY = "customColorPickerPosition";
    const PICKER_LABEL_TRANSLATIONS = {
        eyedropperText: {
            en: "Eyedropper",
            ar_SA: "قطارة",
            az: "Pipet",
            bn: "আইড্রপার",
            zh: "取色器",
            zh_TW: "取色器",
            cs: "Kapátko",
            de: "Pipette",
            el: "Σταγονόμετρο",
            es: "Cuentagotas",
            fa: "قطره چکان",
            fr: "Pipette",
            hi: "आईड्रॉपर",
            hu: "Pipetta",
            idn: "Pipet",
            it: "Contagocce",
            ja: "スポイト",
            ko: "스포이드",
            mr: "आयड्रॉपर",
            np: "आइड्रपर",
            pl: "Próbnik koloru",
            pt: "Conta-gotas",
            ru: "Пипетка",
            sl: "Kapalka",
            ta: "நிறத் துளையி",
            th: "ตัวดูดสี",
            tr: "Damlalık",
            uk: "Піпетка",
            ur: "آئی ڈراپر",
            uz: "Tomizgich",
            vi: "Ống nhỏ màu"
        }
    };
    const PICKER_I18N = {
        eyedropperText: {
            en: "Eyedropper",
            ar_SA: "قطارة اللون",
            az: "Damlaliq",
            bn: "আইড্রপার",
            cs: "Kapátko",
            de: "Pipette",
            el: "Σταγονόμετρο",
            es: "Cuentagotas",
            fa: "قطره‌چکان",
            fr: "Pipette",
            hi: "आईड्रॉपर",
            hu: "Pipetta",
            idn: "Pipet",
            it: "Contagocce",
            ja: "スポイト",
            ko: "스포이트",
            mr: "आयड्रॉपर",
            np: "आइड्रपर",
            pl: "Pipeta",
            pt: "Conta-gotas",
            ru: "Пипетка",
            sl: "Kapalka",
            ta: "ஐடிராப்பர்",
            th: "ที่ดูดสี",
            tr: "Damlalik",
            uk: "Піпетка",
            ur: "آئی ڈراپر",
            uz: "Pipetka",
            vi: "Ống hút màu",
            zh: "吸管",
            zh_TW: "吸管"
        }
    };

    let mode = "single";
    let isOpen = false;
    let isClosing = false;
    let closeTimer = 0;
    let dragState = null;

    let singlePicker = null;
    let singleSnapshot = null;
    let singleDraftColor = "#EA1010";
    let singleState = {
        title: "Pick color",
        onPreview: null,
        onApply: null,
        onCancel: null,
        standalone: false
    };
    let syncingFromInput = false;
    let syncingSingleProgrammatically = false;
    let singleInteractionActive = false;
    let singlePreviewRaf = 0;
    let singlePreviewQueuedColor = "";
    let singlePreviewIndicatorsCleared = false;

    let dualAccentPicker = null;
    let dualSurfacePicker = null;
    let activeDualTarget = "accent";
    let dualSyncing = false;
    let dualInteractionActive = false;
    let dualPreviewRaf = 0;
    let dualState = {
        title: "Pick colors",
        accentLabel: "Colors",
        surfaceLabel: "Backgrounds",
        accentColor: "#7B3FF2",
        surfaceColor: "#FFBFA0",
        onPreview: null,
        onApply: null,
        onCancel: null
    };

    // Global dark-mode SVG overrides should not recolor picker handles or popup action icons.
    function preservePickerSvgColors(root) {
        if (!root) {
            return;
        }

        root.querySelectorAll("svg:not(.keep-color)").forEach((svg) => {
            svg.classList.add("keep-color");
        });
    }

    function observePickerSvgColors(root) {
        if (!root) {
            return;
        }

        preservePickerSvgColors(root);

        if (typeof MutationObserver !== "function" || keepColorObservers.has(root)) {
            return;
        }

        const observer = new MutationObserver(() => {
            preservePickerSvgColors(root);
        });

        observer.observe(root, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ["class"]
        });

        keepColorObservers.set(root, observer);
    }

    keepColorButtons.forEach((button) => {
        preservePickerSvgColors(button);
    });
    observePickerSvgColors(pickerMount);
    observePickerSvgColors(dualAccentMount);
    observePickerSvgColors(dualSurfaceMount);

    if (popover.parentElement !== document.body) {
        document.body.appendChild(popover);
    }
    syncPopoverSurfaceMode();

    function getPickerAnimDur() {
        const mult = parseFloat(
            getComputedStyle(document.documentElement).getPropertyValue("--ui-anim-mult")
        ) || 1;
        return Math.round(220 * mult);
    }

    function getResolvedThemeMode() {
        const segment = document.getElementById("themeSegment");
        const domMode = segment?.dataset?.active;

        if (domMode === "dark" || domMode === "light" || domMode === "system") {
            return domMode;
        }

        return localStorage.getItem("preferredTheme") || "light";
    }

    function isDirectThemeDarkMode() {
        const body = document.body;
        const preferredTheme = getResolvedThemeMode();

        if (preferredTheme === "dark") {
            return true;
        }
        if (preferredTheme === "system") {
            return body.getAttribute("sysTheme") === "systemDark";
        }
        return false;
    }

    function isPredefinedFilterDarkMode() {
        const body = document.body;
        return (
            isDirectThemeDarkMode() &&
            body.getAttribute("data-custom-theme") !== "active" &&
            body.getAttribute("data-dual-theme") !== "active"
        );
    }

    function shouldOptOutOfPageDarkInvert() {
        return isPredefinedFilterDarkMode();
    }

    function getFilterSafePickerColor(colorValue) {
        const normalized = normalizeHex(colorValue, "#FFFFFF");

        if (!isPredefinedFilterDarkMode()) {
            return normalized;
        }

        if (shouldOptOutOfPageDarkInvert()) {
            return normalized;
        }

        if (typeof window._filterInvertHueRotate === "function") {
            return normalizeHex(window._filterInvertHueRotate(normalized), normalized);
        }

        if (typeof _filterInvertHueRotate === "function") {
            return normalizeHex(_filterInvertHueRotate(normalized), normalized);
        }

        return normalized;
    }

    function syncPopoverSurfaceMode() {
        const darkSurface = isDirectThemeDarkMode();
        const optOut = shouldOptOutOfPageDarkInvert();
        popover.dataset.surfaceMode = darkSurface ? "dark" : "light";
        popover.dataset.filterOptout = optOut ? "true" : "false";

        const pickerRoots = [pickerMount, dualAccentMount, dualSurfaceMount].filter(Boolean);
        pickerRoots.forEach((root) => {
            if (optOut) {
                root.style.filter = "none";
                root.style.webkitFilter = "none";
                root.querySelectorAll(".IroColorPicker, .IroBox, .IroSlider, .IroSliderGradient").forEach((node) => {
                    node.style.filter = "none";
                    node.style.webkitFilter = "none";
                });
                return;
            }

            root.style.removeProperty("filter");
            root.style.removeProperty("-webkit-filter");
            root.style.webkitFilter = "";
            root.querySelectorAll(".IroColorPicker, .IroBox, .IroSlider, .IroSliderGradient").forEach((node) => {
                node.style.removeProperty("filter");
                node.style.removeProperty("-webkit-filter");
                node.style.webkitFilter = "";
            });
        });

        if (optOut) {
            // Page dark mode applies `invert(1) hue-rotate(180deg)` on an ancestor.
            // To truly opt the popup out, we must apply the inverse sequence here:
            // `hue-rotate(180deg) invert(1)`. Re-applying the same order does NOT
            // cancel for saturated colors and is exactly what made the hue bar / box
            // look wrong on first open for predefined dark themes.
            popover.style.filter = "hue-rotate(180deg) invert(1)";
            popover.style.webkitFilter = "hue-rotate(180deg) invert(1)";
        } else {
            popover.style.removeProperty("filter");
            popover.style.removeProperty("-webkit-filter");
            popover.style.webkitFilter = "";
        }
    }

    function normalizeHex(value, fallback = "#EA1010") {
        const hex = String(value || "").trim();
        return /^#([0-9a-f]{6})$/i.test(hex) ? hex.toUpperCase() : fallback;
    }

    function expandHex(value) {
        const hex = String(value || "").trim();
        if (/^#([0-9a-f]{6})$/i.test(hex)) {
            return hex.toUpperCase();
        }
        const shortMatch = hex.match(/^#([0-9a-f]{3})$/i);
        if (!shortMatch) {
            return "";
        }
        const [r, g, b] = shortMatch[1].split("");
        return `#${r}${r}${g}${g}${b}${b}`.toUpperCase();
    }

    function rgbStringToHex(value) {
        const match = String(value || "").trim().match(/^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
        if (!match) {
            return "";
        }
        const [, rRaw, gRaw, bRaw] = match;
        const toHex = (channel) => Math.max(0, Math.min(255, Number(channel) || 0)).toString(16).padStart(2, "0");
        return `#${toHex(rRaw)}${toHex(gRaw)}${toHex(bRaw)}`.toUpperCase();
    }

        function hexToRgb(hex) {
        const normalized = expandHex(hex);
        if (!normalized) {
            return null;
        }

        return {
            r: parseInt(normalized.slice(1, 3), 16),
            g: parseInt(normalized.slice(3, 5), 16),
            b: parseInt(normalized.slice(5, 7), 16)
        };
    }

    function rgbToHex(rgb) {
        if (!rgb) {
            return "#000000";
        }

        const clamp = (value) => Math.max(0, Math.min(255, Math.round(Number(value) || 0)));
        return `#${[clamp(rgb.r), clamp(rgb.g), clamp(rgb.b)]
            .map((part) => part.toString(16).padStart(2, "0"))
            .join("")}`.toUpperCase();
    }

    function mixHex(colorA, colorB, amount = 0.5) {
        const a = hexToRgb(colorA);
        const b = hexToRgb(colorB);
        if (!a) {
            return normalizeHex(colorB, "#000000");
        }
        if (!b) {
            return normalizeHex(colorA, "#000000");
        }

        const t = Math.max(0, Math.min(1, Number(amount) || 0));
        return rgbToHex({
            r: a.r + (b.r - a.r) * t,
            g: a.g + (b.g - a.g) * t,
            b: a.b + (b.b - a.b) * t
        });
    }

    function shiftHex(color, amount = 0, lighten = true) {
        return mixHex(color, lighten ? "#FFFFFF" : "#000000", amount);
    }

    function isNearBlack(hex) {
        const rgb = hexToRgb(hex);
        if (!rgb) {
            return false;
        }
        return (rgb.r <= 12 && rgb.g <= 12 && rgb.b <= 12) || getPerceivedLuminance(hex) <= 0.012;
    }

    function getPerceivedLuminance(hex) {
        const rgb = hexToRgb(hex);
        if (!rgb) {
            return 0;
        }

        const normalizeChannel = (channel) => {
            const value = channel / 255;
            return value <= 0.03928 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
        };

        const r = normalizeChannel(rgb.r);
        const g = normalizeChannel(rgb.g);
        const b = normalizeChannel(rgb.b);
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }

    function setPopoverThemePalette(palette) {
        if (!popover || !palette) {
            return;
        }

        Object.entries(palette).forEach(([key, value]) => {
            popover.style.setProperty(key, value);
        });
    }
    function forceWhitePickerForeground() {
        const isDark = popover.dataset.surfaceMode === "dark";
        const baseColor = isDark ? "#FFFFFF" : "#1C1B1F";
        const foreground = getFilterSafePickerColor(baseColor);
        const mutedColor = getFilterSafePickerColor(isDark ? "#A0A0A0" : "#606060");

        // Determine if primary button background is light or dark to set appropriate text contrast
        let primaryText = "#FFFFFF";
        if (!isDark) {
            const primaryStartHex = popover.style.getPropertyValue("--picker-primary-start").trim();
            if (primaryStartHex) {
                const lum = getPerceivedLuminance(primaryStartHex);
                if (lum > 0.45) {
                    primaryText = "#1C1B1F";
                }
            } else {
                primaryText = "#1C1B1F";
            }
        }

        popover.style.setProperty("--picker-text", foreground);
        popover.style.setProperty("--picker-muted", mutedColor);
        popover.style.setProperty("--picker-secondary-text", foreground);
        popover.style.setProperty("--picker-primary-text", isDark ? "#FFFFFF" : primaryText);
        popover.style.setProperty("--picker-drag-line", foreground);

        const textNodes = [
            titleLabel,
            valueLabel,
            accentTitle,
            accentValue,
            surfaceTitle,
            surfaceValue,
            dragBarLabel
        ];

        textNodes.forEach((node) => {
            if (!node) {
                return;
            }
            node.style.color = foreground;
            node.style.fill = foreground;
        });

        [cancelBtn, applyBtn, actionBtn, accentActionBtn, surfaceActionBtn, closeBtn].forEach((button) => {
            if (!button) {
                return;
            }

            const isPrimary = button === applyBtn;
            const btnColor = isPrimary ? primaryText : foreground;

            button.style.color = btnColor;
            button.style.fill = btnColor;
            
            // Customize Done button background in dark mode to be var(--picker-primary-start) with white text for high contrast and readability
            if (isPrimary) {
                if (isDark) {
                    button.style.background = "var(--picker-primary-start)";
                    button.style.color = "#FFFFFF";
                } else {
                    button.style.background = "";
                }
            }

            button.querySelectorAll(".customColorPickerButtonLabel, svg").forEach((el) => {
                if (isPrimary && isDark) {
                    el.style.color = "#FFFFFF";
                    el.style.fill = "#FFFFFF";
                } else {
                    el.style.color = btnColor;
                    el.style.fill = btnColor;
                }
                el.style.stroke = "none";
            });
        });
    }

    function preparePaletteForCurrentFilter(palette) {
        if (!palette || !isPredefinedFilterDarkMode()) {
            return palette;
        }

        const mapped = {};
        Object.entries(palette).forEach(([key, value]) => {
            mapped[key] = getFilterSafePickerColor(value);
        });
        return mapped;
    }

    function buildSinglePopoverPalette(colorValue) {
        const seedColor = (singleState && singleState.standalone) ? getCurrentThemeSeedColor() : colorValue;
        const accent = normalizeHex(seedColor, getCurrentThemeSeedColor());
        const darkMode = popover.dataset.surfaceMode === "dark";
        const surface = darkMode
            ? mixHex(accent, "#081018", 0.78)
            : mixHex(accent, "#F8FBFF", 0.78);
        const surfaceStrong = darkMode
            ? mixHex(surface, "#02060C", 0.28)
            : mixHex(surface, "#FFFFFF", 0.42);
        const border = darkMode
            ? mixHex(accent, "#FFFFFF", 0.18)
            : mixHex(accent, "#DCEBFF", 0.34);
        const text = darkMode ? "#FFFFFF" : "#1C1B1F";

        return preparePaletteForCurrentFilter({
            "--picker-card-bg-top": darkMode ? shiftHex(surfaceStrong, 0.08, true) : shiftHex(surfaceStrong, 0.12, true),
            "--picker-card-bg-bottom": darkMode ? mixHex(surface, "#010409", 0.22) : mixHex(surface, "#DDEBFF", 0.22),
            "--picker-card-border": border,
            "--picker-text": text,
            "--picker-muted": mixHex("#FFFFFF", accent, darkMode ? 0.18 : 0.24),
            "--picker-shell-bg": darkMode ? mixHex(surface, "#0A1320", 0.34) : mixHex(surface, "#EDF5FF", 0.35),
            "--picker-shell-border": darkMode ? mixHex(border, "#FFFFFF", 0.1) : mixHex(border, "#FFFFFF", 0.35),
            "--picker-pane-bg": darkMode ? mixHex(surfaceStrong, accent, 0.08) : mixHex(surfaceStrong, accent, 0.14),
            "--picker-pane-border": border,
            "--picker-secondary-bg": darkMode ? mixHex(surfaceStrong, accent, 0.12) : mixHex(surfaceStrong, accent, 0.22),
            "--picker-secondary-bg-hover": darkMode ? mixHex(surfaceStrong, accent, 0.2) : mixHex(surfaceStrong, accent, 0.32),
            "--picker-secondary-text": "#FFFFFF",
            "--picker-primary-start": darkMode ? mixHex(accent, "#000000", 0.25) : shiftHex(accent, 0.08, true),
            "--picker-primary-end": darkMode ? mixHex(accent, "#0A1420", 0.35) : mixHex(accent, "#0E2A4A", 0.14),
            "--picker-primary-text": "#FFFFFF",
            "--picker-drag-bg": darkMode ? mixHex(surfaceStrong, accent, 0.1) : mixHex(surfaceStrong, accent, 0.18),
            "--picker-drag-bg-hover": darkMode ? mixHex(surfaceStrong, accent, 0.18) : mixHex(surfaceStrong, accent, 0.28),
            "--picker-drag-line": mixHex("#FFFFFF", accent, darkMode ? 0.14 : 0.18)
        });
    }

    function buildDualPopoverPalette(accentColor, surfaceColor) {
        const accent = normalizeHex(accentColor, dualState.accentColor);
        const surfaceSeed = normalizeHex(surfaceColor, dualState.surfaceColor);
        const darkMode = popover.dataset.surfaceMode === "dark";
        
        // Single and dual color pickers now derive their background from the accent color so they look identical
        const surface = darkMode
            ? mixHex(accent, "#081018", 0.78)
            : mixHex(accent, "#F8FBFF", 0.78);
        const surfaceStrong = darkMode
            ? mixHex(surface, "#02060C", 0.28)
            : mixHex(surface, "#FFFFFF", 0.42);
        const border = darkMode
            ? mixHex(accent, "#FFFFFF", 0.18)
            : mixHex(accent, "#DCEBFF", 0.34);
        const text = darkMode ? "#FFFFFF" : "#1C1B1F";

        return preparePaletteForCurrentFilter({
            "--picker-card-bg-top": darkMode ? shiftHex(surfaceStrong, 0.08, true) : shiftHex(surfaceStrong, 0.12, true),
            "--picker-card-bg-bottom": darkMode ? mixHex(surface, "#010409", 0.22) : mixHex(surface, "#DDEBFF", 0.22),
            "--picker-card-border": border,
            "--picker-text": text,
            "--picker-muted": mixHex("#FFFFFF", accent, darkMode ? 0.18 : 0.24),
            "--picker-shell-bg": darkMode ? mixHex(surface, "#0A1320", 0.34) : mixHex(surface, "#EDF5FF", 0.35),
            "--picker-shell-border": darkMode ? mixHex(border, "#FFFFFF", 0.1) : mixHex(border, "#FFFFFF", 0.35),
            "--picker-pane-bg": darkMode ? mixHex(surfaceStrong, accent, 0.08) : mixHex(surfaceStrong, accent, 0.14),
            "--picker-pane-border": border,
            "--picker-secondary-bg": darkMode ? mixHex(surfaceStrong, accent, 0.12) : mixHex(surfaceStrong, accent, 0.22),
            "--picker-secondary-bg-hover": darkMode ? mixHex(surfaceStrong, accent, 0.2) : mixHex(surfaceStrong, accent, 0.32),
            "--picker-secondary-text": "#FFFFFF",
            "--picker-primary-start": darkMode ? mixHex(accent, "#000000", 0.25) : shiftHex(accent, 0.08, true),
            "--picker-primary-end": darkMode ? mixHex(accent, "#0A1420", 0.35) : mixHex(accent, "#0E2A4A", 0.14),
            "--picker-primary-text": "#FFFFFF",
            "--picker-drag-bg": darkMode ? mixHex(surfaceStrong, accent, 0.1) : mixHex(surfaceStrong, accent, 0.18),
            "--picker-drag-bg-hover": darkMode ? mixHex(surfaceStrong, accent, 0.18) : mixHex(surfaceStrong, accent, 0.28),
            "--picker-drag-line": mixHex("#FFFFFF", accent, darkMode ? 0.14 : 0.18)
        });
    }

    function applyPopoverPaletteFromState() {
        if (mode === "dual") {
            setPopoverThemePalette(buildDualPopoverPalette(dualState.accentColor, dualState.surfaceColor));
            return;
        }

        setPopoverThemePalette(buildSinglePopoverPalette(singleDraftColor || colorInput.value || getCurrentThemeSeedColor()));
    }
    function resolveCssColorToHex(value, fallback = "#EA1010") {
        const expandedHex = expandHex(value);
        if (expandedHex) {
            return expandedHex;
        }

        const root = document.documentElement;
        const probe = document.createElement("span");
        probe.style.position = "absolute";
        probe.style.opacity = "0";
        probe.style.pointerEvents = "none";
        probe.style.color = String(value || "").trim();
        root.appendChild(probe);
        const resolved = getComputedStyle(probe).color;
        probe.remove();

        return rgbStringToHex(resolved) || normalizeHex(value, fallback);
    }

    function hasActiveDualTheme() {
        return document.body.getAttribute("data-dual-theme") === "active" || !!localStorage.getItem("dualColorTheme");
    }

    function getStoredSingleThemeColor() {
        const stored = expandHex(localStorage.getItem("customThemeColor"));
        return stored || "";
    }

    function getSelectedPredefinedThemeSeedColor() {
        const selectedTheme = String(localStorage.getItem("selectedTheme") || "").trim();
        if (!selectedTheme) {
            return "";
        }

        const themePrefix = selectedTheme === "dark" ? "dark" : selectedTheme;
        const rawThemeAccent = resolveCssColorToHex(
            getComputedStyle(document.documentElement).getPropertyValue(`--darkColor-${themePrefix}`).trim(),
            ""
        );
        if (rawThemeAccent) {
            return getFilterSafePickerColor(rawThemeAccent);
        }

        const selectedPlate = document.querySelector(`.colorPlate[value="${selectedTheme === "violet" ? "olive" : selectedTheme}"]`);
        if (!selectedPlate) {
            return "";
        }

        const selectedPlateColor = getComputedStyle(selectedPlate).backgroundColor;
        const selectedPlateHex = rgbStringToHex(selectedPlateColor) || "";
        return selectedPlateHex ? getFilterSafePickerColor(selectedPlateHex) : "";
    }

    function getCurrentThemeSeedColor() {
        const storedCustom = getStoredSingleThemeColor();
        if (storedCustom && !hasActiveDualTheme()) {
            return storedCustom;
        }

        if (document.body.getAttribute("data-custom-theme") === "active") {
            const currentInput = expandHex(colorInput.value);
            if (currentInput) {
                return currentInput;
            }
        }

        const selectedPredefined = getSelectedPredefinedThemeSeedColor();
        if (selectedPredefined) {
            return selectedPredefined;
        }

        const accent = getComputedStyle(document.documentElement).getPropertyValue("--darkColor-blue").trim();
        const resolvedAccent = resolveCssColorToHex(accent, normalizeHex(colorInput.value));

        if (isPredefinedFilterDarkMode()) {
            if (typeof window._filterInvertHueRotate === "function") {
                return normalizeHex(window._filterInvertHueRotate(resolvedAccent), resolvedAccent);
            }

            if (typeof _filterInvertHueRotate === "function") {
                return normalizeHex(_filterInvertHueRotate(resolvedAccent), resolvedAccent);
            }
        }

        return resolvedAccent;
    }

     function syncSingleColorToCurrentTheme() {
        const currentHex = getCurrentThemeSeedColor();
        colorInput.value = currentHex;
        singleDraftColor = currentHex;
        updateSingleVisuals(currentHex);

        if (
            singlePicker &&
            !syncingSingleProgrammatically &&
            singlePicker.color.hexString.toUpperCase() !== currentHex
        ) {
            syncingSingleProgrammatically = true;
            singlePicker.color.set(currentHex);
            syncingSingleProgrammatically = false;
        }
    }

    function getCurrentDualThemeColors() {
        try {
            const stored = JSON.parse(localStorage.getItem("dualColorTheme") || "null");
            if (stored && stored.c1 && stored.c2) {
                return {
                    accentColor: normalizeHex(stored.c1),
                    surfaceColor: normalizeHex(stored.c2)
                };
            }
        } catch (e) {}
        return null;
    }

    function syncDualColorsToCurrentTheme() {
        const stored = getCurrentDualThemeColors();
        const accent = stored ? stored.accentColor : resolveCssColorToHex(getComputedStyle(document.documentElement).getPropertyValue("--darkColor-blue").trim(), dualState.accentColor);
        const surface = stored ? stored.surfaceColor : resolveCssColorToHex(getComputedStyle(document.documentElement).getPropertyValue("--bg-color-blue").trim(), dualState.surfaceColor);

        dualState.accentColor = accent;
        dualState.surfaceColor = surface;

        if (dualAccentPicker && !dualInteractionActive) {
            dualSyncing = true;
            dualAccentPicker.color.set(accent);
            dualSyncing = false;
        }
        if (dualSurfacePicker && !dualInteractionActive) {
            dualSyncing = true;
            dualSurfacePicker.color.set(surface);
            dualSyncing = false;
        }
        updateDualVisuals();
    }

    function getPickerLanguage() {
        return document.documentElement.lang || localStorage.getItem("selectedLanguage") || "en";
    }

    function getPickerTranslation(key, fallback = "") {
        const lang = getPickerLanguage();
        if (typeof translations !== "undefined") {
            const translated = translations[lang]?.[key] || translations.en?.[key];
            if (translated) {
                return translated;
            }
        }
        if (PICKER_LABEL_TRANSLATIONS[key]) {
            return PICKER_LABEL_TRANSLATIONS[key][lang] || PICKER_LABEL_TRANSLATIONS[key].en || fallback;
        }
        return fallback;
    }

    function cleanDoneLabel(text) {
        return String(text || "").replace(/^[\s✓✔☑️✅]+/u, "").trim() || "Done";
    }

    function setButtonLabel(button, text) {
        const label = button.querySelector(".customColorPickerButtonLabel");
        if (label) {
            label.textContent = text;
        } else {
            button.textContent = text;
        }
        button.setAttribute("aria-label", text);
        button.setAttribute("title", text);
    }

    function setTooltipLabel(button, text) {
        button.setAttribute("aria-label", text);
        button.setAttribute("title", text);
        button.dataset.tooltip = text;
    }

    function applyPickerTranslations() {
        const cancelText = getPickerTranslation("cancelText", "Cancel");
        const doneText = cleanDoneLabel(getPickerTranslation("leDone", "Done"));
        const eyedropperText = getPickerTranslation("eyedropperText", "Eyedropper");
        const dragText = getPickerTranslation("leDragLabel", "drag");
        const dragTitle = getPickerTranslation(
            "dragToMoveTitle",
            getPickerTranslation("dragToMove", "Drag to move")
        );

        setButtonLabel(cancelBtn, cancelText);
        setButtonLabel(actionBtn, eyedropperText);
        setButtonLabel(applyBtn, doneText);
        setTooltipLabel(actionBtn, eyedropperText);
        setTooltipLabel(accentActionBtn, eyedropperText);
        setTooltipLabel(surfaceActionBtn, eyedropperText);
        if (dragBarLabel) {
            dragBarLabel.textContent = dragText;
        }
        dragBar.setAttribute("title", dragTitle);
        dragBar.setAttribute("aria-label", dragTitle);
        forceWhitePickerForeground();
    }

    function setStoredValue(key, value) {
        if (value == null || value === "") {
            localStorage.removeItem(key);
            return;
        }
        localStorage.setItem(key, value);
    }

    function captureSingleSnapshot() {
        return {
            colorInputValue: normalizeHex(colorInput.value),
            customThemeColor: localStorage.getItem("customThemeColor"),
            safePresetTheme: localStorage.getItem("safePresetTheme"),
            selectedTheme: localStorage.getItem("selectedTheme"),
            dualColorTheme: localStorage.getItem("dualColorTheme"),
            dualColorSwapped: localStorage.getItem("dualColorSwapped"),
            customThemeSwapped: localStorage.getItem("customThemeSwapped")
        };
    }

    function clearDualPreviewVisualState() {
        if (document.body.getAttribute("data-dual-theme") === "active") {
            document.body.removeAttribute("data-dual-theme");
        }

        document.querySelectorAll(".colorPlate-grad").forEach((button) => {
            button.classList.remove("grad-active");
        });

        const dualSwapBtn = document.getElementById("dualSwapBtn");
        if (dualSwapBtn) {
            dualSwapBtn.style.display = "none";
            dualSwapBtn.classList.remove("dualSwapActive");
        }

        const dualTriggerBtn = document.getElementById("dualColorTriggerBtn");
        if (dualTriggerBtn) {
            dualTriggerBtn.classList.remove("dualActive");
        }
    }

    function beginSinglePreviewInteraction() {
        window._colorPickerDragging = true;
        window._pickerChangingTheme = true;
        clearTimeout(window._pickerChangingThemeTimer);
        singlePreviewIndicatorsCleared = false;
        document.documentElement.classList.add("no-theme-transition");
    }

    function endSinglePreviewInteraction() {
        singleInteractionActive = false;
        window._colorPickerDragging = false;
        clearTimeout(window._pickerChangingThemeTimer);
        window._pickerChangingThemeTimer = setTimeout(() => {
            window._pickerChangingTheme = false;
        }, 320);
        requestAnimationFrame(() => {
            document.documentElement.classList.remove("no-theme-transition");
            document.dispatchEvent(new CustomEvent("theme-colors-changed"));
            if (typeof changeFaviconColor === "function") {
                changeFaviconColor();
            }
        });
    }

    function beginDualPreviewInteraction() {
        window._colorPickerDragging = true;
        window._pickerChangingTheme = true;
        clearTimeout(window._pickerChangingThemeTimer);
        document.documentElement.classList.add("no-theme-transition");
    }

    function endDualPreviewInteraction() {
        dualInteractionActive = false;
        window._colorPickerDragging = false;
        clearTimeout(window._pickerChangingThemeTimer);
        window._pickerChangingThemeTimer = setTimeout(() => {
            window._pickerChangingTheme = false;
        }, 320);
        requestAnimationFrame(() => {
            document.documentElement.classList.remove("no-theme-transition");
            document.dispatchEvent(new CustomEvent("theme-colors-changed"));
            if (typeof changeFaviconColor === "function") {
                changeFaviconColor();
            }
        });
    }

    function previewSingleTheme(colorValue, options = {}) {
        const hex = normalizeHex(colorValue);
        const livePreview = singleInteractionActive && !options.commit;
        singleDraftColor = hex;
        if (singleState.standalone) {
            updateSingleVisuals(hex);
            if (typeof singleState.onPreview === "function") {
                singleState.onPreview(hex);
            }
            return;
        }
        colorInput.value = hex;

        if (typeof applyCustomTheme === "function") {
            const shouldRefreshPickerChrome = !singlePreviewIndicatorsCleared || !livePreview;
            if (!singlePreviewIndicatorsCleared) {
                clearDualPreviewVisualState();
                if (typeof window.clearPresetThemeIndicators === "function") {
                    window.clearPresetThemeIndicators();
                } else {
                    document.querySelectorAll(".colorPlate").forEach((radio) => {
                        radio.checked = false;
                    });
                }
                singlePreviewIndicatorsCleared = true;
            }
            const previousCommitOnly = window._colorPickerCommitOnly;
            window._colorPickerCommitOnly = !livePreview;
            applyCustomTheme(hex);
            window._colorPickerCommitOnly = previousCommitOnly;
            updateSingleVisuals(hex);
            if (shouldRefreshPickerChrome) {
                syncPopoverSurfaceMode();
                forceWhitePickerForeground();
            }
            return;
        }

        updateSingleVisuals(hex);
        if (!livePreview) {
            setInputColor(hex, "live");
        }
    }

    function queueSinglePreview(colorValue) {
        singleDraftColor = normalizeHex(colorValue);
        singlePreviewQueuedColor = singleDraftColor;

        if (singlePreviewRaf) {
            return;
        }

        singlePreviewRaf = requestAnimationFrame(() => {
            const hex = singlePreviewQueuedColor;
            singlePreviewRaf = 0;
            singlePreviewQueuedColor = "";
            previewSingleTheme(hex, { commit: false });
        });
    }

    function commitSingleTheme(colorValue) {
        const hex = normalizeHex(colorValue);
        singleDraftColor = hex;
        colorInput.value = hex;

        setStoredValue("customThemeColor", hex);
        setStoredValue("safePresetTheme", null);
        setStoredValue("selectedTheme", null);
        setStoredValue("dualColorTheme", null);
        setStoredValue("dualColorSwapped", null);
        setStoredValue("customThemeSwapped", null);

        clearDualPreviewVisualState();
        if (typeof window.clearPresetThemeIndicators === "function") {
            window.clearPresetThemeIndicators();
        } else {
            document.querySelectorAll(".colorPlate").forEach((radio) => {
                radio.checked = false;
            });
        }

        const previousCommitOnly = window._colorPickerCommitOnly;
        window._colorPickerCommitOnly = true;
        window._pickerChangingTheme = true;
        clearTimeout(window._pickerChangingThemeTimer);
        window._pickerChangingThemeTimer = setTimeout(() => {
            window._pickerChangingTheme = false;
        }, 320);
        try {
            if (typeof applyCustomTheme === "function") {
                applyCustomTheme(hex);
            }
        } finally {
            window._colorPickerCommitOnly = previousCommitOnly;
        }

        updateSingleVisuals(hex);
        syncPopoverSurfaceMode();
        forceWhitePickerForeground();

        if (typeof addSavedColor === "function") {
            addSavedColor(hex);
        }
        if (typeof renderSavedColors === "function") {
            renderSavedColors();
        }
    }

    function restoreSingleSnapshot() {
        if (!singleSnapshot) {
            return;
        }

        setStoredValue("customThemeColor", singleSnapshot.customThemeColor);
        setStoredValue("safePresetTheme", singleSnapshot.safePresetTheme);
        setStoredValue("selectedTheme", singleSnapshot.selectedTheme);
        setStoredValue("dualColorTheme", singleSnapshot.dualColorTheme);
        setStoredValue("dualColorSwapped", singleSnapshot.dualColorSwapped);
        setStoredValue("customThemeSwapped", singleSnapshot.customThemeSwapped);

        colorInput.value = singleSnapshot.colorInputValue;
        singleDraftColor = singleSnapshot.colorInputValue;
        updateSingleVisuals(singleDraftColor);

        if (singleSnapshot.dualColorTheme && window.dualColorTheme && typeof window.dualColorTheme.loadStoredDualColor === "function") {
            window.dualColorTheme.loadStoredDualColor();
        } else if (singleSnapshot.safePresetTheme && typeof applySafePresetTheme === "function") {
            applySafePresetTheme(singleSnapshot.safePresetTheme);
            document.querySelectorAll(".colorPlate").forEach((radio) => {
                radio.checked = radio.value === (singleSnapshot.safePresetTheme === "violet" ? "olive" : singleSnapshot.safePresetTheme);
            });
        } else if (singleSnapshot.customThemeColor && typeof applyCustomTheme === "function") {
            applyCustomTheme(singleSnapshot.customThemeColor);
        } else if (singleSnapshot.selectedTheme && typeof applyPredefinedThemeNow === "function") {
            applyPredefinedThemeNow(singleSnapshot.selectedTheme);
        }

        if (typeof renderSavedColors === "function") {
            renderSavedColors();
        }
    }

    function clampPopoverPosition(left, top) {
        const cardWidth = popover.offsetWidth || 360;
        const cardHeight = popover.offsetHeight || pickerCard?.offsetHeight || 520;
        const edgePadding = 0;
        const maxLeft = Math.max(edgePadding, window.innerWidth - cardWidth - edgePadding);
        const maxTop = Math.max(edgePadding, window.innerHeight - cardHeight - edgePadding);

        return {
            left: Math.max(edgePadding, Math.min(maxLeft, Math.round(left))),
            top: Math.max(edgePadding, Math.min(maxTop, Math.round(top)))
        };
    }

    function applyPopoverPosition(left, top) {
        const pos = clampPopoverPosition(left, top);
        popover.style.left = `${pos.left}px`;
        popover.style.top = `${pos.top}px`;
        popover.style.transform = "none";
    }

    function savePopoverPosition() {
        const left = parseFloat(popover.style.left);
        const top = parseFloat(popover.style.top);
        if (!Number.isFinite(left) || !Number.isFinite(top)) {
            return;
        }
        localStorage.setItem(PICKER_POSITION_KEY, JSON.stringify({ left, top }));
    }

    function restorePopoverPosition() {
        try {
            const raw = localStorage.getItem(PICKER_POSITION_KEY);
            if (!raw) return false;
            const pos = JSON.parse(raw);
            if (!pos || !Number.isFinite(pos.left) || !Number.isFinite(pos.top)) {
                return false;
            }
            applyPopoverPosition(pos.left, pos.top);
            return true;
        } catch (error) {
            return false;
        }
    }

    function centerPopover() {
        popover.style.left = "50%";
        popover.style.top = "50%";
        popover.style.transform = "translate(-50%, -50%)";
    }

    function openWindow() {
        if (closeTimer) {
            clearTimeout(closeTimer);
            closeTimer = 0;
        }
        syncPopoverSurfaceMode();
        
        const alreadyOpen = isOpen && !isClosing;
        isClosing = false;

        if (!alreadyOpen) {
            popover.classList.remove("is-closing");
            popover.classList.remove("is-open");
            popover.style.display = "block";
            if (!restorePopoverPosition()) {
                centerPopover();
            }
        }

        applyPickerTranslations();

        if (mode === "single") {
            const currentHex = normalizeHex(singleDraftColor || colorInput.value || getCurrentThemeSeedColor());
            ensureSinglePicker(currentHex, isPredefinedFilterDarkMode());
            if (singlePicker) {
                syncingSingleProgrammatically = true;
                if (singlePicker.color.hexString.toUpperCase() !== currentHex) {
                    singlePicker.color.set(currentHex);
                }
                syncingSingleProgrammatically = false;
            }
        }

        applyPopoverPaletteFromState();
        window._customColorPickerOpen = true;
        isOpen = true;
        
        if (!alreadyOpen) {
            requestAnimationFrame(() => {
                popover.classList.add("is-open");
                refreshPopoverThemeState({
                    syncSingle: mode === "single" && !singleInteractionActive
                });
                requestAnimationFrame(() => {
                    refreshPopoverThemeState({
                        syncSingle: mode === "single" && !singleInteractionActive
                    });
                });
            });
        } else {
            refreshPopoverThemeState({
                syncSingle: mode === "single" && !singleInteractionActive
            });
        }
    }

    function queueDualPreview() {
        if (dualPreviewRaf || typeof dualState.onPreview !== "function") {
            return;
        }

        dualPreviewRaf = requestAnimationFrame(() => {
            dualPreviewRaf = 0;
            
            accentValue.value = dualState.accentColor;
            surfaceValue.value = dualState.surfaceColor;
            applyPopoverPaletteFromState();

            dualState.onPreview({
                accentColor: dualState.accentColor,
                surfaceColor: dualState.surfaceColor
            });
        });
    }

    function updateSingleVisuals(colorValue) {
        const hex = normalizeHex(colorValue);
        valueLabel.value = hex;
        applyPopoverPaletteFromState();
    }

    function updateDualVisuals() {
        accentTitle.textContent = dualState.accentLabel;
        surfaceTitle.textContent = dualState.surfaceLabel;
        accentValue.value = dualState.accentColor;
        surfaceValue.value = dualState.surfaceColor;
        applyPopoverPaletteFromState();
    }

    function setMode(nextMode) {
        mode = nextMode === "dual" ? "dual" : "single";
        popover.dataset.mode = mode;

        if (mode === "dual") {
            titleLabel.textContent = getPickerTranslation("dualColorTriggerTitle", dualState.title || "Pick two colors");
            valueLabel.hidden = true;
            singleBody.hidden = true;
            dualBody.hidden = false;
            cancelBtn.hidden = false;
            actionBtn.hidden = true;
            accentActionBtn.hidden = !window.EyeDropper;
            surfaceActionBtn.hidden = !window.EyeDropper;
            updateDualVisuals();
            applyPickerTranslations();
        } else {
            titleLabel.textContent = singleState.title || getPickerTranslation("rangColor", "Pick color");
            valueLabel.hidden = false;
            singleBody.hidden = false;
            dualBody.hidden = true;
            cancelBtn.hidden = false;
            actionBtn.hidden = !window.EyeDropper;
            accentActionBtn.hidden = true;
            surfaceActionBtn.hidden = true;
            updateSingleVisuals(singleDraftColor || colorInput.value);
            applyPickerTranslations();
        }
    }

    window.addEventListener("material-you-language-change", () => {
        applyPickerTranslations();
        if (mode === "dual") {
            titleLabel.textContent = getPickerTranslation("dualColorTriggerTitle", dualState.title || "Pick two colors");
        } else {
            titleLabel.textContent = singleState.title || getPickerTranslation("rangColor", "Pick color");
        }
    });

    function setInputColor(colorValue, emitChangeType) {
        const hex = normalizeHex(colorValue);
        colorInput.value = hex;
        updateSingleVisuals(hex);

        syncingFromInput = true;
        colorInput.dispatchEvent(new Event("input", { bubbles: true }));
        if (emitChangeType === "commit") {
            colorInput.dispatchEvent(new Event("change", { bubbles: true }));
        }
        syncingFromInput = false;
    }

    function buildPicker(target, initialColor) {
        return new iro.ColorPicker(target, {
            width: 300,
            color: normalizeHex(initialColor),
            borderWidth: 0,
            borderColor: "transparent",
            padding: 0,
            sliderMargin: 14,
            layout: [
                {
                    component: iro.ui.Box,
                    options: { sliderType: "saturation" }
                },
                {
                    component: iro.ui.Slider,
                    options: { sliderType: "hue" }
                }
            ]
        });
    }

    function ensureSinglePicker(initialColor = colorInput.value, forceRebuild = false) {
        if (!window.iro || !pickerMount) {
            return;
        }

        if (singlePicker && !forceRebuild) {
            return;
        }

        pickerMount.innerHTML = "";
        singlePicker = buildPicker(pickerMount, initialColor);

        singlePicker.on("input:start", () => {
            singleInteractionActive = true;
            beginSinglePreviewInteraction();
        });

        singlePicker.on("color:change", (color) => {
            const hex = color.hexString.toUpperCase();
            if (singleInteractionActive && !syncingFromInput && !syncingSingleProgrammatically) {
                queueSinglePreview(hex);
            }
        });

        singlePicker.on("input:end", (color) => {
            const hex = color.hexString.toUpperCase();
            if (singlePreviewRaf) {
                cancelAnimationFrame(singlePreviewRaf);
                singlePreviewRaf = 0;
                singlePreviewQueuedColor = "";
            }
            previewSingleTheme(hex, { commit: false });
            endSinglePreviewInteraction();
        });
    }

    function ensureDualPickers() {
        if ((!dualAccentPicker && dualAccentMount) || (!dualSurfacePicker && dualSurfaceMount)) {
            if (!window.iro) {
                return;
            }
        }

        if (!dualAccentPicker) {
            dualAccentPicker = buildPicker(dualAccentMount, dualState.accentColor);
            dualAccentMount.addEventListener("pointerdown", () => {
                activeDualTarget = "accent";
            });

            dualAccentPicker.on("input:start", () => {
                activeDualTarget = "accent";
                dualInteractionActive = true;
                beginDualPreviewInteraction();
            });

            dualAccentPicker.on("color:change", (color) => {
                dualState.accentColor = color.hexString.toUpperCase();
                updateDualVisuals();
                if (!dualSyncing && dualInteractionActive) {
                    queueDualPreview();
                }
            });

            dualAccentPicker.on("input:end", (color) => {
                dualState.accentColor = color.hexString.toUpperCase();
                updateDualVisuals();
                if (dualPreviewRaf) {
                    cancelAnimationFrame(dualPreviewRaf);
                    dualPreviewRaf = 0;
                }
                if (!dualSyncing && typeof dualState.onPreview === "function") {
                    dualState.onPreview({
                        accentColor: dualState.accentColor,
                        surfaceColor: dualState.surfaceColor
                    });
                }
                endDualPreviewInteraction();
            });
        }

        if (!dualSurfacePicker) {
            dualSurfacePicker = buildPicker(dualSurfaceMount, dualState.surfaceColor);
            dualSurfaceMount.addEventListener("pointerdown", () => {
                activeDualTarget = "surface";
            });

            dualSurfacePicker.on("input:start", () => {
                activeDualTarget = "surface";
                dualInteractionActive = true;
                beginDualPreviewInteraction();
            });

            dualSurfacePicker.on("color:change", (color) => {
                dualState.surfaceColor = color.hexString.toUpperCase();
                updateDualVisuals();
                if (!dualSyncing && dualInteractionActive) {
                    queueDualPreview();
                }
            });

            dualSurfacePicker.on("input:end", (color) => {
                dualState.surfaceColor = color.hexString.toUpperCase();
                updateDualVisuals();
                if (dualPreviewRaf) {
                    cancelAnimationFrame(dualPreviewRaf);
                    dualPreviewRaf = 0;
                }
                if (!dualSyncing && typeof dualState.onPreview === "function") {
                    dualState.onPreview({
                        accentColor: dualState.accentColor,
                        surfaceColor: dualState.surfaceColor
                    });
                }
                endDualPreviewInteraction();
            });
        }
    }

    function syncDualPickers() {
        if (!dualAccentPicker || !dualSurfacePicker) {
            return;
        }

        dualSyncing = true;
        dualAccentPicker.color.set(dualState.accentColor);
        dualSurfacePicker.color.set(dualState.surfaceColor);
        dualSyncing = false;
        updateDualVisuals();
    }

    function openSinglePopover(options = {}) {
        const standalone = !!(
            options &&
            (typeof options.onApply === "function" ||
             typeof options.onPreview === "function" ||
             typeof options.onCancel === "function" ||
             options.title ||
             options.color)
        );
        const currentHex = standalone
            ? normalizeHex(options.color, "#FFFFFF")
            : getCurrentThemeSeedColor();
        singleState = {
            title: options.title || "Pick color",
            onPreview: typeof options.onPreview === "function" ? options.onPreview : null,
            onApply: typeof options.onApply === "function" ? options.onApply : null,
            onCancel: typeof options.onCancel === "function" ? options.onCancel : null,
            standalone
        };
        colorInput.value = currentHex;
        singleDraftColor = currentHex;

        if (!window.iro) {
            colorInput.click();
            return;
        }

        setMode("single");
        singleSnapshot = standalone ? null : captureSingleSnapshot();
        updateSingleVisuals(singleDraftColor);
        openWindow();
    }

    function openDualPopover(options = {}) {
        dualState = {
            title: options.title || "Pick colors",
            accentLabel: options.accentLabel || "Colors",
            surfaceLabel: options.surfaceLabel || "Backgrounds",
            accentColor: normalizeHex(options.accentColor, "#7B3FF2"),
            surfaceColor: normalizeHex(options.surfaceColor, "#FFBFA0"),
            onPreview: typeof options.onPreview === "function" ? options.onPreview : null,
            onApply: typeof options.onApply === "function" ? options.onApply : null,
            onCancel: typeof options.onCancel === "function" ? options.onCancel : null
        };

        setMode("dual");
        activeDualTarget = "accent";
        openWindow();
        ensureDualPickers();
        syncDualPickers();
    }

    function closePopover(options = {}) {
        if ((!isOpen && !isClosing) || isClosing) return;

        const reason = options.reason || "dismiss";
        const afterClose = typeof options.afterClose === "function" ? options.afterClose : null;
        const closingMode = mode;
        const cancelDualFn = closingMode === "dual" && reason !== "apply" && typeof dualState.onCancel === "function"
            ? dualState.onCancel
            : null;
        const appliedSingleFn = closingMode === "single" && reason === "apply" && singleState.standalone && typeof singleState.onApply === "function"
            ? singleState.onApply
            : null;
        const appliedSingleColor = singleDraftColor;
        const cancelSingleFn = closingMode === "single" && singleState.standalone && reason !== "apply" && typeof singleState.onCancel === "function"
            ? singleState.onCancel
            : null;
        const shouldRestoreSingle = closingMode === "single" && reason !== "apply";

        if (dualPreviewRaf) {
            cancelAnimationFrame(dualPreviewRaf);
            dualPreviewRaf = 0;
        }

        if (singlePreviewRaf) {
            cancelAnimationFrame(singlePreviewRaf);
            singlePreviewRaf = 0;
            singlePreviewQueuedColor = "";
        }

        finishDrag();

        if (closingMode === "single") {
            endSinglePreviewInteraction();
        }

        isClosing = true;
        isOpen = false;
        popover.classList.remove("is-open");
        popover.classList.add("is-closing");
        window._customColorPickerOpen = false;

        if (closeTimer) {
            clearTimeout(closeTimer);
        }

        closeTimer = setTimeout(() => {
            closeTimer = 0;
            if (!isOpen) {
                popover.style.display = "none";
                popover.classList.remove("is-closing");
                isClosing = false;

                if (shouldRestoreSingle && !singleState.standalone) {
                    restoreSingleSnapshot();
                }

                if (typeof cancelDualFn === "function") {
                    cancelDualFn();
                }

                if (typeof cancelSingleFn === "function") {
                    cancelSingleFn();
                }

                if (closingMode === "single") {
                    singleSnapshot = null;
                    singleState = {
                        title: "Pick color",
                        onPreview: null,
                        onApply: null,
                        onCancel: null,
                        standalone: false
                    };
                    singleDraftColor = "";
                }

                if (typeof appliedSingleFn === "function") {
                    appliedSingleFn(appliedSingleColor);
                }

                if (afterClose) {
                    afterClose();
                }
            }
        }, getPickerAnimDur() + 40);
    }

    async function openSystemEyedropper(targetOverride = null) {
        if (!window.EyeDropper) {
            return;
        }

        try {
            const eyeDropper = new EyeDropper();
            window._colorPickerCommitOnly = false;
            document.documentElement.classList.remove("no-theme-transition");

            const result = await eyeDropper.open();
            const hex = normalizeHex(result?.sRGBHex);

            if (mode === "dual") {
                const dualTarget = targetOverride || activeDualTarget;
                activeDualTarget = dualTarget;
                beginDualPreviewInteraction();
                dualSyncing = true;
                if (dualTarget === "surface") {
                    dualState.surfaceColor = hex;
                    if (dualSurfacePicker) {
                        dualSurfacePicker.color.set(hex);
                    }
                } else {
                    dualState.accentColor = hex;
                    if (dualAccentPicker) {
                        dualAccentPicker.color.set(hex);
                    }
                }
                dualSyncing = false;
                updateDualVisuals();
                if (typeof dualState.onPreview === "function") {
                    dualState.onPreview({
                        accentColor: dualState.accentColor,
                        surfaceColor: dualState.surfaceColor
                    });
                }
                endDualPreviewInteraction();
                return;
            }

            if (singlePicker) {
                syncingSingleProgrammatically = true;
                singlePicker.color.set(hex);
                syncingSingleProgrammatically = false;
            }

            beginSinglePreviewInteraction();
            previewSingleTheme(hex, { commit: false });
            endSinglePreviewInteraction();
        } catch (error) {
            window._colorPickerCommitOnly = false;
            if (mode === "single") {
                endSinglePreviewInteraction();
            }
        }
    }

    trigger.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        openSinglePopover();
    });

    closeBtn.addEventListener("click", (event) => {
        event.stopPropagation();
        closePopover({ reason: "dismiss" });
    });

    cancelBtn.addEventListener("click", (event) => {
        event.stopPropagation();
        closePopover({ reason: "cancel" });
    });

    applyBtn.addEventListener("click", (event) => {
        event.stopPropagation();

        if (mode === "dual") {
            const payload = {
                accentColor: dualState.accentColor,
                surfaceColor: dualState.surfaceColor
            };
            closePopover({
                reason: "apply",
                afterClose: () => {
                    if (typeof dualState.onApply === "function") {
                        dualState.onApply(payload);
                    }
                }
            });
            return;
        }

        const draftColor = singleDraftColor;
        const shouldCommitBuiltInSingle = !singleState.standalone;
        closePopover({
            reason: "apply",
            afterClose: () => {
                if (!shouldCommitBuiltInSingle) return;
                commitSingleTheme(draftColor);
            }
        });
    });

    actionBtn.addEventListener("click", (event) => {
        event.stopPropagation();
        openSystemEyedropper();
    });

    accentActionBtn.addEventListener("click", (event) => {
        event.stopPropagation();
        activeDualTarget = "accent";
        openSystemEyedropper("accent");
    });

    surfaceActionBtn.addEventListener("click", (event) => {
        event.stopPropagation();
        activeDualTarget = "surface";
        openSystemEyedropper("surface");
    });

    dragBar.addEventListener("pointerdown", (event) => {
        if (event.pointerType === "mouse" && event.button !== 0) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();

        const rect = popover.getBoundingClientRect();
        applyPopoverPosition(rect.left, rect.top);

        dragState = {
            pointerId: event.pointerId,
            startX: event.clientX,
            startY: event.clientY,
            startLeft: rect.left,
            startTop: rect.top
        };

        dragBar.setPointerCapture?.(event.pointerId);
        dragBar.classList.add("is-engaged");
    });

    dragBar.addEventListener("pointermove", (event) => {
        if (!dragState || dragState.pointerId !== event.pointerId) {
            return;
        }

        const nextLeft = dragState.startLeft + (event.clientX - dragState.startX);
        const nextTop = dragState.startTop + (event.clientY - dragState.startY);
        applyPopoverPosition(nextLeft, nextTop);
    });

    function finishDrag(event) {
        if (!dragState) {
            return;
        }

        if (event?.pointerId != null && dragState.pointerId !== event.pointerId) {
            return;
        }

        savePopoverPosition();
        dragState = null;
        dragBar.classList.remove("is-engaged");
        if (event?.pointerId != null) {
            dragBar.releasePointerCapture?.(event.pointerId);
        }
    }

    dragBar.addEventListener("pointerup", finishDrag);
    dragBar.addEventListener("pointercancel", finishDrag);

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && isOpen) {
            closePopover({ reason: "dismiss" });
        }
    });

    window.addEventListener("resize", () => {
        if (!isOpen) {
            return;
        }

        if (popover.style.transform === "none") {
            savePopoverPosition();
            restorePopoverPosition();
        } else {
            centerPopover();
        }
    });

    colorInput.addEventListener("input", () => {
        if (mode !== "single") {
            return;
        }

        const hex = normalizeHex(colorInput.value);
        updateSingleVisuals(hex);

        if (
            singlePicker &&
            !syncingFromInput &&
            !syncingSingleProgrammatically &&
            !singleInteractionActive &&
            singlePicker.color.hexString.toUpperCase() !== hex
        ) {
            syncingSingleProgrammatically = true;
            singlePicker.color.set(hex);
            syncingSingleProgrammatically = false;
        }
    });

    function refreshPopoverThemeState() {
        syncPopoverSurfaceMode();

        if (isOpen) {
            if (window._pickerChangingTheme) {
                applyPopoverPaletteFromState();
            } else if (mode === "single" && !singleState.standalone && !singleInteractionActive) {
                syncSingleColorToCurrentTheme();
            } else if (mode === "dual" && !dualInteractionActive) {
                syncDualColorsToCurrentTheme();
            } else {
                applyPopoverPaletteFromState();
            }
            forceWhitePickerForeground();
        }
    }

    function observeImmediateThemeMutations() {
        if (typeof MutationObserver !== "function") {
            return;
        }

        const roots = [
            document.documentElement,
            document.body,
            document.getElementById("themeSegment")
        ].filter(Boolean);

        const observer = new MutationObserver(() => {
            refreshPopoverThemeState();
        });

        roots.forEach((root) => {
            observer.observe(root, {
                attributes: true,
                subtree: false,
                attributeFilter: root === document.documentElement
                    ? ["data-pref"]
                    : root === document.body
                    ? ["class", "sysTheme", "data-custom-theme", "data-dual-theme", "data-bg"]
                    : ["data-active"]
            });
        });
    }

    document.addEventListener("theme-colors-changed", () => {
        refreshPopoverThemeState();
    });

    observeImmediateThemeMutations();
    syncPopoverSurfaceMode();
    syncSingleColorToCurrentTheme();
    setMode("single");

    window.customColorPickerModal = {
        openSingle: openSinglePopover,
        openDual: openDualPopover,
        close: (options) => closePopover(options || { reason: "dismiss" }),
        isOpen: () => isOpen,
        getMode: () => mode,
        getTitle: () => singleState.title,
        isStandalone: () => singleState.standalone,
        swapDualColors: () => {
            if (mode !== "dual" || !isOpen) return;
            const temp = dualState.accentColor;
            dualState.accentColor = dualState.surfaceColor;
            dualState.surfaceColor = temp;
            syncDualPickers();
        },
        syncSingleColor: () => {
            if (mode !== "single" || !isOpen) return;
            syncSingleColorToCurrentTheme();
        }
    };

    function handleHexInput(inputEl, updateFn) {
        function validateAndTrigger(val, isLive) {
            if (!val.startsWith("#")) {
                val = "#" + val;
            }
            if (/^#[0-9A-F]{6}$/i.test(val)) {
                updateFn(val.toUpperCase());
            } else if (!isLive) {
                inputEl.value = inputEl.dataset.prevVal || "#FFFFFF";
                const msg = (currentLanguage === "ar_SA" || currentLanguage === "ar") ? "اللون غير صحيح" : "Invalid Color";
                if (typeof bmShowToast === "function") {
                    bmShowToast(msg, "delete");
                }
            }
        }
        inputEl.addEventListener("input", () => {
            let val = inputEl.value.trim();
            if (val.length === 6 || val.length === 7) {
                validateAndTrigger(val, true);
            }
        });
        inputEl.addEventListener("change", () => {
            let val = inputEl.value.trim();
            validateAndTrigger(val, false);
        });
        inputEl.addEventListener("focus", () => {
            inputEl.dataset.prevVal = inputEl.value;
        });
    }

    handleHexInput(valueLabel, (hex) => {
        singleDraftColor = hex;
        updateSingleVisuals(hex);
        if (singlePicker) {
            syncingSingleProgrammatically = true;
            singlePicker.color.set(hex);
            syncingSingleProgrammatically = false;
        }
        if (!singleState.standalone) {
            previewSingleTheme(hex, { commit: false });
        }
    });

    handleHexInput(accentValue, (hex) => {
        dualState.accentColor = hex;
        updateDualVisuals();
        if (dualAccentPicker) {
            dualSyncing = true;
            dualAccentPicker.color.set(hex);
            dualSyncing = false;
        }
        if (typeof dualState.onPreview === "function") {
            dualState.onPreview({
                accentColor: dualState.accentColor,
                surfaceColor: dualState.surfaceColor
            });
        }
    });

    handleHexInput(surfaceValue, (hex) => {
        dualState.surfaceColor = hex;
        updateDualVisuals();
        if (dualSurfacePicker) {
            dualSyncing = true;
            dualSurfacePicker.color.set(hex);
            dualSyncing = false;
        }
        if (typeof dualState.onPreview === "function") {
            dualState.onPreview({
                accentColor: dualState.accentColor,
                surfaceColor: dualState.surfaceColor
            });
        }
    });
});

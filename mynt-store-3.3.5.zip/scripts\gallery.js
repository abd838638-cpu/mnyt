(function () {
    var PICSUM_LIST = "https://picsum.photos/v2/list?page=";
    var PICSUM_DOWNLOAD = "https://picsum.photos/id/";
    var PAGE_SIZE = 30;
    var currentPage = 1;
    var isLoading = false;
    var hasMore = true;

    var modal = document.getElementById("galleryModal");
    var grid = document.getElementById("galleryGrid");
    var loader = document.getElementById("galleryLoader");
    var loadMoreBtn = document.getElementById("galleryLoadMore");
    var closeBtn = document.getElementById("galleryClose");
    var trigger = document.getElementById("galleryTrigger");
    var titleEl = document.getElementById("galleryTitle");

    if (!modal || !trigger) return;

    function getText(key) {
        var lang = localStorage.getItem("selectedLanguage") || "en";
        if (typeof translations !== "undefined") {
            return translations[lang]?.[key] || translations["en"]?.[key] || key;
        }
        return key;
    }

    function applyTexts() {
        if (titleEl) titleEl.textContent = getText("galleryTitle");
        if (loadMoreBtn) loadMoreBtn.textContent = getText("galleryLoadMore");
        if (trigger) trigger.title = getText("galleryTrigger");
    }

    // ── Open / Close ──
    function openGallery() {
        modal.style.display = "flex";
        document.body.style.overflow = "hidden";
        applyTexts();
        if (grid.children.length <= 1) {
            loadImages();
        }
    }

    function closeGallery() {
        modal.style.display = "none";
        document.body.style.overflow = "";
    }

    trigger.addEventListener("click", openGallery);
    closeBtn.addEventListener("click", closeGallery);
    modal.addEventListener("click", function (e) {
        if (e.target === modal) closeGallery();
    });
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && modal.style.display === "flex") closeGallery();
    });

    // ── Load images from Picsum ──
    function loadImages(search) {
        if (isLoading) return;
        isLoading = true;
        loader.style.display = "block";
        loader.textContent = getText("galleryLoading");
        loadMoreBtn.style.display = "none";

        var url;
        if (search) {
            url = PICSUM_LIST + "1&limit=" + PAGE_SIZE;
        } else {
            url = PICSUM_LIST + currentPage + "&limit=" + PAGE_SIZE;
        }

        fetch(url)
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (!data || !data.length) {
                    hasMore = false;
                    loader.textContent = getText("galleryNoMore");
                    isLoading = false;
                    return;
                }
                renderImages(data);
                currentPage++;
                hasMore = data.length === PAGE_SIZE;
                loader.style.display = "none";
                if (hasMore) loadMoreBtn.style.display = "block";
                isLoading = false;
            })
            .catch(function () {
                loader.textContent = getText("galleryError");
                isLoading = false;
            });
    }

    function renderImages(images) {
        if (grid.children.length === 1 && grid.children[0].id === "galleryLoader") {
            grid.innerHTML = "";
        }

    images.forEach(function (img) {
        var item = document.createElement("div");
        item.className = "gallery-item";
        item.dataset.id = img.id;

        var imgEl = document.createElement("img");
        imgEl.src = "https://picsum.photos/id/" + img.id + "/400/300";
        imgEl.loading = "lazy";
        imgEl.decoding = "async";
        imgEl.width = 400;
        imgEl.height = 300;
        imgEl.alt = img.author || "Wallpaper";

        var overlay = document.createElement("div");
        overlay.className = "gallery-item-overlay";
        overlay.textContent = getText("galleryUseAs");

        var author = document.createElement("span");
        author.className = "gallery-item-author";
        author.textContent = img.author || "";

        item.appendChild(imgEl);
        item.appendChild(overlay);
        item.appendChild(author);

        grid.appendChild(item);
    });

    // Single delegated click listener on the grid
    if (!grid._delegated) {
        grid.addEventListener("click", function (e) {
            var item = e.target.closest(".gallery-item");
            if (item && item.dataset.id) {
                setWallpaperFromGallery(item.dataset.id);
            }
        });
        grid._delegated = true;
    }
    }

    // ── Set wallpaper from gallery ──
    function setWallpaperFromGallery(id) {
        var downloadUrl = PICSUM_DOWNLOAD + id + "/1920/1080";

        var items = grid.querySelectorAll(".gallery-item");
        items.forEach(function (el) { el.style.opacity = "0.5"; });
        loader.style.display = "block";
        loader.textContent = getText("galleryApplying");

        fetch(downloadUrl)
            .then(function (r) {
                if (!r.ok) throw new Error("Failed to download");
                return r.blob();
            })
            .then(function (blob) {
                return saveWallpaperBlob(blob);
            })
            .then(function () {
                loader.textContent = getText("galleryDone");
                setTimeout(closeGallery, 600);
            })
            .catch(function () {
                loader.textContent = getText("galleryFailed");
                items.forEach(function (el) { el.style.opacity = "1"; });
                isLoading = false;
            });
    }

    function saveWallpaperBlob(blob) {
        return new Promise(function (resolve, reject) {
            if (typeof saveImageToIndexedDB === "function" && typeof setBodyBgImage === "function") {
                var reader = new FileReader();
                reader.onload = function () {
                    var dataUrl = reader.result;
                    setBodyBgImage(dataUrl);
                    saveImageToIndexedDB(blob, new Date().toISOString(), "upload").then(resolve).catch(reject);
                    localStorage.setItem("hasSingleWallpaper", "true");
                    if (typeof clearFolderWallpapers === "function") {
                        clearFolderWallpapers();
                    }
                };
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            } else {
                reject(new Error("Wallpaper functions not available"));
            }
        });
    }

    // ── Load More ──
    loadMoreBtn.addEventListener("click", function () {
        loadImages();
    });

    // Listen for language changes
    window.addEventListener("material-you-language-change", applyTexts);

    // Initial text
    applyTexts();
})();

/*
 * Material You NewTab
 * Copyright (c) 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

// --------------------------------- Proxy ---------------------------------
let proxyurl;
document.addEventListener("DOMContentLoaded", () => {
    const userProxyInput = document.getElementById("userproxy");
    const saveProxyButton = document.getElementById("saveproxy");
    const savedProxy = localStorage.getItem("proxy");

    const defaultProxyURL = "https://mynt-proxy.rhythmcorehq.com/proxy?url="; //Default proxy url

    if (savedProxy && savedProxy !== defaultProxyURL) {
        userProxyInput.value = savedProxy;
    }

    // Allow pressing Enter to save the proxy
    userProxyInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            saveProxyButton.click();
        }
    });

    // Save the proxy to localStorage
    saveProxyButton.addEventListener("click", () => {
        proxyurl = userProxyInput.value.trim();

        // If the input is empty, use the default proxy.
        if (proxyurl === "") {
            proxyurl = defaultProxyURL;
        } else {
            // Validate if input starts with "http://" or "https://"
            if (!(proxyurl.startsWith("http://") || proxyurl.startsWith("https://"))) {
                proxyurl = "https://" + proxyurl;
            }
        }
        // Set the proxy in localStorage, clear the input, and reload the page
        localStorage.setItem("proxy", proxyurl);
        userProxyInput.value = "";
        location.reload();
    });

    // Determine which proxy URL to use
    proxyurl = savedProxy || defaultProxyURL;
});

// ---------------------------- Search Suggestions ----------------------------

let lastInteractionBy = null;
let originalSearchText = ""; // Store the original search text
const resultBox = document.getElementById("resultBox");
const searchWrapper = document.getElementById("searchWrapper");
const searchSuggestionsCheckbox = document.getElementById("searchsuggestionscheckbox");
const searchShortcutDropdown = document.querySelector(".dropdown-content");
let latestSuggestionRequestId = 0;

function debounce(fn, delay) {
    let timeoutId = null;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => fn.apply(this, args), delay);
    };
}

function syncSearchOverlayState() {
    const hasVisibleResults = resultBox.classList.contains("show") && resultBox.childElementCount > 0;
    const dropdownOpen = searchShortcutDropdown?.classList.contains("show") || false;

    searchWrapper?.classList.toggle("search-results-open", hasVisibleResults);
    searchWrapper?.classList.toggle("search-dropdown-open", dropdownOpen);
    document.body.classList.toggle("search-overlay-open", hasVisibleResults || dropdownOpen);
}

function clearResultBox() {
    resultBox.textContent = "";
    syncSearchOverlayState();
}

// Show the result box
function showResultBox() {
    if (!resultBox.childElementCount) return;
    resultBox.classList.add("show");
    syncSearchOverlayState();
}

// Hide the result box
function hideResultBox() {
    resultBox.classList.remove("show");
    syncSearchOverlayState();
}

window.syncSearchOverlayState = syncSearchOverlayState;
window.hideSearchResultBox = () => {
    hideResultBox();
    clearResultBox();
};

function renderSuggestions(suggestions) {
    resultBox.textContent = "";
    const fragment = document.createDocumentFragment();

    suggestions.forEach((suggestion, index) => {
        const resultItem = document.createElement("div");
        resultItem.className = "resultItem";
        resultItem.textContent = suggestion;
        resultItem.dataset.index = index;
        fragment.appendChild(resultItem);
    });

    resultBox.appendChild(fragment);
    syncSearchOverlayState();
}

const handleSearchInput = debounce(async function (event) {
    if (!searchSuggestionsCheckbox?.checked) {
        hideResultBox();
        clearResultBox();
        return;
    }

    const query = searchInput.value;
    originalSearchText = query;

    if (!query.length) {
        hideResultBox();
        clearResultBox();
        return;
    }

    const requestId = ++latestSuggestionRequestId;

    try {
        const suggestions = await getAutocompleteSuggestions(query);
        if (requestId !== latestSuggestionRequestId || this.value !== query) return;

        if (!Array.isArray(suggestions) || suggestions.length === 0) {
            hideResultBox();
            clearResultBox();
            return;
        }

        renderSuggestions(suggestions);

        if (searchShortcutDropdown?.classList.contains("show")) {
            if (typeof window.setSearchDropdownOpen === "function") {
                window.setSearchDropdownOpen(false);
            } else {
                searchShortcutDropdown.classList.remove("show");
                syncSearchOverlayState();
            }
        }

        showResultBox();
    } catch (error) {
        if (requestId === latestSuggestionRequestId) {
            hideResultBox();
            clearResultBox();
        }
    }
}, 120);

searchInput.addEventListener("input", handleSearchInput);

resultBox.addEventListener("click", (event) => {
    const resultItem = event.target.closest(".resultItem");
    if (!resultItem) return;
    performSearch(resultItem.textContent);
});

resultBox.addEventListener("mouseover", (event) => {
    const resultItem = event.target.closest(".resultItem");
    if (!resultItem || !resultBox.contains(resultItem)) return;

    const currentlyActive = resultBox.querySelector(".active");
    if (currentlyActive && currentlyActive !== resultItem) {
        currentlyActive.classList.remove("active");
    }

    resultItem.classList.add("active");
    lastInteractionBy = "mouse";
});

searchInput.addEventListener("keydown", function (e) {
    const activeItem = resultBox.querySelector(".active");
    let currentIndex = activeItem ? parseInt(activeItem.getAttribute("data-index")) : -1;

    if (resultBox.children.length > 0 && resultBox.classList.contains("show")) {
        if (e.key === "ArrowDown" || e.key === "ArrowUp") {
            e.preventDefault();
            lastInteractionBy = "keyboard";

            if (activeItem) {
                activeItem.classList.remove("active");
            }

            // Calculate new index based on direction
            if (e.key === "ArrowDown") {
                currentIndex = (currentIndex + 1) % resultBox.children.length;
            } else { // ArrowUp
                currentIndex = (currentIndex - 1 + resultBox.children.length) % resultBox.children.length;
            }

            resultBox.children[currentIndex].classList.add("active");

            // Ensure the active item is visible within the result box
            const activeElement = resultBox.children[currentIndex];
            activeElement.scrollIntoView({ block: "nearest" });

            // Auto-complete the search input with selected suggestion
            const suggestionText = activeElement.textContent;
            this.value = suggestionText;

        } else if ((e.key === "ArrowRight" || e.key === "Tab") && activeItem && lastInteractionBy === "mouse") {
            // Check if cursor is at end
            const cursorAtEnd = this.selectionStart === this.value.length;

            if (cursorAtEnd) {
                e.preventDefault();
                const suggestionText = activeItem.textContent;
                this.value = suggestionText;
            }

        } else if (e.key === "Enter") {
            e.preventDefault();
            if (activeItem) {
                // Selected suggestion + Enter = search
                activeItem.click();

            } else {
                // No selection, search with current input value
                performSearch(this.value);
            }

        } else if (e.key === "Escape") {
            e.preventDefault();
            // Restore original search text
            this.value = originalSearchText;
            // Remove any active highlights
            if (activeItem) {
                activeItem.classList.remove("active");
            }
            // Close the suggestions dropdown (matches browser search-box behavior)
            hideResultBox();
        }
    } else if (e.key === "Enter") {
        // No suggestions available, search with current input
        e.preventDefault();
        performSearch(this.value);
    }
});

// Check for different browsers and return the corresponding client parameter
function getClientParam() {
    if (isFirefox) return "firefox";
    if (isOpera) return "opera";
    if (isChromiumBased) return "chrome";
    if (isSafari) return "safari";
    return "firefox"; // Default to Firefox if the browser is not recognized
}

let lastRedditRequestTime = 0;

async function getAutocompleteSuggestions(query) {
    const clientParam = getClientParam(); // Get the browser client parameter dynamically
    const selectedOption = document.querySelector('input[name="search-engine"]:checked')?.value || "engine1";

    // 🔒 Throttle Reddit API calls
    const now = Date.now();
    if (selectedOption === "engine7") {
        if (now - lastRedditRequestTime < 1000) {
            return []; // skip call if within 1 second
        }
        lastRedditRequestTime = now;
    }

    const searchSuggestionsAPI = {
        engine0: `https://duckduckgo.com/ac/?q=${encodeURIComponent(query)}&type=list`,
        engine1: `https://www.google.com/complete/search?client=${clientParam}&q=${encodeURIComponent(query)}`,
        engine2: `https://duckduckgo.com/ac/?q=${encodeURIComponent(query)}&type=list`,
        engine4: `https://search.brave.com/api/suggest?q=${encodeURIComponent(query)}&rich=true&source=web`,
        engine5: `https://www.google.com/complete/search?client=${clientParam}&ds=yt&q=${encodeURIComponent(query)}`,
        engine7: `https://www.reddit.com/search.json?q=${encodeURIComponent(query)}&sort=relevance&limit=15`,
        engine8: `https://${languageCode}.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(query)}&format=json`
    };

    const useproxyCheckbox = document.getElementById("useproxyCheckbox");
    let apiUrl = searchSuggestionsAPI[selectedOption] || searchSuggestionsAPI["engine1"];
    if (useproxyCheckbox.checked && selectedOption !== "engine7") {
        apiUrl = proxyurl + encodeURIComponent(apiUrl);
    }

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (selectedOption === "engine4") {
            const suggestions = data[1].map(item => {
                if (item.is_entity) {
                    return `${item.q} - ${item.name} (${item.category ? item.category : "No category"})`;
                } else {
                    return item.q;
                }
            });
            return suggestions;

        } else if (selectedOption === "engine7") {
            const suggestions = [];
            if (data && data.data && data.data.children) {
                data.data.children.forEach(post => {
                    if (post.data && post.data.title) {
                        const subreddit = post.data.subreddit_name_prefixed;
                        suggestions.push(`${post.data.title} (${subreddit})`);
                    }
                });
            }
            return suggestions;

        } else {
            return data[1];
        }
    } catch (error) {
        console.error("Error fetching autocomplete suggestions:", error);
        return [];
    }
}

// Hide results when clicking outside
document.addEventListener("click", function (event) {
    if (!searchbar.contains(event.target)) {
        hideResultBox();
    }
});

// ------------------------- Toggles --------------------------
document.addEventListener("DOMContentLoaded", function () {
    const searchsuggestionscheckbox = document.getElementById("searchsuggestionscheckbox");
    const proxybypassField = document.getElementById("proxybypassField");
    const proxyinputField = document.getElementById("proxyField");
    const useproxyCheckbox = document.getElementById("useproxyCheckbox");

    // This function shows the proxy disclaimer.
    async function showProxyDisclaimer() {
        const message = translations[currentLanguage]?.ProxyDisclaimer || translations["en"].ProxyDisclaimer;
        return await confirmPrompt(message, agreeText, cancelText);
    }

    // Requests optional host permissions for suggestion APIs
    async function requestHostPermissions() {
        return new Promise((resolve) => {
            try {
                if (typeof chrome === "undefined" || !chrome.permissions || !chrome.permissions.request) {
                    resolve(false);
                    return;
                }
                chrome.permissions.request({
                origins: [
                    "https://www.google.com/*",
                    "https://duckduckgo.com/*",
                    "https://search.brave.com/*",
                    "https://*.wikipedia.org/*"
                ]
            }, (granted) => {
                resolve(granted);
            });
            } catch (_) {
                resolve(false);
            }
        });
    }

    // Add change event listeners for the checkboxes
    searchsuggestionscheckbox.addEventListener("change", async function () {
        saveCheckboxState("searchsuggestionscheckboxState", searchsuggestionscheckbox);
        if (searchsuggestionscheckbox.checked) {
            proxybypassField.classList.remove("inactive");
            saveActiveStatus("proxybypassField", "active");

            if (!isFirefoxAll) {
                await requestHostPermissions();
            }
        } else {
            proxybypassField.classList.add("inactive");
            saveActiveStatus("proxybypassField", "inactive");
            useproxyCheckbox.checked = false;
            saveCheckboxState("useproxyCheckboxState", useproxyCheckbox);
            proxyinputField.classList.add("inactive");
            saveActiveStatus("proxyinputField", "inactive");
        }
    });

    useproxyCheckbox.addEventListener("change", async function () {
        if (useproxyCheckbox.checked) {
            // Show the disclaimer and check the user's choice
            const userConfirmed = await showProxyDisclaimer();
            if (userConfirmed) {
                // Only enable the proxy if the user confirmed
                saveCheckboxState("useproxyCheckboxState", useproxyCheckbox);
                proxyinputField.classList.remove("inactive");
                saveActiveStatus("proxyinputField", "active");
            } else {
                // Revert the checkbox state if the user did not confirm
                useproxyCheckbox.checked = false;
            }
        } else {
            // If the checkbox is unchecked, disable the proxy
            saveCheckboxState("useproxyCheckboxState", useproxyCheckbox);
            proxyinputField.classList.add("inactive");
            saveActiveStatus("proxyinputField", "inactive");
        }
    });

    // Load and apply the saved checkbox states and display statuses
    loadCheckboxState("searchsuggestionscheckboxState", searchsuggestionscheckbox);
    loadCheckboxState("useproxyCheckboxState", useproxyCheckbox);
    loadActiveStatus("proxyinputField", proxyinputField);
    loadActiveStatus("proxybypassField", proxybypassField);
});

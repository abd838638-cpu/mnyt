// Shared color utility functions

function clamp01(value) {
    return Math.max(0, Math.min(1, Number(value) || 0));
}

function mixNumber(start, end, amount) {
    return start + (end - start) * clamp01(amount);
}

function smoothStep(edge0, edge1, value) {
    if (edge0 === edge1) {
        return value >= edge1 ? 1 : 0;
    }
    const t = clamp01((value - edge0) / (edge1 - edge0));
    return t * t * (3 - 2 * t);
}

function getSimpleLuminance(hex) {
    const normalized = String(hex || "").replace("#", "");
    const safeHex = normalized.length === 3
        ? normalized.split("").map((char) => char + char).join("")
        : normalized.padEnd(6, "0").slice(0, 6);
    const r = parseInt(safeHex.substring(0, 2), 16) / 255;
    const g = parseInt(safeHex.substring(2, 4), 16) / 255;
    const b = parseInt(safeHex.substring(4, 6), 16) / 255;
    return clamp01(0.2126 * r + 0.7152 * g + 0.0722 * b);
}

function adjustHexColor(hex, factor, isLighten) {
    if (isLighten === undefined) isLighten = true;
    hex = hex.replace("#", "");
    if (hex.length === 3) {
        hex = hex.split("").map(c => c + c).join("");
    }
    let r = parseInt(hex.substring(0, 2), 16);
    let g = parseInt(hex.substring(2, 4), 16);
    let b = parseInt(hex.substring(4, 6), 16);
    if (isLighten) {
        r = Math.min(255, Math.floor(r + (255 - r) * factor));
        g = Math.min(255, Math.floor(g + (255 - g) * factor));
        b = Math.min(255, Math.floor(b + (255 - b) * factor));
    } else {
        r = Math.max(0, Math.floor(r * (1 - factor)));
        g = Math.max(0, Math.floor(g * (1 - factor)));
        b = Math.max(0, Math.floor(b * (1 - factor)));
    }
    return "#" + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1).toUpperCase();
}

function shiftHexToLuminance(hex, targetLuminance) {
    const sourceHex = String(hex || "#000000").trim() || "#000000";
    const sourceLum = getSimpleLuminance(sourceHex);
    const targetLum = clamp01(targetLuminance);

    if (Math.abs(targetLum - sourceLum) < 0.0005) {
        return adjustHexColor(sourceHex, 0, true);
    }

    if (targetLum > sourceLum) {
        const remaining = 1 - sourceLum;
        const factor = remaining <= 0.0005 ? 0 : clamp01((targetLum - sourceLum) / remaining);
        return adjustHexColor(sourceHex, factor, true);
    }

    const factor = sourceLum <= 0.0005 ? 0 : clamp01((sourceLum - targetLum) / sourceLum);
    return adjustHexColor(sourceHex, factor, false);
}

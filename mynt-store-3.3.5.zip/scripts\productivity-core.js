/*
 * Material You New Tab
 * Copyright (c) 2024-2026 Prem, 2023-2025 XengShi
 * Licensed under the GNU General Public License v3.0 (GPL-3.0)
 */
(function (root) {
    "use strict";
    const durations = [5, 15, 25, 50];
    function normalizeSession(value, now = Date.now()) {
        const s = value && typeof value === "object" ? value : {};
        const minutes = durations.includes(s.minutes) ? s.minutes : 25;
        const duration = minutes * 60;
        const status = ["idle", "running", "paused", "complete"].includes(s.status) ? s.status : "idle";
        return {
            minutes,
            status: status === "running" && !Number.isFinite(s.endsAt) ? "paused" : status,
            remaining: Number.isFinite(s.remaining) ? Math.max(0, Math.min(duration, s.remaining)) : duration,
            endsAt: Number.isFinite(s.endsAt) ? Math.min(s.endsAt, now + duration * 1000) : 0,
            intention: typeof s.intention === "string" ? s.intention.slice(0, 120) : "",
            id: typeof s.id === "string" ? s.id : "",
        };
    }
    function remainingSeconds(session, now = Date.now()) {
        return session.status === "running"
            ? Math.max(0, Math.ceil((session.endsAt - now) / 1000))
            : Math.ceil(session.remaining);
    }
    function formatTime(seconds) {
        const value = Math.max(0, Math.ceil(seconds));
        return `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
    }
    function localDay(timestamp = Date.now()) {
        const date = new Date(timestamp);
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    }
    function normalizeQuery(value) {
        return String(value || "").toLocaleLowerCase().normalize("NFKD")
            .replace(/[\u0300-\u036f\u064b-\u065f\u0670]/g, "").replace(/[أإآ]/g, "ا").trim();
    }
    function matchesQuery(text, query) {
        const haystack = normalizeQuery(text);
        return normalizeQuery(query).split(/\s+/).every(word => haystack.includes(word));
    }
    function recordCompletion(history, session, now = Date.now()) {
        const records = (Array.isArray(history) ? history : []).filter(item => item &&
            typeof item.id === "string" && Number.isFinite(item.at) && [25, 50].includes(item.minutes) &&
            now - item.at < 31 * 86400000 && item.at <= now);
        if ([25, 50].includes(session.minutes) && session.id && !records.some(item => item.id === session.id)) {
            records.push({ id: session.id, at: now, minutes: session.minutes });
        }
        return records.slice(-500);
    }
    const api = { durations, normalizeSession, remainingSeconds, formatTime, localDay, matchesQuery, recordCompletion };
    if (typeof window !== "undefined") root.MyntProductivityCore = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);

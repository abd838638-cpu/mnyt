(function() {
    "use strict";

    var tasks = {};
    var editingId = null;
    var currentFilter = "all";
    var undoneTask = null;
    try { undoneTask = JSON.parse(localStorage.getItem("myntTodoUndo") || "null"); } catch (_) {}
    function todoText(key) {
        var ar = (localStorage.getItem("selectedLanguage") === "ar_SA");
        var labels = {
            all: ["All", "الكل"], pending: ["Pending", "المتبقية"], completed: ["Done", "المنجزة"],
            progress: ["completed", "مكتملة"], empty: ["A little space for your next big idea. Add your first task.", "مساحة لفكرتك القادمة. أضف أول مهمة."],
            emptyFilter: ["No tasks in this view.", "لا توجد مهام في هذا العرض."],
            removed: ["Task deleted", "تم حذف المهمة"], undo: ["Undo", "تراجع"],
            pin: ["Pin", "تثبيت"], unpin: ["Unpin", "إلغاء التثبيت"], edit: ["Edit", "تعديل"], delete: ["Delete", "حذف"]
        };
        return labels[key]?.[ar ? 1 : 0] || key;
    }

    function todayKey() {
        var date = new Date();
        return date.getFullYear() + "-" + String(date.getMonth() + 1).padStart(2, "0") + "-" + String(date.getDate()).padStart(2, "0");
    }

    function loadTasks() {
        try {
            tasks = JSON.parse(localStorage.getItem("todoList") || "{}") || {};
        } catch (e) {
            tasks = {};
        }
        if (!tasks || typeof tasks !== "object" || Array.isArray(tasks)) tasks = {};
        Object.keys(tasks).forEach(function(id) {
            if (!tasks[id] || typeof tasks[id] !== "object" || typeof tasks[id].title !== "string") delete tasks[id];
        });

        var lastDate = localStorage.getItem("todoLastUpdateDate");
        var currentDate = todayKey();
        if (lastDate && lastDate !== currentDate) {
            Object.keys(tasks).forEach(function(id) {
                if (tasks[id].pinned) {
                    tasks[id].status = "pending";
                } else if (tasks[id].status === "completed") {
                    delete tasks[id];
                }
            });
            saveTasks();
        }
        localStorage.setItem("todoLastUpdateDate", currentDate);
    }

    function saveTasks() {
        localStorage.setItem("todoList", JSON.stringify(tasks));
    }

    function makeButton(className, title, text) {
        var button = document.createElement("button");
        button.type = "button";
        button.className = className;
        button.title = title;
        button.setAttribute("aria-label", title);
        button.textContent = text;
        return button;
    }

    function taskIcon(name, filled) {
        var paths = {
            pin: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z"/>',
            edit: '<path d="m16 3 5 5-12 12-6 1 1-6ZM14 5l5 5"/>',
            delete: '<path d="m6 6 12 12M6 18 18 6"/>',
            save: '<path d="m5 12 4 4L19 6"/>'
        };
        return '<svg class="keep-color" viewBox="0 0 24 24" width="18" height="18" fill="' + (filled ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + paths[name] + '</svg>';
    }

    function render() {
        var list = document.getElementById("todoullist");
        if (!list) return;
        list.innerHTML = "";

        var summary = document.getElementById("todoSummary");
        if (!summary) {
            summary = document.createElement("div");
            summary.id = "todoSummary";
            summary.innerHTML = '<div class="ux-todo-summary"><p id="todoProgressText"></p><progress id="todoProgress" max="1" value="0"></progress></div><div id="todoFilters" class="ux-todo-filters" role="group"></div><div id="todoUndo" class="ux-todo-undo" role="status" hidden><span></span><button type="button"></button></div>';
            list.before(summary);
            ["all", "pending", "completed"].forEach(function(filter) {
                var button = makeButton("", todoText(filter), todoText(filter));
                button.dataset.filter = filter;
                button.addEventListener("click", function() { currentFilter = filter; render(); });
                document.getElementById("todoFilters").appendChild(button);
            });
            document.querySelector("#todoUndo button").addEventListener("click", function() {
                if (!undoneTask || !undoneTask.task || !undoneTask.id) return;
                tasks[undoneTask.id] = undoneTask.task;
                undoneTask = null;
                localStorage.removeItem("myntTodoUndo");
                saveTasks(); render();
            });
        }
        var ids = Object.keys(tasks);
        var completedCount = ids.filter(function(id) { return tasks[id].status === "completed"; }).length;
        var progressText = completedCount + " / " + ids.length + " " + todoText("progress");
        document.getElementById("todoProgressText").textContent = progressText;
        document.getElementById("todoProgress").max = ids.length || 1;
        document.getElementById("todoProgress").value = completedCount;
        document.getElementById("todoProgress").setAttribute("aria-label", progressText);
        document.querySelectorAll("#todoFilters button").forEach(function(button) {
            button.textContent = todoText(button.dataset.filter);
            button.setAttribute("aria-label", todoText(button.dataset.filter));
            button.setAttribute("aria-pressed", String(button.dataset.filter === currentFilter));
        });
        var undo = document.getElementById("todoUndo");
        undo.hidden = !undoneTask;
        undo.querySelector("span").textContent = todoText("removed");
        undo.querySelector("button").textContent = todoText("undo");

        Object.keys(tasks).sort(function(a, b) {
            var ap = tasks[a].pinned ? 1 : 0;
            var bp = tasks[b].pinned ? 1 : 0;
            if (ap !== bp) return bp - ap;
            return String(b).localeCompare(String(a));
        }).forEach(function(id) {
            var task = tasks[id];
            if (currentFilter !== "all" && task.status !== currentFilter) return;
            var li = document.createElement("li");
            li.className = "todolistitem" +
                (task.status === "completed" ? " checked" : "") +
                (task.pinned ? " pinned" : "") +
                (editingId === id ? " edit" : "");
            li.dataset.id = id;

            if (editingId === id) {
                var editFinished = false;
                var input = document.createElement("input");
                input.className = "edit-input";
                input.value = task.title || "";
                input.addEventListener("keydown", function(event) {
                    if (event.key === "Enter") { editFinished = true; finishEdit(id, input.value); }
                    if (event.key === "Escape") {
                        editFinished = true;
                        editingId = null;
                        render();
                    }
                });
                input.addEventListener("blur", function() {
                    if (!editFinished) finishEdit(id, input.value);
                });
                li.appendChild(input);
                setTimeout(function() {
                    input.focus();
                    input.select();
                }, 0);
            } else {
                var text = document.createElement("span");
                text.textContent = task.title || "";
                text.setAttribute("role", "checkbox");
                text.setAttribute("aria-checked", String(task.status === "completed"));
                text.tabIndex = 0;
                text.addEventListener("keydown", function(event) {
                    if (event.key === "Enter" || event.key === " ") { event.preventDefault(); toggleStatus(id); }
                });
                text.addEventListener("click", function() {
                    toggleStatus(id);
                });
                li.appendChild(text);
            }

            var pin = makeButton("todopinbtn", todoText(task.pinned ? "unpin" : "pin"), task.pinned ? "★" : "☆");
            pin.innerHTML = taskIcon("pin", task.pinned);
            pin.addEventListener("click", function(event) {
                event.stopPropagation();
                tasks[id].pinned = !tasks[id].pinned;
                saveTasks();
                render();
            });

            var edit = makeButton("todoeditbtn", todoText("edit"), "✎");
            edit.innerHTML = taskIcon(editingId === id ? "save" : "edit");
            edit.addEventListener("click", function(event) {
                event.stopPropagation();
                if (editingId === id) { finishEdit(id, input.value); return; }
                editingId = id;
                render();
            });

            var remove = makeButton("todoremovebtn", todoText("delete"), "×");
            remove.innerHTML = taskIcon("delete");
            remove.addEventListener("click", function(event) {
                event.stopPropagation();
                undoneTask = { id: id, task: tasks[id] };
                localStorage.setItem("myntTodoUndo", JSON.stringify(undoneTask));
                delete tasks[id];
                saveTasks();
                render();
                document.querySelector("#todoUndo button").focus();
            });

            li.appendChild(pin);
            li.appendChild(edit);
            li.appendChild(remove);
            list.appendChild(li);
        });
        if (!list.children.length) {
            var empty = document.createElement("li");
            empty.className = "ux-todo-empty";
            empty.textContent = todoText(ids.length ? "emptyFilter" : "empty");
            list.appendChild(empty);
        }
    }

    function finishEdit(id, value) {
        var title = String(value || "").trim();
        if (!tasks[id]) return;
        if (title) {
            tasks[id].title = title;
        } else {
            delete tasks[id];
        }
        editingId = null;
        saveTasks();
        render();
        var row = Array.from(document.querySelectorAll("#todoullist [data-id]")).find(function(item) { return item.dataset.id === id; });
        (row?.querySelector('[role="checkbox"]') || document.getElementById("todoInput"))?.focus();
    }

    function addTask() {
        var input = document.getElementById("todoInput");
        if (!input) return;
        var title = input.value.trim();
        if (!title) return;
        tasks[String(Date.now())] = {
            title: title,
            status: "pending",
            pinned: false
        };
        input.value = "";
        document.getElementById("todoAdd").disabled = true;
        saveTasks();
        render();
        input.focus();
    }

    function toggleStatus(id) {
        if (!tasks[id]) return;
        tasks[id].status = tasks[id].status === "completed" ? "pending" : "completed";
        saveTasks();
        render();
        var row = Array.from(document.querySelectorAll("#todoullist [data-id]")).find(function(item) { return item.dataset.id === id; });
        (row?.querySelector('[role="checkbox"]') || document.querySelector('#todoFilters button[aria-pressed="true"]'))?.focus();
    }

    function openPanel() {
        var container = document.getElementById("todoContainer");
        var icon = document.getElementById("todoListCont");
        if (!container) return;
        if (window.resetFloatingPanelPosition) {
            window.resetFloatingPanelPosition(container);
        }
        if (window.panelOpenAnim) {
            window.panelOpenAnim(container, "grid");
        } else {
            container.style.display = "grid";
        }
        if (icon) icon.classList.add("menu-open");
        setTimeout(function() {
            var input = document.getElementById("todoInput");
            if (input) input.focus();
        }, 100);
    }

    function closePanel() {
        var container = document.getElementById("todoContainer");
        var icon = document.getElementById("todoListCont");
        if (!container || container.style.display === "none") return;
        if (icon) icon.classList.remove("menu-open");
        if (window.closeWithAnim) {
            window.closeWithAnim(container, function() {
                container.style.display = "none";
            }, "down");
        } else {
            container.style.display = "none";
        }
    }

    function togglePanel(event) {
        if (event) event.stopPropagation();
        var container = document.getElementById("todoContainer");
        if (!container || container.style.display === "none" || !container.style.display) {
            openPanel();
        } else {
            closePanel();
        }
    }

    function syncVisibility() {
        var checkbox = document.getElementById("todoListCheckbox");
        var icon = document.getElementById("todoListCont");
        if (checkbox && icon) {
            icon.style.display = checkbox.checked ? "flex" : "none";
        }
        if (checkbox) {
            localStorage.setItem("todoListCheckboxState", checkbox.checked ? "checked" : "unchecked");
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        loadTasks();
        render();

        var icon = document.getElementById("todoListCont");
        var add = document.getElementById("todoAdd");
        var input = document.getElementById("todoInput");
        var checkbox = document.getElementById("todoListCheckbox");

        if (checkbox) {
            var saved = localStorage.getItem("todoListCheckboxState");
            if (saved === "checked") checkbox.checked = true;
            else if (saved === "unchecked") checkbox.checked = false;
        }

        if (icon) icon.addEventListener("click", togglePanel);
        if (add) add.addEventListener("click", addTask);
        if (input) {
            input.maxLength = 280;
            if (add) add.disabled = !input.value.trim();
            input.addEventListener("input", function() { if (add) add.disabled = !input.value.trim(); });
            input.addEventListener("keydown", function(event) {
                if (event.key === "Enter") addTask();
            });
        }
        if (checkbox) {
            checkbox.addEventListener("change", syncVisibility);
            syncVisibility();
        }
        document.addEventListener("click", function(event) {
            var container = document.getElementById("todoContainer");
            var launcher = document.getElementById("todoListCont");
            if (!container || !launcher) return;
            if (!container.contains(event.target) && !launcher.contains(event.target)) {
                closePanel();
            }
        });
    });
})();

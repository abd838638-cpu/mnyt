(function () {
    var luckyBtn = document.getElementById("luckyBtn");
    if (!luckyBtn) return;

    var luckyBtnIcon = luckyBtn.querySelector("svg");
    var luckyBtnSpan = document.getElementById("luckyBtnText");
    var wallpaperToggle = document.getElementById("luckyWallpaperToggle");

    var savedToggle = localStorage.getItem("luckyWallpaperToggle");
    if (savedToggle !== null) {
        wallpaperToggle.checked = savedToggle === "true";
    } else {
        wallpaperToggle.checked = true;
    }

    wallpaperToggle.addEventListener("change", function () {
        localStorage.setItem("luckyWallpaperToggle", wallpaperToggle.checked);
    });

    var isApplying = false;

    luckyBtn.addEventListener("click", function () {
        if (isApplying) return;
        isApplying = true;
        luckyBtn.classList.add("lucky-btn-applying");
        if (luckyBtnSpan) luckyBtnSpan.textContent = getText("luckyApplying");

        var plates = document.querySelectorAll(".colorPlate[name='color']");
        var values = [];
        plates.forEach(function (p) { if (p.value) values.push(p.value); });

        if (values.length === 0) {
            finish();
            return;
        }

        var randomValue = values[Math.floor(Math.random() * values.length)];

        if (typeof applyPredefinedThemeNow === "function") {
            applyPredefinedThemeNow(randomValue);
        }

        if (wallpaperToggle.checked && typeof setBodyBgImage === "function") {
            setRandomWallpaper(finish);
        } else {
            finish();
        }

        function finish() {
            isApplying = false;
            luckyBtn.classList.remove("lucky-btn-applying");
            if (luckyBtnSpan) luckyBtnSpan.textContent = getText("luckyBtnText");
        }
    });

    function setRandomWallpaper(cb) {
        var imgId = Math.floor(Math.random() * 500) + 10;
        var url = "https://picsum.photos/id/" + imgId + "/1920/1080";

        fetch(url)
            .then(function (r) {
                if (!r.ok) throw new Error();
                return r.blob();
            })
            .then(function (blob) {
                var reader = new FileReader();
                reader.onload = function () {
                    var dataUrl = reader.result;
                    setBodyBgImage(dataUrl);

                    if (typeof saveImageToIndexedDB === "function") {
                        saveImageToIndexedDB(blob, new Date().toISOString(), "upload");
                    }
                    localStorage.setItem("hasSingleWallpaper", "true");
                    if (typeof clearFolderWallpapers === "function") {
                        clearFolderWallpapers();
                    }
                    if (cb) cb();
                };
                reader.readAsDataURL(blob);
            })
            .catch(function () { if (cb) cb(); });
    }

    function getText(key) {
        var lang = localStorage.getItem("selectedLanguage") || "en";
        if (typeof translations !== "undefined") {
            return translations[lang]?.[key] || translations["en"]?.[key] || key;
        }
        return key;
    }

    function applyTexts() {
        var titleEl = document.getElementById("luckyTitle");
        var descEl = document.getElementById("luckyDesc");
        var toggleEl = document.getElementById("luckyWallpaperText");

        if (titleEl) titleEl.textContent = getText("luckyTitle");
        if (descEl) descEl.textContent = getText("luckyDesc");
        if (!isApplying && luckyBtnSpan) luckyBtnSpan.textContent = getText("luckyBtnText");
        if (toggleEl) toggleEl.textContent = getText("luckyWallpaperText");
    }

    applyTexts();
    window.addEventListener("material-you-language-change", applyTexts);
})();

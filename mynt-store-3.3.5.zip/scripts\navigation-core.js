/* Shared navigation helpers. No network or browser API side effects. */
(function () {
    "use strict";
    function normalizeUrl(value) {
        const text = String(value || "").trim();
        if (!text) return "";
        try {
            const url = new URL(/^[a-z][a-z\d+.-]*:/i.test(text) ? text : `https://${text}`);
            return ["http:", "https:"].includes(url.protocol) && url.hostname ? url.href : "";
        } catch { return ""; }
    }
    function faviconCandidates(value, runtimeId, size = 64) {
        const url = normalizeUrl(value);
        if (!url) return [];
        const candidates = [];
        if (runtimeId) candidates.push(`chrome-extension://${runtimeId}/_favicon/?pageUrl=${encodeURIComponent(url)}&size=${size}`);
        candidates.push(`https://www.google.com/s2/favicons?domain=${encodeURIComponent(new URL(url).hostname)}&sz=${size}`);
        return candidates;
    }
    function fallbackIcon(value, label) {
        const url = normalizeUrl(value);
        const name = String(label || (url ? new URL(url).hostname.replace(/^www\./, "") : ""));
        const letter = Array.from(name.trim())[0]?.toLocaleUpperCase() || "↗";
        const safe = letter.replace(/[<>&"']/g, "");
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><rect width="64" height="64" rx="18" fill="#315e8b"/><text x="32" y="43" text-anchor="middle" font-family="Arial,sans-serif" font-size="34" font-weight="600" fill="white">${safe || "↗"}</text></svg>`;
        return `data:image/svg+xml,${encodeURIComponent(svg)}`;
    }
    function normalizedText(text) {
        return String(text || "").normalize("NFKD").replace(/[\u064B-\u065F\u0670]/g, "").replace(/[أإآٱ]/g, "ا").toLocaleLowerCase();
    }
    function searchBookmarks(nodes, query) {
        const terms = normalizedText(query).trim().split(/\s+/).filter(Boolean);
        const visible = new Set(), open = new Set(), matches = new Set(), links = new Set();
        function visit(node, inheritedMatch = false) {
            if (!node || !node.id) return false;
            const id = String(node.id);
            if (node.url) links.add(id);
            const text = normalizedText(`${node.title || ""} ${node.url || ""}`);
            const ownMatch = terms.length > 0 && terms.every(term => text.includes(term));
            if (ownMatch) matches.add(id);
            let childMatch = false;
            for (const child of node.children || []) childMatch = visit(child, inheritedMatch || ownMatch) || childMatch;
            const show = !terms.length || inheritedMatch || ownMatch || childMatch;
            if (show) visible.add(id);
            if (terms.length && node.children && show && (ownMatch || childMatch || inheritedMatch)) open.add(id);
            return show;
        }
        (nodes || []).forEach(node => visit(node));
        return { visible, open, matches, linkCount: links.size };
    }
    const api = { normalizeUrl, faviconCandidates, fallbackIcon, searchBookmarks };
    if (typeof window !== "undefined") window.MyntNavigationCore = api;
    if (typeof module !== "undefined" && module.exports) module.exports = api;
})();

// ── Global Drag Ghost: Dashed Rectangle on ALL websites ──
document.addEventListener("dragstart", (e) => {
    const target = e.target;
    if (!target || !target.getBoundingClientRect) return;

    const r = target.getBoundingClientRect();
    const w = Math.max(r.width, 60);
    const h = Math.max(r.height, 30);

    // Use the actual grab point (where the user clicked inside the element)
    // so the ghost stays aligned with the grid column/row instead of floating randomly
    const offsetX = Math.min(Math.max(e.clientX - r.left, 0), w);
    const offsetY = Math.min(Math.max(e.clientY - r.top, 0), h);

    const ghost = document.createElement("div");
    ghost.style.cssText = `
        position: fixed;
        top: -9999px;
        left: -9999px;
        width: ${w}px;
        height: ${h}px;
        border: 2px dashed var(--darkColor-blue, #888);
        border-radius: 10px;
        background: color-mix(in srgb, var(--darkColor-blue, #888) 8%, transparent);
        box-sizing: border-box;
        pointer-events: none;
        font-size: 0;
        line-height: 0;
        color: transparent;
        z-index: 999999;
    `;
    document.body.appendChild(ghost);

    try {
        e.dataTransfer.setDragImage(ghost, offsetX, offsetY);
    } catch (_) {}

    setTimeout(() => ghost.remove(), 500);
}, true);

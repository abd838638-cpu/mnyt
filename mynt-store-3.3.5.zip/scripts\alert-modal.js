(function() {
    "use strict";

    var activeResolver = null;
    var closingTimer = null;

    function getText(key, fallback) {
        try {
            var lang = window.currentLanguage || "en";
            return (window.translations && window.translations[lang] && window.translations[lang][key]) ||
                (window.translations && window.translations.en && window.translations.en[key]) ||
                fallback;
        } catch (e) {
            return fallback;
        }
    }

    function removeExisting(result) {
        clearTimeout(closingTimer);
        var blur = document.getElementById("prompt-modal-blur");
        var container = document.getElementById("prompt-modal-container");
        if (blur) blur.remove();
        if (container) container.remove();
        document.body.style.overflow = "";
        if (activeResolver) {
            var resolver = activeResolver;
            activeResolver = null;
            resolver(result);
        }
    }

    function closeModal(result) {
        var blur = document.getElementById("prompt-modal-blur");
        var container = document.getElementById("prompt-modal-container");
        if (!container) {
            removeExisting(result);
            return;
        }
        if (blur) {
            blur.classList.remove("prompt-modal-visible");
            blur.classList.add("prompt-modal-closing");
        }
        container.classList.remove("prompt-modal-visible");
        container.classList.add("prompt-modal-closing");
        closingTimer = setTimeout(function() {
            removeExisting(result);
        }, 180);
    }

    function createButton(text, className, onClick) {
        var button = document.createElement("button");
        button.type = "button";
        button.className = "prompt-modal-button " + className;
        button.textContent = text;
        button.addEventListener("click", onClick);
        return button;
    }

    function openModal(config) {
        removeExisting(undefined);

        return new Promise(function(resolve) {
            activeResolver = resolve;
            document.body.style.overflow = "hidden";

            var blur = document.createElement("div");
            blur.id = "prompt-modal-blur";
            blur.className = "prompt-modal-visible";

            var container = document.createElement("div");
            container.id = "prompt-modal-container";
            container.className = "prompt-modal-visible";

            var box = document.createElement("div");
            box.id = "prompt-modal-box";

            var message = document.createElement("p");
            message.id = "prompt-modal-message";
            message.style.whiteSpace = "pre-wrap";
            message.appendChild(document.createTextNode(config.message || ""));

            var input = null;
            if (config.type === "prompt") {
                input = document.createElement("input");
                input.type = "text";
                input.value = config.defaultValue || "";
                input.className = "prompt-modal-input-field";
                input.autocomplete = "off";
                message.appendChild(input);
            }

            var buttons = document.createElement("div");
            buttons.id = "prompt-modal-buttons";

            buttons.appendChild(createButton(config.okText || getText("okText", "OK"), "prompt-modal-ok", function() {
                closeModal(config.type === "prompt" ? ((input.value || "").trim() || null) : true);
            }));

            if (config.type === "confirm" || config.type === "prompt") {
                buttons.appendChild(createButton(config.cancelText || getText("cancelText", "Cancel"), "prompt-modal-cancel", function() {
                    closeModal(config.type === "confirm" ? false : null);
                }));
            }

            (config.extraButtons || []).forEach(function(extra) {
                var button = createButton(extra.text || "", "prompt-modal-extra", function() {
                    closeModal(extra.value);
                });
                if (extra.style) button.setAttribute("style", extra.style);
                buttons.appendChild(button);
            });

            box.appendChild(message);
            box.appendChild(buttons);
            container.appendChild(box);
            document.body.appendChild(blur);
            document.body.appendChild(container);

            function handleKeyDown(event) {
                if (!document.getElementById("prompt-modal-container")) {
                    document.removeEventListener("keydown", handleKeyDown);
                    return;
                }
                if (event.key === "Escape") {
                    event.preventDefault();
                    closeModal(config.type === "alert" ? undefined : null);
                } else if (event.key === "Enter") {
                    if (config.type === "prompt") {
                        event.preventDefault();
                        closeModal(((input.value || "").trim() || null));
                    } else {
                        event.preventDefault();
                        closeModal(true);
                    }
                }
            }

            document.addEventListener("keydown", handleKeyDown);
            var firstFocus = input || box.querySelector(".prompt-modal-ok");
            setTimeout(function() {
                if (firstFocus) {
                    firstFocus.focus();
                    if (input) input.select();
                }
            }, 20);
        });
    }

    window.alertPrompt = function(message, okText) {
        return openModal({
            type: "alert",
            message: message,
            okText: okText || getText("okText", "OK")
        });
    };

    window.confirmPrompt = function(message, okText, cancelText) {
        return openModal({
            type: "confirm",
            message: message,
            okText: okText || getText("yesText", "Yes"),
            cancelText: cancelText || getText("noText", "No")
        });
    };

    window.inputPrompt = function(label, defaultValue, extraButtons) {
        return openModal({
            type: "prompt",
            message: label,
            defaultValue: defaultValue || "",
            extraButtons: extraButtons || [],
            okText: getText("okText", "OK"),
            cancelText: getText("cancelText", "Cancel")
        });
    };
})();
